import"./entry.6b1d3618.js";const i=""+globalThis.__publicAssetsURL("images/arrow-right.svg");export{i as _};
