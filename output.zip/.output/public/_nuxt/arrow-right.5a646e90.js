import"./entry.96c405ac.js";const i=""+globalThis.__publicAssetsURL("images/arrow-right.svg");export{i as _};
