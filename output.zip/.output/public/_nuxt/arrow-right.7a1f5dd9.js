import"./entry.845ae2ca.js";const i=""+globalThis.__publicAssetsURL("images/arrow-right.svg");export{i as _};
