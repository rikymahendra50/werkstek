import"./entry.22855478.js";const i=""+globalThis.__publicAssetsURL("images/arrow-right.svg");export{i as _};
