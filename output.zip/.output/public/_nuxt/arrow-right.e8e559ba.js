import"./entry.586c9ac6.js";const i=""+globalThis.__publicAssetsURL("images/arrow-right.svg");export{i as _};
