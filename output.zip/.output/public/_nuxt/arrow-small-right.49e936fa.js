import"./entry.dd224e89.js";const i=""+globalThis.__publicAssetsURL("images/arrow-small-right.svg");export{i as _};
