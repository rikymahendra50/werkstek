import"./entry.22855478.js";const i=""+globalThis.__publicAssetsURL("images/arrow-small-right.svg");export{i as _};
