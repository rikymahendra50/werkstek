import"./entry.96c405ac.js";const i=""+globalThis.__publicAssetsURL("images/arrow-small-right.svg");export{i as _};
