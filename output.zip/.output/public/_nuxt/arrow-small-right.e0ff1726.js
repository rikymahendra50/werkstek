import"./entry.20ad2272.js";const i=""+globalThis.__publicAssetsURL("images/arrow-small-right.svg");export{i as _};
