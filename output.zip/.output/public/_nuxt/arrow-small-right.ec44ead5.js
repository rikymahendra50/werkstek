import"./entry.9d77ff68.js";const i=""+globalThis.__publicAssetsURL("images/arrow-small-right.svg");export{i as _};
