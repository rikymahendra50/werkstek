const e=()=>({legacy:!1,locale:"en",messages:{en:{welcome:"Welcome"},id:{welcome:"Selamat Datang"}}});export{e as default};
