import { _ as __nuxt_component_0$1 } from '../server.mjs';
import __nuxt_component_2 from './Icon-e394d28f.mjs';
import { useSSRContext, mergeProps, withCtx, createVNode, toDisplayString } from 'vue';
import { ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = {
  __name: "BackButton",
  __ssrInlineRender: true,
  props: {
    link: {
      type: String
    },
    linkTitle: {
      type: String
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_Icon = __nuxt_component_2;
      _push(ssrRenderComponent(_component_NuxtLink, mergeProps({
        to: `/admin/${__props.link}`,
        class: "cursor-pointer flex gap-2 mb-7 transition duration-150 ease-out hover:ease-in items-center"
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Icon, {
              name: "i-heroicons-arrow-left",
              class: "h-6 w-6 stroke-0 fill-none opacity-90"
            }, null, _parent2, _scopeId));
            _push2(`<span class="text-2xl font-bold"${_scopeId}>${ssrInterpolate(__props.linkTitle)}</span>`);
          } else {
            return [
              createVNode(_component_Icon, {
                name: "i-heroicons-arrow-left",
                class: "h-6 w-6 stroke-0 fill-none opacity-90"
              }),
              createVNode("span", { class: "text-2xl font-bold" }, toDisplayString(__props.linkTitle), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CompAdmin/BackButton.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main;

export { __nuxt_component_0 as _ };
//# sourceMappingURL=BackButton-de34e53a.mjs.map
