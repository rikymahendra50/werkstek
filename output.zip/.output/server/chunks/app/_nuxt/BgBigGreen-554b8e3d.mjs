import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { Form, Field, ErrorMessage } from 'vee-validate';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { mergeProps, withCtx, createVNode, toDisplayString, useSSRContext, createTextVNode, ref, unref, openBlock, createBlock } from 'vue';
import { i as _export_sfc, _ as __nuxt_component_0$1, b as useFetch } from '../server.mjs';
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderAttrs, ssrRenderClass, ssrIncludeBooleanAttr } from 'vue/server-renderer';
import { _ as _imports_0$1 } from './arrow-small-right-9e640e2c.mjs';

const _sfc_main$3 = {
  __name: "BgBigEmailInput",
  __ssrInlineRender: true,
  setup(__props) {
    const { loading, transformErrors } = useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const snackbar = useSnackbar();
    const dataForm = ref({
      email: void 0
    });
    async function onSubmit(values, ctx) {
      var _a2;
      var _a, _b, _c;
      loading.value = true;
      const { data, error } = await useFetch("/newsletter-subscribers", {
        method: "POST",
        body: { ...dataForm.value },
        ...requestOptions
      }, "$iafGjBZUtv");
      if (error.value) {
        ctx.setErrors(transformErrors((_a = error.value) == null ? void 0 : _a.data));
        snackbar.add({
          type: "error",
          text: (_a2 = (_c = (_b = error.value) == null ? void 0 : _b.data) == null ? void 0 : _c.message) != null ? _a2 : "Something went wrong"
        });
      } else {
        snackbar.add({
          type: "success",
          text: "Thanks for input your email."
        });
        ctx.resetForm();
      }
      loading.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_VeeField = Field;
      const _component_VeeErrorMessage = ErrorMessage;
      _push(ssrRenderComponent(_component_VeeForm, mergeProps({ onSubmit }, _attrs), {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="rounded-full flex items-center md:p-2 px-1 lg:px-2 bg-quaternary md:max-h-[60px]"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              type: "text",
              name: "email",
              modelValue: unref(dataForm).email,
              "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
              class: "pl-2 text-sm h-full w-full outline-none box-border text-tertiary bg-quaternary",
              placeholder: "Mail@gmail.com",
              autocomplete: "off",
              style: { WebkitAppearance: "none", color: "white" }
            }, null, _parent2, _scopeId));
            _push2(`<button class="rounded-full bg-tertiary text-tertiary hover:bg-opacity-40 transition ml-2 my-2 mr-1" type="submit"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""}${_scopeId}><svg width="40" height="40" viewBox="0 0 24 25" fill="none" xmlns="http://www.w3.org/2000/svg"${_scopeId}><path d="M10.8125 18.6799L16.9997 12.4927L10.8125 6.30554" stroke="#859C81" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"${_scopeId}></path></svg></button></div>`);
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "email",
              class: "md:ml-2 text-sm text-red-700"
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode("div", { class: "rounded-full flex items-center md:p-2 px-1 lg:px-2 bg-quaternary md:max-h-[60px]" }, [
                createVNode(_component_VeeField, {
                  type: "text",
                  name: "email",
                  modelValue: unref(dataForm).email,
                  "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                  class: "pl-2 text-sm h-full w-full outline-none box-border text-tertiary bg-quaternary",
                  placeholder: "Mail@gmail.com",
                  autocomplete: "off",
                  style: { WebkitAppearance: "none", color: "white" }
                }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                createVNode("button", {
                  class: "rounded-full bg-tertiary text-tertiary hover:bg-opacity-40 transition ml-2 my-2 mr-1",
                  type: "submit",
                  disabled: unref(loading)
                }, [
                  (openBlock(), createBlock("svg", {
                    width: "40",
                    height: "40",
                    viewBox: "0 0 24 25",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                  }, [
                    createVNode("path", {
                      d: "M10.8125 18.6799L16.9997 12.4927L10.8125 6.30554",
                      stroke: "#859C81",
                      "stroke-width": "1.875",
                      "stroke-linecap": "round",
                      "stroke-linejoin": "round"
                    })
                  ]))
                ], 8, ["disabled"])
              ]),
              createVNode(_component_VeeErrorMessage, {
                name: "email",
                class: "md:ml-2 text-sm text-red-700"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/BgBigEmailInput.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main$3;
const _sfc_main$2 = {
  props: {
    buttonTitle: {
      type: String,
      default: "Uitgebreid zoeken"
    },
    buttonLink: {
      type: String
    }
  }
};
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_NuxtLink = __nuxt_component_0$1;
  _push(ssrRenderComponent(_component_NuxtLink, mergeProps({
    to: $props.buttonLink,
    class: "border border-quaternary hover:bg-opacity-60 transition rounded-full flex items-center gap-2 p-1 lg:px-2 w-fit"
  }, _attrs), {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<p class="pl-[2px] py-[1px] sm:p-3 text-[12px] lg:text-sm" data-v-d0fe72ca${_scopeId}>${ssrInterpolate($props.buttonTitle)}</p><div class="rounded-full bg-quaternary text-white flex items-center justify-center aspect-square" data-v-d0fe72ca${_scopeId}><img${ssrRenderAttr("src", _imports_0$1)} alt="arrow" class="sm:m-1" data-v-d0fe72ca${_scopeId}></div>`);
      } else {
        return [
          createVNode("p", { class: "pl-[2px] py-[1px] sm:p-3 text-[12px] lg:text-sm" }, toDisplayString($props.buttonTitle), 1),
          createVNode("div", { class: "rounded-full bg-quaternary text-white flex items-center justify-center aspect-square" }, [
            createVNode("img", {
              src: _imports_0$1,
              alt: "arrow",
              class: "sm:m-1"
            })
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ButtonSM.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender$2], ["__scopeId", "data-v-d0fe72ca"]]);
const _sfc_main$1 = {
  props: {
    buttonTitle: {
      type: String
    },
    buttonLink: {
      type: String
    }
  }
};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_NuxtLink = __nuxt_component_0$1;
  _push(ssrRenderComponent(_component_NuxtLink, mergeProps({
    to: $props.buttonLink,
    class: "rounded-full flex items-center gap-2 p-1 px-1 lg:px-4 bg-[#576855] hover:bg-primary transition"
  }, _attrs), {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<span class="p-1 sm:p-3 text-[12px] sm:text-sm lg:text-base"${_scopeId}>${ssrInterpolate($props.buttonTitle)}</span>`);
      } else {
        return [
          createVNode("span", { class: "p-1 sm:p-3 text-[12px] sm:text-sm lg:text-base" }, toDisplayString($props.buttonTitle), 1)
        ];
      }
    }),
    _: 1
  }, _parent));
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ButtonSmaller.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender$1]]);
const _imports_0 = "" + publicAssetsURL("images/white-phone.svg");
const _imports_1 = "" + publicAssetsURL("images/white-mail.svg");
const _sfc_main = {
  data() {
    return {
      EmailForm: {
        title: "Vul je Email in",
        buttonEmailTitle: "Schrijf je in",
        buttonEmailLink: "/"
      }
    };
  },
  props: {
    backgroundColor: {
      type: String,
      required: true,
      default: "primary"
    },
    title1: {
      type: String,
      required: true
    },
    title2: {
      type: String,
      required: true
    },
    title3: {
      type: String,
      required: true
    },
    phoneNumber: {
      type: String,
      required: false,
      default: "085-0290598"
    },
    mail: {
      type: String,
      required: false,
      default: "info@werkstek.nl"
    },
    showEmailSection: {
      type: Boolean,
      default: false
    },
    showButtonSection: {
      type: Boolean,
      default: false
    },
    showSmallerButton: {
      type: Boolean
    },
    linkTitle: {
      type: String,
      default: "Contact opnemen"
    },
    linkButton: {
      type: String,
      required: false,
      default: "/contact"
    },
    linkTitleSmaller: {
      type: String,
      required: false
    },
    linkButtonSmaller: {
      type: String,
      required: false
    },
    showPhoneEmail: {
      type: Boolean,
      required: false,
      default: true
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_BgBigEmailInput = __nuxt_component_0;
  const _component_ButtonSM = __nuxt_component_1;
  const _component_ButtonSmaller = __nuxt_component_2;
  const _component_NuxtLink = __nuxt_component_0$1;
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "py-16 flex gap-2 container-custom ml-[-20px]" }, _attrs))}><span class="bg-quaternary rounded-full min-w-[26px] md:min-w-[46px]"></span><div class="${ssrRenderClass(`w-[95%] lg:w-[80%] bg-${$props.backgroundColor} rounded-2xl box-shadow min-h-[318px] lg:min-h-[418px] flex flex-col justify-center`)}"><div class="mx-3 sm:mx-5 lg:mx-10 flex flex-col text-white justify-between gap-1 lg:gap-2"><div class="w-[90%] lg:w-[60%] grid md:gap-2"><p class="text-[10px] sm:text-[12px] md:text-[14px] xl:text-base font-bold text-[#404040] tracking-widest min-[320px]:pt-2 min-[420px]:pt-0">${ssrInterpolate($props.title1)}</p><p class="text-lg md:text-2xl xl:text-3xl leading-normal md:leading-normal tracking-wider lg:w-[60%] pt-2 font-bold">${ssrInterpolate($props.title2)}</p><p class="text-[12px] md:text-sm font-normal lg:w-[80%] pt-2">${ssrInterpolate($props.title3)}</p></div>`);
  if ($props.showEmailSection) {
    _push(`<div class="flex mt-3 w-[90%] lg:w-[50%]">`);
    _push(ssrRenderComponent(_component_BgBigEmailInput, null, null, _parent));
    _push(`</div>`);
  } else {
    _push(`<!---->`);
  }
  if ($props.showButtonSection) {
    _push(`<div class="flex flex-col min-[400px]:flex-row mt-3 w-[90%] lg:w-[50%] items-center gap-5 my-2">`);
    _push(ssrRenderComponent(_component_ButtonSM, {
      buttonTitle: $props.linkTitle,
      buttonLink: $props.linkButton,
      class: "bg-tertiary bg-opacity-70 text-black"
    }, null, _parent));
    if ($props.showSmallerButton) {
      _push(`<div>`);
      _push(ssrRenderComponent(_component_ButtonSmaller, {
        buttonTitle: $props.linkTitleSmaller,
        buttonLink: $props.linkButtonSmaller
      }, null, _parent));
      _push(`</div>`);
    } else {
      _push(`<!---->`);
    }
    _push(`</div>`);
  } else {
    _push(`<!---->`);
  }
  if ($props.showPhoneEmail) {
    _push(`<div class="flex items-center mt-5"><div class="flex phone items-center"><img${ssrRenderAttr("src", _imports_0)} alt="white-phone">`);
    _push(ssrRenderComponent(_component_NuxtLink, {
      to: `tel:${$props.phoneNumber}`,
      class: "ml-1 lg:ml-3 text-[10px] sm:text-[12px] sm:text-sm lg:text-[14px]"
    }, {
      default: withCtx((_, _push2, _parent2, _scopeId) => {
        if (_push2) {
          _push2(`${ssrInterpolate($props.phoneNumber)}`);
        } else {
          return [
            createTextVNode(toDisplayString($props.phoneNumber), 1)
          ];
        }
      }),
      _: 1
    }, _parent));
    _push(`</div><div class="flex pl-2 lg:pl-10 items-center"><img${ssrRenderAttr("src", _imports_1)} alt="white-phone">`);
    _push(ssrRenderComponent(_component_NuxtLink, {
      to: `mailto:${$props.mail}`,
      class: "ml-1 lg:ml-3 text-[10px] sm:text-[12px] sm:text-sm lg:text-[14px]"
    }, {
      default: withCtx((_, _push2, _parent2, _scopeId) => {
        if (_push2) {
          _push2(`${ssrInterpolate($props.mail)}`);
        } else {
          return [
            createTextVNode(toDisplayString($props.mail), 1)
          ];
        }
      }),
      _: 1
    }, _parent));
    _push(`</div></div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div></div></section>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/BgBigGreen.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_4 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { __nuxt_component_4 as _, __nuxt_component_1 as a };
//# sourceMappingURL=BgBigGreen-554b8e3d.mjs.map
