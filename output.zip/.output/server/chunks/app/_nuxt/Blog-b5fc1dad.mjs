import { _ as __nuxt_component_0 } from './TitleHeader-8492944b.mjs';
import { _ as __nuxt_component_1, a as __nuxt_component_2 } from './EachBlogSmall-83646359.mjs';
import { u as useRequestOptions } from '../server.mjs';
import { useSSRContext, withAsyncContext, mergeProps, unref } from 'vue';
import { u as useFetch } from './fetch-101122a4.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList } from 'vue/server-renderer';

const _sfc_main = {
  __name: "Blog",
  __ssrInlineRender: true,
  props: {
    dontShowTitle: Boolean,
    showTitleHeader: Boolean
  },
  async setup(__props) {
    let __temp, __restore;
    const { requestOptions } = useRequestOptions();
    [__temp, __restore] = withAsyncContext(() => useFetch(`/articles`, {
      method: "get",
      ...requestOptions
    }, "$uhP5DjfvfR")), __temp = await __temp, __restore();
    const { data: top } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/top-article`, {
      method: "get",
      ...requestOptions
    }, "$emgMFJL8aS")), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d;
      const _component_TitleHeader = __nuxt_component_0;
      const _component_EachBlogBig = __nuxt_component_1;
      const _component_EachBlogSmall = __nuxt_component_2;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "lg:container-custom" }, _attrs))}>`);
      if (__props.dontShowTitle) {
        _push(`<div>`);
        if (!__props.showTitleHeader) {
          _push(`<div><div class="pl-3 pb-5 md:pb-10 sm:w-[70%]"><h1 class="text-[20px] sm:text-[26px] md:text-[32px] font-bold"> Lees onze laatste blog\u2019s </h1></div></div>`);
        } else if (__props.showTitleHeader) {
          _push(ssrRenderComponent(_component_TitleHeader, {
            title: `Updates & blogs`,
            secondTitle: `Lees de Werkstek blog`,
            description: `Op de hoogte blijven van de nieuwste kantoortrends? Op zoek naar tips en tricks voor ondernemers? Lees dan ook onze inspirerende blogs!`
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="flex w-full gap-2"><div class="flex flex-col min-[320px]:flex-row w-full lg:w-[60%] justify-center"><!--[-->`);
      ssrRenderList((_b = (_a = unref(top)) == null ? void 0 : _a.data) == null ? void 0 : _b.slice(0, 2), (article) => {
        _push(ssrRenderComponent(_component_EachBlogBig, {
          key: article == null ? void 0 : article.id,
          imageSrc: article == null ? void 0 : article.image,
          title: article == null ? void 0 : article.title,
          description: article == null ? void 0 : article.meta,
          link: `/blog/${article == null ? void 0 : article.slug}`
        }, null, _parent));
      });
      _push(`<!--]--></div><div class="flex-col justify-between lg:flex hidden lg:w-[40%]"><!--[-->`);
      ssrRenderList((_d = (_c = unref(top)) == null ? void 0 : _c.data) == null ? void 0 : _d.slice(2, 5), (article) => {
        _push(ssrRenderComponent(_component_EachBlogSmall, {
          key: article == null ? void 0 : article.id,
          imageSrc: article == null ? void 0 : article.image,
          title: article == null ? void 0 : article.title,
          description: article == null ? void 0 : article.meta,
          link: `/blog/${article.slug}`
        }, null, _parent));
      });
      _push(`<!--]--></div></div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Blog.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_7 = _sfc_main;

export { __nuxt_component_7 as _ };
//# sourceMappingURL=Blog-b5fc1dad.mjs.map
