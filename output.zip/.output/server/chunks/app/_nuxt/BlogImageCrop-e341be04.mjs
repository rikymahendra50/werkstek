import { _ as __nuxt_component_0 } from './client-only-29ef7f45.mjs';
import { useSSRContext, ref, computed, watch } from 'vue';
import { ssrRenderComponent } from 'vue/server-renderer';
import { u as useFileDialog } from './index-c7d55092.mjs';

const _sfc_main = {
  __name: "BlogImageCrop",
  __ssrInlineRender: true,
  props: {
    loading: {
      type: Boolean,
      default: false
    },
    existingimage: {
      type: String,
      default: null
    },
    modelValue: {
      type: File,
      default: null
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { expose: __expose, emit }) {
    const props = __props;
    const modalInput = ref(false);
    const image = ref(null);
    computed(() => {
      return image.value ? URL.createObjectURL(image.value) : null;
    });
    ref();
    const imageReview = ref();
    computed(() => {
      var _a;
      return imageReview.value ? URL.createObjectURL(imageReview.value) : (_a = props.existingimage) != null ? _a : null;
    });
    const { files, open, reset, onChange } = useFileDialog({
      accept: "image/*",
      // Set to accept only image files
      multiple: false
    });
    onChange((files2) => {
      if (!files2) {
        return;
      }
      image.value = files2[0];
      reset();
      modalInput.value = true;
    });
    watch(
      () => modalInput.value,
      (value) => {
        if (!value) {
          image.value = null;
        }
      }
    );
    __expose({
      modalInput
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ClientOnly = __nuxt_component_0;
      _push(ssrRenderComponent(_component_ClientOnly, _attrs, {}, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/BlogImageCrop.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main;

export { __nuxt_component_2 as _ };
//# sourceMappingURL=BlogImageCrop-e341be04.mjs.map
