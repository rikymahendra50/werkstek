import { useSSRContext, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = {
  __name: "ButtonAddForm",
  __ssrInlineRender: true,
  props: {
    buttonName: {
      type: String
    },
    isLoading: {}
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<button${ssrRenderAttrs(mergeProps({
        class: "btn bg-primary text-white btn-sm h-11",
        type: "submit",
        disabled: __props.isLoading
      }, _attrs))}><span class="text-[14px] text-center text-white normal-case">${ssrInterpolate(__props.buttonName)}</span></button>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CompAdmin/ButtonAddForm.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_3 = _sfc_main;

export { __nuxt_component_3 as _ };
//# sourceMappingURL=ButtonAddForm-aa118db7.mjs.map
