import { _ as __nuxt_component_0$1 } from '../server.mjs';
import { useSSRContext, withCtx, createTextVNode, toDisplayString } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = {
  __name: "ButtonAddIndex",
  __ssrInlineRender: true,
  props: {
    name: {
      type: String
    },
    link: {
      type: String
    },
    isLoading: {}
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `/admin/${__props.link}/add`,
        class: "btn btn-sm bg-primary h-11 normal-case text-white hover:text-slate-400 text-[12px]"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` Add New ${ssrInterpolate(__props.name)}`);
          } else {
            return [
              createTextVNode(" Add New " + toDisplayString(__props.name), 1)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/CompAdmin/ButtonAddIndex.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main;

export { __nuxt_component_0 as _ };
//# sourceMappingURL=ButtonAddIndex-0be538de.mjs.map
