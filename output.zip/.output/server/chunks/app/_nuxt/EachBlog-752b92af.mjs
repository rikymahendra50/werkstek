import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import __nuxt_component_2 from './Icon-e394d28f.mjs';
import { u as useRequestOptions, _ as __nuxt_component_0$1 } from '../server.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { useSSRContext, ref, withCtx, createVNode, unref } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderStyle, ssrRenderAttr, ssrRenderComponent, ssrRenderList, ssrRenderClass } from 'vue/server-renderer';

const _imports_0 = "" + publicAssetsURL("images/share.svg");
const _imports_1 = "" + publicAssetsURL("images/behance.svg");
const _imports_2 = "" + publicAssetsURL("images/myspace.svg");
const _imports_3 = "" + publicAssetsURL("images/medium.svg");
const _imports_4 = "" + publicAssetsURL("images/github.svg");
const _sfc_main = {
  __name: "EachBlog",
  __ssrInlineRender: true,
  props: {
    title: {
      type: String
    },
    typeArticle: {
      type: String
    },
    imageSrc: {
      type: String
    },
    imageAlt: {
      type: String
    },
    body: {
      type: String
    },
    comment: {},
    author: {
      type: String
    },
    authorImage: {
      type: String
    },
    authorDescription: {
      type: String
    },
    slugT: {
      type: String
    }
  },
  setup(__props) {
    useRequestHelper();
    useRequestOptions();
    useSnackbar();
    const showMore = ref(false);
    const visibleCommentCount = ref(3);
    const isClamped = ref(true);
    ref(false);
    ref(false);
    ref();
    ref();
    const comment = ref();
    ref();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      const _component_Icon = __nuxt_component_2;
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<section${ssrRenderAttrs(_attrs)}><span class="bg-tertiary absolute top-0 z-[-99] w-full min-h-[315px] md:min-h-[515px]"></span><div class="lg:container-custom mx-10 flex flex-col py-10 lg:py-20"><h1 class="text-primary text-[14px] sm:text-[18px] md:text-[30px]">${ssrInterpolate(__props.typeArticle)}</h1><p class="text-[#404040] text-lg sm:text-[26px] md:text-[30px] mb-3 lg:mb-10 mt-3 md:leading-normal">${ssrInterpolate(__props.title)}</p><div class="min-h-[200px] md:min-h-[500px]" style="${ssrRenderStyle({
        backgroundImage: `url('${__props.imageSrc}')`,
        backgroundPosition: "top left",
        backgroundRepeat: "no-repeat",
        backgroundSize: "cover"
      })}"></div><div class="block lg:hidden my-3 min-[400px]:my-5 sm:my-7 p-3"><div class="flex items-center max-h-[150px] overflow-hidden shadow-sm">`);
      if (__props.authorImage) {
        _push(`<img${ssrRenderAttr("src", __props.authorImage)} alt="author" class="max-w-[15%] sm:max-w-[4rem]">`);
      } else if (!__props.authorImage) {
        _push(`<div class="max-w-[15%] sm:max-w-[4rem]">`);
        _push(ssrRenderComponent(_component_Icon, {
          name: "iconamoon:profile-circle-fill",
          class: "text-gray-400 w-12 h-12"
        }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="flex flex-col pl-4 max-w-[70%]"><p class="text-[0.9rem] overflow-ellipsis overflow-hidden sm:text-lg font-bold">${ssrInterpolate(__props.author)}</p><p class="text-[0.5rem] min-[400px]:text-[12px] sm:text-[14px] overflow-ellipsis overflow-hidden">${ssrInterpolate(__props.authorDescription)}</p></div></div><div class="w-full mt-4 md:mt-4 flex justify-end">`);
      _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex flex-col items-center"${_scopeId}><img${ssrRenderAttr("src", _imports_0)} class="max-w-[20px] h-[20px]"${_scopeId}><p class="text-[14px] md:text-[16px]"${_scopeId}>share</p></div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col items-center" }, [
                createVNode("img", {
                  src: _imports_0,
                  class: "max-w-[20px] h-[20px]"
                }),
                createVNode("p", { class: "text-[14px] md:text-[16px]" }, "share")
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="grid grid-cols-12 lg:mt-20 lg:gap-5"><div class="grid lg:col-span-9 col-span-12"><div class="leading-9 text-[14px]">${__props.body}</div><!--[-->`);
      ssrRenderList((_a = unref(comment)) == null ? void 0 : _a.slice(
        0,
        unref(visibleCommentCount)
      ), (DataComment, index) => {
        _push(`<div class="flex mt-10 gap-5 items-center sm:items-start p-2 shadow-md rounded-lg"><img${ssrRenderAttr("src", `/images/person-comment-1.png`)} alt="person-comment-1" class="object-cover max-w-[100px] max-h-[100px]"><div class="flex flex-col gap-2 md:gap-4 w-full"><h3 class="text-[#121416] text-[20px] md:text-[24px]">${ssrInterpolate(DataComment.name)}</h3><p class="text-[#6D767E] text-[14px] lg:text-[18px]">${ssrInterpolate(DataComment.comment)}</p><div class="flex gap-2 mt-2">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: DataComment.behance
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img${ssrRenderAttr("src", _imports_1)} alt="behance"${_scopeId}>`);
            } else {
              return [
                createVNode("img", {
                  src: _imports_1,
                  alt: "behance"
                })
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: DataComment.myspace
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img${ssrRenderAttr("src", _imports_2)} alt="myspace"${_scopeId}>`);
            } else {
              return [
                createVNode("img", {
                  src: _imports_2,
                  alt: "myspace"
                })
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: DataComment.medium
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img${ssrRenderAttr("src", _imports_3)} alt="medium"${_scopeId}>`);
            } else {
              return [
                createVNode("img", {
                  src: _imports_3,
                  alt: "medium"
                })
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: DataComment.github
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<img${ssrRenderAttr("src", _imports_4)} alt="github"${_scopeId}>`);
            } else {
              return [
                createVNode("img", {
                  src: _imports_4,
                  alt: "github"
                })
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</div><span class="text-right opacity-50">${ssrInterpolate(DataComment.created_at)}</span></div></div>`);
      });
      _push(`<!--]-->`);
      if (((_b = unref(comment)) == null ? void 0 : _b.length) > unref(visibleCommentCount)) {
        _push(`<div class="flex justify-center"><button class="bg-primary max-w-[300px] mt-10 focus:outline-none rounded-full text-white p-3 hover:bg-secondary transition">${ssrInterpolate(unref(showMore) ? "Zie minder" : "Bekijk meer")}</button></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="hidden lg:grid lg:col-span-3 lg:item-center"><div class="lg:flex flex-col items-center"><h1 class="text-[#121416] text-[18px] pb-3">AUTHOR</h1><h3 class="text-[18px]">${ssrInterpolate(__props.author)}</h3>`);
      if (__props.authorImage) {
        _push(`<img${ssrRenderAttr("src", __props.authorImage)} alt="author" class="my-4 rounded-full max-w-[100px] aspect-square object-cover">`);
      } else if (!__props.authorImage) {
        _push(`<div class="my-4 rounded-full max-w-[100px] aspect-square">`);
        _push(ssrRenderComponent(_component_Icon, {
          name: "iconamoon:profile-circle-fill",
          class: "text-gray-400 w-12 h-12"
        }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<p class="${ssrRenderClass([{ "line-clamp-2": unref(isClamped) }, "text-center text-sm leading-9 text-[#ADADAD] cursor-pointer"])}">${ssrInterpolate(__props.authorDescription)}</p></div><div class="flex justify-center"><div class="cursor-pointer"><div class="flex flex-col mt-24 max-w-[20px] h-[20px] justify-center items-center"><img${ssrRenderAttr("src", _imports_0)}><p class="text-[14px] md:text-[16px]">share</p></div></div></div></div></div></div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/EachBlog.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main;

export { __nuxt_component_0 as _ };
//# sourceMappingURL=EachBlog-752b92af.mjs.map
