import { _ as __nuxt_component_0 } from './HeaderWCity-239feb2c.mjs';
import { useSSRContext, mergeProps } from 'vue';
import { ssrRenderComponent, ssrRenderAttrs, ssrInterpolate, ssrRenderList, ssrRenderClass } from 'vue/server-renderer';
import { d as useHead, i as _export_sfc } from '../server.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main$1 = {
  data() {
    return {
      activeIndex: null,
      HeaderFaq: {
        title: "FAQ\u2019s \u2013 De meest gestelde vragen",
        description: "t amet, solor ut adipiscing elit.Lorem ipsum dolor sit amet, solor ut adipiscing elit.Lorem ipsum dolor sit amet, solor ut adipiscing elit.Lorem ipsum dolor sit amet, solor ut adipiscing elit."
      },
      Faq: [
        {
          header: "Hoe kan ik overwaarde inbouwen in mijn huis?",
          description: "U kunt op drie manieren eigen vermogen opbouwen. De eerste (en gemakkelijkste) is de waardering van de markt. Ten tweede: probeer bij het doen van uw maandelijkse hypotheekbetaling een klein beetje meer te sturen."
        },
        {
          header: "Hoe groot is een hectare?",
          description: "-"
        },
        {
          header: "Wat zijn afsluitkosten?",
          description: "-"
        },
        {
          header: "Wat is een eigendomsverzekering?",
          description: "-"
        }
      ]
    };
  },
  methods: {
    toggleDetail(index) {
      if (this.activeIndex === index) {
        this.activeIndex = null;
      } else {
        this.activeIndex = index;
      }
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col container-custom w-[90%] md:w-[80%] my-28 justify-center" }, _attrs))}><div class="flex flex-col justify-center items-center my-10"><h1 class="text-[#404040] text-[20px] md:text-[34px] lg:text-[40px] font-semibold text-center">${ssrInterpolate($data.HeaderFaq.title)}</h1><p class="w-full md:w-[80%] my-5 font-normal text-center text-[14px] md:text-[16px]">${ssrInterpolate($data.HeaderFaq.description)}</p></div><!--[-->`);
  ssrRenderList($data.Faq, (eachFaq, index) => {
    _push(`<div class="max-w-[970px]"><div class="${ssrRenderClass([
      "rounded-[8px] text-white px-5 md:px-10 py-3 w-[100%] cursor-pointer mb-3 transition",
      $data.activeIndex === index ? "bg-secondary w-full" : "bg-[#859C8121] border-2 border-[#1FAB71]"
    ])}"><h1 class="${ssrRenderClass([
      "font-semibold text-[16px] sm:text-[18px] md:text-[20px]",
      $data.activeIndex === index ? "text-white mb-2" : "text-[#404040] py-1"
    ])}">${ssrInterpolate(eachFaq.header)}</h1><p class="${ssrRenderClass([
      "text-[12px] md:text-[14px] leading-6",
      $data.activeIndex === index ? "block text-white" : "hidden text-[#404040]"
    ])}">${ssrInterpolate(eachFaq.description)}</p></div></div>`);
  });
  _push(`<!--]--></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/FaqElement.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = {
  __name: "Faq",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "FAQ"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderWCity = __nuxt_component_0;
      const _component_FaqElement = __nuxt_component_1;
      _push(`<!--[--><div class="mt-28"></div>`);
      _push(ssrRenderComponent(_component_HeaderWCity, {
        title1: "FAQ",
        title2: "Onze meest gestelde vragen",
        description: "Lorem ipsum dolor sit amet, solor ut adipiscing elit. Lorem ipsum dolor sit amet, solor ut adipiscing elit."
      }, null, _parent));
      _push(`<div class="flex justify-center">`);
      _push(ssrRenderComponent(_component_FaqElement, null, null, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/Faq.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=Faq-93873899.mjs.map
