import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import { h as _export_sfc } from '../server.mjs';

const _sfc_main = {
  props: {
    title1: {
      type: String,
      required: true
    },
    title2: {
      type: String,
      required: true
    },
    description: {
      type: String,
      required: true
    },
    imageSrc: {
      type: String,
      required: false,
      default: "/images/bg-title.svg"
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "relative flex items-center" }, _attrs))}><div class="grid md:grid-rows-1 md:grid-cols-2 z-10 bg-[url(&#39;/images/bg-header-w-city.jpg&#39;)] bg-no-repeat bg-cover w-full container-custom"><div class="flex items-center min-h-[340px] sm:min-h-[468px]"><div class="w-full grid gap-5"><p class="text-[20px] lg:text-[24px]">${ssrInterpolate($props.title1)}</p><h1 class="text-2xl md:text-[28px] lg:text-[38px] text-[#231E1F] lg:leading-[60px] font-semibold xl:text-[41px] xl:tracking-wide">${$props.title2}</h1><p class="text-[12px] sm:text-[14px] lg:text-lg text-[#6E6E6E] leading-8 lg:leading-normal font-medium">${ssrInterpolate($props.description)}</p></div></div><div class="hidden md:grid relative mt-5 justify-items-center items-end"><img alt="image" class="z-10 max-w-[532px] w-[90%]"${ssrRenderAttr("src", $props.imageSrc)}></div></div></section>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/HeaderWCity.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { __nuxt_component_0 as _ };
//# sourceMappingURL=HeaderWCity-6b8741a3.mjs.map
