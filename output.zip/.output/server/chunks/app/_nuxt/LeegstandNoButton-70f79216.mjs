import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderClass, ssrInterpolate } from 'vue/server-renderer';
import { i as _export_sfc } from '../server.mjs';

const _sfc_main = {
  props: {
    uniqueIdProp: {
      type: Number,
      required: true
    },
    background: {
      type: String,
      default: "bg-white"
    },
    image: {
      type: String,
      required: true
    },
    imageAlt: {
      type: String,
      required: false,
      default: "image"
    },
    title: {
      type: String,
      required: true
    },
    titledescription2: {
      type: String,
      required: false
    },
    description: {
      type: String,
      required: true
    },
    description2: {
      type: String,
      required: false
    },
    leftToRight: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      uniqueId: `component-${Math.floor(Math.random() * 1e4)}`
    };
  },
  computed: {
    imageClasses() {
      return {
        "sm:order-1": this.leftToRight,
        "sm:order-2": !this.leftToRight,
        "order-2": this.leftToRight
      };
    },
    textClasses() {
      return {
        "sm:order-2": this.leftToRight,
        "sm:order-1": !this.leftToRight,
        "order-1": this.leftToRight,
        "sm:mr-20": !this.leftToRight,
        "sm:ml-20": this.leftToRight
      };
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({
    class: ["py-10 px-3 md:container-custom", $props.background]
  }, _attrs))}><div class="grid sm:grid-cols-2 md:mx-3 lg:mx-4 items-center lg:gap-10"><div class="order-2 flex justify-end max-w-[600px]"><div class="w-[78%] min-[420px]:w-[90%] md:w-[100%]"><img${ssrRenderAttr("src", $props.image)} alt="image"></div></div><div class="${ssrRenderClass([$options.textClasses, "flex-col lg:mx-5"])}"><h1 class="text-[18px] md:text-[26px] lg:text-[36px] text-[#404040] mb-3 md:my-6 font-bold">${ssrInterpolate($props.title)}</h1><p class="text-[12px] md:text-[14px] lg:text-[16px] leading-6 lg:leading-9 text-justify py-4">${ssrInterpolate($props.description)}</p><div class="mt-7 text-justify"><span class="text-[14px] text-[#777]">${ssrInterpolate($props.titledescription2)}</span><br> ${ssrInterpolate($props.description2)}</div></div></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/LeegstandNoButton.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { __nuxt_component_3 as _ };
//# sourceMappingURL=LeegstandNoButton-70f79216.mjs.map
