import __nuxt_component_2 from './Icon-e394d28f.mjs';
import { u as useAxios } from './useAxios-d0468a52.mjs';
import { useSSRContext, ref, withAsyncContext, watch, mergeProps, unref } from 'vue';
import { u as useRequestOptions } from '../server.mjs';
import { u as useFetch } from './fetch-101122a4.mjs';
import { ssrRenderAttrs, ssrRenderClass, ssrInterpolate, ssrRenderList, ssrRenderAttr, ssrRenderComponent } from 'vue/server-renderer';
import { _ as _imports_0 } from './arrow-right-150377ce.mjs';
import { a as _imports_0$1 } from './building-map-interactive-1a786a33.mjs';

const _sfc_main = {
  __name: "MapInteractive",
  __ssrInlineRender: true,
  props: {
    ShowContainerCustom: {
      type: Boolean,
      default: true,
      required: false
    },
    selectedCityT: {
      type: [String, Number],
      required: false,
      default: 1
    },
    selectedMinPriceT: {
      type: [String, Number],
      required: false
    },
    selectedMaxPriceT: {
      type: [String, Number],
      required: false
    },
    SubmitPerform: {
      type: Boolean,
      default: false
    },
    showSearch: {
      type: Boolean,
      default: true
    }
  },
  async setup(__props) {
    var _a, _b, _c, _d;
    let __temp, __restore;
    const props = __props;
    const { axiosRequest } = useAxios();
    ref({ lat: 52.21314997541194, lng: 5.3982948103810795 });
    const { requestOptions } = useRequestOptions();
    const { data, error } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/products`, {
      method: "get",
      ...requestOptions
    }, "$JhnukHI10r")), __temp = await __temp, __restore(), __temp);
    const { data: locationData } = ([__temp, __restore] = withAsyncContext(() => useFetch("/locations", {
      method: "get",
      ...requestOptions
    }, "$ydjyJCRLz0")), __temp = await __temp, __restore(), __temp);
    const numericPrices = data.value.data.map((item) => parseFloat(item.price));
    const uniqueNumericPrices = [];
    numericPrices.forEach((price) => {
      if (!uniqueNumericPrices.includes(price)) {
        uniqueNumericPrices.push(price);
      }
    });
    let numericPricesT = ref(uniqueNumericPrices);
    Math.max(...numericPrices);
    let minestPrice = Math.min(...numericPrices);
    const searchCity = ref();
    const arrayLocation = (_b = (_a = locationData == null ? void 0 : locationData.value) == null ? void 0 : _a.data) == null ? void 0 : _b.map((item) => item);
    let city = ref(arrayLocation);
    let firstLocation = ref((_c = arrayLocation[0]) == null ? void 0 : _c.name);
    const categories = ref([
      {
        title: "Zoek een Locatie",
        selectedOption: firstLocation,
        showDropdown: false,
        options: city
      },
      {
        title: "Zoek op een prijs",
        selectedOption: minestPrice,
        showDropdown: false,
        options: numericPricesT
      }
    ]);
    const titleMap = ref("Waar bent u op zoek naar?");
    let map = ref(null);
    const markers = ref([]);
    const currentInfoWindow = ref(null);
    (_d = data == null ? void 0 : data.value) == null ? void 0 : _d.data;
    const selectedCity = ref(props.selectedCityT);
    const selectedMinPrice = ref(minestPrice);
    const selectedMaxPrice = ref(props.selectedMaxPriceT);
    const filteredData = ref();
    watch(
      () => props.selectedCityT,
      (newValue, oldValue) => {
        selectedCity.value = newValue;
      }
    );
    watch(
      () => props.selectedMinPriceT,
      (newValue, oldValue) => {
        selectedMinPrice.value = newValue;
      }
    );
    watch(
      () => props.selectedMaxPriceT,
      (newValue, oldValue) => {
        selectedMaxPrice.value = newValue;
      }
    );
    watch(
      () => props.SubmitPerform,
      (newValue, oldValue) => {
        performSearch();
      }
    );
    async function performSearch() {
      try {
        let params = {};
        params["filter[location]"] = searchCity.value;
        const response = await axiosRequest.get("/products", { params });
        filteredData.value = response.data;
        findMap(filteredData.value);
        recenterMap(filteredData.value);
      } catch (error2) {
        console.error("Failed to retrieve data from API:", error2);
      }
    }
    const recenterMap = (filteredData2) => {
      if (filteredData2 && filteredData2.data && filteredData2.data.length > 0) {
        const bounds = new google.maps.LatLngBounds();
        filteredData2.data.forEach((item) => {
          bounds.extend(
            new google.maps.LatLng(
              parseFloat(item.latitude),
              parseFloat(item.longitude)
            )
          );
        });
        map.fitBounds(bounds);
      }
    };
    function findMap(dataFilter) {
      if (!dataFilter || !dataFilter.data || dataFilter.data.length === 0) {
        alert("Location Not Found. Please adjust your filter");
        return;
      }
      clearInfoWindows();
      const locations = dataFilter == null ? void 0 : dataFilter.data.map((item) => {
        return {
          latitude: parseFloat(item.latitude),
          longitude: parseFloat(item.longitude)
        };
      });
      locations.forEach((location) => {
        moveToLocation(location.latitude, location.longitude);
      });
    }
    const clearInfoWindows = () => {
      if (currentInfoWindow.value) {
        currentInfoWindow.value.close();
      }
    };
    const moveToLocation = (lat, lng) => {
      if (map) {
        map.setCenter({ lat, lng });
        const filteredMarkers = markers.value.filter(
          (marker) => marker.details.filtered
        );
        const bounds = new google.maps.LatLngBounds();
        filteredMarkers.forEach((marker) => {
          bounds.extend(marker.getPosition());
        });
        map.fitBounds(bounds);
        const matchingMarker = markers.value.find(
          (marker) => marker.getPosition().equals(new google.maps.LatLng(lat, lng))
        );
        if (matchingMarker) {
          matchingMarker.details.filtered = true;
          matchingMarker.setAnimation(google.maps.Animation.BOUNCE);
          setTimeout(() => {
            matchingMarker.setAnimation(null);
          }, 7e4);
        }
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_2;
      _push(`<section${ssrRenderAttrs(mergeProps({
        class: {
          "container-custom": __props.ShowContainerCustom,
          "relative z-20": true,
          "w-full": !__props.ShowContainerCustom
        }
      }, _attrs))}><div id="map" class="${ssrRenderClass(`relative w-full h-[320px] sm:h-[420px] lg:min-h-[519px] min-[1440px]:h-[619px] z-[-999] rounded-2xl`)}"></div><div class="sm:mx-10 hidden"><div class="bg-tertiary box-shadow mt-[-100px] z-10 rounded-[20px] lg:rounded-[30px]"><div class="min-h-[278px] md:grid md:grid-cols-3 items-center h-full px-6 sm:px-10 font-semibold gap-1 md:gap-3 py-5 sm:py-9"><p class="text-[25px] font-bold lg:leading-10 lg:text-3xl text-secondary mb-4 md:mb-0">${ssrInterpolate(unref(titleMap))}</p><!--[-->`);
      ssrRenderList(unref(categories), (category, index) => {
        _push(`<div class="flex flex-col"><p class="text-[14px] pb-3 pl-2 lg:pl-3 lg:pb-2 mt-2">${ssrInterpolate(category.title)}</p>`);
        if (category.title === "Zoek een Locatie") {
          _push(`<div class="relative"><div class="italic w-full flex items-center justify-between bg-[rgb(247,247,247)] rounded-full px-2 pl-4 min-h-[40px] sm:min-h-[50px] cursor-pointer text-quaternary sm:text-[14px] mb-5 md:mb-0">${ssrInterpolate(category.selectedOption)} <div class="max-w-[30px] min-h-[30px] bg-quaternary rounded-full flex items-center justify-center"><img${ssrRenderAttr("src", _imports_0)} alt="arrow" class="rotate-90"></div></div>`);
          if (category.showDropdown) {
            _push(`<ul class="absolute text-[10px] dropdownMap max-h-[200px] overflow-hidden overflow-y-auto lg:text-[14px] top-[100%] left-0 bg-[#F7F7F7] rounded-[5px] mt-1 w-full text-quaternary z-20"><!--[-->`);
            ssrRenderList(unref(city), (item, index2) => {
              _push(`<li class="cursor-pointer hover:bg-secondary transition hover:text-tertiary px-3 py-2">${ssrInterpolate(item.name)}</li>`);
            });
            _push(`<!--]--></ul>`);
          } else {
            _push(`<!---->`);
          }
          _push(`</div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      });
      _push(`<!--]--><div class="text-tertiary grid justify-end md:col-span-3 mt-4"><button class="bg-primary hover:bg-secondary transition-all rounded-full min-h-[48px] flex items-center gap-4 pl-3 pr-1"><p class="font-semibold text-sm pl-2">Uitgebreid zoeken</p><div class="bg-tertiary flex items-center justify-center rounded-full min-w-[40px] min-h-[40px]"><svg width="9" height="15" viewBox="0 0 9 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.8125 13.8749L7.99968 7.68767L1.8125 1.50049" stroke="#F0912D" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"></path></svg></div></button></div></div></div></div>`);
      if (__props.showSearch) {
        _push(`<div class="bg-tertiary box-shadow mt-[-100px] md:mt-[-100px] z-10 rounded-[20px] lg:rounded-[30px] md:h-[188px] mx-3 px-5 grid md:grid-cols-12 items-center gap-4 pt-6 md:pt-0"><div class="md:col-span-4 flex md:justify-center items-center"><img${ssrRenderAttr("src", _imports_0$1)} alt="building-icon" class=""><p class="text-secondary text-2xl lg:text-3xl font-medium z-10 ml-[-40px]"> Waar bent u <br> naar op zoek? </p></div><div class="grid min-[370px]:grid-cols-12 sm:grid-cols-1 md:grid-cols-12 col-span-6 lg:col-span-6 sm:px-0 lg:px-5 sm:gap-2 justify-center items-center"><div class="w-full col-span-12 flex justify-center items-center"><div class="w-[90%] flex flex-col gap-3"><p class="text-lg font-semibold">Locaties</p><input type="text" name="" id="" placeholder="Locaties"${ssrRenderAttr("value", unref(searchCity))} class="w-full italic text-[12px] sm:text-[14px] flex items-center justify-between bg-[rgb(247,247,247)] rounded-full px-2 pl-4 min-h-[40px] sm:min-h-[50px] mb-2 sm:mb-5 md:mb-0 text-[#676767] border-black border"></div></div></div><div class="flex justify-self-end mb-5"><div class="btn bg-primary text-white md:mt-5 hover:bg-primary w-[65px] h-[60px] lg:w-[76px] lg:h-[76px] rounded-[20px]">`);
        _push(ssrRenderComponent(_component_Icon, {
          name: "iconamoon:search-thin",
          class: "text-white w-10 h-10"
        }, null, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MapInteractive.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_4 = _sfc_main;

export { __nuxt_component_4 as _ };
//# sourceMappingURL=MapInteractive-94199233.mjs.map
