import { useSSRContext, ref, resolveComponent, mergeProps, withCtx, createVNode, openBlock, createBlock } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';

const _sfc_main = {
  __name: "MapsTest",
  __ssrInlineRender: true,
  props: {
    latitude: {
      type: String
    },
    longitude: {
      type: String
    }
  },
  emits: ["update:longitude", "update:latitude"],
  setup(__props, { emit }) {
    const props = __props;
    const center = ref({
      lat: parseFloat(props.latitude) || 52.21314997541194,
      lng: parseFloat(props.longitude) || 5.3982948103810795
    });
    const currentMarkerPosition = ref({
      lat: parseFloat(props.latitude) || 52.21314997541194,
      lng: parseFloat(props.longitude) || 5.3982948103810795
    });
    function setPlace(ctx) {
      var _a, _b, _c, _d;
      const latitude = (_b = (_a = ctx.geometry) == null ? void 0 : _a.location) == null ? void 0 : _b.lat();
      const longitude = (_d = (_c = ctx.geometry) == null ? void 0 : _c.location) == null ? void 0 : _d.lng();
      currentMarkerPosition.value = { lat: latitude, lng: longitude };
      center.value = { lat: latitude, lng: longitude };
      updateValue(latitude, longitude);
    }
    function updateValue(latitude, longitude) {
      const updatedLatitude = latitude !== void 0 ? latitude.toString() : void 0;
      const updatedLongitude = longitude !== void 0 ? longitude.toString() : void 0;
      emit("update:longitude", updatedLongitude);
      emit("update:latitude", updatedLatitude);
    }
    function handleMapClick(event) {
      const latitude = event.latLng.lat();
      const longitude = event.latLng.lng();
      currentMarkerPosition.value = { lat: latitude, lng: longitude };
      updateValue(latitude, longitude);
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_GMapMap = resolveComponent("GMapMap");
      const _component_GMapAutocomplete = resolveComponent("GMapAutocomplete");
      const _component_GMapMarker = resolveComponent("GMapMarker");
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "rounded-lg overflow-hidden relative" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_GMapMap, {
        center: center.value,
        zoom: 12,
        "map-type-id": "terrain",
        style: { "width": "100%", "height": "450px" },
        options: {
          disableDefaultUi: true,
          draggableCursor: "pointer"
        },
        onClick: handleMapClick
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="my-5 px-2"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_GMapAutocomplete, {
              class: "input input-bordered w-full",
              placeholder: "Search Location",
              onPlace_changed: setPlace
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_GMapMarker, {
              key: "current",
              position: currentMarkerPosition.value,
              icon: {
                url: "/images/marker-red.svg",
                scaledSize: { width: 50, height: 50 }
              },
              clickable: true
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode("div", { class: "my-5 px-2" }, [
                createVNode(_component_GMapAutocomplete, {
                  class: "input input-bordered w-full",
                  placeholder: "Search Location",
                  onPlace_changed: setPlace
                })
              ]),
              (openBlock(), createBlock(_component_GMapMarker, {
                key: "current",
                position: currentMarkerPosition.value,
                icon: {
                  url: "/images/marker-red.svg",
                  scaledSize: { width: 50, height: 50 }
                },
                clickable: true
              }, null, 8, ["position", "icon"]))
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MapsTest.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_6 = _sfc_main;

export { __nuxt_component_6 as _ };
//# sourceMappingURL=MapsTest-40b91c11.mjs.map
