import { g as useNuxtApp } from '../server.mjs';
import { unref, mergeProps, createSlots, renderList, withCtx, renderSlot, useSSRContext } from 'vue';
import { ssrRenderComponent, ssrRenderSlot } from 'vue/server-renderer';
import { Vue3Snackbar } from 'vue3-snackbar';

const _sfc_main = {
  __name: "NuxtSnackbar",
  __ssrInlineRender: true,
  setup(__props) {
    var _a;
    const snackbarOptions = ((_a = useNuxtApp()) == null ? void 0 : _a.$snackbarOptions) || {};
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(Vue3Snackbar), mergeProps(unref(snackbarOptions), _attrs), createSlots({ _: 2 }, [
        renderList(_ctx.$slots, (_, name) => {
          return {
            name,
            fn: withCtx((slotData, _push2, _parent2, _scopeId) => {
              if (_push2) {
                ssrRenderSlot(_ctx.$slots, name, slotData, null, _push2, _parent2, _scopeId);
              } else {
                return [
                  renderSlot(_ctx.$slots, _ctx.name, slotData)
                ];
              }
            })
          };
        })
      ]), _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("node_modules/nuxt-snackbar/dist/runtime/components/NuxtSnackbar.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as _ };
//# sourceMappingURL=NuxtSnackbar-cce50284.mjs.map
