import { _ as __nuxt_component_0 } from './client-only-29ef7f45.mjs';
import { ref, mergeProps, useSSRContext } from 'vue';
import { Swiper, SwiperSlide } from 'swiper/vue';
import { Autoplay, Pagination, Navigation } from 'swiper/modules';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import { i as _export_sfc } from '../server.mjs';

const _sfc_main = {
  components: {
    Swiper,
    SwiperSlide
  },
  props: {
    data: {
      type: Array
    }
  },
  setup() {
    const slidesPerView = ref(3);
    function formattedRentType(rentType) {
      if (rentType === "monthly") {
        return "maand";
      } else if (rentType === "yearly") {
        return "jaar";
      }
    }
    return {
      slidesPerView,
      formattedRentType,
      modules: [Autoplay, Pagination, Navigation]
    };
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_ClientOnly = __nuxt_component_0;
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "relative flex flex-col py-10" }, _attrs))}><div class="grid grid-cols-1 grid-rows-1"><div class="flex pl-3 sm:pl-6 md:pl-[70px] lg:pl-[80px] xl:pl-[106px] overflow-hidden">`);
  _push(ssrRenderComponent(_component_ClientOnly, null, {}, _parent));
  _push(`</div></div></section>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/SliderLocatiesSort.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { __nuxt_component_1 as _ };
//# sourceMappingURL=SliderLocatiesSort-9a6b5d39.mjs.map
