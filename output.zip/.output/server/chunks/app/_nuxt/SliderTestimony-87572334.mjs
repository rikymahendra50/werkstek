import { _ as __nuxt_component_0 } from './TitleHeader-8492944b.mjs';
import { Swiper, SwiperSlide } from 'swiper/vue';
import __nuxt_component_2 from './Icon-e394d28f.mjs';
import { useSSRContext, ref, mergeProps, withCtx, createVNode, openBlock, createBlock, Fragment, renderList } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import { h as _export_sfc } from '../server.mjs';
import { Autoplay, Pagination } from 'swiper/modules';

const _sfc_main$1 = {
  props: {
    imageSrc: {
      type: String
    },
    description: {
      type: String
    },
    testimonyName: {
      type: String
    },
    position: {
      type: String
    },
    imageAlt: {
      type: String
    }
  }
};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Icon = __nuxt_component_2;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "relative text-left px-5 py-5 rounded-[16px] flex flex-col box-shadow2 my-10 h-[320px] xl:h-[380px] mx-1" }, _attrs))}><div class="flex flex-col justify-between gap-2 h-full"><img${ssrRenderAttr("src", $props.imageSrc)}${ssrRenderAttr("alt", $props.imageAlt)} class="w-[80px] min-[1300px]:w-[90px] aspect-square min-w-[1300px]:h-[90px] mt-[-30px] rounded-full border"><p class="text-[12px] sm:text-[14px] 2xl:text-[18px] text-[#3D3D3D] leading-normal overflow-y-auto max-h-[100px] lg:max-h-[150px] xl:max-h-[240px]">${$props.description}</p><div class="grid grid-cols-12 pt-2 border-t"><div class="flex flex-col text-sm gap-1 text-[10px] col-span-8"><p class="font-bold text-[12px] xl:text-sm">${ssrInterpolate($props.testimonyName)}</p><p class="text-sm xl:text-base">${ssrInterpolate($props.position)}</p></div><div class="flex items-center justify-end col-span-4"><!--[-->`);
  ssrRenderList(4, (index) => {
    _push(ssrRenderComponent(_component_Icon, {
      name: "ic:round-star",
      class: "text-[#da9a3b] w-4"
    }, null, _parent));
  });
  _push(`<!--]--></div></div></div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/EachTestimony.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main = {
  data() {
    return {
      Testimony: [
        {
          id: 4,
          imageSrc: "/images/opportunity-vastgoed-b.v.png",
          imageAlt: "opportunity-vastgoed",
          description: "Werkstek is voor ons een goede partner. Inmiddels druk met elkaar voor drie kantoor panden en we zijn beide tevreden. <br/> Professioneel, correct en slagvaardig.",
          name: "Maurits Kuppens",
          position: "Opportunity Vastgoed B.V."
        },
        {
          id: 5,
          imageSrc: "/images/crmd.jpg",
          imageAlt: "crmd",
          description: "Werkstek biedt onze kantoorlocaties een mooi concept wat laagdrempelig is voor lokale ondernemers om te huren en professioneel is voor ons als vastgoedbeheerder om mee samen te werken. <br/> <br/> Wij werken al jaren prettig samen met Ernst. De betrokkenheid voelt alsof wij zijn enige klant zijn.",
          name: "Yor Berkhout",
          position: "Vastgoed Manager"
        },
        {
          id: 1,
          imageSrc: "/images/icon-werstek.svg",
          imageAlt: "MARC ZANDBERGEN",
          description: "Werkstek is een erg doeltreffend werkplek- en verhuurconcept. Met zowel tijdelijke als langere termijn oplossingen wordt er actief meegedacht met en waarde toegevoegd voor de gebouweigenaar alsook de hurende ondernemers En uiteraard een hele prettige samenwerking!",
          name: "MARC ZANDBERGEN",
          position: "Unifore"
        },
        {
          id: 2,
          imageSrc: "/images/icon-werstek.svg",
          imageAlt: "ERIK WERNERS",
          description: "Vanuit people@places hebben we zeer goede ervaringen met Werkstek. Er wordt altijd snel geschakeld en het contact met Ernst verloopt prettig. Hij kijkt altijd naar een oplossing voor alle partijen. We werken met Werkstek op verschillende locaties naar alle tevredenheid. Ernst is correct, commercieel gedreven en betrokken en altijd op zoek naar het beste resultaat.",
          name: "ERIK WERNERS",
          position: "people@places"
        },
        {
          id: 3,
          imageSrc: "/images/icon-werstek.svg",
          imageAlt: "TON VAN NAMEN",
          description: "Simon werkt uitstekend met Werkstek van Ernst Wilton",
          name: "TON VAN NAMEN",
          position: "simon"
        },
        {
          id: 6,
          imageSrc: "/images/icon-werstek.svg",
          imageAlt: "icon-werstek",
          description: "\u201DPer direct beschikbaar!\u201D, \u2026.. klinkt als een mooie Marketing uitspraak, maar blijkt bij Werkstek ook daadwerkelijk realiteit! Voor diverse cli\xEBnten hebben wij via Werkstek inmiddels meerdere kantoren gehuurd, welke ook daadwerkelijk diezelfde dag nog beschikbaar waren! Korte lijnen, meedenken met het probleem van de klant, flexibiliteit en snel schakelen! Dat is waar de huidige kantoorgebruiker op zit te wachten.",
          name: "Daan van der Meulen",
          position: "LaGuardia Amsterdam Real Estate B.V."
        },
        {
          id: 7,
          imageSrc: "/images/icon-werstek.svg",
          imageAlt: "icon-werstek",
          description: "Werkstek / Ernst Wilton is een daadkrachtige vastgoedpartner waar wij langjarig prettig mee samenwerken.",
          name: "Stefan Gales",
          position: "Grimonte Investment Management BV"
        }
      ]
    };
  },
  components: {
    Swiper,
    SwiperSlide
  },
  setup() {
    const slidesPerViewTestimony = ref(1);
    return {
      slidesPerViewTestimony,
      modules: [Autoplay, Pagination]
    };
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_TitleHeader = __nuxt_component_0;
  const _component_swiper = Swiper;
  const _component_swiper_slide = SwiperSlide;
  const _component_EachTestimony = __nuxt_component_3;
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "md:container-custom" }, _attrs))}>`);
  _push(ssrRenderComponent(_component_TitleHeader, {
    title: "Meningen",
    secondTitle: "Wat vinden onze klanten",
    class: "mt-8"
  }, null, _parent));
  _push(`<div class="my-8 overflow-hidden relative">`);
  _push(ssrRenderComponent(_component_swiper, {
    slidesPerView: $setup.slidesPerViewTestimony,
    spaceBetween: 30,
    pagination: {
      clickable: true,
      el: ".swiper-pagination-custom"
    },
    autoplay: {
      delay: 5e3,
      disableOnInteraction: false
    },
    modules: $setup.modules,
    class: "swiper-testimony"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<!--[-->`);
        ssrRenderList($data.Testimony, (itemTestimony, index) => {
          _push2(ssrRenderComponent(_component_swiper_slide, {
            key: itemTestimony.id
          }, {
            default: withCtx((_2, _push3, _parent3, _scopeId2) => {
              if (_push3) {
                _push3(ssrRenderComponent(_component_EachTestimony, {
                  imageSrc: itemTestimony.imageSrc,
                  imageAlt: itemTestimony.imageAlt,
                  description: itemTestimony.description,
                  testimonyName: itemTestimony.name,
                  position: itemTestimony.position
                }, null, _parent3, _scopeId2));
              } else {
                return [
                  createVNode(_component_EachTestimony, {
                    imageSrc: itemTestimony.imageSrc,
                    imageAlt: itemTestimony.imageAlt,
                    description: itemTestimony.description,
                    testimonyName: itemTestimony.name,
                    position: itemTestimony.position
                  }, null, 8, ["imageSrc", "imageAlt", "description", "testimonyName", "position"])
                ];
              }
            }),
            _: 2
          }, _parent2, _scopeId));
        });
        _push2(`<!--]--><div class="swiper-pagination-custom"${_scopeId}></div>`);
      } else {
        return [
          (openBlock(true), createBlock(Fragment, null, renderList($data.Testimony, (itemTestimony, index) => {
            return openBlock(), createBlock(_component_swiper_slide, {
              key: itemTestimony.id
            }, {
              default: withCtx(() => [
                createVNode(_component_EachTestimony, {
                  imageSrc: itemTestimony.imageSrc,
                  imageAlt: itemTestimony.imageAlt,
                  description: itemTestimony.description,
                  testimonyName: itemTestimony.name,
                  position: itemTestimony.position
                }, null, 8, ["imageSrc", "imageAlt", "description", "testimonyName", "position"])
              ]),
              _: 2
            }, 1024);
          }), 128)),
          createVNode("div", { class: "swiper-pagination-custom" })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></section>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/SliderTestimony.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_6 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { __nuxt_component_6 as _ };
//# sourceMappingURL=SliderTestimony-87572334.mjs.map
