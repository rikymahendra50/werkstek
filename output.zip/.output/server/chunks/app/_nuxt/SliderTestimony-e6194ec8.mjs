import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0 } from './TitleHeader-ee000471.mjs';
import { Swiper, SwiperSlide } from 'swiper/vue';
import __nuxt_component_2 from './Icon-7d2a1472.mjs';
import { useSSRContext, ref, mergeProps, withCtx, createVNode, openBlock, createBlock, Fragment, renderList } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import { i as _export_sfc } from '../server.mjs';
import { Autoplay, Pagination } from 'swiper/modules';

const _imports_0 = "" + publicAssetsURL("images/icon-werstek.svg");
const _sfc_main$1 = {
  props: {
    imageSrc: {
      type: String
    },
    description: {
      type: String
    },
    testimonyName: {
      type: String
    },
    position: {
      type: String
    }
  }
};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Icon = __nuxt_component_2;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "relative text-left px-5 py-5 rounded-[16px] flex flex-col box-shadow2 my-10 h-[320px] lg:h-[300px] mx-1" }, _attrs))}><div class="flex flex-col justify-between gap-2 h-full"><img${ssrRenderAttr("src", _imports_0)} alt="icon-werkstek" class="max-w-[80px] min-[1300px]:max-w-[90px] mt-[-30px]"><p class="text-[12px] sm:text-[14px] 2xl:text-[18px] text-[#3D3D3D] leading-normal">${ssrInterpolate($props.description)}</p><div class="grid grid-cols-2 pt-2 border-t"><div class="flex flex-col text-sm gap-1 text-[10px]"><p class="font-bold text-[12px]">${ssrInterpolate($props.testimonyName)}</p><p class="text-sm">${ssrInterpolate($props.position)}</p></div><div class="flex items-center justify-end"><!--[-->`);
  ssrRenderList(4, (index) => {
    _push(ssrRenderComponent(_component_Icon, {
      name: "ic:round-star",
      class: "text-[#da9a3b] w-4"
    }, null, _parent));
  });
  _push(`<!--]--></div></div></div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/EachTestimony.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main = {
  data() {
    return {
      Testimony: [
        {
          id: 1,
          imageSrc: "/images/person-testimonial-1.png",
          imageAlt: "MARC ZANDBERGEN",
          description: "Werkstek is een erg doeltreffend werkplek- en verhuurconcept. Met zowel tijdelijke als langere termijn oplossingen wordt er actief meegedacht met en waarde toegevoegd voor de gebouweigenaar alsook de hurende ondernemers En uiteraard een hele prettige samenwerking!",
          name: "MARC ZANDBERGEN",
          position: "Unifore"
        },
        {
          id: 2,
          imageSrc: "/images/person-testimonial-1.png",
          imageAlt: "ERIK WERNERS",
          description: "Vanuit people@places hebben we zeer goede ervaringen met Werkstek. Er wordt altijd snel geschakeld en het contact met Ernst verloopt prettig. Hij kijkt altijd naar een oplossing voor alle partijen. We werken met Werkstek op verschillende locaties naar alle tevredenheid. Ernst is correct, commercieel gedreven en betrokken en altijd op zoek naar het beste resultaat.",
          name: "ERIK WERNERS",
          position: "people@places"
        },
        {
          id: 3,
          imageSrc: "/images/person-testimonial-1.png",
          imageAlt: "TON VAN NAMEN",
          description: "Simon werkt uitstekend met Werkstek van Ernst Wilton",
          name: "TON VAN NAMEN",
          position: "simon"
        }
      ]
    };
  },
  components: {
    Swiper,
    SwiperSlide
  },
  setup() {
    const slidesPerViewTestimony = ref(1);
    return {
      slidesPerViewTestimony,
      modules: [Autoplay, Pagination]
    };
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_TitleHeader = __nuxt_component_0;
  const _component_swiper = Swiper;
  const _component_swiper_slide = SwiperSlide;
  const _component_EachTestimony = __nuxt_component_3;
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "md:container-custom" }, _attrs))}>`);
  _push(ssrRenderComponent(_component_TitleHeader, {
    title: "Meningen",
    secondTitle: "Wat vinden onze klanten",
    class: "mt-8"
  }, null, _parent));
  _push(`<div class="my-8 overflow-hidden relative">`);
  _push(ssrRenderComponent(_component_swiper, {
    slidesPerView: $setup.slidesPerViewTestimony,
    spaceBetween: 30,
    pagination: {
      clickable: true,
      el: ".swiper-pagination-custom"
    },
    autoplay: {
      delay: 5e3,
      disableOnInteraction: false
    },
    modules: $setup.modules,
    class: "swiper-testimony"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<!--[-->`);
        ssrRenderList($data.Testimony, (itemTestimony, index) => {
          _push2(ssrRenderComponent(_component_swiper_slide, {
            key: itemTestimony.id
          }, {
            default: withCtx((_2, _push3, _parent3, _scopeId2) => {
              if (_push3) {
                _push3(ssrRenderComponent(_component_EachTestimony, {
                  imageSrc: itemTestimony.imageSrc,
                  description: itemTestimony.description,
                  testimonyName: itemTestimony.name,
                  position: itemTestimony.position
                }, null, _parent3, _scopeId2));
              } else {
                return [
                  createVNode(_component_EachTestimony, {
                    imageSrc: itemTestimony.imageSrc,
                    description: itemTestimony.description,
                    testimonyName: itemTestimony.name,
                    position: itemTestimony.position
                  }, null, 8, ["imageSrc", "description", "testimonyName", "position"])
                ];
              }
            }),
            _: 2
          }, _parent2, _scopeId));
        });
        _push2(`<!--]--><div class="swiper-pagination-custom"${_scopeId}></div>`);
      } else {
        return [
          (openBlock(true), createBlock(Fragment, null, renderList($data.Testimony, (itemTestimony, index) => {
            return openBlock(), createBlock(_component_swiper_slide, {
              key: itemTestimony.id
            }, {
              default: withCtx(() => [
                createVNode(_component_EachTestimony, {
                  imageSrc: itemTestimony.imageSrc,
                  description: itemTestimony.description,
                  testimonyName: itemTestimony.name,
                  position: itemTestimony.position
                }, null, 8, ["imageSrc", "description", "testimonyName", "position"])
              ]),
              _: 2
            }, 1024);
          }), 128)),
          createVNode("div", { class: "swiper-pagination-custom" })
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></section>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/SliderTestimony.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_6 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { __nuxt_component_6 as _ };
//# sourceMappingURL=SliderTestimony-e6194ec8.mjs.map
