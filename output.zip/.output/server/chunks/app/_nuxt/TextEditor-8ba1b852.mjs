import __nuxt_component_2 from './Icon-e394d28f.mjs';
import { useSSRContext, computed, mergeProps, unref } from 'vue';
import { ssrRenderAttrs, ssrIncludeBooleanAttr, ssrRenderClass, ssrRenderComponent } from 'vue/server-renderer';
import { useEditor, EditorContent } from '@tiptap/vue-3';
import StarterKit from '@tiptap/starter-kit';

const _sfc_main = {
  __name: "TextEditor",
  __ssrInlineRender: true,
  props: {
    modelValue: {
      type: [String]
    },
    isError: {
      type: Boolean,
      default: () => false
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit }) {
    const props = __props;
    const contentClass = computed(() => {
      if (props.isError) {
        return "prose-sm p-2 min-h-[100px] mx-auto focus:outline-none border border-red-400 rounded-md";
      }
      return " prose-sm p-2 min-h-[100px] mx-auto focus:outline-none border border-gray-300 rounded-md";
    });
    const editor = useEditor({
      content: props.modelValue,
      extensions: [StarterKit],
      editorProps: {
        attributes: {
          class: contentClass.value
        }
      },
      onUpdate(ctx) {
        emit("update:modelValue", ctx.editor.getHTML());
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Icon = __nuxt_component_2;
      _push(`<div${ssrRenderAttrs(mergeProps({
        class: ["border rounded-lg", { "border-gray-300": !__props.isError, "border-red-400": __props.isError }]
      }, _attrs))}>`);
      if (unref(editor)) {
        _push(`<div class="grid grid-cols-2 gap-2 p-2"><div class="space-x-2 space-y-2"><button${ssrIncludeBooleanAttr(!unref(editor).can().chain().focus().toggleBold().run()) ? " disabled" : ""} class="${ssrRenderClass([{ "is-active": unref(editor).isActive("bold") }, "btn btn-sm btn-square"])}" type="button">`);
        _push(ssrRenderComponent(_component_Icon, { name: "ooui:bold-b" }, null, _parent));
        _push(`</button><button${ssrIncludeBooleanAttr(!unref(editor).can().chain().focus().toggleItalic().run()) ? " disabled" : ""} class="${ssrRenderClass([{ "is-active": unref(editor).isActive("italic") }, "btn btn-sm btn-square"])}" type="button">`);
        _push(ssrRenderComponent(_component_Icon, { name: "tabler:italic" }, null, _parent));
        _push(`</button><button${ssrIncludeBooleanAttr(!unref(editor).can().chain().focus().toggleStrike().run()) ? " disabled" : ""} class="${ssrRenderClass([{ "is-active": unref(editor).isActive("strike") }, "btn btn-sm btn-square"])}" type="button">`);
        _push(ssrRenderComponent(_component_Icon, { name: "mi:strikethrough" }, null, _parent));
        _push(`</button><button${ssrIncludeBooleanAttr(!unref(editor).can().chain().focus().toggleCode().run()) ? " disabled" : ""} class="${ssrRenderClass([{ "is-active": unref(editor).isActive("code") }, "btn btn-sm btn-square"])}" type="button">`);
        _push(ssrRenderComponent(_component_Icon, { name: "ic:baseline-code" }, null, _parent));
        _push(`</button><button class="${ssrRenderClass([{ "is-active": unref(editor).isActive("paragraph") }, "btn btn-sm btn-square"])}" type="button">`);
        _push(ssrRenderComponent(_component_Icon, { name: "ph:paragraph" }, null, _parent));
        _push(`</button></div><div class="space-x-2 space-y-2"><button class="${ssrRenderClass([{ "is-active": unref(editor).isActive("heading", { level: 1 }) }, "btn btn-sm btn-square"])}" type="button"> h1 </button><button class="${ssrRenderClass([{ "is-active": unref(editor).isActive("heading", { level: 2 }) }, "btn btn-sm btn-square"])}" type="button"> h2 </button><button class="${ssrRenderClass([{ "is-active": unref(editor).isActive("heading", { level: 3 }) }, "btn btn-sm btn-square"])}" type="button"> h3 </button><button class="${ssrRenderClass([{ "is-active": unref(editor).isActive("heading", { level: 4 }) }, "btn btn-sm btn-square"])}" type="button"> h4 </button><button class="${ssrRenderClass([{ "is-active": unref(editor).isActive("heading", { level: 5 }) }, "btn btn-sm btn-square"])}" type="button"> h5 </button><button class="${ssrRenderClass([{ "is-active": unref(editor).isActive("heading", { level: 6 }) }, "btn btn-sm btn-square"])}" type="button"> h6 </button></div><div class="space-x-2 space-y-2"><button class="${ssrRenderClass([{ "is-active": unref(editor).isActive("bulletList") }, "btn btn-sm btn-square"])}" type="button">`);
        _push(ssrRenderComponent(_component_Icon, { name: "zondicons:list-bullet" }, null, _parent));
        _push(`</button><button class="${ssrRenderClass([{ "is-active": unref(editor).isActive("orderedList") }, "btn btn-sm btn-square"])}" type="button">`);
        _push(ssrRenderComponent(_component_Icon, { name: "bx:list-ol" }, null, _parent));
        _push(`</button><button class="btn btn-sm btn-square" type="button">`);
        _push(ssrRenderComponent(_component_Icon, { name: "ic:outline-horizontal-rule" }, null, _parent));
        _push(`</button><button class="${ssrRenderClass([{ "is-active": unref(editor).isActive("blockquote") }, "btn btn-sm btn-square"])}" type="button">`);
        _push(ssrRenderComponent(_component_Icon, { name: "mingcute:blockquote-line" }, null, _parent));
        _push(`</button></div><div class="space-y-2 space-x-2"><button type="button" class="btn btn-sm btn-square">`);
        _push(ssrRenderComponent(_component_Icon, { name: "codicon:clear-all" }, null, _parent));
        _push(`</button><button type="button" class="btn btn-sm btn-square">`);
        _push(ssrRenderComponent(_component_Icon, { name: "ant-design:clear-outlined" }, null, _parent));
        _push(`</button><button type="button" class="btn btn-sm btn-square">`);
        _push(ssrRenderComponent(_component_Icon, { name: "icon-park-outline:paragraph-break" }, null, _parent));
        _push(`</button><button${ssrIncludeBooleanAttr(!unref(editor).can().chain().focus().undo().run()) ? " disabled" : ""} type="button" class="btn btn-sm btn-square">`);
        _push(ssrRenderComponent(_component_Icon, { name: "ant-design:undo-outlined" }, null, _parent));
        _push(`</button><button${ssrIncludeBooleanAttr(!unref(editor).can().chain().focus().redo().run()) ? " disabled" : ""} type="button" class="btn btn-sm btn-square">`);
        _push(ssrRenderComponent(_component_Icon, { name: "ant-design:redo-outlined" }, null, _parent));
        _push(`</button></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(ssrRenderComponent(unref(EditorContent), {
        editor: unref(editor),
        class: "p-2 deskBody",
        placehoder: "write something",
        required: ""
      }, null, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Form/TextEditor.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_4 = _sfc_main;

export { __nuxt_component_4 as _ };
//# sourceMappingURL=TextEditor-8ba1b852.mjs.map
