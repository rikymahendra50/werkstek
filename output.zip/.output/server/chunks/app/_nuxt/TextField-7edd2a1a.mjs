import { useField, ErrorMessage } from 'vee-validate';
import { defineComponent, toRef, computed, mergeProps, unref, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';

const _sfc_main = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "TextField",
  __ssrInlineRender: true,
  props: {
    type: {
      default: "text"
    },
    modelValue: [String, Number],
    name: {
      type: String,
      required: true
    },
    step1: {
      type: String
    },
    min: {
      type: [Number, String]
    },
    max: {
      type: [Number, String]
    }
  },
  setup(__props) {
    const props = __props;
    const name = toRef(props, "name");
    const {
      value: inputValue,
      errorMessage,
      handleBlur,
      handleChange,
      meta
    } = useField(name, void 0, {
      syncVModel: true
    });
    const className = computed(() => {
      const arr = ["input"];
      if (!meta.touched) {
        return arr;
      }
      if (meta.touched && meta.valid) {
        arr.push("input-success");
      }
      if (!!errorMessage.value) {
        arr.push("input-error");
      }
      return arr.join(" ");
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeErrorMessage = ErrorMessage;
      _push(`<!--[--><input${ssrRenderAttrs(mergeProps({
        name: unref(name),
        id: unref(name),
        type: __props.type,
        value: unref(inputValue),
        class: unref(className)
      }, _ctx.$attrs, { step: __props.step1 }))}>`);
      _push(ssrRenderComponent(_component_VeeErrorMessage, {
        name: unref(name),
        class: "form-error-message text-red-600"
      }, null, _parent));
      _push(`<!--]-->`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Form/TextField.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as _ };
//# sourceMappingURL=TextField-7edd2a1a.mjs.map
