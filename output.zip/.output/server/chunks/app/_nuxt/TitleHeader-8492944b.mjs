import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import { h as _export_sfc } from '../server.mjs';

const _imports_0 = "" + publicAssetsURL("images/bg-title.svg");
const _sfc_main = {
  props: {
    title: {
      type: String,
      required: true
    },
    secondTitle: {
      type: String,
      required: true
    },
    description: {
      type: String,
      required: false
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-full flex items-center justify-center relative" }, _attrs))}><div class="flex flex-col justify-center items-center text-center py-10"><img${ssrRenderAttr("src", _imports_0)} alt="background-title" class="absolute w-[50%] lg:w-[30%] lg:bottom-10"><span class="text-primary text-[16px]">${ssrInterpolate($props.title)}</span><span class="font-semibold text-[25px] sm:text-[44px]">${$props.secondTitle}</span>`);
  if ($props.description) {
    _push(`<span class="text-sm md:w-[100%] text-center">${$props.description}</span>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/TitleHeader.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { __nuxt_component_0 as _, _imports_0 as a };
//# sourceMappingURL=TitleHeader-8492944b.mjs.map
