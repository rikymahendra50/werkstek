import { a as __nuxt_component_1 } from './BgBigGreen-554b8e3d.mjs';
import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import { i as _export_sfc } from '../server.mjs';

const _sfc_main = {
  props: {
    image: {
      type: String,
      required: true
    },
    title1: {
      type: String,
      required: true
    },
    title2: {
      type: String,
      required: true
    },
    description1: {
      type: String,
      required: true
    },
    description2: {
      type: String,
      required: true
    },
    buttonTitle1: {
      type: String,
      required: true
    },
    buttonLink1: {
      type: String,
      required: true
    },
    buttonTitle2: {
      type: String,
      required: false
    },
    buttonLink2: {
      type: String,
      required: false
    },
    useButton2: {
      type: Boolean,
      required: true
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_ButtonSM = __nuxt_component_1;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "py-10 relative flex items-center" }, _attrs))}><div class="grid md:grid-rows-1 md:grid-cols-2 z-10 px-3 sm:px-6 md:px-[70px] lg:px-[80px]"><div class="mx-auto flex items-center"><div class="grid gap-2"><div class="pr-4 lg:pr-10 grid gap-4"><p class="text-[16px] lg:text-[20px] text-[#1c1c1c]">${ssrInterpolate($props.title1)}</p><p class="text-[30px] lg:text-[40px] text-[#231E1F] font-bold">${ssrInterpolate($props.title2)}</p><p class="text-[12px] lg:text-[16px] text-[#1C1C1C] w-[90%] mt-2">${ssrInterpolate($props.description1)} <br><br> ${ssrInterpolate($props.description2)}</p></div><div class="flex md:grid lg:flex mt-5 lg:mt-10 gap-4 w-full min-[420px]:w-[70%] sm:w-[60%] md:w-[98%] lg:w-[90%]">`);
  if ($props.useButton2) {
    _push(ssrRenderComponent(_component_ButtonSM, {
      buttonTitle: $props.buttonTitle2,
      buttonLink: $props.buttonLink2
    }, null, _parent));
  } else {
    _push(`<!---->`);
  }
  _push(`</div></div></div><div class="grid relative mt-5 justify-items-end md:justify-items-center"><div class="z-10 w-[90%] min-[500px]:w-[80%] md:w-[100%]"><img${ssrRenderAttr("src", $props.image)} alt="image"></div></div></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/VerhuurdersHeader.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { __nuxt_component_0 as _ };
//# sourceMappingURL=VerhuurdersHeader-531d6c1f.mjs.map
