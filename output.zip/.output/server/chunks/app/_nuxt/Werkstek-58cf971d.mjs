import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { useSSRContext, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr } from 'vue/server-renderer';

const _imports_0 = "" + publicAssetsURL("images/logo-werstek-secondary.svg");
const _sfc_main = {
  __name: "Werkstek",
  __ssrInlineRender: true,
  props: {
    className: {
      type: String,
      default: "min-w-[160px] lg:min-w-[215px] min-h-[66px] flex items-center font-bold"
    }
  },
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: __props.className }, _attrs))}><img${ssrRenderAttr("src", _imports_0)} alt="logo"></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Werkstek.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = _sfc_main;

export { __nuxt_component_0 as _ };
//# sourceMappingURL=Werkstek-58cf971d.mjs.map
