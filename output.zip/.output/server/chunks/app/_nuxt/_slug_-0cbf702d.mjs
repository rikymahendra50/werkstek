import { _ as __nuxt_component_0 } from './BackButton-de34e53a.mjs';
import { Form } from 'vee-validate';
import { _ as _sfc_main$1 } from './TextField-7edd2a1a.mjs';
import { _ as __nuxt_component_3 } from './ButtonAddForm-aa118db7.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions, b as useRoute, a as useRouter, d as useHead } from '../server.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { computed, withAsyncContext, ref, unref, withCtx, createVNode, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-101122a4.mjs';
import { u as useSchema } from './useSchema-3365865c.mjs';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import './Icon-e394d28f.mjs';
import './config-aab100d3.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './asyncData-04c89180.mjs';
import 'zod';
import '@vee-validate/zod';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b;
    let __temp, __restore;
    const { loading, transformErrors } = useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const snackbar = useSnackbar();
    const route = useRoute();
    const slug = computed(() => route.params.slug);
    const router = useRouter();
    const { singleNameField } = useSchema();
    const { data: facilities, error } = ([__temp, __restore] = withAsyncContext(() => useFetch(
      `/admins/facilities/${slug.value}`,
      {
        method: "get",
        ...requestOptions
      },
      "$zcBp75TLWF"
    )), __temp = await __temp, __restore(), __temp);
    const selectedImage = ref();
    const formData = ref({
      name: (_b = (_a = facilities == null ? void 0 : facilities.value) == null ? void 0 : _a.data) == null ? void 0 : _b.name
    });
    async function onSubmit(values, ctx) {
      var _a3;
      var _a2, _b2, _c;
      loading.value = true;
      const object = { ...formData.value };
      const formDataT = new FormData();
      for (const item in object) {
        const objectItem = object[item];
        formDataT.append(item, objectItem);
      }
      if (selectedImage.value) {
        formDataT.append("icon", selectedImage.value);
      }
      const { error: error2, data } = await useFetch(
        `/admins/facilities/${slug.value}?_method=PUT`,
        {
          method: "POST",
          body: formDataT,
          ...requestOptions
        },
        "$xs5o1abTQV"
      );
      if (error2.value) {
        ctx.setErrors(transformErrors((_a2 = error2 == null ? void 0 : error2.value) == null ? void 0 : _a2.data));
        snackbar.add({
          type: "error",
          text: (_a3 = (_c = (_b2 = error2.value) == null ? void 0 : _b2.data) == null ? void 0 : _c.message) != null ? _a3 : "Something went wrong"
        });
      } else if (data.value) {
        snackbar.add({
          type: "success",
          text: "Edit Facility Success"
        });
        router.push("/admin/facility");
      }
      loading.value = false;
    }
    useHead({
      title: "Edit Facility"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CompAdminBackButton = __nuxt_component_0;
      const _component_VeeForm = Form;
      const _component_FormTextField = _sfc_main$1;
      const _component_CompAdminButtonAddForm = __nuxt_component_3;
      _push(`<section${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_CompAdminBackButton, {
        link: "facility",
        linkTitle: "Edit Facility"
      }, null, _parent));
      _push(ssrRenderComponent(_component_VeeForm, {
        onSubmit,
        "validation-schema": unref(singleNameField),
        class: "grid grid-cols-2"
      }, {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 gap-3"${_scopeId}><div class="flex flex-col gap-2"${_scopeId}><label for="name"${_scopeId}>Edit Facility</label>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "name",
              name: "name",
              modelValue: unref(formData).name,
              "onUpdate:modelValue": ($event) => unref(formData).name = $event,
              placeholder: "Input Facility Name",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex justify-end mt-5"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_CompAdminButtonAddForm, {
              buttonName: "Edit Facility",
              isLoading: unref(loading)
            }, null, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 gap-3" }, [
                createVNode("div", { class: "flex flex-col gap-2" }, [
                  createVNode("label", { for: "name" }, "Edit Facility"),
                  createVNode(_component_FormTextField, {
                    id: "name",
                    name: "name",
                    modelValue: unref(formData).name,
                    "onUpdate:modelValue": ($event) => unref(formData).name = $event,
                    placeholder: "Input Facility Name",
                    class: "input-bordered",
                    autocomplete: "on"
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode("div", { class: "flex justify-end mt-5" }, [
                  createVNode(_component_CompAdminButtonAddForm, {
                    buttonName: "Edit Facility",
                    isLoading: unref(loading)
                  }, null, 8, ["isLoading"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/facility/edit/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-0cbf702d.mjs.map
