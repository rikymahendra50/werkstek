import { _ as __nuxt_component_0 } from './BackButton-de34e53a.mjs';
import { Form, Field, ErrorMessage } from 'vee-validate';
import { _ as __nuxt_component_2 } from './BlogImageCrop-e341be04.mjs';
import { _ as _sfc_main$1 } from './TextField-7edd2a1a.mjs';
import { _ as __nuxt_component_3 } from './ButtonAddForm-aa118db7.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions, b as useRoute, a as useRouter, d as useHead } from '../server.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { computed, ref, withAsyncContext, mergeProps, unref, withCtx, isRef, createVNode, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-101122a4.mjs';
import { u as useSchema } from './useSchema-3365865c.mjs';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import './Icon-e394d28f.mjs';
import './config-aab100d3.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import './client-only-29ef7f45.mjs';
import './index-c7d55092.mjs';
import './index-73677d9a.mjs';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './asyncData-04c89180.mjs';
import 'zod';
import '@vee-validate/zod';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b, _c, _d;
    let __temp, __restore;
    const { loading, transformErrors } = useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const snackbar = useSnackbar();
    const route = useRoute();
    const router = useRouter();
    const { editAuthorSchema } = useSchema();
    const slug = computed(() => route.params.slug);
    ref(null);
    const { error, data } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/authors/${slug.value}`, {
      method: "get",
      ...requestOptions
    }, "$JmDZpEDyS9")), __temp = await __temp, __restore(), __temp);
    const formData = ref({
      name: (_b = (_a = data == null ? void 0 : data.value) == null ? void 0 : _a.data) == null ? void 0 : _b.name,
      description: (_d = (_c = data == null ? void 0 : data.value) == null ? void 0 : _c.data) == null ? void 0 : _d.description
    });
    ref();
    const selectedImage = ref();
    async function onSubmit(values, ctx) {
      var _a3;
      var _a2, _b2, _c2;
      loading.value = true;
      const object = { ...formData.value };
      const formDataT = new FormData();
      for (const item in object) {
        const objectItem = object[item];
        formDataT.append(item, objectItem);
      }
      if (selectedImage.value) {
        formDataT.append("image", selectedImage.value);
      }
      const { error: error2, data: data2 } = await useFetch(
        `/admins/authors/${slug.value}?_method=PUT`,
        {
          method: "post",
          body: formDataT,
          ...requestOptions
        },
        "$4eypae2JQc"
      );
      if (error2.value) {
        ctx.setErrors(transformErrors((_a2 = error2 == null ? void 0 : error2.value) == null ? void 0 : _a2.data));
        snackbar.add({
          type: "error",
          text: (_a3 = (_c2 = (_b2 = error2.value) == null ? void 0 : _b2.data) == null ? void 0 : _c2.message) != null ? _a3 : "Something went wrong"
        });
      } else if (data2.value) {
        snackbar.add({
          type: "success",
          text: "Edit Author Success"
        });
        router.push("/admin/author");
      }
      loading.value = false;
    }
    useHead({
      title: "Add Author"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CompAdminBackButton = __nuxt_component_0;
      const _component_VeeForm = Form;
      const _component_VeeField = Field;
      const _component_BlogImageCrop = __nuxt_component_2;
      const _component_VeeErrorMessage = ErrorMessage;
      const _component_FormTextField = _sfc_main$1;
      const _component_CompAdminButtonAddForm = __nuxt_component_3;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "overflow-auto" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_CompAdminBackButton, {
        link: "author",
        linkTitle: "Edit Author"
      }, null, _parent));
      _push(`<div class="grid grid-cols-2">`);
      _push(ssrRenderComponent(_component_VeeForm, {
        onSubmit,
        "validation-schema": unref(editAuthorSchema)
      }, {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          var _a2, _b2, _c2, _d2;
          if (_push2) {
            _push2(`<div class="grid mt-10 p-3 gap-2"${_scopeId}><div${_scopeId}><div class="hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              type: "file",
              name: "image",
              id: "image",
              modelValue: unref(selectedImage),
              "onUpdate:modelValue": ($event) => isRef(selectedImage) ? selectedImage.value = $event : null
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_BlogImageCrop, {
              loading: unref(loading),
              existingimage: (_b2 = (_a2 = unref(data)) == null ? void 0 : _a2.data) == null ? void 0 : _b2.image,
              modelValue: unref(selectedImage),
              "onUpdate:modelValue": ($event) => isRef(selectedImage) ? selectedImage.value = $event : null
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "image",
              class: "text-red-500"
            }, null, _parent2, _scopeId));
            _push2(`</div><label for="name"${_scopeId}>Name</label>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "name",
              name: "name",
              modelValue: unref(formData).name,
              "onUpdate:modelValue": ($event) => unref(formData).name = $event,
              placeholder: "Name",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`<label for="description"${_scopeId}>Description</label>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "description",
              name: "description",
              modelValue: unref(formData).description,
              "onUpdate:modelValue": ($event) => unref(formData).description = $event,
              placeholder: "Description",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex justify-end mt-5"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_CompAdminButtonAddForm, {
              buttonName: "Edit Author",
              isLoading: unref(loading)
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "grid mt-10 p-3 gap-2" }, [
                createVNode("div", null, [
                  createVNode("div", { class: "hidden" }, [
                    createVNode(_component_VeeField, {
                      type: "file",
                      name: "image",
                      id: "image",
                      modelValue: unref(selectedImage),
                      "onUpdate:modelValue": ($event) => isRef(selectedImage) ? selectedImage.value = $event : null
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  createVNode(_component_BlogImageCrop, {
                    loading: unref(loading),
                    existingimage: (_d2 = (_c2 = unref(data)) == null ? void 0 : _c2.data) == null ? void 0 : _d2.image,
                    modelValue: unref(selectedImage),
                    "onUpdate:modelValue": ($event) => isRef(selectedImage) ? selectedImage.value = $event : null
                  }, null, 8, ["loading", "existingimage", "modelValue", "onUpdate:modelValue"]),
                  createVNode(_component_VeeErrorMessage, {
                    name: "image",
                    class: "text-red-500"
                  })
                ]),
                createVNode("label", { for: "name" }, "Name"),
                createVNode(_component_FormTextField, {
                  id: "name",
                  name: "name",
                  modelValue: unref(formData).name,
                  "onUpdate:modelValue": ($event) => unref(formData).name = $event,
                  placeholder: "Name",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                createVNode("label", { for: "description" }, "Description"),
                createVNode(_component_FormTextField, {
                  id: "description",
                  name: "description",
                  modelValue: unref(formData).description,
                  "onUpdate:modelValue": ($event) => unref(formData).description = $event,
                  placeholder: "Description",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "flex justify-end mt-5" }, [
                createVNode(_component_CompAdminButtonAddForm, {
                  buttonName: "Edit Author",
                  isLoading: unref(loading)
                }, null, 8, ["isLoading"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/author/edit/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-0dec9cbf.mjs.map
