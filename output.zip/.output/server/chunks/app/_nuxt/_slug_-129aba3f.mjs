import { _ as __nuxt_component_0 } from './BackButton-454ea1e4.mjs';
import { Form, Field, ErrorMessage } from 'vee-validate';
import { _ as _sfc_main$1 } from './TextField-7edd2a1a.mjs';
import { _ as __nuxt_component_4 } from './TextEditor-0bf2d701.mjs';
import { _ as __nuxt_component_6 } from './MapsTest-40b91c11.mjs';
import { _ as __nuxt_component_3 } from './ButtonAddForm-aa118db7.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { computed, withAsyncContext, ref, unref, withCtx, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, createTextVNode, useSSRContext } from 'vue';
import { u as useRouter, a as useRoute, b as useFetch, d as useHead } from '../server.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { u as useSchema } from './useSchema-3365865c.mjs';
import { ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import './Icon-7d2a1472.mjs';
import './config-54e8ad1b.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import '@tiptap/vue-3';
import '@tiptap/starter-kit';
import 'zod';
import '@vee-validate/zod';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s;
    let __temp, __restore;
    const { loading, transformErrors } = useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const router = useRouter();
    const snackbar = useSnackbar();
    const route = useRoute();
    const slug = computed(() => route.params.slug);
    const { formInput } = useSchema();
    const { data: dataSlug } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/products/${slug.value}`, {
      method: "get",
      ...requestOptions
    }, "$dh4AVuFxDg")), __temp = await __temp, __restore(), __temp);
    const { data: location } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/locations`, {
      method: "get",
      ...requestOptions
    }, "$4qDzCIad1Q")), __temp = await __temp, __restore(), __temp);
    const { data: type } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/type-list`, {
      method: "get",
      ...requestOptions
    }, "$FWKwssTQJx")), __temp = await __temp, __restore(), __temp);
    const { data: levelType } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/level-types`, {
      method: "get",
      ...requestOptions
    }, "$D89Nau8ZKI")), __temp = await __temp, __restore(), __temp);
    const { data: facilities, error } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/facilities`, {
      method: "get",
      ...requestOptions
    }, "$RISvrKQApi")), __temp = await __temp, __restore(), __temp);
    const { data: dataPrivilages } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/categories`, {
      method: "get",
      ...requestOptions
    }, "$3rxQXS7z5I")), __temp = await __temp, __restore(), __temp);
    const AllDataSlug = ref(dataSlug == null ? void 0 : dataSlug.value.data);
    const privilegesArray = AllDataSlug == null ? void 0 : AllDataSlug.value.privileges.map(
      (item) => item.privilege
    );
    const facilityArray = AllDataSlug == null ? void 0 : AllDataSlug.value.facility.map(
      (item) => item.facility.id
    );
    const dataIsSaleAble = ref([
      {
        id: 1,
        name: "Yes",
        value: 1
      },
      {
        id: 2,
        name: "No",
        value: 0
      }
    ]);
    const formData = ref({
      name: (_a = AllDataSlug == null ? void 0 : AllDataSlug.value) == null ? void 0 : _a.name,
      postcode: (_b = AllDataSlug == null ? void 0 : AllDataSlug.value) == null ? void 0 : _b.postcode,
      address: (_c = AllDataSlug == null ? void 0 : AllDataSlug.value) == null ? void 0 : _c.address,
      country: (_d = AllDataSlug == null ? void 0 : AllDataSlug.value) == null ? void 0 : _d.country,
      description: (_e = AllDataSlug == null ? void 0 : AllDataSlug.value) == null ? void 0 : _e.description,
      email: (_f = AllDataSlug == null ? void 0 : AllDataSlug.value) == null ? void 0 : _f.email,
      phone_number: (_g = AllDataSlug == null ? void 0 : AllDataSlug.value) == null ? void 0 : _g.phone_number,
      latitude: (_h = AllDataSlug == null ? void 0 : AllDataSlug.value) == null ? void 0 : _h.latitude,
      longitude: (_i = AllDataSlug == null ? void 0 : AllDataSlug.value) == null ? void 0 : _i.longitude,
      price: (_j = AllDataSlug == null ? void 0 : AllDataSlug.value) == null ? void 0 : _j.price,
      rent_type: (_k = AllDataSlug == null ? void 0 : AllDataSlug.value) == null ? void 0 : _k.rent_type,
      area_size: (_l = AllDataSlug == null ? void 0 : AllDataSlug.value) == null ? void 0 : _l.area_size,
      location_id: (_n = (_m = AllDataSlug == null ? void 0 : AllDataSlug.value) == null ? void 0 : _m.location) == null ? void 0 : _n.id,
      type_id: (_p = (_o = AllDataSlug == null ? void 0 : AllDataSlug.value) == null ? void 0 : _o.type) == null ? void 0 : _p.id,
      level_type_id: (_r = (_q = AllDataSlug == null ? void 0 : AllDataSlug.value) == null ? void 0 : _q.level_type) == null ? void 0 : _r.id,
      is_saleable: (_s = AllDataSlug == null ? void 0 : AllDataSlug.value) == null ? void 0 : _s.is_saleable,
      product_facilities: facilityArray.map((facility) => ({
        facility_id: facility
      })),
      product_privileges: privilegesArray.map((privilege) => ({
        privilege
      })),
      rating: AllDataSlug.value.rating
    });
    async function onSubmit(values, ctx) {
      var _a3;
      var _a2, _b2, _c2;
      loading.value = true;
      const { data, error: error2 } = await useFetch(`/admins/products/${slug.value}`, {
        method: "put",
        body: JSON.stringify(formData.value),
        ...requestOptions
      }, "$vFpn73lEkS");
      if (error2.value) {
        ctx.setErrors(transformErrors((_a2 = error2.value) == null ? void 0 : _a2.data));
        snackbar.add({
          type: "error",
          text: (_a3 = (_c2 = (_b2 = error2.value) == null ? void 0 : _b2.data) == null ? void 0 : _c2.message) != null ? _a3 : "Something went wrong"
        });
      } else {
        snackbar.add({
          type: "success",
          text: "Success Edit Property"
        });
        router.push("/admin/onze-locaties");
      }
      loading.value = false;
    }
    useHead({
      title: "Edit Property"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CompAdminBackButton = __nuxt_component_0;
      const _component_VeeForm = Form;
      const _component_FormTextField = _sfc_main$1;
      const _component_VeeField = Field;
      const _component_FormTextEditor = __nuxt_component_4;
      const _component_VeeErrorMessage = ErrorMessage;
      const _component_MapsTest = __nuxt_component_6;
      const _component_CompAdminButtonAddForm = __nuxt_component_3;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_CompAdminBackButton, {
        link: "onze-locaties",
        linkTitle: "Edit Property"
      }, null, _parent));
      _push(`<div class="overflow-y-auto grid md:grid-cols-2">`);
      _push(ssrRenderComponent(_component_VeeForm, {
        onSubmit,
        class: "text-[12px] md:text-[16px] flex-col flex items-center px-3 lg:px-8",
        "validation-schema": unref(formInput)
      }, {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          var _a2, _b2;
          if (_push2) {
            _push2(`<div class="flex flex-col w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="name"${_scopeId}>Name</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "name",
              name: "name",
              modelValue: unref(formData).name,
              "onUpdate:modelValue": ($event) => unref(formData).name = $event,
              placeholder: "Name",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-5 w-full"${_scopeId}><span${_scopeId}>Description</span><div class="hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              name: "body",
              modelValue: unref(formData).description,
              "onUpdate:modelValue": ($event) => unref(formData).description = $event
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_FormTextEditor, {
              modelValue: unref(formData).description,
              "onUpdate:modelValue": ($event) => unref(formData).description = $event,
              "is-error": !!errors.body
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "body",
              class: "text-red-500"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="email"${_scopeId}>Email</label></div>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "email",
              name: "email",
              modelValue: unref(formData).email,
              "onUpdate:modelValue": ($event) => unref(formData).email = $event,
              type: "text",
              class: "input input-bordered w-full input-md",
              placeholder: "Email",
              autocomplete: "off"
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "email",
              class: "text-red-500"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="postcode"${_scopeId}>Postcode</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "postcode",
              name: "postcode",
              modelValue: unref(formData).postcode,
              "onUpdate:modelValue": ($event) => unref(formData).postcode = $event,
              placeholder: "ex:43121",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="address"${_scopeId}>Address</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "address",
              name: "address",
              modelValue: unref(formData).address,
              "onUpdate:modelValue": ($event) => unref(formData).address = $event,
              placeholder: "Address",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="country"${_scopeId}>Country</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "country",
              name: "country",
              modelValue: unref(formData).country,
              "onUpdate:modelValue": ($event) => unref(formData).country = $event,
              placeholder: "ex:Nederland",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="phone"${_scopeId}>Phone Number</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "phone",
              name: "phone",
              type: "text",
              modelValue: unref(formData).phone_number,
              "onUpdate:modelValue": ($event) => unref(formData).phone_number = $event,
              placeholder: "ex:6221210291",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="border-2 w-full p-3 rounded-md"${_scopeId}><div${_scopeId}><p class="mb-3"${_scopeId}> Please find and click the desired location to get the coordinate value. </p>`);
            _push2(ssrRenderComponent(_component_MapsTest, {
              latitude: unref(formData).latitude,
              "onUpdate:latitude": ($event) => unref(formData).latitude = $event,
              longitude: unref(formData).longitude,
              "onUpdate:longitude": ($event) => unref(formData).longitude = $event
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="latitude"${_scopeId}>Latitude</label></div>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "latitude",
              name: "latitude",
              type: "text",
              modelValue: unref(formData).latitude,
              "onUpdate:modelValue": ($event) => unref(formData).latitude = $event,
              placeholder: "ex:51.9934345296239",
              class: "input-bordered input-disabled input",
              autocomplete: "on",
              disabled: ""
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="longitude"${_scopeId}>Longitude</label></div>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "longitude",
              name: "longitude",
              type: "text",
              modelValue: unref(formData).longitude,
              "onUpdate:modelValue": ($event) => unref(formData).longitude = $event,
              placeholder: "ex:5.5162370519396349",
              class: "input-bordered input-disabled input",
              autocomplete: "on",
              disabled: ""
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "latitude",
              class: "text-red-500"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="price"${_scopeId}>Price</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "price",
              name: "price",
              type: "number",
              modelValue: unref(formData).price,
              "onUpdate:modelValue": ($event) => unref(formData).price = $event,
              placeholder: "ex:80",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="renttype"${_scopeId}>Rent Type</label></div>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "renttype",
              name: "renttype",
              as: "select",
              modelValue: unref(formData).rent_type,
              "onUpdate:modelValue": ($event) => unref(formData).rent_type = $event,
              class: "select select-bordered w-full",
              placeholder: "renttype",
              autocomplete: "renttype"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<option disabled selected${_scopeId2}>Rent Type</option><option value="monthly"${_scopeId2}>Montly</option><option value="yearly"${_scopeId2}>Yearly</option>`);
                } else {
                  return [
                    createVNode("option", {
                      disabled: "",
                      selected: ""
                    }, "Rent Type"),
                    createVNode("option", { value: "monthly" }, "Montly"),
                    createVNode("option", { value: "yearly" }, "Yearly")
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "renttype",
              class: "form-error-message text-red-600"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="areasize"${_scopeId}>Area Size</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "areasize",
              name: "areasize",
              type: "number",
              modelValue: unref(formData).area_size,
              "onUpdate:modelValue": ($event) => unref(formData).area_size = $event,
              placeholder: "ex:80",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="rating"${_scopeId}>Rating</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "rating",
              name: "rating",
              type: "number",
              modelValue: unref(formData).rating,
              "onUpdate:modelValue": ($event) => unref(formData).rating = $event,
              placeholder: "ex:10",
              class: "input-bordered",
              autocomplete: "off"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="location"${_scopeId}>Location</label></div>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "location",
              name: "location",
              as: "select",
              modelValue: unref(formData).location_id,
              "onUpdate:modelValue": ($event) => unref(formData).location_id = $event,
              class: "select select-bordered w-full",
              placeholder: "location",
              autocomplete: "location"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                var _a3, _b3;
                if (_push3) {
                  _push3(`<option disabled selected${_scopeId2}>Location</option><!--[-->`);
                  ssrRenderList((_a3 = unref(location)) == null ? void 0 : _a3.data, (item) => {
                    _push3(`<option${ssrRenderAttr("value", item.id)}${_scopeId2}>${ssrInterpolate(item.name)}</option>`);
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    createVNode("option", {
                      disabled: "",
                      selected: ""
                    }, "Location"),
                    (openBlock(true), createBlock(Fragment, null, renderList((_b3 = unref(location)) == null ? void 0 : _b3.data, (item) => {
                      return openBlock(), createBlock("option", {
                        value: item.id
                      }, toDisplayString(item.name), 9, ["value"]);
                    }), 256))
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "location",
              class: "form-error-message text-red-600"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="type"${_scopeId}>Type</label></div>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "type",
              name: "type",
              as: "select",
              modelValue: unref(formData).type_id,
              "onUpdate:modelValue": ($event) => unref(formData).type_id = $event,
              class: "select select-bordered w-full",
              placeholder: "type",
              autocomplete: "off"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<option disabled selected${_scopeId2}>Type</option><!--[-->`);
                  ssrRenderList(unref(type), (item) => {
                    _push3(`<option${ssrRenderAttr("value", item.id)}${_scopeId2}>${ssrInterpolate(item.name)}</option>`);
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    createVNode("option", {
                      disabled: "",
                      selected: ""
                    }, "Type"),
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(type), (item) => {
                      return openBlock(), createBlock("option", {
                        value: item.id
                      }, toDisplayString(item.name), 9, ["value"]);
                    }), 256))
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "type",
              class: "form-error-message text-red-600"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="leveltype"${_scopeId}>Level Type</label></div>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "leveltype",
              name: "leveltype",
              as: "select",
              modelValue: unref(formData).level_type_id,
              "onUpdate:modelValue": ($event) => unref(formData).level_type_id = $event,
              class: "select select-bordered w-full",
              placeholder: "type",
              autocomplete: "type"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                var _a3, _b3;
                if (_push3) {
                  _push3(`<option disabled selected${_scopeId2}>Level Type</option><!--[-->`);
                  ssrRenderList((_a3 = unref(levelType)) == null ? void 0 : _a3.data, (item) => {
                    _push3(`<option${ssrRenderAttr("value", item.id)}${_scopeId2}>${ssrInterpolate(item.name)}</option>`);
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    createVNode("option", {
                      disabled: "",
                      selected: ""
                    }, "Level Type"),
                    (openBlock(true), createBlock(Fragment, null, renderList((_b3 = unref(levelType)) == null ? void 0 : _b3.data, (item) => {
                      return openBlock(), createBlock("option", {
                        value: item.id
                      }, toDisplayString(item.name), 9, ["value"]);
                    }), 256))
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="grid gap-2"${_scopeId}><div class="flex items-center"${_scopeId}><span${_scopeId}>Facilities</span></div><!--[-->`);
            ssrRenderList(unref(facilities).data, (item) => {
              _push2(`<label class="checkbox-label flex gap-2"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_VeeField, {
                id: `facilities + ${item.id}`,
                name: `facilities + ${item.name}`,
                type: "checkbox",
                value: { facility_id: item.id },
                modelValue: unref(formData).product_facilities,
                "onUpdate:modelValue": ($event) => unref(formData).product_facilities = $event,
                placeholder: "facilities",
                autocomplete: "facilities"
              }, null, _parent2, _scopeId));
              _push2(` ${ssrInterpolate(item.name)}</label>`);
            });
            _push2(`<!--]--></div></div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="grid gap-2"${_scopeId}><div class="flex items-center"${_scopeId}><span${_scopeId}>Privileges</span></div><!--[-->`);
            ssrRenderList((_a2 = unref(dataPrivilages)) == null ? void 0 : _a2.data, (item) => {
              _push2(`<label class="checkbox-label flex gap-2"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_VeeField, {
                id: `privileges + ${item.id}`,
                name: `privileges + ${item.name}`,
                type: "checkbox",
                value: { privilege: item.name },
                modelValue: unref(formData).product_privileges,
                "onUpdate:modelValue": ($event) => unref(formData).product_privileges = $event,
                placeholder: "privileges",
                autocomplete: "privileges"
              }, null, _parent2, _scopeId));
              _push2(` ${ssrInterpolate(item.name)}</label>`);
            });
            _push2(`<!--]--></div></div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="grid gap-2"${_scopeId}><div class="flex items-center"${_scopeId}><span${_scopeId}>Is Saleable</span></div><!--[-->`);
            ssrRenderList(unref(dataIsSaleAble), (item) => {
              _push2(`<label class="checkbox-label flex gap-2"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_VeeField, {
                id: `saleAble + ${item.id}`,
                name: `saleAble + ${item.name}`,
                type: "radio",
                value: item.value,
                modelValue: unref(formData).is_saleable,
                "onUpdate:modelValue": ($event) => unref(formData).is_saleable = $event,
                placeholder: "privileges",
                autocomplete: "privileges"
              }, null, _parent2, _scopeId));
              _push2(` ${ssrInterpolate(item.name)}</label>`);
            });
            _push2(`<!--]--></div></div><div class="w-full flex justify-end"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_CompAdminButtonAddForm, {
              buttonName: "Edit Property",
              isLoading: unref(loading)
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "name" }, "Name")
                ]),
                createVNode(_component_FormTextField, {
                  id: "name",
                  name: "name",
                  modelValue: unref(formData).name,
                  "onUpdate:modelValue": ($event) => unref(formData).name = $event,
                  placeholder: "Name",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "flex flex-col my-5 w-full" }, [
                createVNode("span", null, "Description"),
                createVNode("div", { class: "hidden" }, [
                  createVNode(_component_VeeField, {
                    name: "body",
                    modelValue: unref(formData).description,
                    "onUpdate:modelValue": ($event) => unref(formData).description = $event
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode(_component_FormTextEditor, {
                  modelValue: unref(formData).description,
                  "onUpdate:modelValue": ($event) => unref(formData).description = $event,
                  "is-error": !!errors.body
                }, null, 8, ["modelValue", "onUpdate:modelValue", "is-error"]),
                createVNode(_component_VeeErrorMessage, {
                  name: "body",
                  class: "text-red-500"
                })
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "email" }, "Email")
                ]),
                createVNode(_component_VeeField, {
                  id: "email",
                  name: "email",
                  modelValue: unref(formData).email,
                  "onUpdate:modelValue": ($event) => unref(formData).email = $event,
                  type: "text",
                  class: "input input-bordered w-full input-md",
                  placeholder: "Email",
                  autocomplete: "off"
                }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                createVNode(_component_VeeErrorMessage, {
                  name: "email",
                  class: "text-red-500"
                })
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "postcode" }, "Postcode")
                ]),
                createVNode(_component_FormTextField, {
                  id: "postcode",
                  name: "postcode",
                  modelValue: unref(formData).postcode,
                  "onUpdate:modelValue": ($event) => unref(formData).postcode = $event,
                  placeholder: "ex:43121",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "address" }, "Address")
                ]),
                createVNode(_component_FormTextField, {
                  id: "address",
                  name: "address",
                  modelValue: unref(formData).address,
                  "onUpdate:modelValue": ($event) => unref(formData).address = $event,
                  placeholder: "Address",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "country" }, "Country")
                ]),
                createVNode(_component_FormTextField, {
                  id: "country",
                  name: "country",
                  modelValue: unref(formData).country,
                  "onUpdate:modelValue": ($event) => unref(formData).country = $event,
                  placeholder: "ex:Nederland",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "phone" }, "Phone Number")
                ]),
                createVNode(_component_FormTextField, {
                  id: "phone",
                  name: "phone",
                  type: "text",
                  modelValue: unref(formData).phone_number,
                  "onUpdate:modelValue": ($event) => unref(formData).phone_number = $event,
                  placeholder: "ex:6221210291",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "border-2 w-full p-3 rounded-md" }, [
                createVNode("div", null, [
                  createVNode("p", { class: "mb-3" }, " Please find and click the desired location to get the coordinate value. "),
                  createVNode(_component_MapsTest, {
                    latitude: unref(formData).latitude,
                    "onUpdate:latitude": ($event) => unref(formData).latitude = $event,
                    longitude: unref(formData).longitude,
                    "onUpdate:longitude": ($event) => unref(formData).longitude = $event
                  }, null, 8, ["latitude", "onUpdate:latitude", "longitude", "onUpdate:longitude"])
                ]),
                createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                  createVNode("div", { class: "flex items-center" }, [
                    createVNode("label", { for: "latitude" }, "Latitude")
                  ]),
                  createVNode(_component_VeeField, {
                    id: "latitude",
                    name: "latitude",
                    type: "text",
                    modelValue: unref(formData).latitude,
                    "onUpdate:modelValue": ($event) => unref(formData).latitude = $event,
                    placeholder: "ex:51.9934345296239",
                    class: "input-bordered input-disabled input",
                    autocomplete: "on",
                    disabled: ""
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                  createVNode("div", { class: "flex items-center" }, [
                    createVNode("label", { for: "longitude" }, "Longitude")
                  ]),
                  createVNode(_component_VeeField, {
                    id: "longitude",
                    name: "longitude",
                    type: "text",
                    modelValue: unref(formData).longitude,
                    "onUpdate:modelValue": ($event) => unref(formData).longitude = $event,
                    placeholder: "ex:5.5162370519396349",
                    class: "input-bordered input-disabled input",
                    autocomplete: "on",
                    disabled: ""
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode(_component_VeeErrorMessage, {
                  name: "latitude",
                  class: "text-red-500"
                })
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "price" }, "Price")
                ]),
                createVNode(_component_FormTextField, {
                  id: "price",
                  name: "price",
                  type: "number",
                  modelValue: unref(formData).price,
                  "onUpdate:modelValue": ($event) => unref(formData).price = $event,
                  placeholder: "ex:80",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "renttype" }, "Rent Type")
                ]),
                createVNode(_component_VeeField, {
                  id: "renttype",
                  name: "renttype",
                  as: "select",
                  modelValue: unref(formData).rent_type,
                  "onUpdate:modelValue": ($event) => unref(formData).rent_type = $event,
                  class: "select select-bordered w-full",
                  placeholder: "renttype",
                  autocomplete: "renttype"
                }, {
                  default: withCtx(() => [
                    createVNode("option", {
                      disabled: "",
                      selected: ""
                    }, "Rent Type"),
                    createVNode("option", { value: "monthly" }, "Montly"),
                    createVNode("option", { value: "yearly" }, "Yearly")
                  ]),
                  _: 1
                }, 8, ["modelValue", "onUpdate:modelValue"]),
                createVNode(_component_VeeErrorMessage, {
                  name: "renttype",
                  class: "form-error-message text-red-600"
                })
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "areasize" }, "Area Size")
                ]),
                createVNode(_component_FormTextField, {
                  id: "areasize",
                  name: "areasize",
                  type: "number",
                  modelValue: unref(formData).area_size,
                  "onUpdate:modelValue": ($event) => unref(formData).area_size = $event,
                  placeholder: "ex:80",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "rating" }, "Rating")
                ]),
                createVNode(_component_FormTextField, {
                  id: "rating",
                  name: "rating",
                  type: "number",
                  modelValue: unref(formData).rating,
                  "onUpdate:modelValue": ($event) => unref(formData).rating = $event,
                  placeholder: "ex:10",
                  class: "input-bordered",
                  autocomplete: "off"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "location" }, "Location")
                ]),
                createVNode(_component_VeeField, {
                  id: "location",
                  name: "location",
                  as: "select",
                  modelValue: unref(formData).location_id,
                  "onUpdate:modelValue": ($event) => unref(formData).location_id = $event,
                  class: "select select-bordered w-full",
                  placeholder: "location",
                  autocomplete: "location"
                }, {
                  default: withCtx(() => {
                    var _a3;
                    return [
                      createVNode("option", {
                        disabled: "",
                        selected: ""
                      }, "Location"),
                      (openBlock(true), createBlock(Fragment, null, renderList((_a3 = unref(location)) == null ? void 0 : _a3.data, (item) => {
                        return openBlock(), createBlock("option", {
                          value: item.id
                        }, toDisplayString(item.name), 9, ["value"]);
                      }), 256))
                    ];
                  }),
                  _: 1
                }, 8, ["modelValue", "onUpdate:modelValue"]),
                createVNode(_component_VeeErrorMessage, {
                  name: "location",
                  class: "form-error-message text-red-600"
                })
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "type" }, "Type")
                ]),
                createVNode(_component_VeeField, {
                  id: "type",
                  name: "type",
                  as: "select",
                  modelValue: unref(formData).type_id,
                  "onUpdate:modelValue": ($event) => unref(formData).type_id = $event,
                  class: "select select-bordered w-full",
                  placeholder: "type",
                  autocomplete: "off"
                }, {
                  default: withCtx(() => [
                    createVNode("option", {
                      disabled: "",
                      selected: ""
                    }, "Type"),
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(type), (item) => {
                      return openBlock(), createBlock("option", {
                        value: item.id
                      }, toDisplayString(item.name), 9, ["value"]);
                    }), 256))
                  ]),
                  _: 1
                }, 8, ["modelValue", "onUpdate:modelValue"]),
                createVNode(_component_VeeErrorMessage, {
                  name: "type",
                  class: "form-error-message text-red-600"
                })
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "leveltype" }, "Level Type")
                ]),
                createVNode(_component_VeeField, {
                  id: "leveltype",
                  name: "leveltype",
                  as: "select",
                  modelValue: unref(formData).level_type_id,
                  "onUpdate:modelValue": ($event) => unref(formData).level_type_id = $event,
                  class: "select select-bordered w-full",
                  placeholder: "type",
                  autocomplete: "type"
                }, {
                  default: withCtx(() => {
                    var _a3;
                    return [
                      createVNode("option", {
                        disabled: "",
                        selected: ""
                      }, "Level Type"),
                      (openBlock(true), createBlock(Fragment, null, renderList((_a3 = unref(levelType)) == null ? void 0 : _a3.data, (item) => {
                        return openBlock(), createBlock("option", {
                          value: item.id
                        }, toDisplayString(item.name), 9, ["value"]);
                      }), 256))
                    ];
                  }),
                  _: 1
                }, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "grid gap-2" }, [
                  createVNode("div", { class: "flex items-center" }, [
                    createVNode("span", null, "Facilities")
                  ]),
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(facilities).data, (item) => {
                    return openBlock(), createBlock("label", {
                      key: item.id,
                      class: "checkbox-label flex gap-2"
                    }, [
                      createVNode(_component_VeeField, {
                        id: `facilities + ${item.id}`,
                        name: `facilities + ${item.name}`,
                        type: "checkbox",
                        value: { facility_id: item.id },
                        modelValue: unref(formData).product_facilities,
                        "onUpdate:modelValue": ($event) => unref(formData).product_facilities = $event,
                        placeholder: "facilities",
                        autocomplete: "facilities"
                      }, null, 8, ["id", "name", "value", "modelValue", "onUpdate:modelValue"]),
                      createTextVNode(" " + toDisplayString(item.name), 1)
                    ]);
                  }), 128))
                ])
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "grid gap-2" }, [
                  createVNode("div", { class: "flex items-center" }, [
                    createVNode("span", null, "Privileges")
                  ]),
                  (openBlock(true), createBlock(Fragment, null, renderList((_b2 = unref(dataPrivilages)) == null ? void 0 : _b2.data, (item) => {
                    return openBlock(), createBlock("label", {
                      key: item.id,
                      class: "checkbox-label flex gap-2"
                    }, [
                      createVNode(_component_VeeField, {
                        id: `privileges + ${item.id}`,
                        name: `privileges + ${item.name}`,
                        type: "checkbox",
                        value: { privilege: item.name },
                        modelValue: unref(formData).product_privileges,
                        "onUpdate:modelValue": ($event) => unref(formData).product_privileges = $event,
                        placeholder: "privileges",
                        autocomplete: "privileges"
                      }, null, 8, ["id", "name", "value", "modelValue", "onUpdate:modelValue"]),
                      createTextVNode(" " + toDisplayString(item.name), 1)
                    ]);
                  }), 128))
                ])
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "grid gap-2" }, [
                  createVNode("div", { class: "flex items-center" }, [
                    createVNode("span", null, "Is Saleable")
                  ]),
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(dataIsSaleAble), (item) => {
                    return openBlock(), createBlock("label", {
                      key: item.id,
                      class: "checkbox-label flex gap-2"
                    }, [
                      createVNode(_component_VeeField, {
                        id: `saleAble + ${item.id}`,
                        name: `saleAble + ${item.name}`,
                        type: "radio",
                        value: item.value,
                        modelValue: unref(formData).is_saleable,
                        "onUpdate:modelValue": ($event) => unref(formData).is_saleable = $event,
                        placeholder: "privileges",
                        autocomplete: "privileges"
                      }, null, 8, ["id", "name", "value", "modelValue", "onUpdate:modelValue"]),
                      createTextVNode(" " + toDisplayString(item.name), 1)
                    ]);
                  }), 128))
                ])
              ]),
              createVNode("div", { class: "w-full flex justify-end" }, [
                createVNode(_component_CompAdminButtonAddForm, {
                  buttonName: "Edit Property",
                  isLoading: unref(loading)
                }, null, 8, ["isLoading"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/onze-locaties/edit-locaties/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-129aba3f.mjs.map
