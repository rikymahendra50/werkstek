import { _ as __nuxt_component_0 } from './ButtonAddIndex-0be538de.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { h as _export_sfc, u as useRequestOptions, a as useRouter, b as useRoute, d as useHead } from '../server.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { computed, ref, withAsyncContext, watch, mergeProps, unref, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-101122a4.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderAttr } from 'vue/server-renderer';
import { u as useTimeoutFn } from './index-73677d9a.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './asyncData-04c89180.mjs';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    useSnackbar();
    const router = useRouter();
    const route = useRoute();
    const slug = computed(() => route.params.slug);
    const page = ref(1);
    const { data: dataSlug } = ([__temp, __restore] = withAsyncContext(() => useFetch(
      `/admins/products/${slug.value}/images`,
      {
        method: "get",
        ...requestOptions
      },
      "$zOu3zGtpBZ"
    )), __temp = await __temp, __restore(), __temp);
    const { start, stop } = useTimeoutFn(() => {
      replaceWindow();
    }, 1e3);
    watch(
      () => page.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          start();
        }
      }
    );
    function replaceWindow() {
      router.replace(`/admin/onze-locaties/featured-property/${slug.value}/images`);
      refresh();
    }
    useHead({
      title: "Featured Property"
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_CompAdminButtonAddIndex = __nuxt_component_0;
      _push(`<main${ssrRenderAttrs(mergeProps({ class: "flex-grow overflow-y-auto" }, _attrs))} data-v-0badb0f4><div class="mx-auto px-2 sm:px-6 lg:px-8 max-w-sm md:max-w-3xl lg:max-w-[720px] xl:max-w-7xl py-8 space-y-8" data-v-0badb0f4><div class="flex justify-between items-center" data-v-0badb0f4><div data-v-0badb0f4><div class="text-xl md:text-2xl font-bold" data-v-0badb0f4>Featured Product</div></div>`);
      _push(ssrRenderComponent(_component_CompAdminButtonAddIndex, {
        name: "Featured Product",
        link: "onze-locaties/featured-property"
      }, null, _parent));
      _push(`</div><div data-v-0badb0f4><div class="overflow-x-auto !py-2 border rounded-t-lg" data-v-0badb0f4><table class="table table-xs md:table-md w-full rounded-t-xl" data-v-0badb0f4><thead class="h-12" data-v-0badb0f4><tr data-v-0badb0f4><th class="font-medium" data-v-0badb0f4>Image</th></tr></thead><tbody data-v-0badb0f4><!--[-->`);
      ssrRenderList((_a = unref(dataSlug)) == null ? void 0 : _a.data, (item, index) => {
        _push(`<tr class="odd:bg-gray-100 even:hover:bg-gray-100 transition-colors duration-300" data-v-0badb0f4><td class="text-gray-500 text-sm font-normal !py-2 text-[12px]" data-v-0badb0f4><img${ssrRenderAttr("src", item == null ? void 0 : item.image)}${ssrRenderAttr("alt", item == null ? void 0 : item.image)} class="max-w-[100px] h-[100px]" data-v-0badb0f4></td></tr>`);
      });
      _push(`<!--]--></tbody></table></div></div></div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/onze-locaties/featured-property/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _slug_ = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-0badb0f4"]]);

export { _slug_ as default };
//# sourceMappingURL=_slug_-3268ed35.mjs.map
