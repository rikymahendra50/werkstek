import { _ as __nuxt_component_0 } from './BackButton-454ea1e4.mjs';
import { Form } from 'vee-validate';
import { _ as _sfc_main$1 } from './TextField-7edd2a1a.mjs';
import { _ as __nuxt_component_3 } from './ButtonAddForm-aa118db7.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { u as useSchema } from './useSchema-3365865c.mjs';
import { computed, withAsyncContext, ref, unref, withCtx, isRef, createVNode, useSSRContext } from 'vue';
import { a as useRoute, u as useRouter, b as useFetch, d as useHead } from '../server.mjs';
import { ssrRenderComponent } from 'vue/server-renderer';
import './Icon-7d2a1472.mjs';
import './config-54e8ad1b.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'zod';
import '@vee-validate/zod';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b, _c, _d;
    let __temp, __restore;
    const { loading, transformErrors } = useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const snackbar = useSnackbar();
    const { singleNameField } = useSchema();
    const route = useRoute();
    const router = useRouter();
    const slug = computed(() => {
      return route.params.slug;
    });
    const { data, pending } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/types/${slug.value}`, {
      method: "get",
      ...requestOptions
    }, "$wHS2T2gtSB")), __temp = await __temp, __restore(), __temp);
    const name = ref((_b = (_a = data == null ? void 0 : data.value) == null ? void 0 : _a.data) == null ? void 0 : _b.name);
    async function onSubmit(values, ctx) {
      var _a3;
      var _a2, _b2, _c2;
      loading.value = true;
      const { error } = await useFetch(`/admins/types/${slug.value}`, {
        method: "PUT",
        body: { name: name.value },
        ...requestOptions
      }, "$IoKdzhCMoe");
      if (error.value) {
        ctx.setErrors(transformErrors((_a2 = error.value) == null ? void 0 : _a2.data));
        snackbar.add({
          type: "error",
          text: (_a3 = (_c2 = (_b2 = error.value) == null ? void 0 : _b2.data) == null ? void 0 : _c2.message) != null ? _a3 : "Something went wrong"
        });
      } else {
        snackbar.add({
          type: "success",
          text: "Success Edit Type Vacatures"
        });
        router.push("/admin/type");
      }
      loading.value = false;
    }
    useHead({
      title: (_d = (_c = data.value) == null ? void 0 : _c.data) == null ? void 0 : _d.name
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CompAdminBackButton = __nuxt_component_0;
      const _component_VeeForm = Form;
      const _component_FormTextField = _sfc_main$1;
      const _component_CompAdminButtonAddForm = __nuxt_component_3;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_CompAdminBackButton, {
        link: "type",
        linkTitle: "Edit Type"
      }, null, _parent));
      _push(`<div class="grid grid-cols-2 px-4">`);
      _push(ssrRenderComponent(_component_VeeForm, {
        onSubmit,
        "validation-schema": unref(singleNameField)
      }, {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 gap-3"${_scopeId}><div class="flex flex-col"${_scopeId}><label for="name" class="mb-3"${_scopeId}>Type Name</label>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "name",
              name: "name",
              modelValue: unref(name),
              "onUpdate:modelValue": ($event) => isRef(name) ? name.value = $event : null,
              placeholder: "Type Name",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="flex justify-end mt-5"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_CompAdminButtonAddForm, {
              buttonName: "Edit Type Vacatures",
              isLoading: unref(loading)
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 gap-3" }, [
                createVNode("div", { class: "flex flex-col" }, [
                  createVNode("label", {
                    for: "name",
                    class: "mb-3"
                  }, "Type Name"),
                  createVNode(_component_FormTextField, {
                    id: "name",
                    name: "name",
                    modelValue: unref(name),
                    "onUpdate:modelValue": ($event) => isRef(name) ? name.value = $event : null,
                    placeholder: "Type Name",
                    class: "input-bordered",
                    autocomplete: "on"
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ])
              ]),
              createVNode("div", { class: "flex justify-end mt-5" }, [
                createVNode(_component_CompAdminButtonAddForm, {
                  buttonName: "Edit Type Vacatures",
                  isLoading: unref(loading)
                }, null, 8, ["isLoading"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/type/edit/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-3b627ff6.mjs.map
