import { _ as __nuxt_component_0 } from './BackButton-de34e53a.mjs';
import { Form } from 'vee-validate';
import { _ as __nuxt_component_3 } from './ButtonAddForm-aa118db7.mjs';
import { u as useSchema } from './useSchema-3365865c.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions, b as useRoute, a as useRouter, d as useHead } from '../server.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { computed, withAsyncContext, ref, withCtx, unref, createVNode, withDirectives, vModelText, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-101122a4.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import './Icon-e394d28f.mjs';
import './config-aab100d3.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'zod';
import '@vee-validate/zod';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './asyncData-04c89180.mjs';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useSchema();
    const { loading, transformErrors } = useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const snackbar = useSnackbar();
    const route = useRoute();
    const router = useRouter();
    const slug = computed(() => route.params.slug);
    function goToHomeCategory() {
      router.push("/admin/category");
    }
    const { data: eachCategory, error } = ([__temp, __restore] = withAsyncContext(() => useFetch(
      `/admins/categories/${slug.value}`,
      {
        method: "get",
        ...requestOptions
      },
      "$oiF1RkGtWY"
    )), __temp = await __temp, __restore(), __temp);
    const formData = ref({
      name: eachCategory.value.data.name,
      short_description: eachCategory.value.data.short_description,
      full_description: eachCategory.value.data.full_description
    });
    async function onSubmit(values, ctx) {
      var _a2;
      var _a, _b, _c;
      loading.value = true;
      const { error: error2 } = await useFetch(`/admins/categories/${slug.value}`, {
        method: "put",
        body: formData.value,
        ...requestOptions
      }, "$S9nMlfGvEL");
      if (error2.value) {
        ctx.setErrors(transformErrors((_a = error2.value) == null ? void 0 : _a.data));
        snackbar.add({
          type: "error",
          text: (_a2 = (_c = (_b = error2.value) == null ? void 0 : _b.data) == null ? void 0 : _c.message) != null ? _a2 : "Something went wrong"
        });
      } else {
        snackbar.add({
          type: "success",
          text: "Edit Category Success"
        });
        goToHomeCategory();
        ctx.resetForm();
      }
      loading.value = false;
    }
    useHead({
      title: "Edit Category"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CompAdminBackButton = __nuxt_component_0;
      const _component_VeeForm = Form;
      const _component_CompAdminButtonAddForm = __nuxt_component_3;
      _push(`<section${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_CompAdminBackButton, {
        link: "category",
        linkTitle: "Edit Category"
      }, null, _parent));
      _push(ssrRenderComponent(_component_VeeForm, { onSubmit }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-2 mt-3 gap-3"${_scopeId}><div class="flex flex-col"${_scopeId}><label for="Name"${_scopeId}>Name</label><input id="Name" type="text" placeholder="Input Name" class="input input-bordered w-full"${ssrRenderAttr("value", unref(formData).name)} autocomplete="on"${_scopeId}></div><div class="flex flex-col"${_scopeId}><label for="shortDesk"${_scopeId}>Short Description</label><input id="shortDesk" type="text" placeholder="Short Description" class="input input-bordered w-full"${ssrRenderAttr("value", unref(formData).short_description)} autocomplete="on"${_scopeId}></div></div><div class="flex flex-col mt-5"${_scopeId}><label for="fullDesk"${_scopeId}>Full Description</label><textarea id="fullDesk" type="textarea" placeholder="Full Description" class="textarea textarea-bordered w-full" autocomplete="on"${_scopeId}>${ssrInterpolate(unref(formData).full_description)}</textarea></div><div class="flex justify-end mt-5"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_CompAdminButtonAddForm, {
              buttonName: "Edit Category",
              isLoading: unref(loading)
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-2 mt-3 gap-3" }, [
                createVNode("div", { class: "flex flex-col" }, [
                  createVNode("label", { for: "Name" }, "Name"),
                  withDirectives(createVNode("input", {
                    id: "Name",
                    type: "text",
                    placeholder: "Input Name",
                    class: "input input-bordered w-full",
                    "onUpdate:modelValue": ($event) => unref(formData).name = $event,
                    autocomplete: "on"
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelText, unref(formData).name]
                  ])
                ]),
                createVNode("div", { class: "flex flex-col" }, [
                  createVNode("label", { for: "shortDesk" }, "Short Description"),
                  withDirectives(createVNode("input", {
                    id: "shortDesk",
                    type: "text",
                    placeholder: "Short Description",
                    class: "input input-bordered w-full",
                    "onUpdate:modelValue": ($event) => unref(formData).short_description = $event,
                    autocomplete: "on"
                  }, null, 8, ["onUpdate:modelValue"]), [
                    [vModelText, unref(formData).short_description]
                  ])
                ])
              ]),
              createVNode("div", { class: "flex flex-col mt-5" }, [
                createVNode("label", { for: "fullDesk" }, "Full Description"),
                withDirectives(createVNode("textarea", {
                  id: "fullDesk",
                  type: "textarea",
                  placeholder: "Full Description",
                  class: "textarea textarea-bordered w-full",
                  "onUpdate:modelValue": ($event) => unref(formData).full_description = $event,
                  autocomplete: "on"
                }, null, 8, ["onUpdate:modelValue"]), [
                  [vModelText, unref(formData).full_description]
                ])
              ]),
              createVNode("div", { class: "flex justify-end mt-5" }, [
                createVNode(_component_CompAdminButtonAddForm, {
                  buttonName: "Edit Category",
                  isLoading: unref(loading)
                }, null, 8, ["isLoading"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/category/edit/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-4c07cc51.mjs.map
