import { _ as __nuxt_component_0 } from './BackButton-de34e53a.mjs';
import { Form, Field } from 'vee-validate';
import { _ as _sfc_main$1 } from './TextField-7edd2a1a.mjs';
import { _ as __nuxt_component_3 } from './ButtonAddForm-aa118db7.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions, a as useRouter, b as useRoute, d as useHead } from '../server.mjs';
import { computed, withAsyncContext, ref, mergeProps, withCtx, unref, createVNode, openBlock, createBlock, Fragment, renderList, createTextVNode, toDisplayString, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-101122a4.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { u as useSchema } from './useSchema-3365865c.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate } from 'vue/server-renderer';
import './Icon-e394d28f.mjs';
import './config-aab100d3.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './asyncData-04c89180.mjs';
import 'zod';
import '@vee-validate/zod';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b, _c, _d, _e, _f;
    let __temp, __restore;
    const { loading, transformErrors } = useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const router = useRouter();
    const snackbar = useSnackbar();
    const route = useRoute();
    const slug = computed(() => route.params.slug);
    useSchema();
    const { data: dataSlug } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/${slug.value}`, {
      method: "get",
      ...requestOptions
    }, "$96IUJmrVYJ")), __temp = await __temp, __restore(), __temp);
    const formData = ref({
      first_name: (_b = (_a = dataSlug == null ? void 0 : dataSlug.value) == null ? void 0 : _a.data) == null ? void 0 : _b.first_name,
      last_name: (_d = (_c = dataSlug == null ? void 0 : dataSlug.value) == null ? void 0 : _c.data) == null ? void 0 : _d.last_name,
      is_active: (_f = (_e = dataSlug == null ? void 0 : dataSlug.value) == null ? void 0 : _e.data) == null ? void 0 : _f.is_active
    });
    const isActiveData = ref([
      {
        id: 1,
        name: "Yes",
        value: 1
      },
      {
        id: 2,
        name: "No",
        value: 0
      }
    ]);
    async function onSubmit(values, ctx) {
      var _a3;
      var _a2, _b2, _c2;
      loading.value = true;
      const { data, error } = await useFetch(`/admins/${slug.value}`, {
        method: "put",
        body: JSON.stringify(formData.value),
        ...requestOptions
      }, "$yBtc7v30sQ");
      if (error.value) {
        ctx.setErrors(transformErrors((_a2 = error.value) == null ? void 0 : _a2.data));
        snackbar.add({
          type: "error",
          text: (_a3 = (_c2 = (_b2 = error.value) == null ? void 0 : _b2.data) == null ? void 0 : _c2.message) != null ? _a3 : "Something went wrong"
        });
      } else {
        snackbar.add({
          type: "success",
          text: "Success Edit Admin"
        });
        router.push("/admin/admin-list");
      }
      loading.value = false;
    }
    useHead({
      title: "Edit Admin List"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CompAdminBackButton = __nuxt_component_0;
      const _component_VeeForm = Form;
      const _component_FormTextField = _sfc_main$1;
      const _component_VeeField = Field;
      const _component_CompAdminButtonAddForm = __nuxt_component_3;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "overflow-auto" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_CompAdminBackButton, {
        link: "admin-list",
        linkTitle: "Edit Admin List"
      }, null, _parent));
      _push(`<div class="grid grid-cols-2">`);
      _push(ssrRenderComponent(_component_VeeForm, { onSubmit }, {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex flex-col mt-3 px-8 overflow-auto gap-4"${_scopeId}><div class="flex flex-col"${_scopeId}><div class="flex items-center"${_scopeId}><label for="firstname"${_scopeId}>First Name</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "firstname",
              name: "firstname",
              modelValue: unref(formData).first_name,
              "onUpdate:modelValue": ($event) => unref(formData).first_name = $event,
              placeholder: "Input First Name",
              class: "input-bordered",
              autocomplete: "off"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col"${_scopeId}><div class="flex items-center"${_scopeId}><label for="lastname"${_scopeId}>Last Name</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "lastname",
              name: "lastname",
              modelValue: unref(formData).last_name,
              "onUpdate:modelValue": ($event) => unref(formData).last_name = $event,
              placeholder: "Input Last Name",
              class: "input-bordered",
              autocomplete: "off"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col gap-3"${_scopeId}><div class="flex items-center"${_scopeId}><label for="lastname"${_scopeId}>Is Active</label></div><!--[-->`);
            ssrRenderList(unref(isActiveData), (item) => {
              _push2(`<label class="checkbox-label flex gap-2"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_VeeField, {
                id: `isactive + ${item.id}`,
                name: `isactive + ${item.name}`,
                type: "checkbox",
                value: item.value,
                modelValue: unref(formData).is_active,
                "onUpdate:modelValue": ($event) => unref(formData).is_active = $event
              }, null, _parent2, _scopeId));
              _push2(` ${ssrInterpolate(item.name)}</label>`);
            });
            _push2(`<!--]--></div><div class="flex justify-end mt-5"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_CompAdminButtonAddForm, {
              buttonName: "Edit Admin",
              isLoading: unref(loading)
            }, null, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col mt-3 px-8 overflow-auto gap-4" }, [
                createVNode("div", { class: "flex flex-col" }, [
                  createVNode("div", { class: "flex items-center" }, [
                    createVNode("label", { for: "firstname" }, "First Name")
                  ]),
                  createVNode(_component_FormTextField, {
                    id: "firstname",
                    name: "firstname",
                    modelValue: unref(formData).first_name,
                    "onUpdate:modelValue": ($event) => unref(formData).first_name = $event,
                    placeholder: "Input First Name",
                    class: "input-bordered",
                    autocomplete: "off"
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode("div", { class: "flex flex-col" }, [
                  createVNode("div", { class: "flex items-center" }, [
                    createVNode("label", { for: "lastname" }, "Last Name")
                  ]),
                  createVNode(_component_FormTextField, {
                    id: "lastname",
                    name: "lastname",
                    modelValue: unref(formData).last_name,
                    "onUpdate:modelValue": ($event) => unref(formData).last_name = $event,
                    placeholder: "Input Last Name",
                    class: "input-bordered",
                    autocomplete: "off"
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode("div", { class: "flex flex-col gap-3" }, [
                  createVNode("div", { class: "flex items-center" }, [
                    createVNode("label", { for: "lastname" }, "Is Active")
                  ]),
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(isActiveData), (item) => {
                    return openBlock(), createBlock("label", {
                      key: item.id,
                      class: "checkbox-label flex gap-2"
                    }, [
                      createVNode(_component_VeeField, {
                        id: `isactive + ${item.id}`,
                        name: `isactive + ${item.name}`,
                        type: "checkbox",
                        value: item.value,
                        modelValue: unref(formData).is_active,
                        "onUpdate:modelValue": ($event) => unref(formData).is_active = $event
                      }, null, 8, ["id", "name", "value", "modelValue", "onUpdate:modelValue"]),
                      createTextVNode(" " + toDisplayString(item.name), 1)
                    ]);
                  }), 128))
                ]),
                createVNode("div", { class: "flex justify-end mt-5" }, [
                  createVNode(_component_CompAdminButtonAddForm, {
                    buttonName: "Edit Admin",
                    isLoading: unref(loading)
                  }, null, 8, ["isLoading"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/admin-list/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-5c768483.mjs.map
