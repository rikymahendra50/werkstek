import { _ as __nuxt_component_0 } from './BackButton-454ea1e4.mjs';
import { computed, withAsyncContext, unref, useSSRContext } from 'vue';
import { a as useRoute, b as useFetch, d as useHead } from '../server.mjs';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';
import './Icon-7d2a1472.mjs';
import './config-54e8ad1b.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b;
    let __temp, __restore;
    const route = useRoute();
    const slug = computed(() => {
      return route.params.slug;
    });
    const { requestOptions } = useRequestOptions();
    const { data, error, pending } = ([__temp, __restore] = withAsyncContext(() => useFetch(
      `/admins/contacts/${slug.value}`,
      {
        method: "get",
        ...requestOptions
      },
      "$4sKJYgerdm"
    )), __temp = await __temp, __restore(), __temp);
    if (error.value) {
      console.error("Error fetching data:", error);
    }
    useHead({
      title: (_b = (_a = data.value) == null ? void 0 : _a.data) == null ? void 0 : _b.name
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a2, _b2, _c, _d, _e, _f, _g, _h, _i, _j, _k;
      const _component_CompAdminBackButton = __nuxt_component_0;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_CompAdminBackButton, {
        link: "contact",
        linkTitle: "Detail Contact"
      }, null, _parent));
      if (unref(pending)) {
        _push(`<div>Loading...</div>`);
      } else {
        _push(`<!---->`);
      }
      if (unref(data) && ((_a2 = unref(data)) == null ? void 0 : _a2.data)) {
        _push(`<div class="overflow-y-auto"><table class="table"><tbody><tr><td>First Name</td><td>${ssrInterpolate((_c = (_b2 = unref(data)) == null ? void 0 : _b2.data) == null ? void 0 : _c.first_name)}</td></tr><tr><td>Last Name</td><td>${ssrInterpolate((_e = (_d = unref(data)) == null ? void 0 : _d.data) == null ? void 0 : _e.last_name)}</td></tr><tr><td>Email</td><td>${ssrInterpolate((_g = (_f = unref(data)) == null ? void 0 : _f.data) == null ? void 0 : _g.email)}</td></tr><tr><td>Subject</td><td>${ssrInterpolate((_i = (_h = unref(data)) == null ? void 0 : _h.data) == null ? void 0 : _i.subject)}</td></tr><tr><td>Message</td><td>${ssrInterpolate((_k = (_j = unref(data)) == null ? void 0 : _j.data) == null ? void 0 : _k.message)}</td></tr></tbody></table></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/contact/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-6161d235.mjs.map
