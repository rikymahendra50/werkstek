import { _ as __nuxt_component_0 } from './BackButton-454ea1e4.mjs';
import { Form, Field, ErrorMessage } from 'vee-validate';
import { _ as __nuxt_component_2 } from './BlogImageCrop-e341be04.mjs';
import { _ as _sfc_main$2 } from './TextField-7edd2a1a.mjs';
import { _ as __nuxt_component_4 } from './TextEditor-0bf2d701.mjs';
import { _ as __nuxt_component_3 } from './ButtonAddForm-aa118db7.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { computed, withAsyncContext, unref, useSSRContext, ref, mergeProps, withCtx, isRef, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString } from 'vue';
import { a as useRoute, b as useFetch, d as useHead, u as useRouter } from '../server.mjs';
import { u as useSchema } from './useSchema-3365865c.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import './Icon-7d2a1472.mjs';
import './config-54e8ad1b.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import './client-only-29ef7f45.mjs';
import './index-c7d55092.mjs';
import './index-73677d9a.mjs';
import '@tiptap/vue-3';
import '@tiptap/starter-kit';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'zod';
import '@vee-validate/zod';

const _sfc_main$1 = {
  __name: "updateAdmin",
  __ssrInlineRender: true,
  props: {
    eachBlog: {
      type: Object
    },
    categoryBlog: {
      type: Array
    },
    authorBlog: {
      type: Array
    }
  },
  setup(__props) {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    const props = __props;
    const { loading, transformErrors } = useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const snackbar = useSnackbar();
    const route = useRoute();
    const slug = computed(() => route.params.slug);
    const router = useRouter();
    const { editBlogSchema } = useSchema();
    const formData = ref({
      title: (_a = props.eachBlog) == null ? void 0 : _a.title,
      author: (_b = props.eachBlog) == null ? void 0 : _b.author,
      body: (_c = props.eachBlog) == null ? void 0 : _c.body,
      category_id: (_e = (_d = props.eachBlog) == null ? void 0 : _d.category) == null ? void 0 : _e.id,
      meta: (_f = props.eachBlog) == null ? void 0 : _f.meta,
      author_id: (_h = (_g = props.eachBlog) == null ? void 0 : _g.author) == null ? void 0 : _h.id
    });
    const selectedImage = ref();
    async function onSubmit(values, ctx) {
      var _a3;
      var _a2, _b2, _c2;
      loading.value = true;
      const object = { ...formData.value };
      const formDataT = new FormData();
      for (const item in object) {
        const objectItem = object[item];
        formDataT.append(item, objectItem);
      }
      if (selectedImage.value) {
        formDataT.append("image", selectedImage.value);
      }
      const { error, data } = await useFetch(
        `/admins/articles/${slug.value}?_method=PUT`,
        {
          method: "POST",
          body: formDataT,
          ...requestOptions
        },
        "$4DQbAtAzpP"
      );
      if (error.value) {
        ctx.setErrors(transformErrors((_a2 = error == null ? void 0 : error.value) == null ? void 0 : _a2.data));
        snackbar.add({
          type: "error",
          text: (_a3 = (_c2 = (_b2 = error.value) == null ? void 0 : _b2.data) == null ? void 0 : _c2.message) != null ? _a3 : "Something went wrong"
        });
      } else if (data.value) {
        snackbar.add({
          type: "success",
          text: "Edit Blog Success"
        });
        router.push("/admin/blog");
      }
      loading.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_BlogImageCrop = __nuxt_component_2;
      const _component_FormTextField = _sfc_main$2;
      const _component_VeeField = Field;
      const _component_FormTextEditor = __nuxt_component_4;
      const _component_VeeErrorMessage = ErrorMessage;
      const _component_CompAdminButtonAddForm = __nuxt_component_3;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "grid grid-cols-2" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_VeeForm, {
        onSubmit,
        "validation-schema": unref(editBlogSchema)
      }, {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          var _a2, _b2;
          if (_push2) {
            _push2(`<div class="grid p-3"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_BlogImageCrop, {
              loading: unref(loading),
              existingimage: (_a2 = props.eachBlog) == null ? void 0 : _a2.image,
              modelValue: unref(selectedImage),
              "onUpdate:modelValue": ($event) => isRef(selectedImage) ? selectedImage.value = $event : null
            }, null, _parent2, _scopeId));
            _push2(`</div><label for="title" class="mt-3"${_scopeId}>Title</label>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "title",
              name: "title",
              modelValue: unref(formData).title,
              "onUpdate:modelValue": ($event) => unref(formData).title = $event,
              placeholder: "Input Title",
              class: "input-bordered",
              autocomplete: "off"
            }, null, _parent2, _scopeId));
            _push2(`<div class="flex flex-col mt-5"${_scopeId}><span${_scopeId}>Body</span><div class="hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              type: "text",
              name: "body",
              modelValue: unref(formData).body,
              "onUpdate:modelValue": ($event) => unref(formData).body = $event
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_FormTextEditor, {
              modelValue: unref(formData).body,
              "onUpdate:modelValue": ($event) => unref(formData).body = $event,
              "is-error": !!errors.body
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "body",
              class: "text-red-500"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col mt-5"${_scopeId}><label for="category"${_scopeId}>Category</label>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "category",
              name: "category",
              as: "select",
              modelValue: unref(formData).category_id,
              "onUpdate:modelValue": ($event) => unref(formData).category_id = $event,
              class: "select select-bordered w-full",
              placeholder: "category",
              autocomplete: "off"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<option disabled selected${_scopeId2}>Category</option><!--[-->`);
                  ssrRenderList(__props.categoryBlog, (item) => {
                    _push3(`<option${ssrRenderAttr("value", item.id)}${_scopeId2}>${ssrInterpolate(item.name)}</option>`);
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    createVNode("option", {
                      disabled: "",
                      selected: ""
                    }, "Category"),
                    (openBlock(true), createBlock(Fragment, null, renderList(__props.categoryBlog, (item) => {
                      return openBlock(), createBlock("option", {
                        value: item.id
                      }, toDisplayString(item.name), 9, ["value"]);
                    }), 256))
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col mt-5"${_scopeId}><label for="author"${_scopeId}>Author</label>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "author",
              name: "author",
              as: "select",
              modelValue: unref(formData).author_id,
              "onUpdate:modelValue": ($event) => unref(formData).author_id = $event,
              class: "select select-bordered w-full",
              placeholder: "author",
              autocomplete: "off"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<option disabled selected${_scopeId2}>Author</option><!--[-->`);
                  ssrRenderList(__props.authorBlog, (item) => {
                    _push3(`<option${ssrRenderAttr("value", item.id)}${_scopeId2}>${ssrInterpolate(item.name)}</option>`);
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    createVNode("option", {
                      disabled: "",
                      selected: ""
                    }, "Author"),
                    (openBlock(true), createBlock(Fragment, null, renderList(__props.authorBlog, (item) => {
                      return openBlock(), createBlock("option", {
                        value: item.id
                      }, toDisplayString(item.name), 9, ["value"]);
                    }), 256))
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "author",
              class: "text-red-500"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col mt-5"${_scopeId}><label for="meta"${_scopeId}>Meta</label>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "meta",
              name: "meta",
              modelValue: unref(formData).meta,
              "onUpdate:modelValue": ($event) => unref(formData).meta = $event,
              placeholder: "Input Meta",
              class: "input-bordered",
              autocomplete: "off"
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="flex justify-end mt-5"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_CompAdminButtonAddForm, {
              buttonName: "Edit Blog",
              isLoading: unref(loading)
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "grid p-3" }, [
                createVNode("div", null, [
                  createVNode(_component_BlogImageCrop, {
                    loading: unref(loading),
                    existingimage: (_b2 = props.eachBlog) == null ? void 0 : _b2.image,
                    modelValue: unref(selectedImage),
                    "onUpdate:modelValue": ($event) => isRef(selectedImage) ? selectedImage.value = $event : null
                  }, null, 8, ["loading", "existingimage", "modelValue", "onUpdate:modelValue"])
                ]),
                createVNode("label", {
                  for: "title",
                  class: "mt-3"
                }, "Title"),
                createVNode(_component_FormTextField, {
                  id: "title",
                  name: "title",
                  modelValue: unref(formData).title,
                  "onUpdate:modelValue": ($event) => unref(formData).title = $event,
                  placeholder: "Input Title",
                  class: "input-bordered",
                  autocomplete: "off"
                }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                createVNode("div", { class: "flex flex-col mt-5" }, [
                  createVNode("span", null, "Body"),
                  createVNode("div", { class: "hidden" }, [
                    createVNode(_component_VeeField, {
                      type: "text",
                      name: "body",
                      modelValue: unref(formData).body,
                      "onUpdate:modelValue": ($event) => unref(formData).body = $event
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  createVNode(_component_FormTextEditor, {
                    modelValue: unref(formData).body,
                    "onUpdate:modelValue": ($event) => unref(formData).body = $event,
                    "is-error": !!errors.body
                  }, null, 8, ["modelValue", "onUpdate:modelValue", "is-error"]),
                  createVNode(_component_VeeErrorMessage, {
                    name: "body",
                    class: "text-red-500"
                  })
                ]),
                createVNode("div", { class: "flex flex-col mt-5" }, [
                  createVNode("label", { for: "category" }, "Category"),
                  createVNode(_component_VeeField, {
                    id: "category",
                    name: "category",
                    as: "select",
                    modelValue: unref(formData).category_id,
                    "onUpdate:modelValue": ($event) => unref(formData).category_id = $event,
                    class: "select select-bordered w-full",
                    placeholder: "category",
                    autocomplete: "off"
                  }, {
                    default: withCtx(() => [
                      createVNode("option", {
                        disabled: "",
                        selected: ""
                      }, "Category"),
                      (openBlock(true), createBlock(Fragment, null, renderList(__props.categoryBlog, (item) => {
                        return openBlock(), createBlock("option", {
                          value: item.id
                        }, toDisplayString(item.name), 9, ["value"]);
                      }), 256))
                    ]),
                    _: 1
                  }, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode("div", { class: "flex flex-col mt-5" }, [
                  createVNode("label", { for: "author" }, "Author"),
                  createVNode(_component_VeeField, {
                    id: "author",
                    name: "author",
                    as: "select",
                    modelValue: unref(formData).author_id,
                    "onUpdate:modelValue": ($event) => unref(formData).author_id = $event,
                    class: "select select-bordered w-full",
                    placeholder: "author",
                    autocomplete: "off"
                  }, {
                    default: withCtx(() => [
                      createVNode("option", {
                        disabled: "",
                        selected: ""
                      }, "Author"),
                      (openBlock(true), createBlock(Fragment, null, renderList(__props.authorBlog, (item) => {
                        return openBlock(), createBlock("option", {
                          value: item.id
                        }, toDisplayString(item.name), 9, ["value"]);
                      }), 256))
                    ]),
                    _: 1
                  }, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode(_component_VeeErrorMessage, {
                    name: "author",
                    class: "text-red-500"
                  })
                ]),
                createVNode("div", { class: "flex flex-col mt-5" }, [
                  createVNode("label", { for: "meta" }, "Meta"),
                  createVNode(_component_FormTextField, {
                    id: "meta",
                    name: "meta",
                    modelValue: unref(formData).meta,
                    "onUpdate:modelValue": ($event) => unref(formData).meta = $event,
                    placeholder: "Input Meta",
                    class: "input-bordered",
                    autocomplete: "off"
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ])
              ]),
              createVNode("div", { class: "flex justify-end mt-5" }, [
                createVNode(_component_CompAdminButtonAddForm, {
                  buttonName: "Edit Blog",
                  isLoading: unref(loading)
                }, null, 8, ["isLoading"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/updateAdmin.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$1;
const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { requestOptions } = useRequestOptions();
    const route = useRoute();
    const slug = computed(() => route.params.slug);
    const { data: eachBlog, pending: eachBlogPending } = ([__temp, __restore] = withAsyncContext(() => useFetch(
      `/admins/articles/${slug.value}`,
      {
        method: "get",
        ...requestOptions
      },
      "$jCqaT4FE8g"
    )), __temp = await __temp, __restore(), __temp);
    const { data: categoryBlog, pending: categoryBlogPending } = ([__temp, __restore] = withAsyncContext(() => useFetch(
      `/admins/article-categories`,
      {
        method: "get",
        ...requestOptions
      },
      "$VdRd3OKYZW"
    )), __temp = await __temp, __restore(), __temp);
    const { data: authorBlog, pending: authorBlogPending } = ([__temp, __restore] = withAsyncContext(() => useFetch(
      `/admins/authors`,
      {
        method: "get",
        ...requestOptions
      },
      "$Vt2Hr1sIgm"
    )), __temp = await __temp, __restore(), __temp);
    useHead({
      title: "Edit Blog"
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c;
      const _component_CompAdminBackButton = __nuxt_component_0;
      const _component_updateAdmin = __nuxt_component_1;
      _push(`<section${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_CompAdminBackButton, {
        link: "blog",
        linkTitle: "Edit Blog"
      }, null, _parent));
      _push(ssrRenderComponent(_component_updateAdmin, {
        eachBlog: (_a = unref(eachBlog)) == null ? void 0 : _a.data,
        categoryBlog: (_b = unref(categoryBlog)) == null ? void 0 : _b.data,
        authorBlog: (_c = unref(authorBlog)) == null ? void 0 : _c.data
      }, null, _parent));
      _push(`</section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/blog/edit/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-700e5881.mjs.map
