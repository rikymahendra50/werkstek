import { _ as __nuxt_component_0 } from './EachBlog-aa43c077.mjs';
import { computed, withAsyncContext, unref, useSSRContext } from 'vue';
import { a as useRoute, b as useFetch, d as useHead } from '../server.mjs';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { ssrRenderComponent } from 'vue/server-renderer';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './Icon-7d2a1472.mjs';
import './config-54e8ad1b.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './useRequestHelper-553b0504.mjs';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b;
    let __temp, __restore;
    const route = useRoute();
    const slug = computed(() => {
      return route.params.slug;
    });
    const { requestOptions } = useRequestOptions();
    const { data, error, pending } = ([__temp, __restore] = withAsyncContext(() => useFetch(
      `/community-blogs/${slug.value}`,
      {
        method: "get",
        ...requestOptions
      },
      "$uhVwscLA77"
    )), __temp = await __temp, __restore(), __temp);
    if (error.value) {
      console.error("Error fetching data:", error);
    }
    useHead({
      title: (_b = (_a = data.value) == null ? void 0 : _a.data) == null ? void 0 : _b.title
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a2, _b2, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p;
      const _component_EachBlog = __nuxt_component_0;
      _push(`<!--[--><div class="mt-28"></div>`);
      if (unref(data) && ((_a2 = unref(data)) == null ? void 0 : _a2.data)) {
        _push(`<div>`);
        _push(ssrRenderComponent(_component_EachBlog, {
          typeArticle: "Community",
          title: (_c = (_b2 = unref(data)) == null ? void 0 : _b2.data) == null ? void 0 : _c.title,
          imageSrc: unref(data).data.image,
          body: (_e = (_d = unref(data)) == null ? void 0 : _d.data) == null ? void 0 : _e.body,
          author: (_h = (_g = (_f = unref(data)) == null ? void 0 : _f.data) == null ? void 0 : _g.author) == null ? void 0 : _h.name,
          authorImage: (_k = (_j = (_i = unref(data)) == null ? void 0 : _i.data) == null ? void 0 : _j.author) == null ? void 0 : _k.image,
          authorDescription: (_n = (_m = (_l = unref(data)) == null ? void 0 : _l.data) == null ? void 0 : _m.author) == null ? void 0 : _n.description,
          comment: (_p = (_o = unref(data)) == null ? void 0 : _o.data) == null ? void 0 : _p.comments
        }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/werkstek-community/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-73cf472a.mjs.map
