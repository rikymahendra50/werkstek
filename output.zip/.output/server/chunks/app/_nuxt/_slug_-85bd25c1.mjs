import { _ as __nuxt_component_0 } from './BackButton-de34e53a.mjs';
import { Form } from 'vee-validate';
import { _ as __nuxt_component_3 } from './ButtonAddForm-aa118db7.mjs';
import { u as useAxios } from './useAxios-d0468a52.mjs';
import { u as useSchema } from './useSchema-3365865c.mjs';
import { u as useRequestOptions, a as useRouter, b as useRoute, d as useHead } from '../server.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { computed, ref, withAsyncContext, withCtx, unref, createVNode, openBlock, createBlock, createTextVNode, createCommentVNode, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-101122a4.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr, ssrRenderStyle } from 'vue/server-renderer';
import './Icon-e394d28f.mjs';
import './config-aab100d3.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'axios';
import 'zod';
import '@vee-validate/zod';
import './asyncData-04c89180.mjs';

const MAX_FILE_SIZE_MB = 5;
const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { axiosRequest } = useAxios();
    useSchema();
    const { requestOptions } = useRequestOptions();
    const { loading, transformErrors } = useRequestHelper();
    const router = useRouter();
    const snackbar = useSnackbar();
    const route = useRoute();
    const slug = computed(() => {
      return route.params.slug;
    });
    useHead({
      title: "Add or Edit Video"
    });
    const fileInput = ref(null);
    const clickUpload = () => {
      fileInput.value.click();
    };
    const fileInput2 = ref(null);
    const clickUploadThumbnail = () => {
      fileInput2.value.click();
    };
    const { data } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/products/${slug.value}/videos`, {
      method: "get",
      ...requestOptions
    }, "$a3BCBdpgnZ")), __temp = await __temp, __restore(), __temp);
    const selectedVideo = ref();
    ref();
    const videoPreview = ref();
    const thumbnailPreview = ref();
    const selectedThumbnail = ref();
    if (data.value.data) {
      selectedVideo.value = data.value.data.video;
      selectedThumbnail.value = data.value.data.thumbnail;
      videoPreview.value = data.value.data.video;
      thumbnailPreview.value = data.value.data.thumbnail;
    }
    const showModal = () => {
      const modalId = `my_modal_`;
      const modal = document.getElementById(modalId);
      if (modal) {
        modal.showModal();
      }
    };
    const saveToPreviewVideo = (event) => {
      const files = event.target.files;
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (file.size > MAX_FILE_SIZE_MB * 1024 * 1024) {
          alert(
            `File ${file.name} too big. Please chose file width maximum ${MAX_FILE_SIZE_MB} MB.`
          );
          return;
        } else {
          videoPreview.value = URL.createObjectURL(file);
          selectedVideo.value = file;
        }
      }
    };
    const saveToPreviewThumbnail = (event) => {
      const files = event.target.files;
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        if (file.size > MAX_FILE_SIZE_MB * 1024 * 1024) {
          alert(
            `File ${file.name} too big. Please chose file width maximum ${MAX_FILE_SIZE_MB} MB.`
          );
          return;
        } else {
          thumbnailPreview.value = URL.createObjectURL(file);
          selectedThumbnail.value = file;
        }
      }
    };
    async function onSubmit(values, ctx) {
      var _a2;
      var _a, _b;
      loading.value = true;
      const formData = new FormData();
      if (selectedVideo.value instanceof File || selectedVideo.value === null) {
        formData.append("video", selectedVideo.value);
      }
      if (selectedThumbnail.value instanceof File || selectedThumbnail.value === null) {
        formData.append("thumbnail", selectedThumbnail.value);
      }
      try {
        const response = await axiosRequest.post(
          `/admins/products/${slug.value}/videos`,
          formData
        );
        if (response.status >= 200 && response.status < 300) {
          snackbar.add({
            type: "success",
            text: "Add or Edit Video Success"
          });
          router.push("/admin/onze-locaties");
        }
      } catch (error) {
        if ((_b = (_a = error == null ? void 0 : error.response) == null ? void 0 : _a.data) == null ? void 0 : _b.message) {
          ctx.setErrors(transformErrors(error.response.data.message));
          snackbar.add({
            type: "error",
            text: (_a2 = error.response.data.message) != null ? _a2 : "Something went wrong"
          });
        } else {
          snackbar.add({
            type: "error",
            text: "Something went wrong"
          });
        }
      }
      loading.value = false;
    }
    async function deleteVideo() {
      var _a2;
      var _a;
      loading.value = true;
      const { error, data: data2 } = await useFetch(
        `/admins/products/${slug.value}/delete-videos`,
        {
          method: "POST",
          ...requestOptions
        },
        "$EUWbs46lEE"
      );
      if (error.value) {
        snackbar.add({
          type: "error",
          text: (_a2 = (_a = error == null ? void 0 : error.value.data) == null ? void 0 : _a.message) != null ? _a2 : "Something went wrong"
        });
      } else {
        snackbar.add({
          type: "success",
          text: "Delete Video Success"
        });
        router.push("/admin/onze-locaties");
      }
      loading.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CompAdminBackButton = __nuxt_component_0;
      const _component_VeeForm = Form;
      const _component_CompAdminButtonAddForm = __nuxt_component_3;
      _push(`<section${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_CompAdminBackButton, {
        link: "onze-locaties",
        linkTitle: "Add Or Edit Video",
        class: "w-fit"
      }, null, _parent));
      _push(ssrRenderComponent(_component_VeeForm, { onSubmit }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid gap-4 relative"${_scopeId}><div class="grid md:grid-cols-12 gap-5 border rounded-2xl py-3 px-4 text-center"${_scopeId}><div class="md:col-span-6"${_scopeId}><div class="grid gap-4"${_scopeId}><h3${_scopeId}>Video</h3><hr${_scopeId}>`);
            if (unref(videoPreview)) {
              _push2(`<div class="overflow-hidden rounded-lg relative h-full w-full draggable" data-draggable="true"${_scopeId}><video class="max-h-full md:h-[350px] aspect-video" controls${_scopeId}><source${ssrRenderAttr("src", unref(videoPreview))}${_scopeId}> Your browser does not support HTML video. </video></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div${_scopeId}>`);
            if (!unref(videoPreview)) {
              _push2(`<div class="h-full w-full min-h-[150px] overflow-hidden rounded-lg border border-dashed flex items-center justify-center hover:shadow-md transition-all duration-500" role="button"${_scopeId}><label for="fileInput" class="h-full w-full min-h-[150px] overflow-hidden rounded-lg border border-dashed flex items-center justify-center hover:shadow-md transition-all duration-500" role="button"${_scopeId}><div class="flex flex-col"${_scopeId}><div class="flex justify-center"${_scopeId}><svg data-v-9c34c54e="" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="icon h-24 w-24 stroke-0 fill-none opacity-90" width="1em" height="1em" viewBox="0 0 24 24"${_scopeId}><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 4.5v15m7.5-7.5h-15"${_scopeId}></path></svg></div><input type="file" accept="video/mp4,video/x-m4v,video/*" style="${ssrRenderStyle({ "display": "none" })}" name="video"${_scopeId}><span${_scopeId}>Add Video</span></div></label></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div><div class="md:col-span-5"${_scopeId}><div class="grid gap-4"${_scopeId}><h3${_scopeId}>Thumbnail</h3><hr${_scopeId}>`);
            if (unref(thumbnailPreview)) {
              _push2(`<div class="overflow-hidden rounded-lg relative h-full w-full draggable" data-draggable="true"${_scopeId}><img${ssrRenderAttr("src", unref(thumbnailPreview))} alt="video review" class="object-cover md:h-[350px] aspect-video"${_scopeId}></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div${_scopeId}>`);
            if (!unref(thumbnailPreview)) {
              _push2(`<div class="h-full w-full min-h-[150px] overflow-hidden rounded-lg border border-dashed flex items-center justify-center hover:shadow-md transition-all duration-500" role="button"${_scopeId}><label for="fileInput2" class="h-full w-full min-h-[150px] overflow-hidden rounded-lg border border-dashed flex items-center justify-center hover:shadow-md transition-all duration-500" role="button"${_scopeId}><div class="flex flex-col"${_scopeId}><div class="flex justify-center"${_scopeId}><svg data-v-9c34c54e="" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="icon h-24 w-24 stroke-0 fill-none opacity-90" width="1em" height="1em" viewBox="0 0 24 24"${_scopeId}><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 4.5v15m7.5-7.5h-15"${_scopeId}></path></svg></div><input type="file" name="thumbnail" accept="image/png, image/gif, image/jpeg" style="${ssrRenderStyle({ "display": "none" })}"${_scopeId}><span${_scopeId}>Add Thumbnail</span></div></label></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div><div class="w-full flex justify-end z-10 p-2"${_scopeId}><div${_scopeId}>`);
            if (unref(thumbnailPreview)) {
              _push2(`<button class="btn btn-square btn-sm btn-error" type="button"${_scopeId}><svg data-v-9c34c54e="" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="icon h-6 w-6" width="1em" height="1em" viewBox="0 0 24 24"${_scopeId}><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="m14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0"${_scopeId}></path></svg></button>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div></div></div></div><dialog${ssrRenderAttr("id", "my_modal_")} class="modal"${_scopeId}><div class="modal-box"${_scopeId}><h3 class="font-bold text-lg text-red-500"${_scopeId}>Dangers!</h3><p class="py-4 text-sm"${_scopeId}> Are you sure want to delete this video and thumbnail? </p><div class="modal-action"${_scopeId}><form method="dialog"${_scopeId}><button class="btn btn-outline btn-error mr-3 text-[12px]"${_scopeId}> Delete </button><button class="btn"${_scopeId}>Close</button></form></div></div></dialog><div class="flex justify-end mt-5"${_scopeId}></div><span class="block mb-3"${_scopeId}>If you made some changes to your images. please save them.</span>`);
            _push2(ssrRenderComponent(_component_CompAdminButtonAddForm, {
              buttonName: "Save Videos",
              isLoading: unref(loading),
              class: "w-fit",
              disabled: !unref(selectedVideo) || !unref(selectedThumbnail) || !unref(videoPreview) || !unref(thumbnailPreview)
            }, null, _parent2, _scopeId));
          } else {
            return [
              createVNode("div", { class: "grid gap-4 relative" }, [
                createVNode("div", { class: "grid md:grid-cols-12 gap-5 border rounded-2xl py-3 px-4 text-center" }, [
                  createVNode("div", { class: "md:col-span-6" }, [
                    createVNode("div", { class: "grid gap-4" }, [
                      createVNode("h3", null, "Video"),
                      createVNode("hr"),
                      unref(videoPreview) ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "overflow-hidden rounded-lg relative h-full w-full draggable",
                        "data-draggable": "true"
                      }, [
                        createVNode("video", {
                          class: "max-h-full md:h-[350px] aspect-video",
                          controls: ""
                        }, [
                          createVNode("source", { src: unref(videoPreview) }, null, 8, ["src"]),
                          createTextVNode(" Your browser does not support HTML video. ")
                        ])
                      ])) : createCommentVNode("", true),
                      createVNode("div", null, [
                        !unref(videoPreview) ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "h-full w-full min-h-[150px] overflow-hidden rounded-lg border border-dashed flex items-center justify-center hover:shadow-md transition-all duration-500",
                          role: "button",
                          onClick: clickUpload
                        }, [
                          createVNode("label", {
                            for: "fileInput",
                            class: "h-full w-full min-h-[150px] overflow-hidden rounded-lg border border-dashed flex items-center justify-center hover:shadow-md transition-all duration-500",
                            role: "button"
                          }, [
                            createVNode("div", { class: "flex flex-col" }, [
                              createVNode("div", { class: "flex justify-center" }, [
                                (openBlock(), createBlock("svg", {
                                  "data-v-9c34c54e": "",
                                  xmlns: "http://www.w3.org/2000/svg",
                                  "xmlns:xlink": "http://www.w3.org/1999/xlink",
                                  "aria-hidden": "true",
                                  role: "img",
                                  class: "icon h-24 w-24 stroke-0 fill-none opacity-90",
                                  width: "1em",
                                  height: "1em",
                                  viewBox: "0 0 24 24"
                                }, [
                                  createVNode("path", {
                                    fill: "none",
                                    stroke: "currentColor",
                                    "stroke-linecap": "round",
                                    "stroke-linejoin": "round",
                                    "stroke-width": "1.5",
                                    d: "M12 4.5v15m7.5-7.5h-15"
                                  })
                                ]))
                              ]),
                              createVNode("input", {
                                ref_key: "fileInput",
                                ref: fileInput,
                                type: "file",
                                accept: "video/mp4,video/x-m4v,video/*",
                                onChange: saveToPreviewVideo,
                                style: { "display": "none" },
                                name: "video"
                              }, null, 544),
                              createVNode("span", null, "Add Video")
                            ])
                          ])
                        ])) : createCommentVNode("", true)
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "md:col-span-5" }, [
                    createVNode("div", { class: "grid gap-4" }, [
                      createVNode("h3", null, "Thumbnail"),
                      createVNode("hr"),
                      unref(thumbnailPreview) ? (openBlock(), createBlock("div", {
                        key: 0,
                        class: "overflow-hidden rounded-lg relative h-full w-full draggable",
                        "data-draggable": "true"
                      }, [
                        createVNode("img", {
                          src: unref(thumbnailPreview),
                          alt: "video review",
                          class: "object-cover md:h-[350px] aspect-video"
                        }, null, 8, ["src"])
                      ])) : createCommentVNode("", true),
                      createVNode("div", null, [
                        !unref(thumbnailPreview) ? (openBlock(), createBlock("div", {
                          key: 0,
                          class: "h-full w-full min-h-[150px] overflow-hidden rounded-lg border border-dashed flex items-center justify-center hover:shadow-md transition-all duration-500",
                          role: "button",
                          onClick: clickUploadThumbnail
                        }, [
                          createVNode("label", {
                            for: "fileInput2",
                            class: "h-full w-full min-h-[150px] overflow-hidden rounded-lg border border-dashed flex items-center justify-center hover:shadow-md transition-all duration-500",
                            role: "button"
                          }, [
                            createVNode("div", { class: "flex flex-col" }, [
                              createVNode("div", { class: "flex justify-center" }, [
                                (openBlock(), createBlock("svg", {
                                  "data-v-9c34c54e": "",
                                  xmlns: "http://www.w3.org/2000/svg",
                                  "xmlns:xlink": "http://www.w3.org/1999/xlink",
                                  "aria-hidden": "true",
                                  role: "img",
                                  class: "icon h-24 w-24 stroke-0 fill-none opacity-90",
                                  width: "1em",
                                  height: "1em",
                                  viewBox: "0 0 24 24"
                                }, [
                                  createVNode("path", {
                                    fill: "none",
                                    stroke: "currentColor",
                                    "stroke-linecap": "round",
                                    "stroke-linejoin": "round",
                                    "stroke-width": "1.5",
                                    d: "M12 4.5v15m7.5-7.5h-15"
                                  })
                                ]))
                              ]),
                              createVNode("input", {
                                ref_key: "fileInput2",
                                ref: fileInput2,
                                type: "file",
                                name: "thumbnail",
                                accept: "image/png, image/gif, image/jpeg",
                                onChange: saveToPreviewThumbnail,
                                style: { "display": "none" }
                              }, null, 544),
                              createVNode("span", null, "Add Thumbnail")
                            ])
                          ])
                        ])) : createCommentVNode("", true)
                      ])
                    ])
                  ]),
                  createVNode("div", { class: "w-full flex justify-end z-10 p-2" }, [
                    createVNode("div", null, [
                      unref(thumbnailPreview) ? (openBlock(), createBlock("button", {
                        key: 0,
                        class: "btn btn-square btn-sm btn-error",
                        type: "button",
                        onClick: showModal
                      }, [
                        (openBlock(), createBlock("svg", {
                          "data-v-9c34c54e": "",
                          xmlns: "http://www.w3.org/2000/svg",
                          "xmlns:xlink": "http://www.w3.org/1999/xlink",
                          "aria-hidden": "true",
                          role: "img",
                          class: "icon h-6 w-6",
                          width: "1em",
                          height: "1em",
                          viewBox: "0 0 24 24"
                        }, [
                          createVNode("path", {
                            fill: "none",
                            stroke: "currentColor",
                            "stroke-linecap": "round",
                            "stroke-linejoin": "round",
                            "stroke-width": "1.5",
                            d: "m14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0"
                          })
                        ]))
                      ])) : createCommentVNode("", true)
                    ])
                  ])
                ])
              ]),
              createVNode("dialog", {
                id: "my_modal_",
                class: "modal"
              }, [
                createVNode("div", { class: "modal-box" }, [
                  createVNode("h3", { class: "font-bold text-lg text-red-500" }, "Dangers!"),
                  createVNode("p", { class: "py-4 text-sm" }, " Are you sure want to delete this video and thumbnail? "),
                  createVNode("div", { class: "modal-action" }, [
                    createVNode("form", { method: "dialog" }, [
                      createVNode("button", {
                        onClick: deleteVideo,
                        class: "btn btn-outline btn-error mr-3 text-[12px]"
                      }, " Delete "),
                      createVNode("button", { class: "btn" }, "Close")
                    ])
                  ])
                ])
              ]),
              createVNode("div", { class: "flex justify-end mt-5" }),
              createVNode("span", { class: "block mb-3" }, "If you made some changes to your images. please save them."),
              createVNode(_component_CompAdminButtonAddForm, {
                buttonName: "Save Videos",
                isLoading: unref(loading),
                class: "w-fit",
                disabled: !unref(selectedVideo) || !unref(selectedThumbnail) || !unref(videoPreview) || !unref(thumbnailPreview)
              }, null, 8, ["isLoading", "disabled"])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/onze-locaties/add-video/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-85bd25c1.mjs.map
