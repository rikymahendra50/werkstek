import { _ as __nuxt_component_0 } from './HeaderWCity-239feb2c.mjs';
import { withAsyncContext, unref, useSSRContext } from 'vue';
import { a as useRoute, b as useFetch, d as useHead } from '../server.mjs';
import { u as useDateFormatter } from './useConvertTime-0bc9d513.mjs';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { ssrRenderComponent, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b, _c;
    let __temp, __restore;
    const route = useRoute();
    const slug = route.params.slug;
    const { formatDate } = useDateFormatter();
    const { requestOptions } = useRequestOptions();
    const { data, error } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/jobs/${slug}`, {
      method: "get",
      ...requestOptions
    }, "$DsH5DOnQEY")), __temp = await __temp, __restore(), __temp);
    const dataAll = (_a = data == null ? void 0 : data.value) == null ? void 0 : _a.data;
    if (error.value) {
      console.error("Error fetching data:", error);
    }
    useHead({
      title: (_c = (_b = data.value) == null ? void 0 : _b.data) == null ? void 0 : _c.title
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a2, _b2, _c2, _d, _e, _f, _g;
      const _component_HeaderWCity = __nuxt_component_0;
      _push(`<!--[--><div class="mt-28"></div><section>`);
      _push(ssrRenderComponent(_component_HeaderWCity, {
        title1: "Bekijk onze locaties",
        title2: "De Werkstek Vacatures"
      }, null, _parent));
      _push(`<div class="container-custom"><div class="grid grid-cols-1 lg:grid-cols-2 my-20 gap-10"><div class="col-span-1 max-h-[200px] md:max-h-[400px]"><img${ssrRenderAttr("src", (_a2 = unref(dataAll)) == null ? void 0 : _a2.image)} alt="Lees alles" class="object-cover h-full w-full"></div><div class="flex flex-col text-[#1C1F35] justify-center gap-3 text-[18px]"><h1 class="font-semibold mb-5 text-[25px]">Vacature info</h1><p>Locatie : ${ssrInterpolate((_c2 = (_b2 = unref(dataAll)) == null ? void 0 : _b2.location) == null ? void 0 : _c2.name)}</p><p>Categorie : ${ssrInterpolate((_d = unref(dataAll)) == null ? void 0 : _d.category)}</p><p>Datum : ${ssrInterpolate(unref(formatDate)((_e = unref(dataAll)) == null ? void 0 : _e.updated_at))}</p><p> Soort : ${ssrInterpolate((_f = unref(dataAll)) == null ? void 0 : _f.types.map((item) => item.tpe_name).join(", "))}</p><p>Tags : ${ssrInterpolate((_g = unref(dataAll)) == null ? void 0 : _g.tags.map((item) => item.name).join(", "))}</p></div></div></div></section><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/onze-vacatures/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-878d0bf7.mjs.map
