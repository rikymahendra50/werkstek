import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { computed, withAsyncContext, mergeProps, useSSRContext } from 'vue';
import { a as useRoute, b as useFetch, d as useHead } from '../server.mjs';
import { ssrRenderAttrs } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    useSnackbar();
    const route = useRoute();
    const slug = computed(() => {
      return route.params.slug;
    });
    [__temp, __restore] = withAsyncContext(() => useFetch(`/admins/email-verification/${slug.value}`, {
      method: "POST",
      ...requestOptions
    }, "$kgOaxzSJhQ")), __temp = await __temp, __restore();
    useHead({
      title: "Registration"
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "grid place-items-center items-center h-screen" }, _attrs))}><div class="w-[500px] p-10 shadow-lg grid justify-center"><svg xmlns="http://www.w3.org/2000/svg" w="34" h="34" width="1em" height="1em" viewBox="0 0 24 24"><path fill="#F0912D" fill-rule="evenodd" d="M12 21a9 9 0 1 0 0-18a9 9 0 0 0 0 18m-.232-5.36l5-6l-1.536-1.28l-4.3 5.159l-2.225-2.226l-1.414 1.414l3 3l.774.774z" clip-rule="evenodd"></path></svg><p>Verified Success</p></div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/verified-email/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-87b0ed89.mjs.map
