import { _ as __nuxt_component_0 } from './BackButton-454ea1e4.mjs';
import { Form } from 'vee-validate';
import { _ as _sfc_main$1 } from './TextField-7edd2a1a.mjs';
import { _ as __nuxt_component_2 } from './BlogImageCrop-e341be04.mjs';
import { _ as __nuxt_component_3 } from './ButtonAddForm-aa118db7.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { computed, withAsyncContext, ref, unref, withCtx, isRef, createVNode, useSSRContext } from 'vue';
import { a as useRoute, u as useRouter, b as useFetch, d as useHead } from '../server.mjs';
import { u as useSchema } from './useSchema-3365865c.mjs';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import './Icon-7d2a1472.mjs';
import './config-54e8ad1b.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './client-only-29ef7f45.mjs';
import './index-c7d55092.mjs';
import './index-73677d9a.mjs';
import 'zod';
import '@vee-validate/zod';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { loading, transformErrors } = useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const snackbar = useSnackbar();
    const route = useRoute();
    const slug = computed(() => route.params.slug);
    const router = useRouter();
    const { singleNameField } = useSchema();
    const { data: locations, error } = ([__temp, __restore] = withAsyncContext(() => useFetch(
      `/admins/locations/${slug.value}`,
      {
        method: "get",
        ...requestOptions
      },
      "$1g1sqkrM3t"
    )), __temp = await __temp, __restore(), __temp);
    const selectedImage = ref(null);
    const formData = ref({
      name: locations.value.data.name
    });
    async function onSubmit(values, ctx) {
      var _a2;
      var _a, _b, _c;
      loading.value = true;
      const object = { ...formData.value };
      const formDataT = new FormData();
      for (const item in object) {
        const objectItem = object[item];
        formDataT.append(item, objectItem);
      }
      if (selectedImage.value) {
        formDataT.append("image", selectedImage.value);
      }
      const { error: error2, data } = await useFetch(
        `/admins/locations/${slug.value}?_method=PUT`,
        {
          method: "POST",
          body: selectedImage.value == void 0 ? object : formDataT,
          ...requestOptions
        },
        "$GamhLSM4sf"
      );
      if (error2.value) {
        ctx.setErrors(transformErrors((_a = error2 == null ? void 0 : error2.value) == null ? void 0 : _a.data));
        snackbar.add({
          type: "error",
          text: (_a2 = (_c = (_b = error2.value) == null ? void 0 : _b.data) == null ? void 0 : _c.message) != null ? _a2 : "Something went wrong"
        });
      } else if (data.value) {
        snackbar.add({
          type: "success",
          text: "Edit Location Success"
        });
        router.push("/admin/location");
      }
      loading.value = false;
    }
    useHead({
      title: "Edit Location"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CompAdminBackButton = __nuxt_component_0;
      const _component_VeeForm = Form;
      const _component_FormTextField = _sfc_main$1;
      const _component_BlogImageCrop = __nuxt_component_2;
      const _component_CompAdminButtonAddForm = __nuxt_component_3;
      _push(`<section${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_CompAdminBackButton, {
        link: "location",
        linkTitle: "Edit Location"
      }, null, _parent));
      _push(ssrRenderComponent(_component_VeeForm, {
        "validation-schema": unref(singleNameField),
        onSubmit
      }, {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d;
          if (_push2) {
            _push2(`<div class="grid grid-cols-2 gap-3"${_scopeId}><div class="flex flex-col gap-2"${_scopeId}><label for="name"${_scopeId}>Name</label>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "name",
              name: "name",
              modelValue: unref(formData).name,
              "onUpdate:modelValue": ($event) => unref(formData).name = $event,
              placeholder: "Name",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`<span${_scopeId}>Image</span>`);
            _push2(ssrRenderComponent(_component_BlogImageCrop, {
              loading: unref(loading),
              modelValue: unref(selectedImage),
              "onUpdate:modelValue": ($event) => isRef(selectedImage) ? selectedImage.value = $event : null,
              existingimage: (_b = (_a = unref(locations)) == null ? void 0 : _a.data) == null ? void 0 : _b.image
            }, null, _parent2, _scopeId));
            _push2(`<div class="flex justify-end mt-5"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_CompAdminButtonAddForm, {
              buttonName: "Edit Location",
              isLoading: unref(loading)
            }, null, _parent2, _scopeId));
            _push2(`</div></div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-2 gap-3" }, [
                createVNode("div", { class: "flex flex-col gap-2" }, [
                  createVNode("label", { for: "name" }, "Name"),
                  createVNode(_component_FormTextField, {
                    id: "name",
                    name: "name",
                    modelValue: unref(formData).name,
                    "onUpdate:modelValue": ($event) => unref(formData).name = $event,
                    placeholder: "Name",
                    class: "input-bordered",
                    autocomplete: "on"
                  }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode("span", null, "Image"),
                  createVNode(_component_BlogImageCrop, {
                    loading: unref(loading),
                    modelValue: unref(selectedImage),
                    "onUpdate:modelValue": ($event) => isRef(selectedImage) ? selectedImage.value = $event : null,
                    existingimage: (_d = (_c = unref(locations)) == null ? void 0 : _c.data) == null ? void 0 : _d.image
                  }, null, 8, ["loading", "modelValue", "onUpdate:modelValue", "existingimage"]),
                  createVNode("div", { class: "flex justify-end mt-5" }, [
                    createVNode(_component_CompAdminButtonAddForm, {
                      buttonName: "Edit Location",
                      isLoading: unref(loading)
                    }, null, 8, ["isLoading"])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/location/edit/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-8b568ae4.mjs.map
