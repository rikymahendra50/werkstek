import { _ as __nuxt_component_0 } from './BackButton-de34e53a.mjs';
import { Form, Field, ErrorMessage } from 'vee-validate';
import { _ as __nuxt_component_2 } from './BlogImageCrop-e341be04.mjs';
import { _ as _sfc_main$1 } from './TextField-7edd2a1a.mjs';
import { _ as __nuxt_component_4 } from './TextEditor-8ba1b852.mjs';
import { _ as __nuxt_component_3 } from './ButtonAddForm-aa118db7.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions, b as useRoute, a as useRouter, d as useHead } from '../server.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { computed, ref, withAsyncContext, unref, withCtx, isRef, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-101122a4.mjs';
import { u as useSchema } from './useSchema-3365865c.mjs';
import { ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import './Icon-e394d28f.mjs';
import './config-aab100d3.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import './client-only-29ef7f45.mjs';
import './index-c7d55092.mjs';
import './index-73677d9a.mjs';
import '@tiptap/vue-3';
import '@tiptap/starter-kit';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './asyncData-04c89180.mjs';
import 'zod';
import '@vee-validate/zod';

const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a;
    let __temp, __restore;
    const { loading, transformErrors } = useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const snackbar = useSnackbar();
    const route = useRoute();
    const slug = computed(() => route.params.slug);
    const router = useRouter();
    const { editCommunitySchema } = useSchema();
    ref(null);
    const { data: eachCommunity, pending: eachCommunityPending } = ([__temp, __restore] = withAsyncContext(() => useFetch(
      `/admins/community-blogs/${slug.value}`,
      {
        method: "get",
        ...requestOptions
      },
      "$9CVi2d8HSm"
    )), __temp = await __temp, __restore(), __temp);
    const dataSlug = eachCommunity == null ? void 0 : eachCommunity.value.data;
    const formData = ref({
      title: dataSlug == null ? void 0 : dataSlug.title,
      body: dataSlug == null ? void 0 : dataSlug.body,
      meta: dataSlug == null ? void 0 : dataSlug.meta,
      author_id: (_a = dataSlug == null ? void 0 : dataSlug.author) == null ? void 0 : _a.id
    });
    const { data: authorBlog, pending: authorBlogPending } = ([__temp, __restore] = withAsyncContext(() => useFetch(
      `/admins/authors`,
      {
        method: "get",
        ...requestOptions
      },
      "$4j3ZAoSRfz"
    )), __temp = await __temp, __restore(), __temp);
    ref();
    const selectedImage = ref();
    async function onSubmit(values, ctx) {
      var _a3;
      var _a2, _b, _c;
      loading.value = true;
      const object = { ...formData.value };
      const formDataT = new FormData();
      for (const item in object) {
        const objectItem = object[item];
        formDataT.append(item, objectItem);
      }
      if (selectedImage.value) {
        formDataT.append("image", selectedImage.value);
      }
      const { error, data } = await useFetch(
        `/admins/community-blogs/${slug.value}?_method=PUT`,
        {
          method: "POST",
          body: formDataT,
          ...requestOptions
        },
        "$Y06DVawuno"
      );
      if (error.value) {
        ctx.setErrors(transformErrors((_a2 = error == null ? void 0 : error.value) == null ? void 0 : _a2.data));
        snackbar.add({
          type: "error",
          text: (_a3 = (_c = (_b = error.value) == null ? void 0 : _b.data) == null ? void 0 : _c.message) != null ? _a3 : "Something went wrong"
        });
      } else if (data.value) {
        snackbar.add({
          type: "success",
          text: "Edit Community Success"
        });
        router.push("/admin/community");
      }
      loading.value = false;
    }
    useHead({
      title: "Edit Community"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CompAdminBackButton = __nuxt_component_0;
      const _component_VeeForm = Form;
      const _component_BlogImageCrop = __nuxt_component_2;
      const _component_FormTextField = _sfc_main$1;
      const _component_VeeField = Field;
      const _component_FormTextEditor = __nuxt_component_4;
      const _component_VeeErrorMessage = ErrorMessage;
      const _component_CompAdminButtonAddForm = __nuxt_component_3;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_CompAdminBackButton, {
        link: "community",
        linkTitle: "Edit Community"
      }, null, _parent));
      _push(`<div class="grid grid-cols-2">`);
      _push(ssrRenderComponent(_component_VeeForm, {
        onSubmit,
        "validation-schema": unref(editCommunitySchema)
      }, {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          var _a2, _b;
          if (_push2) {
            _push2(`<div class="grid p-3 gap-2"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_BlogImageCrop, {
              loading: unref(loading),
              existingimage: (_a2 = unref(dataSlug)) == null ? void 0 : _a2.image,
              modelValue: unref(selectedImage),
              "onUpdate:modelValue": ($event) => isRef(selectedImage) ? selectedImage.value = $event : null
            }, null, _parent2, _scopeId));
            _push2(`</div><label for="Title"${_scopeId}>Title</label>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "title",
              name: "title",
              modelValue: unref(formData).title,
              "onUpdate:modelValue": ($event) => unref(formData).title = $event,
              placeholder: "Input Title",
              class: "input-bordered",
              autocomplete: "off"
            }, null, _parent2, _scopeId));
            _push2(`<div class="flex flex-col mt-5"${_scopeId}><label for="author"${_scopeId}>Author</label>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "author",
              name: "author",
              as: "select",
              modelValue: unref(formData).author_id,
              "onUpdate:modelValue": ($event) => unref(formData).author_id = $event,
              class: "select select-bordered w-full",
              placeholder: "author",
              autocomplete: "off"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                var _a3, _b2;
                if (_push3) {
                  _push3(`<option disabled selected${_scopeId2}>Author</option><!--[-->`);
                  ssrRenderList((_a3 = unref(authorBlog)) == null ? void 0 : _a3.data, (item) => {
                    _push3(`<option${ssrRenderAttr("value", item.id)}${_scopeId2}>${ssrInterpolate(item.name)}</option>`);
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    createVNode("option", {
                      disabled: "",
                      selected: ""
                    }, "Author"),
                    (openBlock(true), createBlock(Fragment, null, renderList((_b2 = unref(authorBlog)) == null ? void 0 : _b2.data, (item) => {
                      return openBlock(), createBlock("option", {
                        value: item.id
                      }, toDisplayString(item.name), 9, ["value"]);
                    }), 256))
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col mt-5"${_scopeId}><span${_scopeId}>Body</span><div class="hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              type: "text",
              name: "body",
              modelValue: unref(formData).body,
              "onUpdate:modelValue": ($event) => unref(formData).body = $event,
              immediate: ""
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_FormTextEditor, {
              modelValue: unref(formData).body,
              "onUpdate:modelValue": ($event) => unref(formData).body = $event,
              "is-error": !!errors.body
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "body",
              class: "text-red-500"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col mt-5"${_scopeId}><label for="meta"${_scopeId}>Meta</label>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "meta",
              name: "meta",
              modelValue: unref(formData).meta,
              "onUpdate:modelValue": ($event) => unref(formData).meta = $event,
              placeholder: "Input Meta",
              class: "input-bordered",
              autocomplete: "off"
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="flex justify-end mt-5"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_CompAdminButtonAddForm, {
              buttonName: "Edit Community",
              isLoading: unref(loading)
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "grid p-3 gap-2" }, [
                createVNode("div", null, [
                  createVNode(_component_BlogImageCrop, {
                    loading: unref(loading),
                    existingimage: (_b = unref(dataSlug)) == null ? void 0 : _b.image,
                    modelValue: unref(selectedImage),
                    "onUpdate:modelValue": ($event) => isRef(selectedImage) ? selectedImage.value = $event : null
                  }, null, 8, ["loading", "existingimage", "modelValue", "onUpdate:modelValue"])
                ]),
                createVNode("label", { for: "Title" }, "Title"),
                createVNode(_component_FormTextField, {
                  id: "title",
                  name: "title",
                  modelValue: unref(formData).title,
                  "onUpdate:modelValue": ($event) => unref(formData).title = $event,
                  placeholder: "Input Title",
                  class: "input-bordered",
                  autocomplete: "off"
                }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                createVNode("div", { class: "flex flex-col mt-5" }, [
                  createVNode("label", { for: "author" }, "Author"),
                  createVNode(_component_VeeField, {
                    id: "author",
                    name: "author",
                    as: "select",
                    modelValue: unref(formData).author_id,
                    "onUpdate:modelValue": ($event) => unref(formData).author_id = $event,
                    class: "select select-bordered w-full",
                    placeholder: "author",
                    autocomplete: "off"
                  }, {
                    default: withCtx(() => {
                      var _a3;
                      return [
                        createVNode("option", {
                          disabled: "",
                          selected: ""
                        }, "Author"),
                        (openBlock(true), createBlock(Fragment, null, renderList((_a3 = unref(authorBlog)) == null ? void 0 : _a3.data, (item) => {
                          return openBlock(), createBlock("option", {
                            value: item.id
                          }, toDisplayString(item.name), 9, ["value"]);
                        }), 256))
                      ];
                    }),
                    _: 1
                  }, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode("div", { class: "flex flex-col mt-5" }, [
                  createVNode("span", null, "Body"),
                  createVNode("div", { class: "hidden" }, [
                    createVNode(_component_VeeField, {
                      type: "text",
                      name: "body",
                      modelValue: unref(formData).body,
                      "onUpdate:modelValue": ($event) => unref(formData).body = $event,
                      immediate: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  createVNode(_component_FormTextEditor, {
                    modelValue: unref(formData).body,
                    "onUpdate:modelValue": ($event) => unref(formData).body = $event,
                    "is-error": !!errors.body
                  }, null, 8, ["modelValue", "onUpdate:modelValue", "is-error"]),
                  createVNode(_component_VeeErrorMessage, {
                    name: "body",
                    class: "text-red-500"
                  })
                ]),
                createVNode("div", { class: "flex flex-col mt-5" }, [
                  createVNode("label", { for: "meta" }, "Meta"),
                  createVNode(_component_FormTextField, {
                    id: "meta",
                    name: "meta",
                    modelValue: unref(formData).meta,
                    "onUpdate:modelValue": ($event) => unref(formData).meta = $event,
                    placeholder: "Input Meta",
                    class: "input-bordered",
                    autocomplete: "off"
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ])
              ]),
              createVNode("div", { class: "flex justify-end mt-5" }, [
                createVNode(_component_CompAdminButtonAddForm, {
                  buttonName: "Edit Community",
                  isLoading: unref(loading)
                }, null, 8, ["isLoading"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/community/edit/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-9bbf7317.mjs.map
