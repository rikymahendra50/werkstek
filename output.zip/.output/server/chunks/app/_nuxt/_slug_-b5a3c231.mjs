import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { computed, withAsyncContext, unref, useSSRContext, ref, mergeProps, withCtx, createVNode, toDisplayString, openBlock, createBlock, createTextVNode, createCommentVNode, Fragment, renderList, resolveComponent } from 'vue';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderList, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import { b as useRoute, u as useRequestOptions, d as useHead, h as _export_sfc, _ as __nuxt_component_0$1$1 } from '../server.mjs';
import { Swiper, SwiperSlide } from 'swiper/vue';
import __nuxt_component_2 from './Icon-e394d28f.mjs';
import { u as useFetch } from './fetch-101122a4.mjs';
import { EffectCreative, Navigation, Thumbs } from 'swiper/modules';
import { _ as __nuxt_component_1 } from './SliderLocatiesSort-67e9e527.mjs';
import { _ as __nuxt_component_6 } from './SliderTestimony-87572334.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './config-aab100d3.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import './asyncData-04c89180.mjs';
import './client-only-29ef7f45.mjs';
import './TitleHeader-8492944b.mjs';

const _sfc_main$3 = {
  props: {
    title1: {
      type: String,
      default: "locatie"
    },
    title2: {
      type: String
    },
    title3: {
      type: String,
      default: "Categorie"
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex mt-5 mb-5 py-8 items-center lg:w-[50%] relative" }, _attrs))}><div class="flex flex-col gap-2"><h3 class="text-primary font-bold text-[18px]">${ssrInterpolate($props.title1)}</h3><h1 class="text-[22px] sm:text-[30px] font-medium text-[#363636]">${ssrInterpolate($props.title2)}</h1><p class="text-[#4A4A4A] text-[16px]">${ssrInterpolate($props.title3)}</p></div></div>`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/TitleHeader2.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0$1 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main$2 = {
  __name: "MapMini",
  __ssrInlineRender: true,
  props: {
    latitude: {},
    longitude: {},
    levelType: {}
  },
  setup(__props) {
    const props = __props;
    const center = ref({
      lat: parseFloat(props.latitude),
      lng: parseFloat(props.longitude)
    });
    const markers = ref([
      {
        position: {
          lat: parseFloat(props.latitude),
          lng: parseFloat(props.longitude)
        }
      }
    ]);
    function getMarkerIcon(levelTypeName) {
      return {
        url: levelTypeName == null ? void 0 : levelTypeName.image,
        scaledSize: { width: 50, height: 50 }
      };
    }
    function handleMarkerClick(position) {
      const url = `https://www.google.com/maps?q=${position.lat},${position.lng}`;
      window.open(url, "_blank");
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_GMapMap = resolveComponent("GMapMap");
      const _component_GMapMarker = resolveComponent("GMapMarker");
      _push(ssrRenderComponent(_component_GMapMap, mergeProps({
        center: center.value,
        zoom: 14,
        "map-type-id": "terrain",
        style: { "width": "100%", "height": "250px" },
        options: {
          zoomControl: false,
          mapTypeControl: false,
          scaleControl: false,
          streetViewControl: true,
          rotateControl: false,
          fullscreenControl: false
        }
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(markers.value, (m, index) => {
              _push2(ssrRenderComponent(_component_GMapMarker, {
                key: index,
                position: m.position,
                icon: getMarkerIcon(__props.levelType),
                clickable: true,
                onClick: ($event) => handleMarkerClick(m.position)
              }, null, _parent2, _scopeId));
            });
            _push2(`<!--]-->`);
          } else {
            return [
              (openBlock(true), createBlock(Fragment, null, renderList(markers.value, (m, index) => {
                return openBlock(), createBlock(_component_GMapMarker, {
                  key: index,
                  position: m.position,
                  icon: getMarkerIcon(__props.levelType),
                  clickable: true,
                  onClick: ($event) => handleMarkerClick(m.position)
                }, null, 8, ["position", "icon", "onClick"]);
              }), 128))
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MapMini.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_5 = _sfc_main$2;
const _imports_0 = "" + publicAssetsURL("images/telp-bg-primary.svg");
const _imports_1 = "" + publicAssetsURL("images/email-bg-primary.svg");
const _sfc_main$1 = {
  __name: "OnzeLocatiesSingle",
  __ssrInlineRender: true,
  props: {
    title: {
      type: String
    },
    postcode: {
      type: String
    },
    address: {
      type: String
    },
    country: {
      type: String
    },
    type: {
      type: String
    },
    video: {},
    rentType: {
      type: String
    },
    location: {
      type: String
    },
    subTitle: {
      type: String
    },
    thirdTitle: {
      type: String
    },
    imageSrc: {
      type: Array
    },
    description: {
      type: String
    },
    phoneNumber: {},
    email: {},
    latitude: {},
    longitude: {},
    levelType: {},
    price: {},
    facility: {
      type: Array
    },
    location: {},
    special: {
      type: Array
    }
  },
  async setup(__props) {
    let __temp, __restore;
    const props = __props;
    const { requestOptions } = useRequestOptions();
    const showDropdownContactT = ref(false);
    const thumbsSwiper = ref(null);
    const setThumbsSwiper = (swiper) => {
      thumbsSwiper.value = swiper;
    };
    const { data, error } = ([__temp, __restore] = withAsyncContext(() => useFetch("/facilities", {
      method: "get",
      ...requestOptions
    }, "$t5ocfGCGZ9")), __temp = await __temp, __restore(), __temp);
    const facilitySlugName = props == null ? void 0 : props.facility;
    function getCheckboxImage(itemName) {
      return (facilitySlugName == null ? void 0 : facilitySlugName.some(
        (facility) => {
          var _a;
          return ((_a = facility == null ? void 0 : facility.facility) == null ? void 0 : _a.name) === itemName;
        }
      )) ? "/images/checkbox_checked.svg" : "/images/minus-square.png";
    }
    function getAvailabilityStatus(itemName) {
      return (facilitySlugName == null ? void 0 : facilitySlugName.some(
        (facility) => {
          var _a;
          return ((_a = facility == null ? void 0 : facility.facility) == null ? void 0 : _a.name) === itemName;
        }
      )) ? " Beschikbaar" : " Niet beschikbaar";
    }
    const montOrYear = ref();
    const allMedia = ref([]);
    if (Array.isArray(props.imageSrc)) {
      if (props.video) {
        allMedia.value.push(props.video);
      }
      for (let i = 0; i < props.imageSrc.length; i++) {
        allMedia.value.push(props.imageSrc[i]);
      }
    }
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      const _component_TitleHeader2 = __nuxt_component_0$1;
      const _component_Swiper = Swiper;
      const _component_SwiperSlide = SwiperSlide;
      const _component_Icon = __nuxt_component_2;
      const _component_NuxtLink = __nuxt_component_0$1$1;
      const _component_MapMini = __nuxt_component_5;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "container-custom" }, _attrs))} data-v-841bd899>`);
      _push(ssrRenderComponent(_component_TitleHeader2, {
        title1: __props.location,
        title2: __props.title,
        title3: __props.location
      }, null, _parent));
      _push(`<div class="md:grid grid-cols-12 gap-2 sm:gap-5" data-v-841bd899><div class="col-span-8" data-v-841bd899><div class="flex flex-col md:min-h-[400px]" data-v-841bd899><div data-v-841bd899>`);
      _push(ssrRenderComponent(_component_Swiper, {
        modules: ["SwiperEffectCreative" in _ctx ? _ctx.SwiperEffectCreative : unref(EffectCreative), "SwiperNavigation" in _ctx ? _ctx.SwiperNavigation : unref(Navigation), "SwiperThumbs" in _ctx ? _ctx.SwiperThumbs : unref(Thumbs)],
        "slides-per-view": 1,
        effect: "creative",
        "centered-slides": "",
        thumbs: { swiper: unref(thumbsSwiper) },
        class: "overflow-hidden relative",
        "creative-effect": {
          prev: {
            shadow: false,
            translate: ["-20%", 0, -1]
          },
          next: {
            translate: ["100%", 0, 0]
          }
        }
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<!--[-->`);
            ssrRenderList(unref(allMedia), (slide) => {
              _push2(ssrRenderComponent(_component_SwiperSlide, {
                key: slide.id
              }, {
                default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                  if (_push3) {
                    _push3(`<div class="relative" data-v-841bd899${_scopeId2}><div class="absolute mt-5 md:mt-10" data-v-841bd899${_scopeId2}><div class="bg-primary min-w-[140px] lg:min-w-[232px] text-[12px] sm:text-[14px] md:text-[16px] text-white py-1 px-2 md:py-2 md:px-4 grid" data-v-841bd899${_scopeId2}><span data-v-841bd899${_scopeId2}>Prijs :</span><span data-v-841bd899${_scopeId2}>${ssrInterpolate(__props.price)} \u20AC per/${ssrInterpolate(unref(montOrYear))}</span></div></div>`);
                    if (slide.image) {
                      _push3(`<img${ssrRenderAttr("src", slide.image)}${ssrRenderAttr("alt", slide.image)} class="w-full h-full aspect-video md:min-h-[350px] object-cover" data-v-841bd899${_scopeId2}>`);
                    } else if (slide.thumbnail) {
                      _push3(`<div data-v-841bd899${_scopeId2}><video class="w-full h-full aspect-video md:min-h-[350px] object-cover" controls data-v-841bd899${_scopeId2}><source${ssrRenderAttr("src", slide.video)} type="video/mp4" data-v-841bd899${_scopeId2}> Your browser does not support the video tag. </video></div>`);
                    } else {
                      _push3(`<!---->`);
                    }
                    _push3(`</div>`);
                  } else {
                    return [
                      createVNode("div", { class: "relative" }, [
                        createVNode("div", { class: "absolute mt-5 md:mt-10" }, [
                          createVNode("div", { class: "bg-primary min-w-[140px] lg:min-w-[232px] text-[12px] sm:text-[14px] md:text-[16px] text-white py-1 px-2 md:py-2 md:px-4 grid" }, [
                            createVNode("span", null, "Prijs :"),
                            createVNode("span", null, toDisplayString(__props.price) + " \u20AC per/" + toDisplayString(unref(montOrYear)), 1)
                          ])
                        ]),
                        slide.image ? (openBlock(), createBlock("img", {
                          key: 0,
                          src: slide.image,
                          alt: slide.image,
                          class: "w-full h-full aspect-video md:min-h-[350px] object-cover"
                        }, null, 8, ["src", "alt"])) : slide.thumbnail ? (openBlock(), createBlock("div", { key: 1 }, [
                          createVNode("video", {
                            class: "w-full h-full aspect-video md:min-h-[350px] object-cover",
                            controls: ""
                          }, [
                            createVNode("source", {
                              src: slide.video,
                              type: "video/mp4"
                            }, null, 8, ["src"]),
                            createTextVNode(" Your browser does not support the video tag. ")
                          ])
                        ])) : createCommentVNode("", true)
                      ])
                    ];
                  }
                }),
                _: 2
              }, _parent2, _scopeId));
            });
            _push2(`<!--]--><div class="h-full w-full bg-gradient-to-l inset-0 z-10" data-v-841bd899${_scopeId}>`);
            _push2(ssrRenderComponent(_component_Swiper, {
              modules: ["SwiperThumbs" in _ctx ? _ctx.SwiperThumbs : unref(Thumbs), "SwiperNavigation" in _ctx ? _ctx.SwiperNavigation : unref(Navigation)],
              onSwiper: setThumbsSwiper,
              "slides-per-view": 3,
              spaceBetween: 10,
              navigation: true,
              "css-mode": true,
              "watch-slides-progress": true
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<!--[-->`);
                  ssrRenderList(unref(allMedia), (slide, index) => {
                    _push3(ssrRenderComponent(_component_SwiperSlide, { class: "group overflow-hidden mt-3 cursor-pointer" }, {
                      default: withCtx((_3, _push4, _parent4, _scopeId3) => {
                        if (_push4) {
                          if (slide.thumbnail) {
                            _push4(`<div class="flex items-center justify-center relative" data-v-841bd899${_scopeId3}>`);
                            _push4(ssrRenderComponent(_component_Icon, {
                              name: "solar:play-bold",
                              class: "text-white absolute w-10 h-10 md:w-16 md:h-16 opacity-75 transition"
                            }, null, _parent4, _scopeId3));
                            _push4(`<img${ssrRenderAttr("src", slide.thumbnail)}${ssrRenderAttr("alt", slide.thumbnail)} class="group-hover:scale-125 transition-all max-h-[150px] md:max-h-[200px] w-full duration-300 object-cover aspect-square" data-v-841bd899${_scopeId3}></div>`);
                          } else if (slide.image) {
                            _push4(`<img${ssrRenderAttr("src", slide.image)}${ssrRenderAttr("alt", slide.image)} class="group-hover:scale-125 transition-all max-h-[150px] md:max-h-[200px] w-full duration-300 object-cover aspect-square" data-v-841bd899${_scopeId3}>`);
                          } else {
                            _push4(`<!---->`);
                          }
                        } else {
                          return [
                            slide.thumbnail ? (openBlock(), createBlock("div", {
                              key: 0,
                              class: "flex items-center justify-center relative"
                            }, [
                              createVNode(_component_Icon, {
                                name: "solar:play-bold",
                                class: "text-white absolute w-10 h-10 md:w-16 md:h-16 opacity-75 transition"
                              }),
                              createVNode("img", {
                                src: slide.thumbnail,
                                alt: slide.thumbnail,
                                class: "group-hover:scale-125 transition-all max-h-[150px] md:max-h-[200px] w-full duration-300 object-cover aspect-square"
                              }, null, 8, ["src", "alt"])
                            ])) : slide.image ? (openBlock(), createBlock("img", {
                              key: 1,
                              src: slide.image,
                              alt: slide.image,
                              class: "group-hover:scale-125 transition-all max-h-[150px] md:max-h-[200px] w-full duration-300 object-cover aspect-square"
                            }, null, 8, ["src", "alt"])) : createCommentVNode("", true)
                          ];
                        }
                      }),
                      _: 2
                    }, _parent3, _scopeId2));
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(allMedia), (slide, index) => {
                      return openBlock(), createBlock(_component_SwiperSlide, {
                        key: index,
                        class: "group overflow-hidden mt-3 cursor-pointer"
                      }, {
                        default: withCtx(() => [
                          slide.thumbnail ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "flex items-center justify-center relative"
                          }, [
                            createVNode(_component_Icon, {
                              name: "solar:play-bold",
                              class: "text-white absolute w-10 h-10 md:w-16 md:h-16 opacity-75 transition"
                            }),
                            createVNode("img", {
                              src: slide.thumbnail,
                              alt: slide.thumbnail,
                              class: "group-hover:scale-125 transition-all max-h-[150px] md:max-h-[200px] w-full duration-300 object-cover aspect-square"
                            }, null, 8, ["src", "alt"])
                          ])) : slide.image ? (openBlock(), createBlock("img", {
                            key: 1,
                            src: slide.image,
                            alt: slide.image,
                            class: "group-hover:scale-125 transition-all max-h-[150px] md:max-h-[200px] w-full duration-300 object-cover aspect-square"
                          }, null, 8, ["src", "alt"])) : createCommentVNode("", true)
                        ]),
                        _: 2
                      }, 1024);
                    }), 128))
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              (openBlock(true), createBlock(Fragment, null, renderList(unref(allMedia), (slide) => {
                return openBlock(), createBlock(_component_SwiperSlide, {
                  key: slide.id
                }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "relative" }, [
                      createVNode("div", { class: "absolute mt-5 md:mt-10" }, [
                        createVNode("div", { class: "bg-primary min-w-[140px] lg:min-w-[232px] text-[12px] sm:text-[14px] md:text-[16px] text-white py-1 px-2 md:py-2 md:px-4 grid" }, [
                          createVNode("span", null, "Prijs :"),
                          createVNode("span", null, toDisplayString(__props.price) + " \u20AC per/" + toDisplayString(unref(montOrYear)), 1)
                        ])
                      ]),
                      slide.image ? (openBlock(), createBlock("img", {
                        key: 0,
                        src: slide.image,
                        alt: slide.image,
                        class: "w-full h-full aspect-video md:min-h-[350px] object-cover"
                      }, null, 8, ["src", "alt"])) : slide.thumbnail ? (openBlock(), createBlock("div", { key: 1 }, [
                        createVNode("video", {
                          class: "w-full h-full aspect-video md:min-h-[350px] object-cover",
                          controls: ""
                        }, [
                          createVNode("source", {
                            src: slide.video,
                            type: "video/mp4"
                          }, null, 8, ["src"]),
                          createTextVNode(" Your browser does not support the video tag. ")
                        ])
                      ])) : createCommentVNode("", true)
                    ])
                  ]),
                  _: 2
                }, 1024);
              }), 128)),
              createVNode("div", { class: "h-full w-full bg-gradient-to-l inset-0 z-10" }, [
                createVNode(_component_Swiper, {
                  modules: ["SwiperThumbs" in _ctx ? _ctx.SwiperThumbs : unref(Thumbs), "SwiperNavigation" in _ctx ? _ctx.SwiperNavigation : unref(Navigation)],
                  onSwiper: setThumbsSwiper,
                  "slides-per-view": 3,
                  spaceBetween: 10,
                  navigation: true,
                  "css-mode": true,
                  "watch-slides-progress": true
                }, {
                  default: withCtx(() => [
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(allMedia), (slide, index) => {
                      return openBlock(), createBlock(_component_SwiperSlide, {
                        key: index,
                        class: "group overflow-hidden mt-3 cursor-pointer"
                      }, {
                        default: withCtx(() => [
                          slide.thumbnail ? (openBlock(), createBlock("div", {
                            key: 0,
                            class: "flex items-center justify-center relative"
                          }, [
                            createVNode(_component_Icon, {
                              name: "solar:play-bold",
                              class: "text-white absolute w-10 h-10 md:w-16 md:h-16 opacity-75 transition"
                            }),
                            createVNode("img", {
                              src: slide.thumbnail,
                              alt: slide.thumbnail,
                              class: "group-hover:scale-125 transition-all max-h-[150px] md:max-h-[200px] w-full duration-300 object-cover aspect-square"
                            }, null, 8, ["src", "alt"])
                          ])) : slide.image ? (openBlock(), createBlock("img", {
                            key: 1,
                            src: slide.image,
                            alt: slide.image,
                            class: "group-hover:scale-125 transition-all max-h-[150px] md:max-h-[200px] w-full duration-300 object-cover aspect-square"
                          }, null, 8, ["src", "alt"])) : createCommentVNode("", true)
                        ]),
                        _: 2
                      }, 1024);
                    }), 128))
                  ]),
                  _: 1
                }, 8, ["modules"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="mt-2 sm:mt-10 md:mt-9 w-[100%] text-justify" data-v-841bd899><h1 class="text-[#363636] text-[20px] font-semibold my-3" data-v-841bd899>${ssrInterpolate(__props.title)}</h1><span class="text-[12px] md:text-[14px] deskBody md:leading-9" data-v-841bd899>${__props.description}</span></div><p class="text-[#495057] text-base mt-10 mb-5 sm:mb-1 ml-1" data-v-841bd899> De faciliteiten op de locatie </p><div class="w-[95%] min-w-[70px] relative" data-v-841bd899><span class="absolute top-[-39px] text-primary text-4xl" data-v-841bd899>____</span><div class="overflow-x-auto" data-v-841bd899><table class="table md:mt-4" data-v-841bd899><tbody data-v-841bd899><!--[-->`);
      ssrRenderList((_a = unref(data)) == null ? void 0 : _a.data, (item, index) => {
        _push(`<tr class="flex justify-between items-center" data-v-841bd899><td class="text-[13px] w-[40%] sm:w-[50%]" data-v-841bd899>${ssrInterpolate(item.name)}</td><td class="w-[60%] sm:w-[50%] flex items-center text-quaternary gap-3" data-v-841bd899><img${ssrRenderAttr("src", getCheckboxImage(item.name))} alt="checkBox" data-v-841bd899><span class="text-sm" data-v-841bd899>${ssrInterpolate(item == null ? void 0 : item.name)} ${ssrInterpolate(getAvailabilityStatus(item.name))}</span></td></tr>`);
      });
      _push(`<!--]--></tbody></table></div></div></div><div class="col-span-4" data-v-841bd899>`);
      if (((_b = __props.special) == null ? void 0 : _b.length) > 0) {
        _push(`<div class="mb-3" data-v-841bd899><ul class="rounded-[8px] bg-[#859C811A] py-4 px-2 md:px-5" data-v-841bd899><!--[-->`);
        ssrRenderList(__props.special, (item) => {
          _push(`<li class="py-1 lg:py-2 flex items-center" data-v-841bd899><svg width="24" height="23" viewBox="0 0 24 23" fill="none" xmlns="http://www.w3.org/2000/svg" data-v-841bd899><g clip-path="url(#clip0_0_3781)" data-v-841bd899><path d="M12.2786 23C4.34698 22.4668 0.575981 14.2711 0.0558555 10.4064C-0.186019 9.40702 -0.139144 -0.387909 11.1086 0.0119072C22.356 0.411724 23.9014 8.14509 23.9816 9.00721C24.2415 11.8059 21.8359 21.7339 12.2786 23Z" class="fill-current text-primary" data-v-841bd899></path><path d="M7.53746 11.021L10.8247 14.3813L16.4621 8.61868" stroke="white" stroke-width="2" stroke-miterlimit="1.5" stroke-linecap="round" stroke-linejoin="round" data-v-841bd899></path></g><defs data-v-841bd899><clipPath id="clip0_0_3781" data-v-841bd899><path d="M0 10C0 4.47715 4.47715 0 10 0H14C19.5228 0 24 4.47715 24 10V13C24 18.5228 19.5228 23 14 23H10C4.47715 23 0 18.5228 0 13V10Z" fill="white" data-v-841bd899></path></clipPath></defs></svg><span class="pl-2 text-[12px] md:text-[14px]" data-v-841bd899>${ssrInterpolate(item.privilege)}</span></li>`);
        });
        _push(`<!--]--></ul></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="ml-1 md:ml-3" data-v-841bd899><p class="text-[14px] lg:text-[20px] text-[#363636] mb-4" data-v-841bd899> Adresgegevens </p><ul class="flex flex-col gap-1" data-v-841bd899><li class="text-[14px] text-[#4A4A4A]" data-v-841bd899>${ssrInterpolate(__props.address)}</li><li class="text-[12px] text-[#4A4A4A]" data-v-841bd899>${ssrInterpolate(__props.postcode)}</li><li class="text-[12px] md:text-[14px] text-[#4A4A4A]" data-v-841bd899>${ssrInterpolate(__props.location)}</li><li class="text-[13px] md:text-[14px] text-[#4A4A4A]" data-v-841bd899>${ssrInterpolate(__props.country)}</li></ul><div class="my-4 flex flex-col gap-3" data-v-841bd899>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `tel:${__props.phoneNumber}`,
        class: "flex gap-3 items-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} alt="phone-icon" data-v-841bd899${_scopeId}><p class="text-[#404040] text-[14px]" data-v-841bd899${_scopeId}> Tel : <span data-v-841bd899${_scopeId}>${ssrInterpolate(__props.phoneNumber)}</span></p>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                alt: "phone-icon"
              }),
              createVNode("p", { class: "text-[#404040] text-[14px]" }, [
                createTextVNode(" Tel : "),
                createVNode("span", null, toDisplayString(__props.phoneNumber), 1)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: `mailto:' + ${__props.email}`,
        class: "flex gap-3 items-center"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_1)} alt="phone-icon" data-v-841bd899${_scopeId}><p class="text-[#404040] text-[14px]" data-v-841bd899${_scopeId}> E-mail: <span data-v-841bd899${_scopeId}>${ssrInterpolate(__props.email)}</span></p>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_1,
                alt: "phone-icon"
              }),
              createVNode("p", { class: "text-[#404040] text-[14px]" }, [
                createTextVNode(" E-mail: "),
                createVNode("span", null, toDisplayString(__props.email), 1)
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="flex flex-col sm:flex-row text-white my-5 items-start gap-3" data-v-841bd899>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/contact/#contact-form",
        class: "bg-primary w-[50%] md:w-[90%] py-2 rounded-full text-center max-h-[50px] mb-3 hover:bg-secondary transition"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<p class="text-[12px] sm:text-[14px] text-center text-white font-thin" data-v-841bd899${_scopeId}> Aanvragen </p>`);
          } else {
            return [
              createVNode("p", { class: "text-[12px] sm:text-[14px] text-center text-white font-thin" }, " Aanvragen ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="relative w-[50%] md:w-[90%]" data-v-841bd899><div class="bg-primary cursor-pointer py-2 rounded-full text-center max-h-[50px] hover:bg-secondary transition" data-v-841bd899><p class="text-[12px] sm:text-[14px] text-center text-white font-thin" data-v-841bd899> Contact Opnemen </p></div>`);
      if (unref(showDropdownContactT)) {
        _push(`<div class="text-primary flex flex-col my-2 border-primary border rounded-[20px] overflow-hidden" data-v-841bd899>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `tel:${__props.phoneNumber}`,
          class: "flex items-center hover:bg-black hover:text-white transition py-2 px-4"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<p class="text-[14px]" data-v-841bd899${_scopeId}><span data-v-841bd899${_scopeId}>${ssrInterpolate(__props.phoneNumber)}</span></p>`);
            } else {
              return [
                createVNode("p", { class: "text-[14px]" }, [
                  createVNode("span", null, toDisplayString(__props.phoneNumber), 1)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `mailto:' + ${__props.email}`,
          class: "flex items-center hover:bg-black hover:text-white transition py-2 px-4"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<p class="text-[14px]" data-v-841bd899${_scopeId}><span data-v-841bd899${_scopeId}>${ssrInterpolate(__props.email)}</span></p>`);
            } else {
              return [
                createVNode("p", { class: "text-[14px]" }, [
                  createVNode("span", null, toDisplayString(__props.email), 1)
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div>`);
      _push(ssrRenderComponent(_component_MapMini, {
        latitude: __props.latitude,
        longitude: __props.longitude,
        levelType: __props.levelType
      }, null, _parent));
      _push(`</div></div></section>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/OnzeLocatiesSingle.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-841bd899"]]);
const _sfc_main = {
  __name: "[slug]",
  __ssrInlineRender: true,
  async setup(__props) {
    var _a, _b, _c;
    let __temp, __restore;
    const route = useRoute();
    const slug = computed(() => {
      var _a2;
      return (_a2 = route == null ? void 0 : route.params) == null ? void 0 : _a2.slug;
    });
    const { requestOptions } = useRequestOptions();
    const { data, error } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/products/${slug.value}`, {
      method: "get",
      ...requestOptions
    }, "$MHvbsNhZQ4")), __temp = await __temp, __restore(), __temp);
    const OnzeLocatiesData = (_a = data == null ? void 0 : data.value) == null ? void 0 : _a.data;
    [__temp, __restore] = withAsyncContext(() => useFetch(`/products`, {
      method: "get",
      ...requestOptions
    }, "$NSiGxnN0AG")), __temp = await __temp, __restore();
    const { data: sliderDataTest } = useFetch(`/featured-products`, {
      method: "get",
      ...requestOptions
    }, "$WSkW5EtoZn");
    const sortedData = computed(() => {
      var _a2, _b2;
      return (_b2 = (_a2 = sliderDataTest == null ? void 0 : sliderDataTest.value) == null ? void 0 : _a2.data) == null ? void 0 : _b2.slice().sort((a, b) => a.position - b.position);
    });
    if (error.value)
      ;
    useHead({
      title: (_c = (_b = data.value) == null ? void 0 : _b.data) == null ? void 0 : _c.name
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a2, _b2, _c2, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m, _n, _o, _p, _q, _r, _s;
      const _component_OnzeLocatiesSingle = __nuxt_component_0;
      const _component_SliderLocatiesSort = __nuxt_component_1;
      const _component_SliderTestimony = __nuxt_component_6;
      _push(`<!--[--><div class="mt-20"></div>`);
      _push(ssrRenderComponent(_component_OnzeLocatiesSingle, {
        title: (_a2 = unref(OnzeLocatiesData)) == null ? void 0 : _a2.name,
        postcode: (_b2 = unref(OnzeLocatiesData)) == null ? void 0 : _b2.postcode,
        country: (_c2 = unref(OnzeLocatiesData)) == null ? void 0 : _c2.country,
        address: (_d = unref(OnzeLocatiesData)) == null ? void 0 : _d.address,
        location: (_f = (_e = unref(OnzeLocatiesData)) == null ? void 0 : _e.location) == null ? void 0 : _f.name,
        rentType: (_g = unref(OnzeLocatiesData)) == null ? void 0 : _g.rent_type,
        category: (_h = unref(OnzeLocatiesData)) == null ? void 0 : _h.category_id,
        description: (_i = unref(OnzeLocatiesData)) == null ? void 0 : _i.description,
        imageSrc: (_j = unref(OnzeLocatiesData)) == null ? void 0 : _j.images,
        video: (_k = unref(OnzeLocatiesData)) == null ? void 0 : _k.video,
        email: (_l = unref(OnzeLocatiesData)) == null ? void 0 : _l.email,
        phoneNumber: (_m = unref(OnzeLocatiesData)) == null ? void 0 : _m.phone_number,
        latitude: (_n = unref(OnzeLocatiesData)) == null ? void 0 : _n.latitude,
        longitude: (_o = unref(OnzeLocatiesData)) == null ? void 0 : _o.longitude,
        price: (_p = unref(OnzeLocatiesData)) == null ? void 0 : _p.price,
        facility: (_q = unref(OnzeLocatiesData)) == null ? void 0 : _q.facility,
        special: (_r = unref(OnzeLocatiesData)) == null ? void 0 : _r.privileges,
        levelType: (_s = unref(OnzeLocatiesData)) == null ? void 0 : _s.level_type
      }, null, _parent));
      _push(ssrRenderComponent(_component_SliderLocatiesSort, { data: unref(sortedData) }, null, _parent));
      _push(ssrRenderComponent(_component_SliderTestimony, null, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/onze-locaties/[slug].vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=_slug_-b5a3c231.mjs.map
