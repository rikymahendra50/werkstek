const _slug__vue_vue_type_style_index_0_lang = ".col1{width:20%}.col2{width:30%}.col3{width:50%}";

const _slug_Styles_56c2c459 = [_slug__vue_vue_type_style_index_0_lang, _slug__vue_vue_type_style_index_0_lang];

export { _slug_Styles_56c2c459 as default };
//# sourceMappingURL=_slug_-styles.56c2c459.mjs.map
