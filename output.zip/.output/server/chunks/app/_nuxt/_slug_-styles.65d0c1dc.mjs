import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'devalue';
import 'vue/server-renderer';
import '@unhead/ssr';
import 'vue';
import 'unhead';
import '@unhead/shared';

const OnzeLocatiesSingle_vue_vue_type_style_index_0_scoped_841bd899_lang = "[data-v-841bd899] .swiper-button-next,[data-v-841bd899] .swiper-button-prev{background-color:#f0912d;background-position:50%;background-repeat:no-repeat;background-size:20px;border-radius:10px;width:30px}[data-v-841bd899] .swiper-button-next:hover,[data-v-841bd899] .swiper-button-prev:hover{background-color:#f0912d}[data-v-841bd899] .swiper-button-prev{background-image:url(" + publicAssetsURL("images/arrow-left.svg") + ");left:5px}[data-v-841bd899] .swiper-button-next{background-image:url(" + publicAssetsURL("images/arrow-right.svg") + ')}[data-v-841bd899] .swiper-button-next:after,[data-v-841bd899] .swiper-button-prev:after{content:""}@media (max-width:1028px){[data-v-841bd899] .swiper-button-next,[data-v-841bd899] .swiper-button-prev{opacity:.6;width:10px}[data-v-841bd899] .swiper-button-next{right:0}[data-v-841bd899] .swiper-button-prev{right:0}}';

const OnzeLocatiesSingle_vue_vue_type_style_index_1_lang = ".deskBody ol,.deskBody ul{list-style:revert;margin-left:20px}";

const _slug_Styles_65d0c1dc = [OnzeLocatiesSingle_vue_vue_type_style_index_0_scoped_841bd899_lang, OnzeLocatiesSingle_vue_vue_type_style_index_1_lang];

export { _slug_Styles_65d0c1dc as default };
//# sourceMappingURL=_slug_-styles.65d0c1dc.mjs.map
