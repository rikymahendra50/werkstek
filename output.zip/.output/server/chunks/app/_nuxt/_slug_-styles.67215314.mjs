const _slug__vue_vue_type_style_index_0_scoped_0badb0f4_lang = ".overflow-auto[data-v-0badb0f4]{overflow-y:auto}.overflow-auto[data-v-0badb0f4]::-webkit-scrollbar{display:none}";

const _slug_Styles_67215314 = [_slug__vue_vue_type_style_index_0_scoped_0badb0f4_lang, _slug__vue_vue_type_style_index_0_scoped_0badb0f4_lang];

export { _slug_Styles_67215314 as default };
//# sourceMappingURL=_slug_-styles.67215314.mjs.map
