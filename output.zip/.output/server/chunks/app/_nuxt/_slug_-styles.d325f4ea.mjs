const _slug__vue_vue_type_style_index_0_scoped_48a4d229_lang = ".overflow-auto[data-v-48a4d229]{overflow-y:auto}.overflow-auto[data-v-48a4d229]::-webkit-scrollbar{display:none}";

const _slug_Styles_d325f4ea = [_slug__vue_vue_type_style_index_0_scoped_48a4d229_lang, _slug__vue_vue_type_style_index_0_scoped_48a4d229_lang];

export { _slug_Styles_d325f4ea as default };
//# sourceMappingURL=_slug_-styles.d325f4ea.mjs.map
