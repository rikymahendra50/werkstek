import { _ as __nuxt_component_0 } from './BackButton-de34e53a.mjs';
import { Form, Field, ErrorMessage } from 'vee-validate';
import { _ as __nuxt_component_2 } from './BlogImageCrop-e341be04.mjs';
import { _ as _sfc_main$1 } from './TextField-7edd2a1a.mjs';
import { _ as __nuxt_component_3 } from './ButtonAddForm-aa118db7.mjs';
import { u as useAxios } from './useAxios-6c01fa3d.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions, a as useRouter, b as useRoute, d as useHead } from '../server.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { withAsyncContext, ref, unref, withCtx, isRef, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, withDirectives, vModelCheckbox, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-101122a4.mjs';
import { u as useSchema } from './useSchema-3365865c.mjs';
import { ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate, ssrIncludeBooleanAttr, ssrLooseContain } from 'vue/server-renderer';
import './Icon-e394d28f.mjs';
import './config-aab100d3.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './client-only-29ef7f45.mjs';
import './index-c7d55092.mjs';
import './index-73677d9a.mjs';
import 'axios';
import './asyncData-04c89180.mjs';
import 'zod';
import '@vee-validate/zod';

const _sfc_main = {
  __name: "add",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { axiosRequest } = useAxios();
    const { loading, transformErrors } = useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const snackbar = useSnackbar();
    const router = useRouter();
    useRoute();
    const { vacaturesSchema } = useSchema();
    const { data: location } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/locations`, {
      method: "get",
      ...requestOptions
    }, "$iJmg0Y3t7h")), __temp = await __temp, __restore(), __temp);
    const { data: type } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/type-jobs`, {
      method: "get",
      ...requestOptions
    }, "$yEj7fwOQyw")), __temp = await __temp, __restore(), __temp);
    const { data: privilages } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/categories`, {
      method: "get",
      ...requestOptions
    }, "$xLFKqxobUW")), __temp = await __temp, __restore(), __temp);
    function isRequired(value) {
      if (value && value.trim()) {
        return true;
      }
      return "This is required";
    }
    const formData = ref({
      title: void 0,
      hours: void 0,
      location_id: void 0,
      types: [],
      // Initialize with an empty object with type_id
      category: void 0,
      tags: []
      // Initialize with an empty object with name
    });
    ref([
      {
        id: 1,
        name: "Admin"
      },
      {
        id: 2,
        name: "CS"
      }
    ]);
    const selectedImage = ref();
    async function onSubmit(values, ctx) {
      try {
        loading.value = true;
        const formDataT = new FormData();
        formDataT.append("image", selectedImage.value);
        formDataT.append("title", formData.value.title);
        formDataT.append("hours", formData.value.hours);
        formDataT.append("location_id", formData.value.location_id);
        formDataT.append("category", formData.value.category);
        formData.value.tags.forEach((data, index) => {
          formDataT.append(`tags[${index}][name]`, data == null ? void 0 : data.name);
        });
        formData.value.types.forEach((data, index) => {
          formDataT.append(`types[${index}][type_id]`, data == null ? void 0 : data.type_id);
        });
        const response = await axiosRequest.post(`/admins/jobs`, formDataT);
        if (response.status >= 200 && response.status < 300) {
          snackbar.add({
            type: "success",
            text: "Data added successfully."
          });
          router.push("/admin/onze-vacatures");
        } else {
          throw new Error("Failed to add data. Unexpected status code.");
        }
      } catch (error) {
        if (error.response && error.response.data && error.response.data.message) {
          ctx.setErrors(transformErrors(error.response.data.message));
          snackbar.add({
            type: "error",
            text: error.response.data.message
          });
        } else {
          snackbar.add({
            type: "error",
            text: error.message || "Something went wrong."
          });
        }
      } finally {
        loading.value = false;
      }
    }
    useHead({
      title: "Add Property"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CompAdminBackButton = __nuxt_component_0;
      const _component_VeeField = Field;
      const _component_BlogImageCrop = __nuxt_component_2;
      const _component_VeeErrorMessage = ErrorMessage;
      const _component_FormTextField = _sfc_main$1;
      const _component_CompAdminButtonAddForm = __nuxt_component_3;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_CompAdminBackButton, {
        link: "onze-locaties",
        linkTitle: "Add Vacatures"
      }, null, _parent));
      _push(`<div class="overflow-y-auto grid md:grid-cols-2">`);
      _push(ssrRenderComponent(unref(Form), {
        onSubmit,
        "validation-schema": unref(vacaturesSchema),
        class: "text-[12px] md:text-[16px] flex-col flex items-center px-3 lg:px-8"
      }, {
        default: withCtx(({ error }, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d;
          if (_push2) {
            _push2(`<div class="w-full my-4"${_scopeId}><div class="mb-2"${_scopeId}>Image</div><div class="hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              type: "file",
              name: "image",
              id: "image",
              modelValue: unref(selectedImage),
              "onUpdate:modelValue": ($event) => isRef(selectedImage) ? selectedImage.value = $event : null
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_BlogImageCrop, {
              loading: unref(loading),
              name: "image",
              modelValue: unref(selectedImage),
              "onUpdate:modelValue": ($event) => isRef(selectedImage) ? selectedImage.value = $event : null
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "image",
              class: "text-red-500"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="title"${_scopeId}>Title</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "title",
              name: "title",
              modelValue: unref(formData).title,
              "onUpdate:modelValue": ($event) => unref(formData).title = $event,
              placeholder: "Title",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="location"${_scopeId}>Location</label></div>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "location",
              name: "location",
              as: "select",
              modelValue: unref(formData).location_id,
              "onUpdate:modelValue": ($event) => unref(formData).location_id = $event,
              class: "select select-bordered w-full",
              placeholder: "location",
              autocomplete: "location"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                var _a2, _b2;
                if (_push3) {
                  _push3(`<option disabled selected${_scopeId2}>Location</option><!--[-->`);
                  ssrRenderList((_a2 = unref(location)) == null ? void 0 : _a2.data, (item) => {
                    _push3(`<option${ssrRenderAttr("value", item.id)}${_scopeId2}>${ssrInterpolate(item.name)}</option>`);
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    createVNode("option", {
                      disabled: "",
                      selected: ""
                    }, "Location"),
                    (openBlock(true), createBlock(Fragment, null, renderList((_b2 = unref(location)) == null ? void 0 : _b2.data, (item) => {
                      return openBlock(), createBlock("option", {
                        value: item.id
                      }, toDisplayString(item.name), 9, ["value"]);
                    }), 256))
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "location",
              class: "form-error-message text-red-600"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="category"${_scopeId}>Category</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "category",
              name: "category",
              modelValue: unref(formData).category,
              "onUpdate:modelValue": ($event) => unref(formData).category = $event,
              placeholder: "Category",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col gap-3 my-2 w-full"${_scopeId}><div${_scopeId}>Tags</div><!--[-->`);
            ssrRenderList((_a = unref(privilages)) == null ? void 0 : _a.data, (item) => {
              _push2(`<div class="flex items-center gap-3"${_scopeId}><input${ssrRenderAttr("id", `test + ${item.id}`)} name="tags"${ssrIncludeBooleanAttr(Array.isArray(unref(formData).tags) ? ssrLooseContain(unref(formData).tags, { name: item.name }) : unref(formData).tags) ? " checked" : ""} class="input-bordered" type="checkbox"${ssrRenderAttr("value", { name: item.name })}${_scopeId}><label${ssrRenderAttr("for", `test + ${item.id}`)}${_scopeId}>${ssrInterpolate(item.name)}</label></div>`);
            });
            _push2(`<!--]-->`);
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "tags",
              class: "form-error-message text-red-600"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="hours"${_scopeId}>Hours</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "hours",
              name: "hours",
              type: "string",
              modelValue: unref(formData).hours,
              "onUpdate:modelValue": ($event) => unref(formData).hours = $event,
              placeholder: "hours",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col gap-3 my-2 w-full"${_scopeId}><div${_scopeId}>Types</div><!--[-->`);
            ssrRenderList((_b = unref(type)) == null ? void 0 : _b.data, (item) => {
              _push2(`<div class="flex items-center gap-3"${_scopeId}><input${ssrRenderAttr("id", `test2 + ${item.id}`)}${ssrRenderAttr("name", `test2 + ${item.name}`)}${ssrIncludeBooleanAttr(Array.isArray(unref(formData).types) ? ssrLooseContain(unref(formData).types, { type_id: item.id }) : unref(formData).types) ? " checked" : ""} class="input-bordered" type="checkbox"${ssrRenderAttr("value", { type_id: item.id })}${ssrRenderAttr("rules", isRequired)}${_scopeId}><label${ssrRenderAttr("for", `test2 + ${item.id}`)}${_scopeId}>${ssrInterpolate(item.name)}</label></div>`);
            });
            _push2(`<!--]-->`);
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "types",
              class: "form-error-message text-red-600"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex justify-end w-full mt-3"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_CompAdminButtonAddForm, {
              buttonName: "Add Vacatures",
              isLoading: unref(loading)
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "w-full my-4" }, [
                createVNode("div", { class: "mb-2" }, "Image"),
                createVNode("div", { class: "hidden" }, [
                  createVNode(_component_VeeField, {
                    type: "file",
                    name: "image",
                    id: "image",
                    modelValue: unref(selectedImage),
                    "onUpdate:modelValue": ($event) => isRef(selectedImage) ? selectedImage.value = $event : null
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode(_component_BlogImageCrop, {
                  loading: unref(loading),
                  name: "image",
                  modelValue: unref(selectedImage),
                  "onUpdate:modelValue": ($event) => isRef(selectedImage) ? selectedImage.value = $event : null
                }, null, 8, ["loading", "modelValue", "onUpdate:modelValue"]),
                createVNode(_component_VeeErrorMessage, {
                  name: "image",
                  class: "text-red-500"
                })
              ]),
              createVNode("div", { class: "flex flex-col w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "title" }, "Title")
                ]),
                createVNode(_component_FormTextField, {
                  id: "title",
                  name: "title",
                  modelValue: unref(formData).title,
                  "onUpdate:modelValue": ($event) => unref(formData).title = $event,
                  placeholder: "Title",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "location" }, "Location")
                ]),
                createVNode(_component_VeeField, {
                  id: "location",
                  name: "location",
                  as: "select",
                  modelValue: unref(formData).location_id,
                  "onUpdate:modelValue": ($event) => unref(formData).location_id = $event,
                  class: "select select-bordered w-full",
                  placeholder: "location",
                  autocomplete: "location"
                }, {
                  default: withCtx(() => {
                    var _a2;
                    return [
                      createVNode("option", {
                        disabled: "",
                        selected: ""
                      }, "Location"),
                      (openBlock(true), createBlock(Fragment, null, renderList((_a2 = unref(location)) == null ? void 0 : _a2.data, (item) => {
                        return openBlock(), createBlock("option", {
                          value: item.id
                        }, toDisplayString(item.name), 9, ["value"]);
                      }), 256))
                    ];
                  }),
                  _: 1
                }, 8, ["modelValue", "onUpdate:modelValue"]),
                createVNode(_component_VeeErrorMessage, {
                  name: "location",
                  class: "form-error-message text-red-600"
                })
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "category" }, "Category")
                ]),
                createVNode(_component_FormTextField, {
                  id: "category",
                  name: "category",
                  modelValue: unref(formData).category,
                  "onUpdate:modelValue": ($event) => unref(formData).category = $event,
                  placeholder: "Category",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "flex flex-col gap-3 my-2 w-full" }, [
                createVNode("div", null, "Tags"),
                (openBlock(true), createBlock(Fragment, null, renderList((_c = unref(privilages)) == null ? void 0 : _c.data, (item) => {
                  return openBlock(), createBlock("div", { class: "flex items-center gap-3" }, [
                    withDirectives(createVNode("input", {
                      id: `test + ${item.id}`,
                      name: "tags",
                      "onUpdate:modelValue": ($event) => unref(formData).tags = $event,
                      class: "input-bordered",
                      type: "checkbox",
                      value: { name: item.name }
                    }, null, 8, ["id", "onUpdate:modelValue", "value"]), [
                      [vModelCheckbox, unref(formData).tags]
                    ]),
                    createVNode("label", {
                      for: `test + ${item.id}`
                    }, toDisplayString(item.name), 9, ["for"])
                  ]);
                }), 256)),
                createVNode(_component_VeeErrorMessage, {
                  name: "tags",
                  class: "form-error-message text-red-600"
                })
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "hours" }, "Hours")
                ]),
                createVNode(_component_FormTextField, {
                  id: "hours",
                  name: "hours",
                  type: "string",
                  modelValue: unref(formData).hours,
                  "onUpdate:modelValue": ($event) => unref(formData).hours = $event,
                  placeholder: "hours",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "flex flex-col gap-3 my-2 w-full" }, [
                createVNode("div", null, "Types"),
                (openBlock(true), createBlock(Fragment, null, renderList((_d = unref(type)) == null ? void 0 : _d.data, (item) => {
                  return openBlock(), createBlock("div", { class: "flex items-center gap-3" }, [
                    withDirectives(createVNode("input", {
                      id: `test2 + ${item.id}`,
                      name: `test2 + ${item.name}`,
                      "onUpdate:modelValue": ($event) => unref(formData).types = $event,
                      class: "input-bordered",
                      type: "checkbox",
                      value: { type_id: item.id },
                      rules: isRequired
                    }, null, 8, ["id", "name", "onUpdate:modelValue", "value"]), [
                      [vModelCheckbox, unref(formData).types]
                    ]),
                    createVNode("label", {
                      for: `test2 + ${item.id}`
                    }, toDisplayString(item.name), 9, ["for"])
                  ]);
                }), 256)),
                createVNode(_component_VeeErrorMessage, {
                  name: "types",
                  class: "form-error-message text-red-600"
                })
              ]),
              createVNode("div", { class: "flex justify-end w-full mt-3" }, [
                createVNode(_component_CompAdminButtonAddForm, {
                  buttonName: "Add Vacatures",
                  isLoading: unref(loading)
                }, null, 8, ["isLoading"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/onze-vacatures/add.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=add-10ac9a61.mjs.map
