import { _ as __nuxt_component_0 } from './BackButton-de34e53a.mjs';
import { Form, Field, ErrorMessage } from 'vee-validate';
import { _ as _sfc_main$1 } from './TextField-7edd2a1a.mjs';
import { _ as __nuxt_component_4 } from './TextEditor-8ba1b852.mjs';
import { _ as __nuxt_component_6 } from './MapsTest-40b91c11.mjs';
import { _ as __nuxt_component_3 } from './ButtonAddForm-aa118db7.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions, a as useRouter, b as useRoute, d as useHead } from '../server.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { withAsyncContext, ref, watch, unref, withCtx, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, createTextVNode, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-101122a4.mjs';
import { u as useSchema } from './useSchema-3365865c.mjs';
import { ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import './Icon-e394d28f.mjs';
import './config-aab100d3.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import '@tiptap/vue-3';
import '@tiptap/starter-kit';
import './asyncData-04c89180.mjs';
import 'zod';
import '@vee-validate/zod';

const _sfc_main = {
  __name: "add",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { loading, transformErrors } = useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const snackbar = useSnackbar();
    const router = useRouter();
    useRoute();
    const { formInput } = useSchema();
    const { data: dataPrivilages } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/category-list`, {
      headers: {
        accept: "application/json"
      },
      method: "get",
      ...requestOptions
    }, "$N937qazUqS")), __temp = await __temp, __restore(), __temp);
    const dataIsSaleAble = ref([
      {
        id: 1,
        name: "Yes",
        value: 1
      },
      {
        id: 2,
        name: "No",
        value: 0
      }
    ]);
    const { data: facilities, error } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/facility-list`, {
      headers: {
        accept: "application/json"
      },
      method: "get",
      ...requestOptions
    }, "$Gt3tLu8G4w")), __temp = await __temp, __restore(), __temp);
    const { data: location } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/locations-list`, {
      headers: {
        accept: "application/json"
      },
      method: "get",
      ...requestOptions
    }, "$lkfc8U7TPl")), __temp = await __temp, __restore(), __temp);
    const { data: type } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/type-list`, {
      headers: {
        accept: "application/json"
      },
      method: "get",
      ...requestOptions
    }, "$xI8fqskAmI")), __temp = await __temp, __restore(), __temp);
    const { data: levelType } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/level-type-list`, {
      headers: {
        accept: "application/json"
      },
      method: "get",
      ...requestOptions
    }, "$N2FDpq1QmX")), __temp = await __temp, __restore(), __temp);
    const formData = ref({
      name: void 0,
      description: void 0,
      email: void 0,
      country: void 0,
      postcode: void 0,
      address: void 0,
      phone_number: void 0,
      latitude: void 0,
      longitude: void 0,
      price: void 0,
      rent_type: void 0,
      area_size: void 0,
      location_id: void 0,
      type_id: void 0,
      level_type_id: void 0,
      is_saleable: dataIsSaleAble.value[0].value,
      product_facilities: [],
      product_privileges: [],
      rating: void 0
    });
    watch(
      () => formData.value.description,
      (newValue) => {
        if (newValue === "<p></p>" || !newValue) {
          formData.value.description = void 0;
        }
      }
    );
    async function onSubmit(values, ctx) {
      var _a2;
      var _a, _b, _c;
      loading.value = true;
      const { data, error: error2 } = await useFetch("/admins/products", {
        method: "POST",
        body: JSON.stringify(formData.value),
        ...requestOptions
      }, "$QrPA7itO5k");
      if (error2.value) {
        ctx.setErrors(transformErrors((_a = error2.value) == null ? void 0 : _a.data));
        snackbar.add({
          type: "error",
          text: (_a2 = (_c = (_b = error2.value) == null ? void 0 : _b.data) == null ? void 0 : _c.message) != null ? _a2 : "Something went wrong"
        });
      } else {
        snackbar.add({
          type: "success",
          text: "Success Adding Data"
        });
        router.push("/admin/onze-locaties");
      }
      loading.value = false;
    }
    useHead({
      title: "Add Property"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CompAdminBackButton = __nuxt_component_0;
      const _component_VeeForm = Form;
      const _component_FormTextField = _sfc_main$1;
      const _component_VeeField = Field;
      const _component_FormTextEditor = __nuxt_component_4;
      const _component_VeeErrorMessage = ErrorMessage;
      const _component_MapsTest = __nuxt_component_6;
      const _component_CompAdminButtonAddForm = __nuxt_component_3;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_CompAdminBackButton, {
        link: "onze-locaties",
        linkTitle: "Add Property"
      }, null, _parent));
      _push(`<div class="overflow-y-auto grid md:grid-cols-2">`);
      _push(ssrRenderComponent(_component_VeeForm, {
        onSubmit,
        class: "text-[12px] md:text-[16px] flex-col flex items-center px-3 lg:px-8",
        "validation-schema": unref(formInput)
      }, {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          var _a, _b, _c, _d;
          if (_push2) {
            _push2(`<div class="flex flex-col w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="name"${_scopeId}>Name</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "name",
              name: "name",
              modelValue: unref(formData).name,
              "onUpdate:modelValue": ($event) => unref(formData).name = $event,
              placeholder: "Name",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-5 w-full"${_scopeId}><span${_scopeId}>Description</span><div class="hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              name: "body",
              modelValue: unref(formData).description,
              "onUpdate:modelValue": ($event) => unref(formData).description = $event
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_FormTextEditor, {
              modelValue: unref(formData).description,
              "onUpdate:modelValue": ($event) => unref(formData).description = $event,
              "is-error": !!errors.body
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "body",
              class: "text-red-500"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="email"${_scopeId}>Email</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "email",
              name: "email",
              modelValue: unref(formData).email,
              "onUpdate:modelValue": ($event) => unref(formData).email = $event,
              placeholder: "ex:werstek@gmail.com",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="postcode"${_scopeId}>Postcode</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "postcode",
              name: "postcode",
              modelValue: unref(formData).postcode,
              "onUpdate:modelValue": ($event) => unref(formData).postcode = $event,
              placeholder: "ex:43121",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="address"${_scopeId}>Address</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "address",
              name: "address",
              modelValue: unref(formData).address,
              "onUpdate:modelValue": ($event) => unref(formData).address = $event,
              placeholder: "Address",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="country"${_scopeId}>Country</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "country",
              name: "country",
              modelValue: unref(formData).country,
              "onUpdate:modelValue": ($event) => unref(formData).country = $event,
              placeholder: "ex:Nederland",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="phone"${_scopeId}>Phone Number</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "phone",
              name: "phone",
              type: "text",
              modelValue: unref(formData).phone_number,
              "onUpdate:modelValue": ($event) => unref(formData).phone_number = $event,
              placeholder: "ex:6221210291",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="w-full p-3 rounded-md"${_scopeId}><div${_scopeId}><p class="mb-3"${_scopeId}> Please find and click the desired location to get the coordinate value. </p>`);
            _push2(ssrRenderComponent(_component_MapsTest, {
              latitude: unref(formData).latitude,
              "onUpdate:latitude": ($event) => unref(formData).latitude = $event,
              longitude: unref(formData).longitude,
              "onUpdate:longitude": ($event) => unref(formData).longitude = $event
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="latitude"${_scopeId}>Latitude</label></div>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "latitude",
              name: "latitude",
              type: "text",
              modelValue: unref(formData).latitude,
              "onUpdate:modelValue": ($event) => unref(formData).latitude = $event,
              placeholder: "ex:51.9934345296239",
              class: "input-bordered input-disabled input",
              autocomplete: "on",
              disabled: ""
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="longitude"${_scopeId}>Longitude</label></div>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "longitude",
              name: "longitude",
              type: "text",
              modelValue: unref(formData).longitude,
              "onUpdate:modelValue": ($event) => unref(formData).longitude = $event,
              placeholder: "ex:5.5162370519396349",
              class: "input-bordered input-disabled input",
              autocomplete: "on",
              disabled: ""
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "latitude",
              class: "text-red-500"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="price"${_scopeId}>Price</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "price",
              name: "price",
              type: "number",
              modelValue: unref(formData).price,
              "onUpdate:modelValue": ($event) => unref(formData).price = $event,
              placeholder: "ex:80",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="renttype"${_scopeId}>Rent Type</label></div>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "renttype",
              name: "renttype",
              as: "select",
              modelValue: unref(formData).rent_type,
              "onUpdate:modelValue": ($event) => unref(formData).rent_type = $event,
              class: "select select-bordered w-full",
              placeholder: "renttype",
              autocomplete: "renttype"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<option disabled selected${_scopeId2}>Rent Type</option><option value="monthly"${_scopeId2}>Montly</option><option value="yearly"${_scopeId2}>Yearly</option>`);
                } else {
                  return [
                    createVNode("option", {
                      disabled: "",
                      selected: ""
                    }, "Rent Type"),
                    createVNode("option", { value: "monthly" }, "Montly"),
                    createVNode("option", { value: "yearly" }, "Yearly")
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "renttype",
              class: "form-error-message text-red-600"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="areasize"${_scopeId}>Area Size</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "areasize",
              name: "areasize",
              type: "number",
              modelValue: unref(formData).area_size,
              "onUpdate:modelValue": ($event) => unref(formData).area_size = $event,
              placeholder: "ex:80",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="rating"${_scopeId}>Rating</label></div>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "rating",
              name: "rating",
              type: "number",
              modelValue: unref(formData).rating,
              "onUpdate:modelValue": ($event) => unref(formData).rating = $event,
              placeholder: "ex:10",
              class: "input-bordered",
              autocomplete: "off"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="location"${_scopeId}>Location</label></div>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "location",
              name: "location",
              as: "select",
              modelValue: unref(formData).location_id,
              "onUpdate:modelValue": ($event) => unref(formData).location_id = $event,
              class: "select select-bordered w-full",
              placeholder: "location"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                var _a2, _b2;
                if (_push3) {
                  _push3(`<option disabled selected${_scopeId2}>Location</option><!--[-->`);
                  ssrRenderList((_a2 = unref(location)) == null ? void 0 : _a2.data, (item) => {
                    _push3(`<option${ssrRenderAttr("value", item.id)}${_scopeId2}>${ssrInterpolate(item.name)}</option>`);
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    createVNode("option", {
                      disabled: "",
                      selected: ""
                    }, "Location"),
                    (openBlock(true), createBlock(Fragment, null, renderList((_b2 = unref(location)) == null ? void 0 : _b2.data, (item) => {
                      return openBlock(), createBlock("option", {
                        value: item.id
                      }, toDisplayString(item.name), 9, ["value"]);
                    }), 256))
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "location",
              class: "form-error-message text-red-600"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="type"${_scopeId}>Type</label></div>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "type",
              name: "type",
              as: "select",
              modelValue: unref(formData).type_id,
              "onUpdate:modelValue": ($event) => unref(formData).type_id = $event,
              class: "select select-bordered w-full",
              placeholder: "type"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<option disabled selected${_scopeId2}>Type</option><!--[-->`);
                  ssrRenderList(unref(type), (item) => {
                    _push3(`<option${ssrRenderAttr("value", item.id)}${_scopeId2}>${ssrInterpolate(item.name)}</option>`);
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    createVNode("option", {
                      disabled: "",
                      selected: ""
                    }, "Type"),
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(type), (item) => {
                      return openBlock(), createBlock("option", {
                        value: item.id
                      }, toDisplayString(item.name), 9, ["value"]);
                    }), 256))
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "type",
              class: "form-error-message text-red-600"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="flex items-center"${_scopeId}><label for="leveltype"${_scopeId}>Level Type</label></div>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "leveltype",
              name: "leveltype",
              as: "select",
              modelValue: unref(formData).level_type_id,
              "onUpdate:modelValue": ($event) => unref(formData).level_type_id = $event,
              class: "select select-bordered w-full",
              placeholder: "Level Type",
              autocomplete: "off"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                var _a2, _b2;
                if (_push3) {
                  _push3(`<option disabled selected${_scopeId2}>Level Type</option><!--[-->`);
                  ssrRenderList((_a2 = unref(levelType)) == null ? void 0 : _a2.data, (item) => {
                    _push3(`<option${ssrRenderAttr("value", item.id)}${_scopeId2}>${ssrInterpolate(item.name)}</option>`);
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    createVNode("option", {
                      disabled: "",
                      selected: ""
                    }, "Level Type"),
                    (openBlock(true), createBlock(Fragment, null, renderList((_b2 = unref(levelType)) == null ? void 0 : _b2.data, (item) => {
                      return openBlock(), createBlock("option", {
                        value: item.id
                      }, toDisplayString(item.name), 9, ["value"]);
                    }), 256))
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "leveltype",
              class: "form-error-message text-red-600"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="grid gap-2"${_scopeId}><div class="flex items-center"${_scopeId}><span${_scopeId}>Facilities</span></div><!--[-->`);
            ssrRenderList((_a = unref(facilities)) == null ? void 0 : _a.data, (item) => {
              _push2(`<label class="checkbox-label flex gap-2"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_VeeField, {
                id: `facilities + ${item.id}`,
                name: `facilities + ${item.name}`,
                type: "checkbox",
                value: { facility_id: item.id },
                modelValue: unref(formData).product_facilities,
                "onUpdate:modelValue": ($event) => unref(formData).product_facilities = $event,
                placeholder: "facilities",
                autocomplete: "facilities"
              }, null, _parent2, _scopeId));
              _push2(` ${ssrInterpolate(item.name)}</label>`);
            });
            _push2(`<!--]--></div></div><div class="flex flex-col my-2 w-full"${_scopeId}><div class="grid gap-2"${_scopeId}><div class="flex items-center"${_scopeId}><span${_scopeId}>Privileges</span></div><!--[-->`);
            ssrRenderList((_b = unref(dataPrivilages)) == null ? void 0 : _b.data, (item) => {
              _push2(`<label class="checkbox-label flex gap-2"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_VeeField, {
                id: `privileges + ${item.id}`,
                name: `privileges + ${item.name}`,
                type: "checkbox",
                value: { privilege: item.name },
                modelValue: unref(formData).product_privileges,
                "onUpdate:modelValue": ($event) => unref(formData).product_privileges = $event,
                placeholder: "privileges",
                autocomplete: "privileges"
              }, null, _parent2, _scopeId));
              _push2(` ${ssrInterpolate(item.name)}</label>`);
            });
            _push2(`<!--]--></div></div><div class="flex-col my-2 w-full hidden"${_scopeId}><div class="grid gap-2"${_scopeId}><div class="flex items-center"${_scopeId}><span${_scopeId}>Is Saleable</span></div><!--[-->`);
            ssrRenderList(unref(dataIsSaleAble), (item) => {
              _push2(`<label class="checkbox-label flex gap-2"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_VeeField, {
                id: `isSaleAble + ${item.id}`,
                name: `isSaleAble + ${item.name}`,
                type: "radio",
                value: item.value,
                modelValue: unref(formData).is_saleable,
                "onUpdate:modelValue": ($event) => unref(formData).is_saleable = $event,
                placeholder: "privileges",
                autocomplete: "privileges"
              }, null, _parent2, _scopeId));
              _push2(` ${ssrInterpolate(item.name)}</label>`);
            });
            _push2(`<!--]--></div></div><div class="flex justify-end w-full"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_CompAdminButtonAddForm, {
              buttonName: "Add Property",
              isLoading: unref(loading)
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "name" }, "Name")
                ]),
                createVNode(_component_FormTextField, {
                  id: "name",
                  name: "name",
                  modelValue: unref(formData).name,
                  "onUpdate:modelValue": ($event) => unref(formData).name = $event,
                  placeholder: "Name",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "flex flex-col my-5 w-full" }, [
                createVNode("span", null, "Description"),
                createVNode("div", { class: "hidden" }, [
                  createVNode(_component_VeeField, {
                    name: "body",
                    modelValue: unref(formData).description,
                    "onUpdate:modelValue": ($event) => unref(formData).description = $event
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode(_component_FormTextEditor, {
                  modelValue: unref(formData).description,
                  "onUpdate:modelValue": ($event) => unref(formData).description = $event,
                  "is-error": !!errors.body
                }, null, 8, ["modelValue", "onUpdate:modelValue", "is-error"]),
                createVNode(_component_VeeErrorMessage, {
                  name: "body",
                  class: "text-red-500"
                })
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "email" }, "Email")
                ]),
                createVNode(_component_FormTextField, {
                  id: "email",
                  name: "email",
                  modelValue: unref(formData).email,
                  "onUpdate:modelValue": ($event) => unref(formData).email = $event,
                  placeholder: "ex:werstek@gmail.com",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "postcode" }, "Postcode")
                ]),
                createVNode(_component_FormTextField, {
                  id: "postcode",
                  name: "postcode",
                  modelValue: unref(formData).postcode,
                  "onUpdate:modelValue": ($event) => unref(formData).postcode = $event,
                  placeholder: "ex:43121",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "address" }, "Address")
                ]),
                createVNode(_component_FormTextField, {
                  id: "address",
                  name: "address",
                  modelValue: unref(formData).address,
                  "onUpdate:modelValue": ($event) => unref(formData).address = $event,
                  placeholder: "Address",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "country" }, "Country")
                ]),
                createVNode(_component_FormTextField, {
                  id: "country",
                  name: "country",
                  modelValue: unref(formData).country,
                  "onUpdate:modelValue": ($event) => unref(formData).country = $event,
                  placeholder: "ex:Nederland",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "phone" }, "Phone Number")
                ]),
                createVNode(_component_FormTextField, {
                  id: "phone",
                  name: "phone",
                  type: "text",
                  modelValue: unref(formData).phone_number,
                  "onUpdate:modelValue": ($event) => unref(formData).phone_number = $event,
                  placeholder: "ex:6221210291",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "w-full p-3 rounded-md" }, [
                createVNode("div", null, [
                  createVNode("p", { class: "mb-3" }, " Please find and click the desired location to get the coordinate value. "),
                  createVNode(_component_MapsTest, {
                    latitude: unref(formData).latitude,
                    "onUpdate:latitude": ($event) => unref(formData).latitude = $event,
                    longitude: unref(formData).longitude,
                    "onUpdate:longitude": ($event) => unref(formData).longitude = $event
                  }, null, 8, ["latitude", "onUpdate:latitude", "longitude", "onUpdate:longitude"])
                ]),
                createVNode("div", { class: "flex flex-col w-full" }, [
                  createVNode("div", { class: "flex items-center" }, [
                    createVNode("label", { for: "latitude" }, "Latitude")
                  ]),
                  createVNode(_component_VeeField, {
                    id: "latitude",
                    name: "latitude",
                    type: "text",
                    modelValue: unref(formData).latitude,
                    "onUpdate:modelValue": ($event) => unref(formData).latitude = $event,
                    placeholder: "ex:51.9934345296239",
                    class: "input-bordered input-disabled input",
                    autocomplete: "on",
                    disabled: ""
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                  createVNode("div", { class: "flex items-center" }, [
                    createVNode("label", { for: "longitude" }, "Longitude")
                  ]),
                  createVNode(_component_VeeField, {
                    id: "longitude",
                    name: "longitude",
                    type: "text",
                    modelValue: unref(formData).longitude,
                    "onUpdate:modelValue": ($event) => unref(formData).longitude = $event,
                    placeholder: "ex:5.5162370519396349",
                    class: "input-bordered input-disabled input",
                    autocomplete: "on",
                    disabled: ""
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode(_component_VeeErrorMessage, {
                  name: "latitude",
                  class: "text-red-500"
                })
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "price" }, "Price")
                ]),
                createVNode(_component_FormTextField, {
                  id: "price",
                  name: "price",
                  type: "number",
                  modelValue: unref(formData).price,
                  "onUpdate:modelValue": ($event) => unref(formData).price = $event,
                  placeholder: "ex:80",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "renttype" }, "Rent Type")
                ]),
                createVNode(_component_VeeField, {
                  id: "renttype",
                  name: "renttype",
                  as: "select",
                  modelValue: unref(formData).rent_type,
                  "onUpdate:modelValue": ($event) => unref(formData).rent_type = $event,
                  class: "select select-bordered w-full",
                  placeholder: "renttype",
                  autocomplete: "renttype"
                }, {
                  default: withCtx(() => [
                    createVNode("option", {
                      disabled: "",
                      selected: ""
                    }, "Rent Type"),
                    createVNode("option", { value: "monthly" }, "Montly"),
                    createVNode("option", { value: "yearly" }, "Yearly")
                  ]),
                  _: 1
                }, 8, ["modelValue", "onUpdate:modelValue"]),
                createVNode(_component_VeeErrorMessage, {
                  name: "renttype",
                  class: "form-error-message text-red-600"
                })
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "areasize" }, "Area Size")
                ]),
                createVNode(_component_FormTextField, {
                  id: "areasize",
                  name: "areasize",
                  type: "number",
                  modelValue: unref(formData).area_size,
                  "onUpdate:modelValue": ($event) => unref(formData).area_size = $event,
                  placeholder: "ex:80",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "rating" }, "Rating")
                ]),
                createVNode(_component_FormTextField, {
                  id: "rating",
                  name: "rating",
                  type: "number",
                  modelValue: unref(formData).rating,
                  "onUpdate:modelValue": ($event) => unref(formData).rating = $event,
                  placeholder: "ex:10",
                  class: "input-bordered",
                  autocomplete: "off"
                }, null, 8, ["modelValue", "onUpdate:modelValue"])
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "location" }, "Location")
                ]),
                createVNode(_component_VeeField, {
                  id: "location",
                  name: "location",
                  as: "select",
                  modelValue: unref(formData).location_id,
                  "onUpdate:modelValue": ($event) => unref(formData).location_id = $event,
                  class: "select select-bordered w-full",
                  placeholder: "location"
                }, {
                  default: withCtx(() => {
                    var _a2;
                    return [
                      createVNode("option", {
                        disabled: "",
                        selected: ""
                      }, "Location"),
                      (openBlock(true), createBlock(Fragment, null, renderList((_a2 = unref(location)) == null ? void 0 : _a2.data, (item) => {
                        return openBlock(), createBlock("option", {
                          value: item.id
                        }, toDisplayString(item.name), 9, ["value"]);
                      }), 256))
                    ];
                  }),
                  _: 1
                }, 8, ["modelValue", "onUpdate:modelValue"]),
                createVNode(_component_VeeErrorMessage, {
                  name: "location",
                  class: "form-error-message text-red-600"
                })
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "type" }, "Type")
                ]),
                createVNode(_component_VeeField, {
                  id: "type",
                  name: "type",
                  as: "select",
                  modelValue: unref(formData).type_id,
                  "onUpdate:modelValue": ($event) => unref(formData).type_id = $event,
                  class: "select select-bordered w-full",
                  placeholder: "type"
                }, {
                  default: withCtx(() => [
                    createVNode("option", {
                      disabled: "",
                      selected: ""
                    }, "Type"),
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(type), (item) => {
                      return openBlock(), createBlock("option", {
                        value: item.id
                      }, toDisplayString(item.name), 9, ["value"]);
                    }), 256))
                  ]),
                  _: 1
                }, 8, ["modelValue", "onUpdate:modelValue"]),
                createVNode(_component_VeeErrorMessage, {
                  name: "type",
                  class: "form-error-message text-red-600"
                })
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "flex items-center" }, [
                  createVNode("label", { for: "leveltype" }, "Level Type")
                ]),
                createVNode(_component_VeeField, {
                  id: "leveltype",
                  name: "leveltype",
                  as: "select",
                  modelValue: unref(formData).level_type_id,
                  "onUpdate:modelValue": ($event) => unref(formData).level_type_id = $event,
                  class: "select select-bordered w-full",
                  placeholder: "Level Type",
                  autocomplete: "off"
                }, {
                  default: withCtx(() => {
                    var _a2;
                    return [
                      createVNode("option", {
                        disabled: "",
                        selected: ""
                      }, "Level Type"),
                      (openBlock(true), createBlock(Fragment, null, renderList((_a2 = unref(levelType)) == null ? void 0 : _a2.data, (item) => {
                        return openBlock(), createBlock("option", {
                          value: item.id
                        }, toDisplayString(item.name), 9, ["value"]);
                      }), 256))
                    ];
                  }),
                  _: 1
                }, 8, ["modelValue", "onUpdate:modelValue"]),
                createVNode(_component_VeeErrorMessage, {
                  name: "leveltype",
                  class: "form-error-message text-red-600"
                })
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "grid gap-2" }, [
                  createVNode("div", { class: "flex items-center" }, [
                    createVNode("span", null, "Facilities")
                  ]),
                  (openBlock(true), createBlock(Fragment, null, renderList((_c = unref(facilities)) == null ? void 0 : _c.data, (item) => {
                    return openBlock(), createBlock("label", {
                      key: item.id,
                      class: "checkbox-label flex gap-2"
                    }, [
                      createVNode(_component_VeeField, {
                        id: `facilities + ${item.id}`,
                        name: `facilities + ${item.name}`,
                        type: "checkbox",
                        value: { facility_id: item.id },
                        modelValue: unref(formData).product_facilities,
                        "onUpdate:modelValue": ($event) => unref(formData).product_facilities = $event,
                        placeholder: "facilities",
                        autocomplete: "facilities"
                      }, null, 8, ["id", "name", "value", "modelValue", "onUpdate:modelValue"]),
                      createTextVNode(" " + toDisplayString(item.name), 1)
                    ]);
                  }), 128))
                ])
              ]),
              createVNode("div", { class: "flex flex-col my-2 w-full" }, [
                createVNode("div", { class: "grid gap-2" }, [
                  createVNode("div", { class: "flex items-center" }, [
                    createVNode("span", null, "Privileges")
                  ]),
                  (openBlock(true), createBlock(Fragment, null, renderList((_d = unref(dataPrivilages)) == null ? void 0 : _d.data, (item) => {
                    return openBlock(), createBlock("label", {
                      key: item.id,
                      class: "checkbox-label flex gap-2"
                    }, [
                      createVNode(_component_VeeField, {
                        id: `privileges + ${item.id}`,
                        name: `privileges + ${item.name}`,
                        type: "checkbox",
                        value: { privilege: item.name },
                        modelValue: unref(formData).product_privileges,
                        "onUpdate:modelValue": ($event) => unref(formData).product_privileges = $event,
                        placeholder: "privileges",
                        autocomplete: "privileges"
                      }, null, 8, ["id", "name", "value", "modelValue", "onUpdate:modelValue"]),
                      createTextVNode(" " + toDisplayString(item.name), 1)
                    ]);
                  }), 128))
                ])
              ]),
              createVNode("div", { class: "flex-col my-2 w-full hidden" }, [
                createVNode("div", { class: "grid gap-2" }, [
                  createVNode("div", { class: "flex items-center" }, [
                    createVNode("span", null, "Is Saleable")
                  ]),
                  (openBlock(true), createBlock(Fragment, null, renderList(unref(dataIsSaleAble), (item) => {
                    return openBlock(), createBlock("label", {
                      key: item.id,
                      class: "checkbox-label flex gap-2"
                    }, [
                      createVNode(_component_VeeField, {
                        id: `isSaleAble + ${item.id}`,
                        name: `isSaleAble + ${item.name}`,
                        type: "radio",
                        value: item.value,
                        modelValue: unref(formData).is_saleable,
                        "onUpdate:modelValue": ($event) => unref(formData).is_saleable = $event,
                        placeholder: "privileges",
                        autocomplete: "privileges"
                      }, null, 8, ["id", "name", "value", "modelValue", "onUpdate:modelValue"]),
                      createTextVNode(" " + toDisplayString(item.name), 1)
                    ]);
                  }), 128))
                ])
              ]),
              createVNode("div", { class: "flex justify-end w-full" }, [
                createVNode(_component_CompAdminButtonAddForm, {
                  buttonName: "Add Property",
                  isLoading: unref(loading)
                }, null, 8, ["isLoading"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/onze-locaties/add.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=add-1f2f5f32.mjs.map
