import { _ as __nuxt_component_0 } from './BackButton-454ea1e4.mjs';
import { Form, Field } from 'vee-validate';
import { _ as _sfc_main$1 } from './TextField-7edd2a1a.mjs';
import { _ as __nuxt_component_3 } from './ButtonAddForm-aa118db7.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { ref, mergeProps, withCtx, unref, isRef, createVNode, withDirectives, vModelText, useSSRContext } from 'vue';
import { u as useRouter, d as useHead, b as useFetch } from '../server.mjs';
import { u as useSchema } from './useSchema-3365865c.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import './Icon-7d2a1472.mjs';
import './config-54e8ad1b.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'zod';
import '@vee-validate/zod';

const _sfc_main = {
  __name: "add",
  __ssrInlineRender: true,
  setup(__props) {
    const { loading, transformErrors } = useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const snackbar = useSnackbar();
    const router = useRouter();
    useSchema();
    ref(null);
    const formData = ref({
      name: void 0,
      color: void 0
    });
    ref();
    const selectedImage = ref();
    async function onSubmit(values, ctx) {
      var _a2;
      var _a, _b, _c;
      loading.value = true;
      const object = { ...formData.value };
      const formDataT = new FormData();
      for (const item in object) {
        const objectItem = object[item];
        formDataT.append(item, objectItem);
      }
      if (selectedImage.value) {
        formDataT.append("image", selectedImage.value);
      }
      const { error, data } = await useFetch(`/admins/level-types`, {
        method: "POST",
        body: formDataT,
        ...requestOptions
      }, "$vuKcmXFwRF");
      if (error.value) {
        ctx.setErrors(transformErrors((_a = error == null ? void 0 : error.value) == null ? void 0 : _a.data));
        snackbar.add({
          type: "error",
          text: (_a2 = (_c = (_b = error.value) == null ? void 0 : _b.data) == null ? void 0 : _c.message) != null ? _a2 : "Something went wrong"
        });
      } else if (data.value) {
        snackbar.add({
          type: "success",
          text: "Add Level Type Success"
        });
        router.push("/admin/level-type");
      }
      loading.value = false;
    }
    useHead({
      title: "Add Level Type"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CompAdminBackButton = __nuxt_component_0;
      const _component_VeeForm = Form;
      const _component_VeeField = Field;
      const _component_FormTextField = _sfc_main$1;
      const _component_CompAdminButtonAddForm = __nuxt_component_3;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "overflow-auto" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_CompAdminBackButton, {
        link: "level-type",
        linkTitle: "Add Level Type"
      }, null, _parent));
      _push(`<div class="grid grid-cols-2">`);
      _push(ssrRenderComponent(_component_VeeForm, { onSubmit }, {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid mt-10 p-3 gap-2"${_scopeId}><div${_scopeId}><p class="pb-2"${_scopeId}>Image</p>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              type: "file",
              name: "image",
              class: "file-input file-input-bordered w-full max-w-xs",
              modelValue: unref(selectedImage),
              "onUpdate:modelValue": ($event) => isRef(selectedImage) ? selectedImage.value = $event : null
            }, null, _parent2, _scopeId));
            _push2(`</div><label for="name"${_scopeId}>Name</label>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "name",
              name: "name",
              modelValue: unref(formData).name,
              "onUpdate:modelValue": ($event) => unref(formData).name = $event,
              placeholder: "Name",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`<label for="color"${_scopeId}>Color Border</label><input id="color" name="color" type="color"${ssrRenderAttr("value", unref(formData).color)} placeholder="Color" class="input-bordered" autocomplete="on"${_scopeId}></div><div class="flex justify-end mt-5"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_CompAdminButtonAddForm, {
              buttonName: "Add Level Type",
              isLoading: unref(loading)
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "grid mt-10 p-3 gap-2" }, [
                createVNode("div", null, [
                  createVNode("p", { class: "pb-2" }, "Image"),
                  createVNode(_component_VeeField, {
                    type: "file",
                    name: "image",
                    class: "file-input file-input-bordered w-full max-w-xs",
                    modelValue: unref(selectedImage),
                    "onUpdate:modelValue": ($event) => isRef(selectedImage) ? selectedImage.value = $event : null
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode("label", { for: "name" }, "Name"),
                createVNode(_component_FormTextField, {
                  id: "name",
                  name: "name",
                  modelValue: unref(formData).name,
                  "onUpdate:modelValue": ($event) => unref(formData).name = $event,
                  placeholder: "Name",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                createVNode("label", { for: "color" }, "Color Border"),
                withDirectives(createVNode("input", {
                  id: "color",
                  name: "color",
                  type: "color",
                  "onUpdate:modelValue": ($event) => unref(formData).color = $event,
                  placeholder: "Color",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["onUpdate:modelValue"]), [
                  [vModelText, unref(formData).color]
                ])
              ]),
              createVNode("div", { class: "flex justify-end mt-5" }, [
                createVNode(_component_CompAdminButtonAddForm, {
                  buttonName: "Add Level Type",
                  isLoading: unref(loading)
                }, null, 8, ["isLoading"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/level-type/add.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=add-23643162.mjs.map
