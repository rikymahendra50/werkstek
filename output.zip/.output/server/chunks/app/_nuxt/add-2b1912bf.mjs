import { _ as __nuxt_component_0 } from './BackButton-454ea1e4.mjs';
import { Form, Field, ErrorMessage } from 'vee-validate';
import { _ as __nuxt_component_2 } from './BlogImageCrop-e341be04.mjs';
import { _ as _sfc_main$1 } from './TextField-7edd2a1a.mjs';
import { _ as __nuxt_component_4 } from './TextEditor-0bf2d701.mjs';
import { _ as __nuxt_component_3 } from './ButtonAddForm-aa118db7.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { withAsyncContext, ref, mergeProps, unref, withCtx, isRef, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, useSSRContext } from 'vue';
import { a as useRoute, u as useRouter, b as useFetch, d as useHead } from '../server.mjs';
import { u as useSchema } from './useSchema-3365865c.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import './Icon-7d2a1472.mjs';
import './config-54e8ad1b.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import './client-only-29ef7f45.mjs';
import './index-c7d55092.mjs';
import './index-73677d9a.mjs';
import '@tiptap/vue-3';
import '@tiptap/starter-kit';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'zod';
import '@vee-validate/zod';

const _sfc_main = {
  __name: "add",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { loading, transformErrors } = useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const snackbar = useSnackbar();
    useRoute();
    const router = useRouter();
    const { blogSchema } = useSchema();
    const { data: categoryBlog, error } = ([__temp, __restore] = withAsyncContext(() => useFetch(
      `/admins/article-categories`,
      {
        method: "get",
        ...requestOptions
      },
      "$dQOUDhkSvI"
    )), __temp = await __temp, __restore(), __temp);
    const { data: authorData } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/authors`, {
      method: "get",
      ...requestOptions
    }, "$Ygt63PgUYz")), __temp = await __temp, __restore(), __temp);
    ref(null);
    const formData = ref({
      title: void 0,
      body: void 0,
      category_id: void 0,
      meta: void 0,
      author_id: void 0
    });
    ref();
    const selectedImage = ref();
    async function onSubmit(values, ctx) {
      var _a2;
      var _a, _b, _c;
      loading.value = true;
      const object = { ...formData.value };
      const formDataT = new FormData();
      for (const item in object) {
        const objectItem = object[item];
        formDataT.append(item, objectItem);
      }
      if (selectedImage.value) {
        formDataT.append("image", selectedImage.value);
      }
      const { error: error2, data } = await useFetch(`/admins/articles`, {
        method: "POST",
        body: formDataT,
        ...requestOptions
      }, "$Je86HHajFV");
      if (error2.value) {
        ctx.setErrors(transformErrors((_a = error2 == null ? void 0 : error2.value) == null ? void 0 : _a.data));
        snackbar.add({
          type: "error",
          text: (_a2 = (_c = (_b = error2.value) == null ? void 0 : _b.data) == null ? void 0 : _c.message) != null ? _a2 : "Something went wrong"
        });
      } else if (data.value) {
        snackbar.add({
          type: "success",
          text: "Add Blog Success"
        });
        router.push("/admin/blog");
      }
      loading.value = false;
    }
    useHead({
      title: "Add Blog"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CompAdminBackButton = __nuxt_component_0;
      const _component_VeeForm = Form;
      const _component_VeeField = Field;
      const _component_BlogImageCrop = __nuxt_component_2;
      const _component_VeeErrorMessage = ErrorMessage;
      const _component_FormTextField = _sfc_main$1;
      const _component_FormTextEditor = __nuxt_component_4;
      const _component_CompAdminButtonAddForm = __nuxt_component_3;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "overflow-auto" }, _attrs))}>`);
      _push(ssrRenderComponent(_component_CompAdminBackButton, {
        link: "blog",
        linkTitle: "Add Blog"
      }, null, _parent));
      _push(`<div class="grid grid-cols-2">`);
      _push(ssrRenderComponent(_component_VeeForm, {
        onSubmit,
        "validation-schema": unref(blogSchema)
      }, {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid mt-10 p-3 gap-2"${_scopeId}><div${_scopeId}><div class="hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              type: "file",
              name: "image",
              id: "image",
              modelValue: unref(selectedImage),
              "onUpdate:modelValue": ($event) => isRef(selectedImage) ? selectedImage.value = $event : null
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_BlogImageCrop, {
              loading: unref(loading),
              name: "image",
              modelValue: unref(selectedImage),
              "onUpdate:modelValue": ($event) => isRef(selectedImage) ? selectedImage.value = $event : null
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "image",
              class: "text-red-500"
            }, null, _parent2, _scopeId));
            _push2(`</div><label for="title"${_scopeId}>Title</label>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "title",
              name: "title",
              modelValue: unref(formData).title,
              "onUpdate:modelValue": ($event) => unref(formData).title = $event,
              placeholder: "Name",
              class: "input-bordered",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`<div class="flex flex-col mt-5"${_scopeId}><label for="author"${_scopeId}>Author</label>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "author",
              name: "author",
              as: "select",
              modelValue: unref(formData).author_id,
              "onUpdate:modelValue": ($event) => unref(formData).author_id = $event,
              class: "select select-bordered w-full",
              placeholder: "category",
              autocomplete: "off"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                var _a, _b;
                if (_push3) {
                  _push3(`<option disabled selected${_scopeId2}>Author</option><!--[-->`);
                  ssrRenderList((_a = unref(authorData)) == null ? void 0 : _a.data, (item) => {
                    _push3(`<option${ssrRenderAttr("value", item.id)}${_scopeId2}>${ssrInterpolate(item.name)}</option>`);
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    createVNode("option", {
                      disabled: "",
                      selected: ""
                    }, "Author"),
                    (openBlock(true), createBlock(Fragment, null, renderList((_b = unref(authorData)) == null ? void 0 : _b.data, (item) => {
                      return openBlock(), createBlock("option", {
                        value: item.id
                      }, toDisplayString(item.name), 9, ["value"]);
                    }), 256))
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "author",
              class: "text-red-500"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col mt-5"${_scopeId}><span${_scopeId}>Body</span><div class="hidden"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              type: "text",
              name: "body",
              modelValue: unref(formData).body,
              "onUpdate:modelValue": ($event) => unref(formData).body = $event,
              immediate: ""
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
            _push2(ssrRenderComponent(_component_FormTextEditor, {
              modelValue: unref(formData).body,
              "onUpdate:modelValue": ($event) => unref(formData).body = $event,
              "is-error": !!errors.body
            }, null, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "body",
              class: "text-red-500"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col mt-5"${_scopeId}><label for="category"${_scopeId}>Category</label>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "category",
              name: "category",
              as: "select",
              modelValue: unref(formData).category_id,
              "onUpdate:modelValue": ($event) => unref(formData).category_id = $event,
              class: "select select-bordered w-full",
              placeholder: "category",
              autocomplete: "off"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<option disabled selected${_scopeId2}>Category</option><!--[-->`);
                  ssrRenderList(unref(categoryBlog).data, (item) => {
                    _push3(`<option${ssrRenderAttr("value", item.id)}${_scopeId2}>${ssrInterpolate(item.name)}</option>`);
                  });
                  _push3(`<!--]-->`);
                } else {
                  return [
                    createVNode("option", {
                      disabled: "",
                      selected: ""
                    }, "Category"),
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(categoryBlog).data, (item) => {
                      return openBlock(), createBlock("option", {
                        value: item.id
                      }, toDisplayString(item.name), 9, ["value"]);
                    }), 256))
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "category",
              class: "form-error-message text-red-600"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col mt-5"${_scopeId}><label for="meta"${_scopeId}>Meta</label>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "meta",
              name: "meta",
              modelValue: unref(formData).meta,
              "onUpdate:modelValue": ($event) => unref(formData).meta = $event,
              placeholder: "Input Meta",
              class: "input-bordered",
              autocomplete: "off"
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="flex justify-end mt-5"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_CompAdminButtonAddForm, {
              buttonName: "Add Blog",
              isLoading: unref(loading)
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "grid mt-10 p-3 gap-2" }, [
                createVNode("div", null, [
                  createVNode("div", { class: "hidden" }, [
                    createVNode(_component_VeeField, {
                      type: "file",
                      name: "image",
                      id: "image",
                      modelValue: unref(selectedImage),
                      "onUpdate:modelValue": ($event) => isRef(selectedImage) ? selectedImage.value = $event : null
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  createVNode(_component_BlogImageCrop, {
                    loading: unref(loading),
                    name: "image",
                    modelValue: unref(selectedImage),
                    "onUpdate:modelValue": ($event) => isRef(selectedImage) ? selectedImage.value = $event : null
                  }, null, 8, ["loading", "modelValue", "onUpdate:modelValue"]),
                  createVNode(_component_VeeErrorMessage, {
                    name: "image",
                    class: "text-red-500"
                  })
                ]),
                createVNode("label", { for: "title" }, "Title"),
                createVNode(_component_FormTextField, {
                  id: "title",
                  name: "title",
                  modelValue: unref(formData).title,
                  "onUpdate:modelValue": ($event) => unref(formData).title = $event,
                  placeholder: "Name",
                  class: "input-bordered",
                  autocomplete: "on"
                }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                createVNode("div", { class: "flex flex-col mt-5" }, [
                  createVNode("label", { for: "author" }, "Author"),
                  createVNode(_component_VeeField, {
                    id: "author",
                    name: "author",
                    as: "select",
                    modelValue: unref(formData).author_id,
                    "onUpdate:modelValue": ($event) => unref(formData).author_id = $event,
                    class: "select select-bordered w-full",
                    placeholder: "category",
                    autocomplete: "off"
                  }, {
                    default: withCtx(() => {
                      var _a;
                      return [
                        createVNode("option", {
                          disabled: "",
                          selected: ""
                        }, "Author"),
                        (openBlock(true), createBlock(Fragment, null, renderList((_a = unref(authorData)) == null ? void 0 : _a.data, (item) => {
                          return openBlock(), createBlock("option", {
                            value: item.id
                          }, toDisplayString(item.name), 9, ["value"]);
                        }), 256))
                      ];
                    }),
                    _: 1
                  }, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode(_component_VeeErrorMessage, {
                    name: "author",
                    class: "text-red-500"
                  })
                ]),
                createVNode("div", { class: "flex flex-col mt-5" }, [
                  createVNode("span", null, "Body"),
                  createVNode("div", { class: "hidden" }, [
                    createVNode(_component_VeeField, {
                      type: "text",
                      name: "body",
                      modelValue: unref(formData).body,
                      "onUpdate:modelValue": ($event) => unref(formData).body = $event,
                      immediate: ""
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  createVNode(_component_FormTextEditor, {
                    modelValue: unref(formData).body,
                    "onUpdate:modelValue": ($event) => unref(formData).body = $event,
                    "is-error": !!errors.body
                  }, null, 8, ["modelValue", "onUpdate:modelValue", "is-error"]),
                  createVNode(_component_VeeErrorMessage, {
                    name: "body",
                    class: "text-red-500"
                  })
                ]),
                createVNode("div", { class: "flex flex-col mt-5" }, [
                  createVNode("label", { for: "category" }, "Category"),
                  createVNode(_component_VeeField, {
                    id: "category",
                    name: "category",
                    as: "select",
                    modelValue: unref(formData).category_id,
                    "onUpdate:modelValue": ($event) => unref(formData).category_id = $event,
                    class: "select select-bordered w-full",
                    placeholder: "category",
                    autocomplete: "off"
                  }, {
                    default: withCtx(() => [
                      createVNode("option", {
                        disabled: "",
                        selected: ""
                      }, "Category"),
                      (openBlock(true), createBlock(Fragment, null, renderList(unref(categoryBlog).data, (item) => {
                        return openBlock(), createBlock("option", {
                          value: item.id
                        }, toDisplayString(item.name), 9, ["value"]);
                      }), 256))
                    ]),
                    _: 1
                  }, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode(_component_VeeErrorMessage, {
                    name: "category",
                    class: "form-error-message text-red-600"
                  })
                ]),
                createVNode("div", { class: "flex flex-col mt-5" }, [
                  createVNode("label", { for: "meta" }, "Meta"),
                  createVNode(_component_FormTextField, {
                    id: "meta",
                    name: "meta",
                    modelValue: unref(formData).meta,
                    "onUpdate:modelValue": ($event) => unref(formData).meta = $event,
                    placeholder: "Input Meta",
                    class: "input-bordered",
                    autocomplete: "off"
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ])
              ]),
              createVNode("div", { class: "flex justify-end mt-5" }, [
                createVNode(_component_CompAdminButtonAddForm, {
                  buttonName: "Add Blog",
                  isLoading: unref(loading)
                }, null, 8, ["isLoading"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/blog/add.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=add-2b1912bf.mjs.map
