import { _ as __nuxt_component_0 } from './BackButton-de34e53a.mjs';
import { Form } from 'vee-validate';
import { u as useForgotPassword, _ as _sfc_main$1 } from './useForgotPassword-e6ea2eaa.mjs';
import { _ as _sfc_main$2 } from './TextField-7edd2a1a.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions, a as useRouter, d as useHead } from '../server.mjs';
import { u as useSchema } from './useSchema-3365865c.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { ref, mergeProps, unref, withCtx, createVNode, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-101122a4.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrIncludeBooleanAttr } from 'vue/server-renderer';
import './Icon-e394d28f.mjs';
import './config-aab100d3.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'zod';
import '@vee-validate/zod';
import './asyncData-04c89180.mjs';

const _sfc_main = {
  __name: "add",
  __ssrInlineRender: true,
  setup(__props) {
    const { loading, transformErrors } = useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const { registerSchema } = useSchema();
    const snackbar = useSnackbar();
    const router = useRouter();
    useForgotPassword();
    const form = ref({
      first_name: void 0,
      last_name: void 0,
      email: void 0,
      password: void 0,
      confirm_password: void 0
    });
    async function onSubmit(values, ctx) {
      var _a2;
      var _a, _b, _c;
      loading.value = true;
      const { data, error } = await useFetch(`/admins`, {
        method: "post",
        body: {
          first_name: form.value.first_name,
          last_name: form.value.last_name,
          email: form.value.email,
          password: form.value.password,
          confirm_password: form.value.confirm_password
        },
        ...requestOptions
      }, "$6DLawu0jYd");
      if (error.value) {
        ctx.setErrors(transformErrors((_a = error == null ? void 0 : error.value) == null ? void 0 : _a.data));
        snackbar.add({
          type: "error",
          text: (_a2 = (_c = (_b = error.value) == null ? void 0 : _b.data) == null ? void 0 : _c.message) != null ? _a2 : "Something went wrong"
        });
      } else {
        snackbar.add({
          type: "success",
          text: "We have received your registration. The next step is to verify your email address to activate your account."
        });
        router.push("/admin/admin-list");
      }
    }
    useHead({
      title: "Register admin"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CompAdminBackButton = __nuxt_component_0;
      const _component_VeeForm = Form;
      const _component_FormGroup = _sfc_main$1;
      const _component_FormTextField = _sfc_main$2;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "grid place-items-center items-center" }, _attrs))}><div class="w-full p-4 justify-center">`);
      _push(ssrRenderComponent(_component_CompAdminBackButton, {
        link: "admin-list",
        linkTitle: "Register Admin"
      }, null, _parent));
      _push(ssrRenderComponent(_component_VeeForm, {
        onSubmit,
        "validation-schema": unref(registerSchema),
        class: "grid grid-cols-2"
      }, {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 text-left gap-4 rounded-md"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormGroup, {
              label: "First Name",
              name: "first_name"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_FormTextField, {
                    id: "first_name",
                    name: "first_name",
                    modelValue: unref(form).first_name,
                    "onUpdate:modelValue": ($event) => unref(form).first_name = $event,
                    placeholder: "First Name",
                    class: "input-bordered",
                    autocomplete: "on"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_FormTextField, {
                      id: "first_name",
                      name: "first_name",
                      modelValue: unref(form).first_name,
                      "onUpdate:modelValue": ($event) => unref(form).first_name = $event,
                      placeholder: "First Name",
                      class: "input-bordered",
                      autocomplete: "on"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormGroup, {
              label: "Last Name",
              name: "last_name"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_FormTextField, {
                    id: "last_name",
                    name: "last_name",
                    modelValue: unref(form).last_name,
                    "onUpdate:modelValue": ($event) => unref(form).last_name = $event,
                    placeholder: "Last Name",
                    class: "input-bordered",
                    autocomplete: "on"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_FormTextField, {
                      id: "last_name",
                      name: "last_name",
                      modelValue: unref(form).last_name,
                      "onUpdate:modelValue": ($event) => unref(form).last_name = $event,
                      placeholder: "Last Name",
                      class: "input-bordered",
                      autocomplete: "on"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormGroup, {
              label: "Email",
              name: "email"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_FormTextField, {
                    id: "email",
                    name: "email",
                    modelValue: unref(form).email,
                    "onUpdate:modelValue": ($event) => unref(form).email = $event,
                    placeholder: "ex:myemail@gmail.com",
                    class: "input-bordered",
                    autocomplete: "on"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_FormTextField, {
                      id: "email",
                      name: "email",
                      modelValue: unref(form).email,
                      "onUpdate:modelValue": ($event) => unref(form).email = $event,
                      placeholder: "ex:myemail@gmail.com",
                      class: "input-bordered",
                      autocomplete: "on"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormGroup, {
              label: "Password",
              name: "password"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_FormTextField, {
                    id: "password",
                    name: "password",
                    type: "password",
                    modelValue: unref(form).password,
                    "onUpdate:modelValue": ($event) => unref(form).password = $event,
                    placeholder: "Password",
                    class: "input-bordered",
                    autocomplete: "on"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_FormTextField, {
                      id: "password",
                      name: "password",
                      type: "password",
                      modelValue: unref(form).password,
                      "onUpdate:modelValue": ($event) => unref(form).password = $event,
                      placeholder: "Password",
                      class: "input-bordered",
                      autocomplete: "on"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormGroup, {
              label: "Confirm Password",
              name: "confirm_password"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_FormTextField, {
                    id: "confirm_password",
                    name: "confirm_password",
                    type: "password",
                    modelValue: unref(form).confirm_password,
                    "onUpdate:modelValue": ($event) => unref(form).confirm_password = $event,
                    placeholder: "Confirm Password",
                    class: "input-bordered",
                    autocomplete: "on"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_FormTextField, {
                      id: "confirm_password",
                      name: "confirm_password",
                      type: "password",
                      modelValue: unref(form).confirm_password,
                      "onUpdate:modelValue": ($event) => unref(form).confirm_password = $event,
                      placeholder: "Confirm Password",
                      class: "input-bordered",
                      autocomplete: "on"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`<div class="flex justify-end"${_scopeId}><button class="btn bg-primary text-white" type="submit"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""}${_scopeId}> Submit </button></div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 text-left gap-4 rounded-md" }, [
                createVNode(_component_FormGroup, {
                  label: "First Name",
                  name: "first_name"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_FormTextField, {
                      id: "first_name",
                      name: "first_name",
                      modelValue: unref(form).first_name,
                      "onUpdate:modelValue": ($event) => unref(form).first_name = $event,
                      placeholder: "First Name",
                      class: "input-bordered",
                      autocomplete: "on"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_FormGroup, {
                  label: "Last Name",
                  name: "last_name"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_FormTextField, {
                      id: "last_name",
                      name: "last_name",
                      modelValue: unref(form).last_name,
                      "onUpdate:modelValue": ($event) => unref(form).last_name = $event,
                      placeholder: "Last Name",
                      class: "input-bordered",
                      autocomplete: "on"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_FormGroup, {
                  label: "Email",
                  name: "email"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_FormTextField, {
                      id: "email",
                      name: "email",
                      modelValue: unref(form).email,
                      "onUpdate:modelValue": ($event) => unref(form).email = $event,
                      placeholder: "ex:myemail@gmail.com",
                      class: "input-bordered",
                      autocomplete: "on"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_FormGroup, {
                  label: "Password",
                  name: "password"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_FormTextField, {
                      id: "password",
                      name: "password",
                      type: "password",
                      modelValue: unref(form).password,
                      "onUpdate:modelValue": ($event) => unref(form).password = $event,
                      placeholder: "Password",
                      class: "input-bordered",
                      autocomplete: "on"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_FormGroup, {
                  label: "Confirm Password",
                  name: "confirm_password"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_FormTextField, {
                      id: "confirm_password",
                      name: "confirm_password",
                      type: "password",
                      modelValue: unref(form).confirm_password,
                      "onUpdate:modelValue": ($event) => unref(form).confirm_password = $event,
                      placeholder: "Confirm Password",
                      class: "input-bordered",
                      autocomplete: "on"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode("div", { class: "flex justify-end" }, [
                  createVNode("button", {
                    class: "btn bg-primary text-white",
                    type: "submit",
                    disabled: unref(loading)
                  }, " Submit ", 8, ["disabled"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/admin-list/add.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=add-ea0b635a.mjs.map
