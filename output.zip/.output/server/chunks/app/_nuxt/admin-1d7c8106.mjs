import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { useSSRContext, defineComponent, ref, computed, provide, mergeProps, unref, inject, withCtx, createVNode, openBlock, createBlock, createTextVNode, renderSlot } from 'vue';
import { ssrRenderAttrs, ssrRenderSlot, ssrRenderComponent, ssrRenderAttr, ssrRenderClass, ssrIncludeBooleanAttr } from 'vue/server-renderer';
import { b as useWindowSize, o as onClickOutside } from './index-c7d55092.mjs';
import { h as _export_sfc, i as useAuth, b as useRoute, _ as __nuxt_component_0$1 } from '../server.mjs';
import __nuxt_component_2$1 from './Icon-e394d28f.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { _ as _sfc_main$4 } from './NuxtSnackbar-cce50284.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './index-73677d9a.mjs';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './config-aab100d3.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';

const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "Wrapper",
  __ssrInlineRender: true,
  setup(__props) {
    const showTableOrMobileSidebar = ref(false);
    const { width } = useWindowSize();
    const sideNav = ref(null);
    const tableOrMobile = computed(() => {
      return width.value <= 768;
    });
    onClickOutside(sideNav, () => {
      if (tableOrMobile.value) {
        showTableOrMobileSidebar.value = false;
      }
    });
    provide("showTableOrMobileSidebar", showTableOrMobileSidebar);
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "relative" }, _attrs))}>`);
      if (unref(showTableOrMobileSidebar)) {
        _push(`<div class="absolute block lg:hidden z-50 max-w-[280px] bg-white">`);
        ssrRenderSlot(_ctx.$slots, "mbAndSmSidebar", {}, null, _push, _parent);
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="grid h-screen min-h-screen w-full lg:grid-cols-[280px_1fr]">`);
      ssrRenderSlot(_ctx.$slots, "sidebar", {}, null, _push, _parent);
      _push(`<div class="flex flex-col">`);
      ssrRenderSlot(_ctx.$slots, "main-content", {}, null, _push, _parent);
      _push(`</div></div></div>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Admin/Wrapper.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _imports_0 = "" + publicAssetsURL("images/werstek-logo-secondary.png");
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "SideNav",
  __ssrInlineRender: true,
  setup(__props) {
    inject("showTableOrMobileSidebar");
    const { loading, transformErrors } = useRequestHelper();
    useAuth();
    useRoute();
    ref(false);
    const isRouteActive = (route2) => {
      const currentRoute = useRoute();
      return currentRoute.path === route2;
    };
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_icon = __nuxt_component_2$1;
      const _component_Icon = __nuxt_component_2$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "border-r bg-white" }, _attrs))}><div class="flex h-full max-h-screen flex-col gap-4"><div class="flex h-[60px] items-center border-b px-6 justify-between">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/admin",
        class: "flex items-center justify-center gap-2 font-semibold my-10"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} alt="image-logo-secondary" class="w-[170px] ml-6"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                alt: "image-logo-secondary",
                class: "w-[170px] ml-6"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<div class="block lg:hidden"><button type="button" class="btn btn-square btn-sm">`);
      _push(ssrRenderComponent(_component_icon, { name: "i-heroicons-x-mark" }, null, _parent));
      _push(`<span class="sr-only">Toggle notifications</span></button></div></div><div class="flex-1 py-2 bg-white"><nav class="grid items-start px-4 text-[12px] font-medium">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/admin",
        class: [{
          "bg-transparent text-black hover:bg-gray-100": !isRouteActive("/admin"),
          "bg-black text-black hover:bg-opacity-30": isRouteActive("/admin")
        }, "flex items-center gap-3 rounded-lg bg-gray-100 px-3 py-2 text-gray-600 transition-all"]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z"${_scopeId}></path></svg> Profile `);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "0 0 24 24",
                "stroke-width": "1.5",
                stroke: "currentColor",
                class: "w-5 h-5"
              }, [
                createVNode("path", {
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round",
                  d: "M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z"
                })
              ])),
              createTextVNode(" Profile ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/admin/admin-list",
        class: [{
          "bg-transparent text-black hover:bg-gray-100": !isRouteActive("/admin/admin-list"),
          "bg-black text-black hover:bg-opacity-30": isRouteActive("/admin/admin-list")
        }, "flex items-center gap-3 rounded-lg bg-gray-100 px-3 py-2 text-gray-600 transition-all"]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z"${_scopeId}></path></svg> Admin List `);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "0 0 24 24",
                "stroke-width": "1.5",
                stroke: "currentColor",
                class: "w-5 h-5"
              }, [
                createVNode("path", {
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round",
                  d: "M15.75 6a3.75 3.75 0 1 1-7.5 0 3.75 3.75 0 0 1 7.5 0ZM4.501 20.118a7.5 7.5 0 0 1 14.998 0A17.933 17.933 0 0 1 12 21.75c-2.676 0-5.216-.584-7.499-1.632Z"
                })
              ])),
              createTextVNode(" Admin List ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/admin/onze-locaties",
        class: [{
          "bg-transparent text-black hover:bg-gray-100": !isRouteActive(
            "/admin/onze-locaties"
          ),
          "bg-black text-black hover:bg-opacity-30": isRouteActive(
            "/admin/onze-locaties"
          )
        }, "flex items-center gap-3 rounded-lg bg-gray-100 px-3 py-2 text-gray-600 transition-all"]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" d="M8.25 21v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21m0 0h4.5V3.545M12.75 21h7.5V10.75M2.25 21h1.5m18 0h-18M2.25 9l4.5-1.636M18.75 3l-1.5.545m0 6.205 3 1m1.5.5-1.5-.5M6.75 7.364V3h-3v18m3-13.636 10.5-3.819"${_scopeId}></path></svg> Property `);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "0 0 24 24",
                "stroke-width": "1.5",
                stroke: "currentColor",
                class: "w-5 h-5"
              }, [
                createVNode("path", {
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round",
                  d: "M8.25 21v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21m0 0h4.5V3.545M12.75 21h7.5V10.75M2.25 21h1.5m18 0h-18M2.25 9l4.5-1.636M18.75 3l-1.5.545m0 6.205 3 1m1.5.5-1.5-.5M6.75 7.364V3h-3v18m3-13.636 10.5-3.819"
                })
              ])),
              createTextVNode(" Property ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<details><summary class="${ssrRenderClass([{
        "bg-transparent text-black hover:bg-gray-100": !isRouteActive("/admin/onze-vacatures") && !isRouteActive("/admin/type-vacatures"),
        "bg-gray-200 text-black hover:bg-opacity-30": isRouteActive("/admin/onze-vacatures") || isRouteActive("/admin/type-vacatures")
      }, "group bg-black cursor-pointer flex items-center gap-3 rounded-lg px-3 py-2 text-gray-600 transition-all relative"])}">`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "solar:suitcase-broken",
        class: "text-black w-5 h-5"
      }, null, _parent));
      _push(`<span>Vacancies</span><svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" class="w-4 h-4 absolute right-3"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></summary><ul class="ml-9 grid"><li class="mt-1">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/admin/onze-vacatures",
        class: "w-full"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="${ssrRenderClass([{
              "bg-transparent text-black hover:bg-gray-100": !isRouteActive("/admin/onze-vacatures"),
              "bg-gray-200 text-black hover:bg-opacity-30": isRouteActive("/admin/onze-vacatures")
            }, "text-gray-600 hover:text-black transition-all hover:bg-gray-100 pl-2 py-2 rounded-lg"])}"${_scopeId}> Vacancies List </div>`);
          } else {
            return [
              createVNode("div", {
                class: ["text-gray-600 hover:text-black transition-all hover:bg-gray-100 pl-2 py-2 rounded-lg", {
                  "bg-transparent text-black hover:bg-gray-100": !isRouteActive("/admin/onze-vacatures"),
                  "bg-gray-200 text-black hover:bg-opacity-30": isRouteActive("/admin/onze-vacatures")
                }]
              }, " Vacancies List ", 2)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li><li class="mt-1">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/admin/type-vacatures",
        class: "w-full"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="${ssrRenderClass([{
              "bg-transparent text-black hover:bg-gray-100": !isRouteActive("/admin/type-vacatures"),
              "bg-gray-200 text-black hover:bg-opacity-30": isRouteActive("/admin/type-vacatures")
            }, "text-gray-600 hover:text-black transition-all hover:bg-gray-100 pl-2 py-2 rounded-lg"])}"${_scopeId}> Vacancies Type </div>`);
          } else {
            return [
              createVNode("div", {
                class: ["text-gray-600 hover:text-black transition-all hover:bg-gray-100 pl-2 py-2 rounded-lg", {
                  "bg-transparent text-black hover:bg-gray-100": !isRouteActive("/admin/type-vacatures"),
                  "bg-gray-200 text-black hover:bg-opacity-30": isRouteActive("/admin/type-vacatures")
                }]
              }, " Vacancies Type ", 2)
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</li></ul></details>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/admin/location",
        class: [{
          "bg-transparent text-black hover:bg-gray-100": !isRouteActive("/admin/location"),
          "bg-black text-black hover:bg-opacity-30": isRouteActive("/admin/location")
        }, "flex items-center gap-3 rounded-lg bg-gray-100 px-3 py-2 text-gray-600 transition-all"]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" class="w-5 h-5"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" d="M15 10.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"${_scopeId}></path><path stroke-linecap="round" stroke-linejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1 1 15 0Z"${_scopeId}></path></svg> Location `);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                width: "24",
                height: "24",
                fill: "none",
                viewBox: "0 0 24 24",
                "stroke-width": "2",
                stroke: "currentColor",
                class: "w-5 h-5"
              }, [
                createVNode("path", {
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round",
                  d: "M15 10.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"
                }),
                createVNode("path", {
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round",
                  d: "M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1 1 15 0Z"
                })
              ])),
              createTextVNode(" Location ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/admin/level-type",
        class: [{
          "bg-transparent text-black hover:bg-gray-100": !isRouteActive("/admin/level-type"),
          "bg-black text-black hover:bg-opacity-30": isRouteActive("/admin/level-type")
        }, "flex items-center gap-3 rounded-lg bg-gray-100 px-3 py-2 text-gray-600 transition-all"]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-5 w-5"${_scopeId}><path d="M3 3v18h18"${_scopeId}></path><path d="m19 9-5 5-4-4-3 3"${_scopeId}></path></svg> Level Type `);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                width: "24",
                height: "24",
                viewBox: "0 0 24 24",
                fill: "none",
                stroke: "currentColor",
                "stroke-width": "2",
                "stroke-linecap": "round",
                "stroke-linejoin": "round",
                class: "h-5 w-5"
              }, [
                createVNode("path", { d: "M3 3v18h18" }),
                createVNode("path", { d: "m19 9-5 5-4-4-3 3" })
              ])),
              createTextVNode(" Level Type ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/admin/privilages",
        class: ["flex items-center gap-3 rounded-lg bg-gray-100 px-3 py-2 text-gray-600 transition-all", {
          "bg-transparent text-black hover:bg-gray-100": !isRouteActive("/admin/privilages"),
          "bg-black text-black hover:bg-opacity-30": isRouteActive("/admin/privilages")
        }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(ssrRenderComponent(_component_Icon, {
              name: "streamline:give-gift",
              class: "text-black w-5 h-5"
            }, null, _parent2, _scopeId));
            _push2(` Privilages `);
          } else {
            return [
              createVNode(_component_Icon, {
                name: "streamline:give-gift",
                class: "text-black w-5 h-5"
              }),
              createTextVNode(" Privilages ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/admin/type",
        class: ["flex items-center gap-3 rounded-lg bg-gray-100 px-3 py-2 text-gray-600 transition-all", {
          "bg-transparent text-black hover:bg-gray-100": !isRouteActive("/admin/type"),
          "bg-black text-black hover:bg-opacity-30": isRouteActive("/admin/type")
        }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-5 w-5"${_scopeId}><path d="M3 3v18h18"${_scopeId}></path><path d="m19 9-5 5-4-4-3 3"${_scopeId}></path></svg> Type `);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                width: "24",
                height: "24",
                viewBox: "0 0 24 24",
                fill: "none",
                stroke: "currentColor",
                "stroke-width": "2",
                "stroke-linecap": "round",
                "stroke-linejoin": "round",
                class: "h-5 w-5"
              }, [
                createVNode("path", { d: "M3 3v18h18" }),
                createVNode("path", { d: "m19 9-5 5-4-4-3 3" })
              ])),
              createTextVNode(" Type ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/admin/facility",
        class: ["flex items-center gap-3 rounded-lg bg-gray-100 px-3 py-2 text-gray-600 transition-all", {
          "bg-transparent text-black hover:bg-gray-100": !isRouteActive("/admin/facility"),
          "bg-black text-black hover:bg-opacity-30": isRouteActive("/admin/facility")
        }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" d="M8.25 21v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21m0 0h4.5V3.545M12.75 21h7.5V10.75M2.25 21h1.5m18 0h-18M2.25 9l4.5-1.636M18.75 3l-1.5.545m0 6.205 3 1m1.5.5-1.5-.5M6.75 7.364V3h-3v18m3-13.636 10.5-3.819"${_scopeId}></path></svg> Facility `);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "0 0 24 24",
                "stroke-width": "1.5",
                stroke: "currentColor",
                class: "w-5 h-5"
              }, [
                createVNode("path", {
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round",
                  d: "M8.25 21v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21m0 0h4.5V3.545M12.75 21h7.5V10.75M2.25 21h1.5m18 0h-18M2.25 9l4.5-1.636M18.75 3l-1.5.545m0 6.205 3 1m1.5.5-1.5-.5M6.75 7.364V3h-3v18m3-13.636 10.5-3.819"
                })
              ])),
              createTextVNode(" Facility ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/admin/blog",
        class: ["flex items-center gap-3 rounded-lg bg-gray-100 px-3 py-2 text-gray-600 transition-all", {
          "bg-transparent text-black hover:bg-gray-100": !isRouteActive("/admin/blog"),
          "bg-black text-black hover:bg-opacity-30": isRouteActive("/admin/blog")
        }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" d="M12 7.5h1.5m-1.5 3h1.5m-7.5 3h7.5m-7.5 3h7.5m3-9h3.375c.621 0 1.125.504 1.125 1.125V18a2.25 2.25 0 0 1-2.25 2.25M16.5 7.5V18a2.25 2.25 0 0 0 2.25 2.25M16.5 7.5V4.875c0-.621-.504-1.125-1.125-1.125H4.125C3.504 3.75 3 4.254 3 4.875V18a2.25 2.25 0 0 0 2.25 2.25h13.5M6 7.5h3v3H6v-3Z"${_scopeId}></path></svg> Blog `);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "0 0 24 24",
                "stroke-width": "1.5",
                stroke: "currentColor",
                class: "w-5 h-5"
              }, [
                createVNode("path", {
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round",
                  d: "M12 7.5h1.5m-1.5 3h1.5m-7.5 3h7.5m-7.5 3h7.5m3-9h3.375c.621 0 1.125.504 1.125 1.125V18a2.25 2.25 0 0 1-2.25 2.25M16.5 7.5V18a2.25 2.25 0 0 0 2.25 2.25M16.5 7.5V4.875c0-.621-.504-1.125-1.125-1.125H4.125C3.504 3.75 3 4.254 3 4.875V18a2.25 2.25 0 0 0 2.25 2.25h13.5M6 7.5h3v3H6v-3Z"
                })
              ])),
              createTextVNode(" Blog ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/admin/blog-category",
        class: ["flex items-center gap-3 rounded-lg bg-gray-100 px-3 py-2 text-gray-600 transition-all", {
          "bg-transparent text-black hover:bg-gray-100": !isRouteActive(
            "/admin/blog-category"
          ),
          "bg-black text-black hover:bg-opacity-30": isRouteActive(
            "/admin/blog-category"
          )
        }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" d="M12 7.5h1.5m-1.5 3h1.5m-7.5 3h7.5m-7.5 3h7.5m3-9h3.375c.621 0 1.125.504 1.125 1.125V18a2.25 2.25 0 0 1-2.25 2.25M16.5 7.5V18a2.25 2.25 0 0 0 2.25 2.25M16.5 7.5V4.875c0-.621-.504-1.125-1.125-1.125H4.125C3.504 3.75 3 4.254 3 4.875V18a2.25 2.25 0 0 0 2.25 2.25h13.5M6 7.5h3v3H6v-3Z"${_scopeId}></path></svg> Blog / Community Category `);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "0 0 24 24",
                "stroke-width": "1.5",
                stroke: "currentColor",
                class: "w-5 h-5"
              }, [
                createVNode("path", {
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round",
                  d: "M12 7.5h1.5m-1.5 3h1.5m-7.5 3h7.5m-7.5 3h7.5m3-9h3.375c.621 0 1.125.504 1.125 1.125V18a2.25 2.25 0 0 1-2.25 2.25M16.5 7.5V18a2.25 2.25 0 0 0 2.25 2.25M16.5 7.5V4.875c0-.621-.504-1.125-1.125-1.125H4.125C3.504 3.75 3 4.254 3 4.875V18a2.25 2.25 0 0 0 2.25 2.25h13.5M6 7.5h3v3H6v-3Z"
                })
              ])),
              createTextVNode(" Blog / Community Category ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/admin/author",
        class: ["flex items-center gap-3 rounded-lg bg-gray-100 px-3 py-2 text-gray-600 transition-all", {
          "bg-transparent text-black hover:bg-gray-100": !isRouteActive("/admin/author"),
          "bg-black text-black hover:bg-opacity-30": isRouteActive("/admin/author")
        }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" d="M12 7.5h1.5m-1.5 3h1.5m-7.5 3h7.5m-7.5 3h7.5m3-9h3.375c.621 0 1.125.504 1.125 1.125V18a2.25 2.25 0 0 1-2.25 2.25M16.5 7.5V18a2.25 2.25 0 0 0 2.25 2.25M16.5 7.5V4.875c0-.621-.504-1.125-1.125-1.125H4.125C3.504 3.75 3 4.254 3 4.875V18a2.25 2.25 0 0 0 2.25 2.25h13.5M6 7.5h3v3H6v-3Z"${_scopeId}></path></svg> Blog / Community Author `);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "0 0 24 24",
                "stroke-width": "1.5",
                stroke: "currentColor",
                class: "w-5 h-5"
              }, [
                createVNode("path", {
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round",
                  d: "M12 7.5h1.5m-1.5 3h1.5m-7.5 3h7.5m-7.5 3h7.5m3-9h3.375c.621 0 1.125.504 1.125 1.125V18a2.25 2.25 0 0 1-2.25 2.25M16.5 7.5V18a2.25 2.25 0 0 0 2.25 2.25M16.5 7.5V4.875c0-.621-.504-1.125-1.125-1.125H4.125C3.504 3.75 3 4.254 3 4.875V18a2.25 2.25 0 0 0 2.25 2.25h13.5M6 7.5h3v3H6v-3Z"
                })
              ])),
              createTextVNode(" Blog / Community Author ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/admin/community",
        class: ["flex items-center gap-3 rounded-lg bg-gray-100 px-3 py-2 text-gray-600 transition-all", {
          "bg-transparent text-black hover:bg-gray-100": !isRouteActive("/admin/community"),
          "bg-black text-black hover:bg-opacity-30": isRouteActive("/admin/community")
        }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-5 h-5"${_scopeId}><path stroke-linecap="round" stroke-linejoin="round" d="M12 7.5h1.5m-1.5 3h1.5m-7.5 3h7.5m-7.5 3h7.5m3-9h3.375c.621 0 1.125.504 1.125 1.125V18a2.25 2.25 0 0 1-2.25 2.25M16.5 7.5V18a2.25 2.25 0 0 0 2.25 2.25M16.5 7.5V4.875c0-.621-.504-1.125-1.125-1.125H4.125C3.504 3.75 3 4.254 3 4.875V18a2.25 2.25 0 0 0 2.25 2.25h13.5M6 7.5h3v3H6v-3Z"${_scopeId}></path></svg> Community `);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "0 0 24 24",
                "stroke-width": "1.5",
                stroke: "currentColor",
                class: "w-5 h-5"
              }, [
                createVNode("path", {
                  "stroke-linecap": "round",
                  "stroke-linejoin": "round",
                  d: "M12 7.5h1.5m-1.5 3h1.5m-7.5 3h7.5m-7.5 3h7.5m3-9h3.375c.621 0 1.125.504 1.125 1.125V18a2.25 2.25 0 0 1-2.25 2.25M16.5 7.5V18a2.25 2.25 0 0 0 2.25 2.25M16.5 7.5V4.875c0-.621-.504-1.125-1.125-1.125H4.125C3.504 3.75 3 4.254 3 4.875V18a2.25 2.25 0 0 0 2.25 2.25h13.5M6 7.5h3v3H6v-3Z"
                })
              ])),
              createTextVNode(" Community ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/admin/contact",
        class: ["flex items-center gap-3 rounded-lg bg-gray-100 px-3 py-2 text-gray-600 transition-all", {
          "bg-transparent text-black hover:bg-gray-100": !isRouteActive("/admin/contact"),
          "bg-black text-black hover:bg-opacity-30": isRouteActive("/admin/contact")
        }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-5 w-5"${_scopeId}><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"${_scopeId}></path><circle cx="9" cy="7" r="4"${_scopeId}></circle><path d="M22 21v-2a4 4 0 0 0-3-3.87"${_scopeId}></path><path d="M16 3.13a4 4 0 0 1 0 7.75"${_scopeId}></path></svg> Contact `);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                width: "24",
                height: "24",
                viewBox: "0 0 24 24",
                fill: "none",
                stroke: "currentColor",
                "stroke-width": "2",
                "stroke-linecap": "round",
                "stroke-linejoin": "round",
                class: "h-5 w-5"
              }, [
                createVNode("path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" }),
                createVNode("circle", {
                  cx: "9",
                  cy: "7",
                  r: "4"
                }),
                createVNode("path", { d: "M22 21v-2a4 4 0 0 0-3-3.87" }),
                createVNode("path", { d: "M16 3.13a4 4 0 0 1 0 7.75" })
              ])),
              createTextVNode(" Contact ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "/admin/newsletter",
        class: ["flex items-center gap-3 rounded-lg bg-gray-100 px-3 py-2 text-gray-600 transition-all", {
          "bg-transparent text-black hover:bg-gray-100": !isRouteActive("/admin/newsletter"),
          "bg-black text-black hover:bg-opacity-30": isRouteActive("/admin/newsletter")
        }]
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" fill="currentColor" class="w-4 h-4"${_scopeId}><path fill-rule="evenodd" d="M1.756 4.568A1.5 1.5 0 0 0 1 5.871V12.5A1.5 1.5 0 0 0 2.5 14h11a1.5 1.5 0 0 0 1.5-1.5V5.87a1.5 1.5 0 0 0-.756-1.302l-5.5-3.143a1.5 1.5 0 0 0-1.488 0l-5.5 3.143Zm1.82 2.963a.75.75 0 0 0-.653 1.35l4.1 1.98a2.25 2.25 0 0 0 1.955 0l4.1-1.98a.75.75 0 1 0-.653-1.35L8.326 9.51a.75.75 0 0 1-.652 0L3.575 7.53Z" clip-rule="evenodd"${_scopeId}></path></svg> Newsletter `);
          } else {
            return [
              (openBlock(), createBlock("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                viewBox: "0 0 16 16",
                fill: "currentColor",
                class: "w-4 h-4"
              }, [
                createVNode("path", {
                  "fill-rule": "evenodd",
                  d: "M1.756 4.568A1.5 1.5 0 0 0 1 5.871V12.5A1.5 1.5 0 0 0 2.5 14h11a1.5 1.5 0 0 0 1.5-1.5V5.87a1.5 1.5 0 0 0-.756-1.302l-5.5-3.143a1.5 1.5 0 0 0-1.488 0l-5.5 3.143Zm1.82 2.963a.75.75 0 0 0-.653 1.35l4.1 1.98a2.25 2.25 0 0 0 1.955 0l4.1-1.98a.75.75 0 1 0-.653-1.35L8.326 9.51a.75.75 0 0 1-.652 0L3.575 7.53Z",
                  "clip-rule": "evenodd"
                })
              ])),
              createTextVNode(" Newsletter ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<button${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""} class="btn btn-error mt-20"> Logout </button></nav></div></div></div>`);
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Admin/SideNav.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = {
  __name: "Header",
  __ssrInlineRender: true,
  setup(__props) {
    inject("showTableOrMobileSidebar");
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<header${ssrRenderAttrs(mergeProps({ class: "flex h-14 lg:h-[60px] items-center gap-4 border-b bg-white px-6" }, _attrs))}><div class="flex items-center justify-between w-[100%] lg:w-[40%] gap-4"><a class="font-semibold" href="#">Werkstek</a><button class="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-primary hover:text-accent-foreground h-10 w-10 lg:hidden"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-6 w-6"><line x1="4" x2="20" y1="12" y2="12"></line><line x1="4" x2="20" y1="6" y2="6"></line><line x1="4" x2="20" y1="18" y2="18"></line></svg><span class="sr-only">Toggle navigation menu</span></button></div><div class="flex-1"><div class="hidden lg:flex items-center gap-4"><form class="w-[90%]"></form><button class="jikaadaprofile(inline-flex) hidden items-center justify-center whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 hover:bg-primary hover:text-accent-foreground rounded-full border border-gray-200 w-8 h-8 dark:border-gray-800" type="button" id="radix-:r0:" aria-haspopup="menu" aria-expanded="false" data-state="closed"></button></div></div></header>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Admin/Header.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$1;
const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_AdminWrapper = _sfc_main$3;
  const _component_AdminSideNav = _sfc_main$2;
  const _component_AdminHeader = __nuxt_component_2;
  const _component_NuxtSnackbar = _sfc_main$4;
  _push(ssrRenderComponent(_component_AdminWrapper, _attrs, {
    mbAndSmSidebar: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_AdminSideNav, null, null, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_AdminSideNav)
        ];
      }
    }),
    sidebar: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_AdminSideNav, { class: "hidden lg:block" }, null, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_AdminSideNav, { class: "hidden lg:block" })
        ];
      }
    }),
    "main-content": withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_AdminHeader, null, null, _parent2, _scopeId));
        _push2(`<main class="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6 h-full flex-grow"${_scopeId}>`);
        ssrRenderSlot(_ctx.$slots, "default", {}, null, _push2, _parent2, _scopeId);
        _push2(`</main>`);
        _push2(ssrRenderComponent(_component_NuxtSnackbar, null, null, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_AdminHeader),
          createVNode("main", { class: "flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-6 h-full flex-grow" }, [
            renderSlot(_ctx.$slots, "default")
          ]),
          createVNode(_component_NuxtSnackbar)
        ];
      }
    }),
    _: 3
  }, _parent));
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/admin.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const admin = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { admin as default };
//# sourceMappingURL=admin-1d7c8106.mjs.map
