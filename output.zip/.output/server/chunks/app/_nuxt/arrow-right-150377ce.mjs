import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + publicAssetsURL("images/arrow-right.svg");

export { _imports_0 as _ };
//# sourceMappingURL=arrow-right-150377ce.mjs.map
