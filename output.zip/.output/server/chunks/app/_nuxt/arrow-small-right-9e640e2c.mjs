import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + publicAssetsURL("images/arrow-small-right.svg");

export { _imports_0 as _ };
//# sourceMappingURL=arrow-small-right-9e640e2c.mjs.map
