import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { i as _export_sfc, _ as __nuxt_component_0$1 } from '../server.mjs';
import { useSSRContext, mergeProps, withCtx, createVNode, toDisplayString } from 'vue';
import { ssrRenderComponent, ssrInterpolate } from 'vue/server-renderer';

const _sfc_main = {
  props: {
    buttonLink: {
      type: String
    },
    buttonTitle: {
      type: String
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_NuxtLink = __nuxt_component_0$1;
  _push(ssrRenderComponent(_component_NuxtLink, mergeProps({
    to: $props.buttonLink,
    class: "border bg-primary hover:bg-secondary transition text-sm rounded-full flex items-center justify-center lg:gap-2 py-2 md:py-1 px-2 sm:px-1 lg:px-2 xl:px-4 text-tertiary max-w-[184px]"
  }, _attrs), {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<p class="p-1 sm:p-3 font-medium text-[12px] sm:text-sm lg:text-base"${_scopeId}>${ssrInterpolate($props.buttonTitle)}</p>`);
      } else {
        return [
          createVNode("p", { class: "p-1 sm:p-3 font-medium text-[12px] sm:text-sm lg:text-base" }, toDisplayString($props.buttonTitle), 1)
        ];
      }
    }),
    _: 1
  }, _parent));
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ButtonPrimary.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
const _imports_0 = "" + publicAssetsURL("images/building-map-interactive.png");

export { __nuxt_component_0 as _, _imports_0 as a };
//# sourceMappingURL=building-map-interactive-f174b598.mjs.map
