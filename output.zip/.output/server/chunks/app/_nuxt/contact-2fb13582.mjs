import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0$2 } from './building-map-interactive-f174b598.mjs';
import { _ as __nuxt_component_4$1, a as __nuxt_component_1$1 } from './BgBigGreen-554b8e3d.mjs';
import { useSSRContext, ref, mergeProps, withCtx, createTextVNode, createVNode, unref } from 'vue';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderAttr, ssrIncludeBooleanAttr, ssrInterpolate } from 'vue/server-renderer';
import { d as useHead, i as _export_sfc, b as useFetch, _ as __nuxt_component_0$1 } from '../server.mjs';
import { Form, Field, ErrorMessage } from 'vee-validate';
import { u as useSchema } from './useSchema-3365865c.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { _ as __nuxt_component_4 } from './MapInteractive-ae8c81de.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './arrow-small-right-9e640e2c.mjs';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'zod';
import '@vee-validate/zod';
import './Icon-7d2a1472.mjs';
import './config-54e8ad1b.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import './useAxios-029d07ba.mjs';
import 'axios';
import './arrow-right-150377ce.mjs';

const _imports_0$1 = "" + publicAssetsURL("images/img-home-1.png");
const _sfc_main$2 = {
  props: {
    image: {
      type: String,
      required: true
    },
    title1: {
      type: String,
      required: true
    },
    title2: {
      type: String,
      required: true
    },
    title3: {
      type: String,
      required: true
    },
    buttonTitle1: {
      type: String,
      required: false
    },
    buttonLink1: {
      type: String,
      required: false
    },
    buttonTitle2: {
      type: String,
      required: false
    },
    buttonLink2: {
      type: String,
      required: false
    },
    titleBg1: {
      type: String,
      required: true
    },
    titleBg2: {
      type: String,
      required: true
    },
    titleBg3: {
      type: String,
      required: true
    },
    count1: {
      type: Number,
      required: true
    },
    count2: {
      type: Number,
      required: true
    },
    count3: {
      type: Number,
      required: true
    },
    classcustom: {
      type: String,
      required: false
    },
    showButton: {
      type: Boolean,
      required: false,
      default: false
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_ButtonPrimary = __nuxt_component_0$2;
  const _component_ButtonSM = __nuxt_component_1$1;
  _push(`<section${ssrRenderAttrs(mergeProps({
    class: ["bg-white min:h-[1109px] lg:py-10 relative flex items-center px-10", $props.classcustom]
  }, _attrs))}><div class="grid md:grid-rows-1 md:grid-cols-2 z-10"><div class="lg:pl-14 flex items-start mt-10 lg:mt-20 justify-center"><div class="grid gap-2"><span class="text-[14px] sm:text-[22px] font-semibold">${$props.title1}</span><span class="text-[20px] sm:text-[40px] font-bold">${$props.title2}</span><span class="text-[12px] sm:text-[18px] mt-3 lg:w-[90%]">${ssrInterpolate($props.title3)}</span>`);
  if ($props.showButton) {
    _push(`<div class="flex mt-5 lg:mt-10 justify-end md:justify-around lg:justify-start gap-5 max-h-[46px] sm:max-h-[64px]">`);
    _push(ssrRenderComponent(_component_ButtonPrimary, {
      buttonTitle: $props.buttonTitle1,
      buttonLink: $props.buttonLink1
    }, null, _parent));
    _push(ssrRenderComponent(_component_ButtonSM, {
      buttonTitle: $props.buttonTitle2,
      buttonLink: $props.buttonLink2
    }, null, _parent));
    _push(`</div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div></div><div class="grid relative mt-5 justify-items-end"><div class="w-[80%] lg:w-[100%] xl:hidden block"><svg width="100%" viewBox="0 0 657 745" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path fill-rule="evenodd" clip-rule="evenodd" d="M657 40.053C657 17.9616 639.091 0.0529785 617 0.0529785H181C158.909 0.0529785 141 17.9616 141 40.053V57.053C141 79.1444 123.091 97.053 101 97.053H40C17.9086 97.053 0 114.962 0 137.053V704.053C0 726.144 17.9086 744.053 40 744.053H141H617C639.091 744.053 657 726.144 657 704.053V97.053V40.053Z" fill="url(#pattern0)"></path><defs><pattern id="pattern0" patternContentUnits="objectBoundingBox" width="1" height="1"><use xlink:href="#image0_161_2608" transform="matrix(0.000961307 0 0 0.000848896 -0.162676 0)"></use></pattern><image id="image0_161_2608" width="1768" height="1178"${ssrRenderAttr("xlink:href", _imports_0$1)}></image></defs></svg></div><div class="w-[80%] lg:w-[100%] hidden xl:block"><img${ssrRenderAttr("src", $props.image)}${ssrRenderAttr("alt", $props.image)}></div></div><div id="contact-form"></div></div></section>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/StatistiekLocaties.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender]]);
const _imports_0 = "" + publicAssetsURL("images/icon-facebook-black.svg");
const _imports_1 = "" + publicAssetsURL("images/icon-instagram-black.svg");
const _imports_2 = "" + publicAssetsURL("images/icon-youtube-black.svg");
const _imports_3 = "" + publicAssetsURL("images/icon-linkedin-black.svg");
const _sfc_main$1 = {
  __name: "ContactUs",
  __ssrInlineRender: true,
  setup(__props) {
    const { contactSchema } = useSchema();
    const { loading, transformErrors } = useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const snackbar = useSnackbar();
    const dataForm = ref({
      first_name: void 0,
      last_name: void 0,
      email: void 0,
      subject: void 0,
      message: void 0
    });
    async function onSubmit(values, ctx) {
      var _a2;
      var _a, _b, _c;
      loading.value = true;
      const { data, error } = await useFetch("/contacts", {
        method: "POST",
        body: { ...dataForm.value },
        ...requestOptions
      }, "$lQCMwiLKgo");
      if (error.value) {
        ctx.setErrors(transformErrors((_a = error.value) == null ? void 0 : _a.data));
        snackbar.add({
          type: "error",
          text: (_a2 = (_c = (_b = error.value) == null ? void 0 : _b.data) == null ? void 0 : _c.message) != null ? _a2 : "Something went wrong"
        });
      } else {
        snackbar.add({
          type: "success",
          text: "Thank you for your message. We will get back to you as soon as possible."
        });
        ctx.resetForm();
      }
      loading.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_VeeForm = Form;
      const _component_VeeField = Field;
      const _component_VeeErrorMessage = ErrorMessage;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex flex-col justify-center items-center md:my-10" }, _attrs))}><h1 class="text-[#404040] text-[35px] font-semibold my-4"> Neem contact op </h1><p class="text-[14px] text-center"> Heb je vragen of opmerkingen? Wil je een afspraak maken of een rondleiding aanvragen? </p><div class="flex my-5 w-full flex-col sm:flex-row justify-center px-5 md:px-0 gap-5"><div class="flex flex-col mt-2 mx-2 sm:mx-0 md:w-[400px] py-5 pl-2 md:pl-5 bg-[#F7F7F7] box-shadow2 max-h-[400px] sm:w-[50%] order-2 sm:order-1"><p class="text-[16px] text-[#230000] leading-9"> Dan kun je een mail sturen of bellen: </p>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "mailto:/info@werkstek.nl",
        class: "text-[#777] text-[12px] sm:text-[14px] leading-9"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` info@werkstek.nl `);
          } else {
            return [
              createTextVNode(" info@werkstek.nl ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "https://api.whatsapp.com/send?phone=31655400370",
        class: "text-[#777] text-[12px] sm:text-[14px] leading-9"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(` 31655400370 `);
          } else {
            return [
              createTextVNode(" 31655400370 ")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`<h1 class="text-[12px] sm:text-[14px] text-[#230000] leading-9 my-1 md:my-4"> Ons Werkstek hoofdkantoor: </h1><p class="text-[#777] text-[12px] sm:text-[14px] leading-9"> Werkstek B.V. </p><p class="text-[#777] text-[12px] sm:text-[14px] leading-9"> Tussen de Bogen 81 </p><p class="text-[#777] text-[12px] sm:text-[14px] leading-9"> 1013 JB AMSTERDAM </p><div class="flex gap-3 mt-2">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "https://www.facebook.com/werkstek/",
        target: "_blank"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_0)} alt="icon-facebook-black"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_0,
                alt: "icon-facebook-black"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "https://www.instagram.com/werkstek/",
        target: "_blank"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_1)} alt="icon-instagram-black"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_1,
                alt: "icon-instagram-black"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "https://www.youtube.com/channel/UC6Oo-nukQWPpGzapf7T6PnA",
        target: "_blank"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_2)} alt="icon-youtube-black"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_2,
                alt: "icon-youtube-black"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "https://www.linkedin.com/company/werkstek/",
        target: "_blank"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<img${ssrRenderAttr("src", _imports_3)} alt="icon-linkedin-black"${_scopeId}>`);
          } else {
            return [
              createVNode("img", {
                src: _imports_3,
                alt: "icon-linkedin-black"
              })
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div><div class="order-1 sm:order-2 md:w-[400px] text-[#777] sm:w-[50%]">`);
      _push(ssrRenderComponent(_component_VeeForm, {
        "validation-schema": unref(contactSchema),
        onSubmit
      }, {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex flex-col text-[12px] md:text-[14px]"${_scopeId}><div class="flex flex-col my-2"${_scopeId}><div class="flex items-center"${_scopeId}><label for="first_name"${_scopeId}>Je naam (verplicht)</label></div>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "first_name",
              name: "first_name",
              modelValue: unref(dataForm).first_name,
              "onUpdate:modelValue": ($event) => unref(dataForm).first_name = $event,
              type: "text",
              class: "input w-full input-sm",
              placeholder: "Naam",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`<hr${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "first_name",
              class: "text-[13px] text-error"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2"${_scopeId}><div class="flex items-center"${_scopeId}><label for="last_name"${_scopeId}>Achternaam</label></div>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "last_name",
              name: "last_name",
              modelValue: unref(dataForm).last_name,
              "onUpdate:modelValue": ($event) => unref(dataForm).last_name = $event,
              type: "text",
              class: "input w-full input-sm",
              placeholder: "Achternaam",
              autocomplete: "on"
            }, null, _parent2, _scopeId));
            _push2(`<hr${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "last_name",
              class: "text-[13px] text-error"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2"${_scopeId}><div class="flex items-center"${_scopeId}><label for="email"${_scopeId}>Je e-mailadres (verplicht)</label></div>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "email",
              name: "email",
              modelValue: unref(dataForm).email,
              "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
              type: "text",
              class: "input w-full input-sm",
              placeholder: "Mail",
              autocomplete: "Mail"
            }, null, _parent2, _scopeId));
            _push2(`<hr${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "email",
              class: "text-[13px] text-error"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2"${_scopeId}><div class="flex items-center"${_scopeId}><label for="subject"${_scopeId}>Onderwerp</label></div>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "subject",
              name: "subject",
              modelValue: unref(dataForm).subject,
              "onUpdate:modelValue": ($event) => unref(dataForm).subject = $event,
              type: "text",
              class: "input w-full input-sm",
              placeholder: "Onderwerp",
              autocomplete: "Onderwerp"
            }, null, _parent2, _scopeId));
            _push2(`<hr${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "subject",
              class: "text-[13px] text-error"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col my-2"${_scopeId}><div class="flex items-center"${_scopeId}><label for="message"${_scopeId}>Je bericht</label></div>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              id: "message",
              name: "message",
              modelValue: unref(dataForm).message,
              "onUpdate:modelValue": ($event) => unref(dataForm).message = $event,
              as: "textarea",
              class: "textarea textarea-sm textarea-ghost h-[100px] min-h-[50px] max-h-[150px]",
              placeholder: "Je bericht"
            }, null, _parent2, _scopeId));
            _push2(`<hr${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeErrorMessage, {
              name: "message",
              class: "text-[13px] text-error"
            }, null, _parent2, _scopeId));
            _push2(`</div></div><div class="flex justify-end"${_scopeId}><button type="submit"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""} class="btn normal-case mt-4 bg-primary disabled:bg-secondary hover:bg-secondary transition min-w-[120px] sm:min-w-[152px] min-h-[42px] sm:min-h-[52px] rounded-full flex items-center justify-center cursor-pointer"${_scopeId}><span class="text-base text-center text-white"${_scopeId}> Versturen </span></button></div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col text-[12px] md:text-[14px]" }, [
                createVNode("div", { class: "flex flex-col my-2" }, [
                  createVNode("div", { class: "flex items-center" }, [
                    createVNode("label", { for: "first_name" }, "Je naam (verplicht)")
                  ]),
                  createVNode(_component_VeeField, {
                    id: "first_name",
                    name: "first_name",
                    modelValue: unref(dataForm).first_name,
                    "onUpdate:modelValue": ($event) => unref(dataForm).first_name = $event,
                    type: "text",
                    class: "input w-full input-sm",
                    placeholder: "Naam",
                    autocomplete: "on"
                  }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode("hr"),
                  createVNode(_component_VeeErrorMessage, {
                    name: "first_name",
                    class: "text-[13px] text-error"
                  })
                ]),
                createVNode("div", { class: "flex flex-col my-2" }, [
                  createVNode("div", { class: "flex items-center" }, [
                    createVNode("label", { for: "last_name" }, "Achternaam")
                  ]),
                  createVNode(_component_VeeField, {
                    id: "last_name",
                    name: "last_name",
                    modelValue: unref(dataForm).last_name,
                    "onUpdate:modelValue": ($event) => unref(dataForm).last_name = $event,
                    type: "text",
                    class: "input w-full input-sm",
                    placeholder: "Achternaam",
                    autocomplete: "on"
                  }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode("hr"),
                  createVNode(_component_VeeErrorMessage, {
                    name: "last_name",
                    class: "text-[13px] text-error"
                  })
                ]),
                createVNode("div", { class: "flex flex-col my-2" }, [
                  createVNode("div", { class: "flex items-center" }, [
                    createVNode("label", { for: "email" }, "Je e-mailadres (verplicht)")
                  ]),
                  createVNode(_component_VeeField, {
                    id: "email",
                    name: "email",
                    modelValue: unref(dataForm).email,
                    "onUpdate:modelValue": ($event) => unref(dataForm).email = $event,
                    type: "text",
                    class: "input w-full input-sm",
                    placeholder: "Mail",
                    autocomplete: "Mail"
                  }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode("hr"),
                  createVNode(_component_VeeErrorMessage, {
                    name: "email",
                    class: "text-[13px] text-error"
                  })
                ]),
                createVNode("div", { class: "flex flex-col my-2" }, [
                  createVNode("div", { class: "flex items-center" }, [
                    createVNode("label", { for: "subject" }, "Onderwerp")
                  ]),
                  createVNode(_component_VeeField, {
                    id: "subject",
                    name: "subject",
                    modelValue: unref(dataForm).subject,
                    "onUpdate:modelValue": ($event) => unref(dataForm).subject = $event,
                    type: "text",
                    class: "input w-full input-sm",
                    placeholder: "Onderwerp",
                    autocomplete: "Onderwerp"
                  }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode("hr"),
                  createVNode(_component_VeeErrorMessage, {
                    name: "subject",
                    class: "text-[13px] text-error"
                  })
                ]),
                createVNode("div", { class: "flex flex-col my-2" }, [
                  createVNode("div", { class: "flex items-center" }, [
                    createVNode("label", { for: "message" }, "Je bericht")
                  ]),
                  createVNode(_component_VeeField, {
                    id: "message",
                    name: "message",
                    modelValue: unref(dataForm).message,
                    "onUpdate:modelValue": ($event) => unref(dataForm).message = $event,
                    as: "textarea",
                    class: "textarea textarea-sm textarea-ghost h-[100px] min-h-[50px] max-h-[150px]",
                    placeholder: "Je bericht"
                  }, null, 8, ["modelValue", "onUpdate:modelValue"]),
                  createVNode("hr"),
                  createVNode(_component_VeeErrorMessage, {
                    name: "message",
                    class: "text-[13px] text-error"
                  })
                ])
              ]),
              createVNode("div", { class: "flex justify-end" }, [
                createVNode("button", {
                  type: "submit",
                  disabled: unref(loading),
                  class: "btn normal-case mt-4 bg-primary disabled:bg-secondary hover:bg-secondary transition min-w-[120px] sm:min-w-[152px] min-h-[42px] sm:min-h-[52px] rounded-full flex items-center justify-center cursor-pointer"
                }, [
                  createVNode("span", { class: "text-base text-center text-white" }, " Versturen ")
                ], 8, ["disabled"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ContactUs.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$1;
const _sfc_main = {
  __name: "contact",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Contact"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_StatistiekLocaties = __nuxt_component_0;
      const _component_ContactUs = __nuxt_component_1;
      const _component_MapInteractive = __nuxt_component_4;
      const _component_BgBigGreen = __nuxt_component_4$1;
      _push(`<!--[--><div class="mt-20"></div>`);
      _push(ssrRenderComponent(_component_StatistiekLocaties, {
        image: "/images/img-home-11.png",
        title1: "Neem contact op",
        title2: "Neem contact </br> op met Werkstek",
        title3: "Werkstek slaat een brug tussen de leegstand van kantoorruimtes en de vraag naar betaalbare werkplekken. Werkstek huurt en verhuurt een toenemend aantal werkplekken en kantoorunits.",
        titleBg1: "Locaties",
        titleBg2: "Statistiek 2",
        titleBg3: "Statistiek 3",
        count1: 280,
        count2: 15,
        count3: 49,
        showButton: true,
        buttonTitle1: "Over Werkstek",
        buttonTitle2: "Voor verhuurders",
        buttonLink1: "/over-werkstek",
        buttonLink2: "/voor-verhuurders"
      }, null, _parent));
      _push(ssrRenderComponent(_component_ContactUs, { class: "mb-10" }, null, _parent));
      _push(ssrRenderComponent(_component_MapInteractive, {
        ShowContainerCustom: false,
        class: "container-custom my-10"
      }, null, _parent));
      _push(ssrRenderComponent(_component_BgBigGreen, {
        title1: "Blijf op de hoogte",
        title2: "Schrijf je in voor de nieuwsbrief",
        title3: "Op de hoogte blijven van beschikbare werkplekken? Schrijf je dan nu vrijblijvend in!",
        backgroundColor: "secondary",
        showEmailSection: true
      }, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/contact.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=contact-2fb13582.mjs.map
