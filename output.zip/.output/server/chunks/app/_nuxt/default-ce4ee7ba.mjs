import { useSSRContext, ref, unref, withCtx, createTextVNode, toDisplayString, mergeProps, createVNode } from 'vue';
import { h as _export_sfc, u as useRequestOptions, a as useRouter, b as useRoute, _ as __nuxt_component_0$1 } from '../server.mjs';
import { _ as __nuxt_component_0$2 } from './Werkstek-58cf971d.mjs';
import __nuxt_component_2 from './Icon-e394d28f.mjs';
import { o as onClickOutside } from './index-c7d55092.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderSlot, ssrRenderList, ssrInterpolate, ssrRenderClass, ssrRenderAttr, ssrRenderStyle } from 'vue/server-renderer';
import { _ as _imports_0 } from './arrow-small-right-9e640e2c.mjs';
import { _ as _sfc_main$4 } from './NuxtSnackbar-cce50284.mjs';
import { u as useFetch } from './fetch-101122a4.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import './config-aab100d3.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import './index-73677d9a.mjs';
import './asyncData-04c89180.mjs';

const _sfc_main$3 = {};
function _sfc_ssrRender$2(_ctx, _push, _parent, _attrs) {
  _push(`<!--[--><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" data-v-26af423f><a href="https://api.whatsapp.com/send?phone=31655400370" class="float" target="_blank" data-v-26af423f><i class="fa fa-whatsapp my-float" data-v-26af423f></i></a><!--]-->`);
}
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/floating-whatsapp.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["ssrRender", _sfc_ssrRender$2], ["__scopeId", "data-v-26af423f"]]);
const _sfc_main$2 = {
  data() {
    return {
      isOpen: false,
      isDropdownOpenContact: false
    };
  },
  setup() {
    const isDropdownOpen = ref(false);
    const target = ref(null);
    onClickOutside(target, (event) => isDropdownOpen.value = false);
    return {
      isDropdownOpen,
      target,
      onClickOutside
    };
  },
  methods: {
    isRouteActive(route) {
      return this.$route.path === route;
    },
    showDropdownOver() {
      this.isDropdownOpen = !this.isDropdownOpen;
    },
    showDropdownContact() {
      this.isDropdownOpenContact = !this.isDropdownOpenContact;
    },
    drawer() {
      this.isOpen = !this.isOpen;
    },
    isUpdateActive() {
      return this.$route.path.startsWith("/blog") || this.$route.path.startsWith("/werkstek-community");
    },
    isUpdateActive2() {
      return this.$route.path.startsWith("/onze-vacatures") || this.$route.path.startsWith("/over-werkstek");
    }
  },
  watch: {
    isOpen: {
      immediate: true,
      handler(isOpen) {
      }
    }
  },
  mounted() {
    document.addEventListener("keydown", (e) => {
      if (e.keyCode == 27 && this.isOpen)
        this.isOpen = false;
    });
  }
};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Werkstek = __nuxt_component_0$2;
  const _component_NuxtLink = __nuxt_component_0$1;
  const _component_Icon = __nuxt_component_2;
  _push(`<nav${ssrRenderAttrs(mergeProps({ class: "w-full z-50 top-0 fixed" }, _attrs))}><div class="flex items-center justify-between w-full relative bg-white container-custom py-2">`);
  _push(ssrRenderComponent(_component_Werkstek, { class: "lg:hidden" }, null, _parent));
  _push(`<div class="lg:hidden flex"><button name="toggle"><svg class="h-8 w-8 fill-current text-quaternary" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" stroke="currentColor"><path d="M4 6h16M4 12h16M4 18h16"></path></svg></button></div><div class="hidden lg:flex z-[99999] items-center justify-between w-full"><ul class="flex items-center md:gap-1 bg-primary p-1 rounded-full text-tertiary md:w-[77%]"><li class="bg-white rounded-full">`);
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_Werkstek, null, null, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_Werkstek)
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><div class="flex justify-evenly items-center w-full font-medium"><li class="text-sm">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/onze-locaties",
    class: ["navlink", { active: $options.isRouteActive("/onze-locaties") }]
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Onze locaties`);
      } else {
        return [
          createTextVNode("Onze locaties")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="text-sm">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/voor-verhuurders",
    class: ["navlink", { active: $options.isRouteActive("/voor-verhuurders") }]
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Verhuur`);
      } else {
        return [
          createTextVNode("Verhuur")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="relative"><span class="${ssrRenderClass([{ active: $options.isUpdateActive2() }, "bg-transparent border-none text-white font-thin hover:bg-transparent cursor-pointer navlink text-sm"])}"> Over werkstek </span>`);
  if ($setup.isDropdownOpen) {
    _push(`<ul class="rounded-xl bg-black z-[1] shadow text-white text-sm mt-5 w-[200px] absolute right-[-55px]"><li class="text-sm hover:text-primary group hover:rounded-t-xl">`);
    _push(ssrRenderComponent(_component_NuxtLink, {
      onClick: ($event) => $setup.isDropdownOpen = false,
      to: "/over-werkstek",
      class: ["rounded-none w-full flex justify-between items-center px-4 py-3", { active: $options.isRouteActive("/over-werkstek") }],
      activeClass: "bg-black text-primary rounded-t-xl"
    }, {
      default: withCtx((_, _push2, _parent2, _scopeId) => {
        if (_push2) {
          _push2(` Over Werkstek <div class="${ssrRenderClass([{
            "text-black bg-white rounded-full": !$options.isRouteActive("/over-werkstek"),
            "bg-primary rounded-full": $options.isRouteActive("/over-werkstek")
          }, "group-hover:bg-primary rounded-full w-5 h-5 flex items-center justify-center pr-[3px]"])}"${_scopeId}>`);
          _push2(ssrRenderComponent(_component_Icon, {
            name: "fluent:ios-arrow-24-filled",
            class: ["rotate-180", {
              "text-black": !$options.isRouteActive("/over-werkstek"),
              "bg-primary rounded-full text-black": $options.isRouteActive("/over-werkstek")
            }]
          }, null, _parent2, _scopeId));
          _push2(`</div>`);
        } else {
          return [
            createTextVNode(" Over Werkstek "),
            createVNode("div", {
              class: ["group-hover:bg-primary rounded-full w-5 h-5 flex items-center justify-center pr-[3px]", {
                "text-black bg-white rounded-full": !$options.isRouteActive("/over-werkstek"),
                "bg-primary rounded-full": $options.isRouteActive("/over-werkstek")
              }]
            }, [
              createVNode(_component_Icon, {
                name: "fluent:ios-arrow-24-filled",
                class: ["rotate-180", {
                  "text-black": !$options.isRouteActive("/over-werkstek"),
                  "bg-primary rounded-full text-black": $options.isRouteActive("/over-werkstek")
                }]
              }, null, 8, ["class"])
            ], 2)
          ];
        }
      }),
      _: 1
    }, _parent));
    _push(`</li><li class="text-sm hover:text-primary hover:rounded-b-xl group">`);
    _push(ssrRenderComponent(_component_NuxtLink, {
      onClick: ($event) => $setup.isDropdownOpen = false,
      to: "/onze-vacatures",
      class: ["rounded-none w-full flex justify-between items-center px-4 py-3", { active: $options.isRouteActive("/onze-vacatures") }],
      activeClass: "bg-black text-primary rounded-b-xl"
    }, {
      default: withCtx((_, _push2, _parent2, _scopeId) => {
        if (_push2) {
          _push2(` Onze Vacatures <div class="${ssrRenderClass([{
            "text-black bg-white rounded-full": !$options.isRouteActive("/onze-vacatures"),
            "bg-primary rounded-full": $options.isRouteActive("/onze-vacatures")
          }, "group-hover:bg-primary rounded-full w-5 h-5 flex items-center justify-center pr-[3px]"])}"${_scopeId}>`);
          _push2(ssrRenderComponent(_component_Icon, {
            name: "fluent:ios-arrow-24-filled",
            class: ["rotate-180", {
              "text-black": !$options.isRouteActive("/onze-vacatures"),
              "bg-primary rounded-full text-black": $options.isRouteActive("/onze-vacatures")
            }]
          }, null, _parent2, _scopeId));
          _push2(`</div>`);
        } else {
          return [
            createTextVNode(" Onze Vacatures "),
            createVNode("div", {
              class: ["group-hover:bg-primary rounded-full w-5 h-5 flex items-center justify-center pr-[3px]", {
                "text-black bg-white rounded-full": !$options.isRouteActive("/onze-vacatures"),
                "bg-primary rounded-full": $options.isRouteActive("/onze-vacatures")
              }]
            }, [
              createVNode(_component_Icon, {
                name: "fluent:ios-arrow-24-filled",
                class: ["rotate-180", {
                  "text-black": !$options.isRouteActive("/onze-vacatures"),
                  "bg-primary rounded-full text-black": $options.isRouteActive("/onze-vacatures")
                }]
              }, null, 8, ["class"])
            ], 2)
          ];
        }
      }),
      _: 1
    }, _parent));
    _push(`</li></ul>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</li><li class="text-sm">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/blog",
    class: ["navlink", { active: $options.isRouteActive("/blog") }]
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Blog`);
      } else {
        return [
          createTextVNode("Blog")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="text-sm">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/werkstek-community",
    class: ["navlink", { active: $options.isRouteActive("/werkstek-community") }]
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Community`);
      } else {
        return [
          createTextVNode("Community")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li></div></ul><div class="relative group py-2">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/contact",
    onClick: $options.showDropdownContact,
    class: "border hover:bg-slate-50 xl:p-2 border-quaternary hover:bg-opacity-60 transition rounded-full flex items-center gap-2 p-1 lg:px-2 w-fit"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<p class="pl-[2px] py-[1px] sm:p-3 text-[12px] lg:text-sm"${_scopeId}> Contact opnemen </p><div class="rounded-full bg-quaternary text-white flex items-center justify-center aspect-square"${_scopeId}><img${ssrRenderAttr("src", _imports_0)} alt="arrow" class="sm:m-1"${_scopeId}></div>`);
      } else {
        return [
          createVNode("p", { class: "pl-[2px] py-[1px] sm:p-3 text-[12px] lg:text-sm" }, " Contact opnemen "),
          createVNode("div", { class: "rounded-full bg-quaternary text-white flex items-center justify-center aspect-square" }, [
            createVNode("img", {
              src: _imports_0,
              alt: "arrow",
              class: "sm:m-1"
            })
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`<div class="hover:rounded-b-xl hidden group-hover:block rounded-xl bg-black z-[1] shadow text-white text-sm mt-[5px] w-[200px] absolute">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    onClick: ($event) => $setup.isDropdownOpen = false,
    to: "mailto:/info@werkstek.nl",
    class: "rounded-none w-full flex justify-between items-center px-4 py-3 hover:text-primary"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` info@werkstek.nl `);
      } else {
        return [
          createTextVNode(" info@werkstek.nl ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, {
    onClick: ($event) => $setup.isDropdownOpen = false,
    to: "tel:0850290598",
    class: "rounded-none w-full flex justify-between items-center px-4 py-3 hover:text-primary"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` 085 \u2013 0290598 `);
      } else {
        return [
          createTextVNode(" 085 \u2013 0290598 ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></div><div style="${ssrRenderStyle($data.isOpen ? null : { display: "none" })}" class="z-10 fixed inset-0 transition-opacity"><div class="absolute inset-0 bg-quaternary opacity-50" tabindex="0"></div></div><aside class="${ssrRenderClass([$data.isOpen ? "translate-x-0" : "-translate-x-full", "p-5 transform top-0 left-0 w-64 bg-white fixed h-full overflow-auto ease-in-out transition-all duration-300 z-30"])}"><div class="close"><button name="drawer-menu" class="absolute top-0 right-0 mt-4 mr-4"><svg class="w-6 h-6" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" stroke="currentColor"><path d="M6 18L18 6M6 6l12 12"></path></svg></button></div><span class="flex w-full items-center p-4 border-b">`);
  _push(ssrRenderComponent(_component_NuxtLink, { to: "/" }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(ssrRenderComponent(_component_Werkstek, null, null, _parent2, _scopeId));
      } else {
        return [
          createVNode(_component_Werkstek)
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</span><ul class="divide-y font-sans text-m"><li class="cursor-pointer">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/voor-verhuurders",
    onClick: ($event) => $data.isOpen = false,
    class: "my-4 inline-block w-full"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Verhuur`);
      } else {
        return [
          createTextVNode("Verhuur")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="cursor-pointer">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/onze-locaties",
    onClick: ($event) => $data.isOpen = false,
    class: "my-4 inline-block w-full"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Onze locaties`);
      } else {
        return [
          createTextVNode("Onze locaties")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="cursor-pointer dropdown w-full"><details class="dropdown w-full"><summary tabindex="1" class="bg-transparent border-none my-4 font-thin cursor-pointer gap-2 flex items-center"><span>Over Werkstek</span>`);
  _push(ssrRenderComponent(_component_Icon, {
    name: "radix-icons:triangle-up",
    class: "text-primary rotate-180 w-7 h-7"
  }, null, _parent));
  _push(`</summary><ul tabindex="1" class="ml-[-20px] dropdown-content z-[1] menu p-1 shadow bg-base-100 rounded-sm text-black w-full"><li class="text-sm">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/over-werkstek",
    onClick: ($event) => $data.isOpen = false
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Over Werkstek `);
      } else {
        return [
          createTextVNode(" Over Werkstek ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><hr><li class="text-sm">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/onze-vacatures",
    onClick: ($event) => $data.isOpen = false
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` Werstek Vacatures `);
      } else {
        return [
          createTextVNode(" Werstek Vacatures ")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li></ul></details></li><li class="cursor-pointer">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/blog",
    onClick: ($event) => $data.isOpen = false,
    class: "my-4 inline-block w-full"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Blog`);
      } else {
        return [
          createTextVNode("Blog")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="cursor-pointer">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/werkstek-community",
    onClick: ($event) => $data.isOpen = false,
    class: "my-4 inline-block w-full"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Community`);
      } else {
        return [
          createTextVNode("Community")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li><li class="cursor-pointer"></li><li class="cursor-pointer">`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/contact",
    onClick: ($event) => $data.isOpen = false,
    class: "mt-8 w-full text-center font-semibold cta inline-block bg-primary hover:bg-white border border-primary px-3 py-2 rounded text-white hover:text-primary"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Contact opnemen`);
      } else {
        return [
          createTextVNode("Contact opnemen")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "mailto:/info@werkstek.nl",
    onClick: ($event) => $data.isOpen = false,
    class: "w-full mt-5 mb-3 text-center font-semibold cta inline-block bg-transparent border border-primary px-3 py-2 rounded text-gray-700 hover:text-primary"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`Info@werkstek.nl`);
      } else {
        return [
          createTextVNode("Info@werkstek.nl")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "tel:0850290598",
    onClick: ($event) => $data.isOpen = false,
    class: "w-full text-center font-semibold cta inline-block bg-transparent border border-primary px-3 py-2 rounded text-gray-700 hover:text-primary"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(` 085 \u2013 0290598`);
      } else {
        return [
          createTextVNode(" 085 \u2013 0290598")
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</li></ul></aside></div></nav>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Navbar.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main$1 = {
  __name: "Footer",
  __ssrInlineRender: true,
  setup(__props) {
    const { requestOptions } = useRequestOptions();
    useRouter();
    useRoute();
    ref("");
    ref("");
    const { data: dataLocation } = useFetch("/locations", {
      method: "get",
      ...requestOptions
    }, "$oeF46sJglj");
    const { data: dataProduct } = useFetch("/products", {
      method: "get",
      ...requestOptions
    }, "$HHSEI6b2nZ");
    const { data: types } = useFetch("/types", {
      method: "get",
      ...requestOptions
    }, "$JA7FfYz0nr");
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c;
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<!--[--><section id="footer" class="relative border-t-2 border-secondary container-custom"><div class="grid sm:grid-cols-3 gap-5 md:gap-0 my-10"><div class="flex flex-col gap-5"><div class="grid gap-2 text-sm"><span class="text-[#808080]">Soorten kantoorruimte</span><ul class="grid gap-4"><!--[-->`);
      ssrRenderList((_a = unref(types)) == null ? void 0 : _a.data.slice(0, 5), (item) => {
        _push(`<li class="cursor-pointer"><span class="hover:text-primary">${ssrInterpolate(item.name)}</span></li>`);
      });
      _push(`<!--]--></ul></div><div class="grid gap-2 text-sm"><span class="text-[#808080]">Meer informatie</span><ul class="grid gap-4"><li><a href="algemene-voorwaarden-werkstek.pdf" target="_blank" class="hover:text-primary">Algemene voorwaarden</a></li></ul></div></div><div class="flex flex-col text-sm"><div class="grid gap-3"><span class="text-[#808080]">Populaire locaties</span><ul class="grid"><li class="cursor-pointer grid gap-4"><!--[-->`);
      ssrRenderList((_b = unref(dataLocation)) == null ? void 0 : _b.data.slice(0, 10), (item) => {
        _push(`<div class="hover:text-primary"> Kantoorruimte ${ssrInterpolate(item.name)}</div>`);
      });
      _push(`<!--]--></li></ul></div></div><div class="flex flex-col text-sm"><div class="grid gap-3"><span class="text-[#808080]">Populaire ruimtes</span><ul class="grid gap-4"><!--[-->`);
      ssrRenderList((_c = unref(dataProduct)) == null ? void 0 : _c.data.slice(0, 4), (item) => {
        _push(`<li class="cursor-pointer">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/onze-locaties/${item.slug}`,
          class: "hover:text-primary"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(item.name)}`);
            } else {
              return [
                createTextVNode(toDisplayString(item.name), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</li>`);
      });
      _push(`<!--]--></ul></div></div></div></section><div class="bg-tertiary flex flex-col lg:flex-row items-center container-custom"><div class="grid sm:grid-cols-12 place-items-center py-5"><div class="sm:col-span-8 flex sm:flex-row flex-col gap-4 text-[12px] sm:text-sm"><p class="text-[#8C8E91]"> Copyright All Rights Reserved \xA9 2023 Werkstek </p><a href="algemene-voorwaarden-werkstek.pdf" target="_blank" class="hover:text-primary col-span-4">Veel gestelde vragen</a><span class="hidden sm:block">|</span>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "privacy-verklaring",
        class: "sm:pr-4 hover:text-primary"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Privacy verklaring`);
          } else {
            return [
              createTextVNode("Privacy verklaring")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div><div class="sm:col-span-4 mt-9 sm:mt-0">`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "https://spdigitalagency.com/id",
        class: "text-[12px] opacity-60"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`Design &amp; Developed by s.p. Digital`);
          } else {
            return [
              createTextVNode("Design & Developed by s.p. Digital")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div></div><!--]-->`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Footer.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_3 = _sfc_main$1;
const _sfc_main = {
  Navbar: __nuxt_component_1,
  Footer: __nuxt_component_3
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_floating_whatsapp = __nuxt_component_0;
  const _component_Navbar = __nuxt_component_1;
  const _component_NuxtSnackbar = _sfc_main$4;
  const _component_Footer = __nuxt_component_3;
  _push(`<div${ssrRenderAttrs(_attrs)}>`);
  _push(ssrRenderComponent(_component_floating_whatsapp, null, null, _parent));
  _push(ssrRenderComponent(_component_Navbar, null, null, _parent));
  _push(`<main>`);
  ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
  _push(`</main>`);
  _push(ssrRenderComponent(_component_NuxtSnackbar, null, null, _parent));
  _push(ssrRenderComponent(_component_Footer, null, null, _parent));
  _push(`</div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("layouts/default.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const _default = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);

export { _default as default };
//# sourceMappingURL=default-ce4ee7ba.mjs.map
