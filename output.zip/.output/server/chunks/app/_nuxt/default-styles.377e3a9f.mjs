const floatingWhatsapp_vue_vue_type_style_index_0_scoped_26af423f_lang = ".float[data-v-26af423f]{background-color:#25d366;border-radius:50px;bottom:40px;box-shadow:2px 2px 3px #999;color:#fff;font-size:30px;height:60px;position:fixed;right:40px;text-align:center;width:60px;z-index:100}.my-float[data-v-26af423f]{margin-top:16px}";

const defaultStyles_377e3a9f = [floatingWhatsapp_vue_vue_type_style_index_0_scoped_26af423f_lang];

export { defaultStyles_377e3a9f as default };
//# sourceMappingURL=default-styles.377e3a9f.mjs.map
