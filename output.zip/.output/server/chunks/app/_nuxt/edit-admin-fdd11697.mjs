import { _ as __nuxt_component_0 } from './Werkstek-58cf971d.mjs';
import { Form, Field } from 'vee-validate';
import { d as useHead, b as useFetch } from '../server.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { u as useSchema } from './useSchema-3365865c.mjs';
import { ref, mergeProps, withCtx, unref, createVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrIncludeBooleanAttr } from 'vue/server-renderer';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'zod';
import '@vee-validate/zod';

const _sfc_main = {
  __name: "edit-admin",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Registasion"
    });
    const { loading, transformErrors } = useRequestHelper();
    const { requestOptions } = useRequestOptions();
    useSchema();
    const form = ref({
      first_name: "",
      last_name: "",
      email: ""
    });
    async function onSubmit(values, ctx) {
      var _a2;
      var _a, _b, _c;
      loading.value = true;
      const { error } = await useFetch(`/admins`, {
        method: "POST",
        body: JSON.stringify(form.value),
        ...requestOptions
      }, "$y0QNwngbbi");
      if (error.value) {
        ctx.setErrors(transformErrors((_a = error.value) == null ? void 0 : _a.data));
        snackbar.add({
          type: "error",
          text: (_a2 = (_c = (_b = error.value) == null ? void 0 : _b.data) == null ? void 0 : _c.message) != null ? _a2 : "Something went wrong"
        });
      } else {
        snackbar.add({
          type: "success",
          text: "Success Edit Admin"
        });
        ctx.resetForm();
      }
      loading.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Werkstek = __nuxt_component_0;
      const _component_VeeForm = Form;
      const _component_VeeField = Field;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "grid place-items-center items-center h-screen" }, _attrs))}><div class="w-[500px] p-10 justify-center shadow-lg">`);
      _push(ssrRenderComponent(_component_Werkstek, { class: "mb-10" }, null, _parent));
      _push(ssrRenderComponent(_component_VeeForm, { onSubmit }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<h4 class="pb-1 text-lg"${_scopeId}>First Name</h4><div class="flex flex-col space-y-4"${_scopeId}><div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              name: "firstName",
              class: "input input-bordered w-full",
              modelValue: unref(form).first_name,
              "onUpdate:modelValue": ($event) => unref(form).first_name = $event
            }, null, _parent2, _scopeId));
            _push2(`</div><h4 class="pb-1 text-lg"${_scopeId}>Last Name</h4><div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              name: "lastname",
              class: "input input-bordered w-full",
              modelValue: unref(form).last_name,
              "onUpdate:modelValue": ($event) => unref(form).last_name = $event
            }, null, _parent2, _scopeId));
            _push2(`</div><h4 class="pb-1 text-lg"${_scopeId}>Email</h4><div${_scopeId}>`);
            _push2(ssrRenderComponent(_component_VeeField, {
              name: "email",
              class: "input input-bordered w-full",
              modelValue: unref(form).email,
              "onUpdate:modelValue": ($event) => unref(form).email = $event
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="mt-10"${_scopeId}><button${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""} type="submit" class="btn bg-[#F0912D] text-white w-full hover:bg-secondary"${_scopeId}> Submit </button></div></div>`);
          } else {
            return [
              createVNode("h4", { class: "pb-1 text-lg" }, "First Name"),
              createVNode("div", { class: "flex flex-col space-y-4" }, [
                createVNode("div", null, [
                  createVNode(_component_VeeField, {
                    name: "firstName",
                    class: "input input-bordered w-full",
                    modelValue: unref(form).first_name,
                    "onUpdate:modelValue": ($event) => unref(form).first_name = $event
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode("h4", { class: "pb-1 text-lg" }, "Last Name"),
                createVNode("div", null, [
                  createVNode(_component_VeeField, {
                    name: "lastname",
                    class: "input input-bordered w-full",
                    modelValue: unref(form).last_name,
                    "onUpdate:modelValue": ($event) => unref(form).last_name = $event
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode("h4", { class: "pb-1 text-lg" }, "Email"),
                createVNode("div", null, [
                  createVNode(_component_VeeField, {
                    name: "email",
                    class: "input input-bordered w-full",
                    modelValue: unref(form).email,
                    "onUpdate:modelValue": ($event) => unref(form).email = $event
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode("div", { class: "mt-10" }, [
                  createVNode("button", {
                    disabled: unref(loading),
                    type: "submit",
                    class: "btn bg-[#F0912D] text-white w-full hover:bg-secondary"
                  }, " Submit ", 8, ["disabled"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/edit-admin.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=edit-admin-fdd11697.mjs.map
