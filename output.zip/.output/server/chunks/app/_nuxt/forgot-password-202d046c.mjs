import { Form, Field, ErrorMessage } from 'vee-validate';
import { u as useForgotPassword, _ as _sfc_main$5 } from './useForgotPassword-e6ea2eaa.mjs';
import { _ as _sfc_main$6 } from './TextField-7edd2a1a.mjs';
import { u as useSchema } from './useSchema-3365865c.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { a as useRouter, d as useHead, u as useRequestOptions } from '../server.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { useSSRContext, defineComponent, computed, mergeProps, unref, withCtx, createVNode, ref, watch, openBlock, createBlock, createTextVNode, createCommentVNode, toDisplayString } from 'vue';
import { u as useFetch } from './fetch-101122a4.mjs';
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrIncludeBooleanAttr, ssrRenderList, ssrRenderAttr, ssrRenderClass } from 'vue/server-renderer';
import { a as useStepper } from './index-c7d55092.mjs';
import 'zod';
import '@vee-validate/zod';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './asyncData-04c89180.mjs';
import './index-73677d9a.mjs';

const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  emits: ["next", "update:email"],
  setup(__props, { emit }) {
    useSchema();
    const snackbar = useSnackbar();
    const { requestOptions } = useRequestOptions();
    const { loading, message, alertType, transformErrors } = useRequestHelper();
    const { stateForm } = useForgotPassword();
    const { onlyEmailSchema } = useSchema();
    function updateToParent() {
      emit("update:email", stateForm.value.email);
      emit("next");
    }
    async function onSubmit(values, ctx) {
      var _a2;
      var _a, _b, _c;
      loading.value = true;
      const { data, error } = await useFetch(`/admins/forget-password`, {
        method: "POST",
        body: { email: stateForm.value.email },
        ...requestOptions
      }, "$PASZLp1iyA");
      if (error.value) {
        ctx.setErrors(transformErrors((_a = error.value) == null ? void 0 : _a.data));
        snackbar.add({
          type: "error",
          text: (_a2 = (_c = (_b = error.value) == null ? void 0 : _b.data) == null ? void 0 : _c.message) != null ? _a2 : "Something went wrong"
        });
      } else {
        snackbar.add({
          type: "success",
          text: "Sending OTP Success, Please check your email"
        });
        updateToParent();
      }
      loading.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_FormGroup = _sfc_main$5;
      const _component_FormTextField = _sfc_main$6;
      _push(ssrRenderComponent(_component_VeeForm, mergeProps({
        onSubmit,
        "validation-schema": unref(onlyEmailSchema)
      }, _attrs), {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 w-[450px] text-left gap-4 p-4 rounded-md shadow"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormGroup, {
              label: "Email",
              name: "email"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_FormTextField, {
                    id: "email",
                    name: "email",
                    modelValue: unref(stateForm).email,
                    "onUpdate:modelValue": ($event) => unref(stateForm).email = $event,
                    placeholder: "ex:myemail@gmail.com",
                    class: "input-bordered",
                    autocomplete: "off"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_FormTextField, {
                      id: "email",
                      name: "email",
                      modelValue: unref(stateForm).email,
                      "onUpdate:modelValue": ($event) => unref(stateForm).email = $event,
                      placeholder: "ex:myemail@gmail.com",
                      class: "input-bordered",
                      autocomplete: "off"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            _push2(`<div${_scopeId}><p class="text-gray-400"${_scopeId}>We will send a code to your email</p></div><div${_scopeId}><button class="btn btn-success" type="submit"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""}${_scopeId}> Submit </button></div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 w-[450px] text-left gap-4 p-4 rounded-md shadow" }, [
                createVNode(_component_FormGroup, {
                  label: "Email",
                  name: "email"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_FormTextField, {
                      id: "email",
                      name: "email",
                      modelValue: unref(stateForm).email,
                      "onUpdate:modelValue": ($event) => unref(stateForm).email = $event,
                      placeholder: "ex:myemail@gmail.com",
                      class: "input-bordered",
                      autocomplete: "off"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 2
                }, 1024),
                createVNode("div", null, [
                  createVNode("p", { class: "text-gray-400" }, "We will send a code to your email")
                ]),
                createVNode("div", null, [
                  createVNode("button", {
                    class: "btn btn-success",
                    type: "submit",
                    disabled: unref(loading)
                  }, " Submit ", 8, ["disabled"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ForgotPassword/index.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "InputOTP",
  __ssrInlineRender: true,
  props: {
    inputLength: {
      type: Number,
      default: () => 6
    },
    modelValue: {
      type: [String, Number]
    },
    isError: {
      type: Boolean,
      default: false
    }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit }) {
    const prop = __props;
    ref([]);
    const length = computed(() => prop.inputLength);
    const fieldValues = ref([]);
    const composite = computed(() => {
      const nonNullFields = fieldValues.value.filter((value) => value);
      if (length.value !== nonNullFields.length) {
        return "";
      }
      return nonNullFields.join("");
    });
    watch(composite, () => {
      if (composite.value) {
        emit("update:modelValue", composite.value);
      } else {
        emit("update:modelValue", "");
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "inline-flex space-x-2.5" }, _attrs))}><!--[-->`);
      ssrRenderList(unref(length), (i) => {
        _push(`<input type="text"${ssrRenderAttr("value", unref(fieldValues)[i - 1])} class="${ssrRenderClass([{ "input-error": __props.isError }, "input input-bordered h-14 w-10 px-3.5"])}" maxlength="1">`);
      });
      _push(`<!--]--></div>`);
    };
  }
});
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Form/InputOTP.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "VerifiedOTP",
  __ssrInlineRender: true,
  props: {
    email: String,
    otp: String
  },
  emits: ["next", "update:otp"],
  setup(__props, { emit }) {
    const props = __props;
    const { requestOptions } = useRequestOptions();
    const snackbar = useSnackbar();
    const { stateForm, countdown, showPinEmailExpired, secondTime } = useForgotPassword();
    const { otpSchema } = useSchema();
    const { loading, message, alertType } = useRequestHelper();
    function updateToParent() {
      emit("update:otp", stateForm.value.otp);
      emit("next");
    }
    function resentEmail() {
      showPinEmailExpired.value = false;
      secondTime.value = 60;
      countdown();
      useFetch("/admins/resend-email-verification", {
        headers: {
          Accept: "application/json"
        },
        method: "POST",
        body: { email: stateForm.value.email },
        ...requestOptions
      }, "$NrsNwnK01s");
    }
    async function onSubmit() {
      var _a2;
      var _a, _b;
      loading.value = true;
      const { error } = await useFetch("/admins/forget-password/verify-pin", {
        method: "POST",
        body: JSON.stringify({
          email: props.email,
          pin: stateForm.value.otp
        }),
        ...requestOptions
      }, "$q5WxwtDszJ");
      if (error.value) {
        snackbar.add({
          type: "error",
          text: (_a2 = (_b = (_a = error.value) == null ? void 0 : _a.data) == null ? void 0 : _b.message) != null ? _a2 : "Something went wrong"
        });
      } else {
        snackbar.add({
          type: "success",
          text: "Thank you for your message. We will get back to you as soon as possible."
        });
        updateToParent();
      }
      loading.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_FormGroup = _sfc_main$5;
      const _component_VeeField = Field;
      const _component_FormInputOTP = _sfc_main$3;
      const _component_VeeErrorMessage = ErrorMessage;
      _push(ssrRenderComponent(_component_VeeForm, mergeProps({
        onSubmit,
        "validation-schema": unref(otpSchema)
      }, _attrs), {
        default: withCtx(({ errors }, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 w-[450px] text-left gap-4 p-4 rounded-md shadow"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormGroup, {
              label: "OTP",
              name: "otp"
            }, {
              default: withCtx((_, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(`<div class="hidden"${_scopeId2}>`);
                  _push3(ssrRenderComponent(_component_VeeField, {
                    name: "otp",
                    modelValue: unref(stateForm).otp,
                    "onUpdate:modelValue": ($event) => unref(stateForm).otp = $event
                  }, null, _parent3, _scopeId2));
                  _push3(`</div>`);
                  _push3(ssrRenderComponent(_component_FormInputOTP, {
                    modelValue: unref(stateForm).otp,
                    "onUpdate:modelValue": ($event) => unref(stateForm).otp = $event,
                    "is-error": !!(errors == null ? void 0 : errors.otp)
                  }, null, _parent3, _scopeId2));
                  _push3(ssrRenderComponent(_component_VeeErrorMessage, {
                    name: "otp",
                    class: "form-error-message"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode("div", { class: "hidden" }, [
                      createVNode(_component_VeeField, {
                        name: "otp",
                        modelValue: unref(stateForm).otp,
                        "onUpdate:modelValue": ($event) => unref(stateForm).otp = $event
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    createVNode(_component_FormInputOTP, {
                      modelValue: unref(stateForm).otp,
                      "onUpdate:modelValue": ($event) => unref(stateForm).otp = $event,
                      "is-error": !!(errors == null ? void 0 : errors.otp)
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "is-error"]),
                    createVNode(_component_VeeErrorMessage, {
                      name: "otp",
                      class: "form-error-message"
                    })
                  ];
                }
              }),
              _: 2
            }, _parent2, _scopeId));
            if (unref(showPinEmailExpired)) {
              _push2(`<div${_scopeId}><p class="text-gray-400"${_scopeId}> If you did not receive an email <span class="link" role="button"${_scopeId}>click here</span></p></div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`<div${_scopeId}>`);
            if (unref(secondTime) > 0) {
              _push2(`<div class="text-gray-400 text-sm"${_scopeId}> We have sent an OTP to your email. Your OTP will expired in <span class="whitespace-nowrap"${_scopeId}>${ssrInterpolate(unref(secondTime))} seconds </span></div>`);
            } else {
              _push2(`<!---->`);
            }
            if (unref(showPinEmailExpired)) {
              _push2(`<div class="text-error text-sm"${_scopeId}> Your OTP has expired. Please request a new one </div>`);
            } else {
              _push2(`<!---->`);
            }
            _push2(`</div><div${_scopeId}><button type="submit"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""} class="btn btn-success"${_scopeId}> Submit </button></div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 w-[450px] text-left gap-4 p-4 rounded-md shadow" }, [
                createVNode(_component_FormGroup, {
                  label: "OTP",
                  name: "otp"
                }, {
                  default: withCtx(() => [
                    createVNode("div", { class: "hidden" }, [
                      createVNode(_component_VeeField, {
                        name: "otp",
                        modelValue: unref(stateForm).otp,
                        "onUpdate:modelValue": ($event) => unref(stateForm).otp = $event
                      }, null, 8, ["modelValue", "onUpdate:modelValue"])
                    ]),
                    createVNode(_component_FormInputOTP, {
                      modelValue: unref(stateForm).otp,
                      "onUpdate:modelValue": ($event) => unref(stateForm).otp = $event,
                      "is-error": !!(errors == null ? void 0 : errors.otp)
                    }, null, 8, ["modelValue", "onUpdate:modelValue", "is-error"]),
                    createVNode(_component_VeeErrorMessage, {
                      name: "otp",
                      class: "form-error-message"
                    })
                  ]),
                  _: 2
                }, 1024),
                unref(showPinEmailExpired) ? (openBlock(), createBlock("div", { key: 0 }, [
                  createVNode("p", { class: "text-gray-400" }, [
                    createTextVNode(" If you did not receive an email "),
                    createVNode("span", {
                      class: "link",
                      onClick: resentEmail,
                      role: "button"
                    }, "click here")
                  ])
                ])) : createCommentVNode("", true),
                createVNode("div", null, [
                  unref(secondTime) > 0 ? (openBlock(), createBlock("div", {
                    key: 0,
                    class: "text-gray-400 text-sm"
                  }, [
                    createTextVNode(" We have sent an OTP to your email. Your OTP will expired in "),
                    createVNode("span", { class: "whitespace-nowrap" }, toDisplayString(unref(secondTime)) + " seconds ", 1)
                  ])) : createCommentVNode("", true),
                  unref(showPinEmailExpired) ? (openBlock(), createBlock("div", {
                    key: 1,
                    class: "text-error text-sm"
                  }, " Your OTP has expired. Please request a new one ")) : createCommentVNode("", true)
                ]),
                createVNode("div", null, [
                  createVNode("button", {
                    type: "submit",
                    disabled: unref(loading),
                    class: "btn btn-success"
                  }, " Submit ", 8, ["disabled"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ForgotPassword/VerifiedOTP.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "Change",
  __ssrInlineRender: true,
  props: {
    email: String,
    otp: String
  },
  emits: ["next"],
  setup(__props, { emit }) {
    const props = __props;
    const { stateForm } = useForgotPassword();
    const { loading, message, alertType } = useRequestHelper();
    const { resetPasswordSchema } = useSchema();
    const { requestOptions } = useRequestOptions();
    const resetPassword = computed(() => {
      return {
        email: props.email,
        pin: props.otp,
        password: stateForm.value.password,
        confirm_password: stateForm.value.password_confirmation
      };
    });
    async function onSubmit() {
      loading.value = true;
      await useFetch("/admins/forget-password/reset-password", {
        headers: {
          accept: "application/json"
        },
        method: "POST",
        body: JSON.stringify(resetPassword.value),
        ...requestOptions
      }, "$bLOsZUM853");
      emit("next");
      loading.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VeeForm = Form;
      const _component_FormGroup = _sfc_main$5;
      const _component_FormTextField = _sfc_main$6;
      _push(ssrRenderComponent(_component_VeeForm, mergeProps({
        onSubmit,
        "validation-schema": unref(resetPasswordSchema)
      }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid grid-cols-1 w-[450px] text-left gap-4 p-4 rounded-md shadow"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_FormGroup, {
              label: "Passowrd",
              name: "password"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_FormTextField, {
                    modelValue: unref(stateForm).password,
                    "onUpdate:modelValue": ($event) => unref(stateForm).password = $event,
                    name: "password",
                    placeholder: "*******",
                    type: "password",
                    class: "input input-bordered"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_FormTextField, {
                      modelValue: unref(stateForm).password,
                      "onUpdate:modelValue": ($event) => unref(stateForm).password = $event,
                      name: "password",
                      placeholder: "*******",
                      type: "password",
                      class: "input input-bordered"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(ssrRenderComponent(_component_FormGroup, {
              label: "Confirm Passowrd",
              name: "confirm_password"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(ssrRenderComponent(_component_FormTextField, {
                    modelValue: unref(stateForm).password_confirmation,
                    "onUpdate:modelValue": ($event) => unref(stateForm).password_confirmation = $event,
                    name: "confirm_password",
                    type: "password",
                    placeholder: "*******",
                    class: "input input-bordered"
                  }, null, _parent3, _scopeId2));
                } else {
                  return [
                    createVNode(_component_FormTextField, {
                      modelValue: unref(stateForm).password_confirmation,
                      "onUpdate:modelValue": ($event) => unref(stateForm).password_confirmation = $event,
                      name: "confirm_password",
                      type: "password",
                      placeholder: "*******",
                      class: "input input-bordered"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`<div${_scopeId}><p class="text-gray-400"${_scopeId}>We will send a code to your email</p></div><div${_scopeId}><button type="submit"${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""} class="btn btn-success"${_scopeId}> Submit </button></div></div>`);
          } else {
            return [
              createVNode("div", { class: "grid grid-cols-1 w-[450px] text-left gap-4 p-4 rounded-md shadow" }, [
                createVNode(_component_FormGroup, {
                  label: "Passowrd",
                  name: "password"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_FormTextField, {
                      modelValue: unref(stateForm).password,
                      "onUpdate:modelValue": ($event) => unref(stateForm).password = $event,
                      name: "password",
                      placeholder: "*******",
                      type: "password",
                      class: "input input-bordered"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode(_component_FormGroup, {
                  label: "Confirm Passowrd",
                  name: "confirm_password"
                }, {
                  default: withCtx(() => [
                    createVNode(_component_FormTextField, {
                      modelValue: unref(stateForm).password_confirmation,
                      "onUpdate:modelValue": ($event) => unref(stateForm).password_confirmation = $event,
                      name: "confirm_password",
                      type: "password",
                      placeholder: "*******",
                      class: "input input-bordered"
                    }, null, 8, ["modelValue", "onUpdate:modelValue"])
                  ]),
                  _: 1
                }),
                createVNode("div", null, [
                  createVNode("p", { class: "text-gray-400" }, "We will send a code to your email")
                ]),
                createVNode("div", null, [
                  createVNode("button", {
                    type: "submit",
                    disabled: unref(loading),
                    class: "btn btn-success"
                  }, " Submit ", 8, ["disabled"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
});
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/ForgotPassword/Change.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "forgot-password",
  __ssrInlineRender: true,
  setup(__props) {
    const router = useRouter();
    const stepper = useStepper({
      "forgot-password": {
        title: "Forgot Password",
        isValid: () => true
      },
      otp: {
        title: "Verification OTP",
        isValid: () => true
      },
      "change-password": {
        title: "Change Password",
        isValid: () => true
      }
    });
    const { stateForm } = useForgotPassword();
    const titleHeader = computed(() => {
      var _a2;
      var _a, _b;
      return (_a2 = (_b = (_a = stepper.current) == null ? void 0 : _a.value) == null ? void 0 : _b.title) != null ? _a2 : "Forgot Password";
    });
    function goToHome() {
      router.push("/admin");
    }
    useHead({
      title: titleHeader.value
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ForgotPassword = _sfc_main$4;
      const _component_ForgotPasswordVerifiedOTP = _sfc_main$2;
      const _component_ForgotPasswordChange = _sfc_main$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "hero min-h-screen" }, _attrs))}><div class="hero-content text-center"><div class="max-w-md"><h1 class="text-4xl font-bold mb-6">${ssrInterpolate(unref(stepper).current.value.title)}</h1>`);
      if (unref(stepper).isCurrent("forgot-password")) {
        _push(ssrRenderComponent(_component_ForgotPassword, {
          email: unref(stateForm).email,
          "onUpdate:email": ($event) => unref(stateForm).email = $event,
          onNext: () => unref(stepper).goTo("otp")
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(stepper).isCurrent("otp")) {
        _push(ssrRenderComponent(_component_ForgotPasswordVerifiedOTP, {
          otp: unref(stateForm).otp,
          "onUpdate:otp": ($event) => unref(stateForm).otp = $event,
          email: unref(stateForm).email,
          onNext: () => unref(stepper).goTo("change-password")
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      if (unref(stepper).isCurrent("change-password")) {
        _push(ssrRenderComponent(_component_ForgotPasswordChange, {
          email: unref(stateForm).email,
          otp: unref(stateForm).otp,
          onNext: goToHome
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/forgot-password.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=forgot-password-202d046c.mjs.map
