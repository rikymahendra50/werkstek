const i18n_config = () => ({
  legacy: false,
  locale: "en",
  messages: {
    en: {
      welcome: "Welcome"
    },
    id: {
      welcome: "Selamat Datang"
    }
  }
});

export { i18n_config as default };
//# sourceMappingURL=i18n.config-9bd4920e.mjs.map
