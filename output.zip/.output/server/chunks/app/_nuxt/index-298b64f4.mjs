import { _ as __nuxt_component_0 } from './HeaderWCity-239feb2c.mjs';
import { _ as __nuxt_component_7 } from './Blog-376275f4.mjs';
import { _ as __nuxt_component_0$1 } from './BlogItem-1242a3e6.mjs';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { useSSRContext, ref, withAsyncContext, watch, computed, resolveComponent, mergeProps, unref, withCtx, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString } from 'vue';
import { d as useHead, j as useAsyncData, i as _export_sfc } from '../server.mjs';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderList, ssrRenderClass, ssrInterpolate } from 'vue/server-renderer';
import { _ as __nuxt_component_4 } from './BgBigGreen-554b8e3d.mjs';
import './TitleHeader-ee000471.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './EachBlogSmall-c7af16bb.mjs';
import './client-only-29ef7f45.mjs';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'vee-validate';
import './useRequestHelper-553b0504.mjs';
import './arrow-small-right-9e640e2c.mjs';

const _sfc_main$1 = {
  __name: "Blog2",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { requestOptions } = useRequestOptions();
    const page = ref(1);
    const { data, error, refresh } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "articles",
      () => $fetch(`/articles?page=${page.value}`, {
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    watch(
      () => page.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          start();
        }
      }
    );
    const categoryData = computed(() => {
      var _a, _b;
      const categories = (_b = (_a = data == null ? void 0 : data.value) == null ? void 0 : _a.data) == null ? void 0 : _b.map((item) => item == null ? void 0 : item.category);
      const uniqueCategories = [...new Set(categories.map((cat) => cat == null ? void 0 : cat.id))].map(
        (id) => categories.find((cat) => (cat == null ? void 0 : cat.id) === id)
      );
      return [{ id: null, name: "Alle" }, ...uniqueCategories];
    });
    const selectedCategory = ref(null);
    ref(true);
    const handleCategoryClick = (categorySlug) => {
      selectedCategory.value = categorySlug === "Alle" ? null : categorySlug;
    };
    const filteredData = computed(() => {
      var _a, _b, _c;
      if (!selectedCategory.value) {
        return (_a = data == null ? void 0 : data.value) == null ? void 0 : _a.data;
      } else {
        return (_c = (_b = data == null ? void 0 : data.value) == null ? void 0 : _b.data) == null ? void 0 : _c.filter(
          (item) => {
            var _a2;
            return ((_a2 = item == null ? void 0 : item.category) == null ? void 0 : _a2.slug) === selectedCategory.value;
          }
        );
      }
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      const _component_VMenu = resolveComponent("VMenu");
      const _component_BlogItem = __nuxt_component_0$1;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "container-custom" }, _attrs))} data-v-b66094e9><div class="overflow-x-auto hidden md:flex gap-4 lg:gap-6 text-[12px] sm:text-[14px] md:text-[16px] text-[#121416] border-b-2 mt-6 justify-between overflow-auto" data-v-b66094e9><!--[-->`);
      ssrRenderList((_a = unref(categoryData)) == null ? void 0 : _a.slice(0, 4), (category, index) => {
        _push(`<button class="${ssrRenderClass([{ active: unref(selectedCategory) === (category == null ? void 0 : category.slug) }, "categorylink"])}" data-v-b66094e9>${ssrInterpolate(category == null ? void 0 : category.name)}</button>`);
      });
      _push(`<!--]-->`);
      if (unref(categoryData).length > 4) {
        _push(ssrRenderComponent(_component_VMenu, null, {
          popper: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a2, _b2;
            if (_push2) {
              _push2(`<div class="grid gap-2" data-v-b66094e9${_scopeId}><!--[-->`);
              ssrRenderList((_a2 = unref(categoryData)) == null ? void 0 : _a2.slice(4), (category, index) => {
                _push2(`<button class="${ssrRenderClass([{ active: unref(selectedCategory) === category.slug }, "hover:bg-primary p-2 text-[14px] hover:text-white"])}" data-v-b66094e9${_scopeId}>${ssrInterpolate(category.name)}</button>`);
              });
              _push2(`<!--]--></div>`);
            } else {
              return [
                createVNode("div", { class: "grid gap-2" }, [
                  (openBlock(true), createBlock(Fragment, null, renderList((_b2 = unref(categoryData)) == null ? void 0 : _b2.slice(4), (category, index) => {
                    return openBlock(), createBlock("button", {
                      class: ["hover:bg-primary p-2 text-[14px] hover:text-white", { active: unref(selectedCategory) === category.slug }],
                      key: category.id,
                      onClick: ($event) => handleCategoryClick(category.slug)
                    }, toDisplayString(category.name), 11, ["onClick"]);
                  }), 128))
                ])
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<button class="btn btn-ghost hover:bg-primary" data-v-b66094e9${_scopeId}><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" data-v-b66094e9${_scopeId}><path fill="none" stroke="black" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M3 6h18M3 12h18M3 18h18" data-v-b66094e9${_scopeId}></path></svg></button>`);
            } else {
              return [
                createVNode("button", { class: "btn btn-ghost hover:bg-primary" }, [
                  (openBlock(), createBlock("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "1em",
                    height: "1em",
                    viewBox: "0 0 24 24"
                  }, [
                    createVNode("path", {
                      fill: "none",
                      stroke: "black",
                      "stroke-linecap": "round",
                      "stroke-linejoin": "round",
                      "stroke-width": "2.5",
                      d: "M3 6h18M3 12h18M3 18h18"
                    })
                  ]))
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="overflow-x-auto flex md:hidden gap-4 lg:gap-6 text-[12px] sm:text-[14px] md:text-[16px] text-[#121416] border-b-2 mt-6 justify-between overflow-auto" data-v-b66094e9><!--[-->`);
      ssrRenderList((_b = unref(categoryData)) == null ? void 0 : _b.slice(0, 3), (category, index) => {
        _push(`<button class="${ssrRenderClass([{ active: unref(selectedCategory) === (category == null ? void 0 : category.slug) }, "categorylink"])}" data-v-b66094e9>${ssrInterpolate(category == null ? void 0 : category.name)}</button>`);
      });
      _push(`<!--]-->`);
      if (unref(categoryData).length > 3) {
        _push(ssrRenderComponent(_component_VMenu, null, {
          popper: withCtx((_, _push2, _parent2, _scopeId) => {
            var _a2, _b2;
            if (_push2) {
              _push2(`<div class="grid gap-2" data-v-b66094e9${_scopeId}><!--[-->`);
              ssrRenderList((_a2 = unref(categoryData)) == null ? void 0 : _a2.slice(3), (category, index) => {
                _push2(`<button class="${ssrRenderClass([{ active: unref(selectedCategory) === category.slug }, "hover:bg-primary p-2 text-[14px] hover:text-white"])}" data-v-b66094e9${_scopeId}>${ssrInterpolate(category.name)}</button>`);
              });
              _push2(`<!--]--></div>`);
            } else {
              return [
                createVNode("div", { class: "grid gap-2" }, [
                  (openBlock(true), createBlock(Fragment, null, renderList((_b2 = unref(categoryData)) == null ? void 0 : _b2.slice(3), (category, index) => {
                    return openBlock(), createBlock("button", {
                      class: ["hover:bg-primary p-2 text-[14px] hover:text-white", { active: unref(selectedCategory) === category.slug }],
                      key: category.id,
                      onClick: ($event) => handleCategoryClick(category.slug)
                    }, toDisplayString(category.name), 11, ["onClick"]);
                  }), 128))
                ])
              ];
            }
          }),
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`<button class="btn btn-ghost hover:bg-primary" data-v-b66094e9${_scopeId}><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24" data-v-b66094e9${_scopeId}><path fill="none" stroke="black" stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M3 6h18M3 12h18M3 18h18" data-v-b66094e9${_scopeId}></path></svg></button>`);
            } else {
              return [
                createVNode("button", { class: "btn btn-ghost hover:bg-primary" }, [
                  (openBlock(), createBlock("svg", {
                    xmlns: "http://www.w3.org/2000/svg",
                    width: "1em",
                    height: "1em",
                    viewBox: "0 0 24 24"
                  }, [
                    createVNode("path", {
                      fill: "none",
                      stroke: "black",
                      "stroke-linecap": "round",
                      "stroke-linejoin": "round",
                      "stroke-width": "2.5",
                      d: "M3 6h18M3 12h18M3 18h18"
                    })
                  ]))
                ])
              ];
            }
          }),
          _: 1
        }, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="grid min-[320px]:grid-cols-1 min-[420px]:grid-cols-2 lg:grid-cols-3 gap-3 mt-10" data-v-b66094e9><!--[-->`);
      ssrRenderList(unref(filteredData), (item) => {
        _push(ssrRenderComponent(_component_BlogItem, {
          link: `/blog/${item.slug}`,
          image: item == null ? void 0 : item.image,
          title: item == null ? void 0 : item.title,
          description: item == null ? void 0 : item.meta,
          key: item.id
        }, null, _parent));
      });
      _push(`<!--]--></div></section>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Blog2.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-b66094e9"]]);
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Blog"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderWCity = __nuxt_component_0;
      const _component_Blog = __nuxt_component_7;
      const _component_Blog2 = __nuxt_component_2;
      const _component_BgBigGreen = __nuxt_component_4;
      _push(`<!--[--><div class="mt-20"></div>`);
      _push(ssrRenderComponent(_component_HeaderWCity, {
        title1: "Bekijk onze locaties",
        title2: "Lees de Werkstek </br> blogs & updates",
        description: "Lees hier onze interessante blogs"
      }, null, _parent));
      _push(`<div class="container-custom grid gap-3 pt-8"><p class="text-[25px] sm:text-[30px] md:text-[40px] text-[#000000] font-medium"> Lees onze laatste blog\u2019s </p></div>`);
      _push(ssrRenderComponent(_component_Blog, { class: "my-10" }, null, _parent));
      _push(ssrRenderComponent(_component_Blog2, { ShowTitleCategory: true }, null, _parent));
      _push(ssrRenderComponent(_component_BgBigGreen, {
        title1: "Blijf op de hoogte",
        title2: "Schrijf je in voor de nieuwsbrief",
        title3: "Op de hoogte blijven van beschikbare werkplekken? Schrijf je dan nu vrijblijvend in!",
        showButtonSection: true,
        backgroundColor: "secondary"
      }, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/blog/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-298b64f4.mjs.map
