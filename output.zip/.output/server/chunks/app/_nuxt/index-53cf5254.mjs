import { useSSRContext, defineComponent, ref, mergeProps } from 'vue';
import { h as _export_sfc, d as useHead, u as useRequestOptions } from '../server.mjs';
import { ssrRenderAttrs } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    ref(true);
    useHead({
      title: "Admin Home"
    });
    useRequestOptions();
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<table${ssrRenderAttrs(mergeProps({ class: "tableAdmin" }, _attrs))} data-v-78fcc35c><caption data-v-78fcc35c> Your Profile </caption><thead data-v-78fcc35c><tr class="text-sm" data-v-78fcc35c><th scope="col" data-v-78fcc35c>Name</th><th scope="col" data-v-78fcc35c>Position</th><th scope="col" data-v-78fcc35c>Email</th><th scope="col" data-v-78fcc35c>Active</th></tr></thead></table>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-78fcc35c"]]);

export { index as default };
//# sourceMappingURL=index-53cf5254.mjs.map
