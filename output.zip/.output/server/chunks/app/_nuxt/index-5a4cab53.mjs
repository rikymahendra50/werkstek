import { _ as __nuxt_component_0 } from './HeaderWCity-239feb2c.mjs';
import { _ as __nuxt_component_0$1 } from './TitleHeader-ee000471.mjs';
import { _ as __nuxt_component_1$1, a as __nuxt_component_2$1 } from './EachBlogSmall-c7af16bb.mjs';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { useSSRContext, withAsyncContext, mergeProps, unref } from 'vue';
import { d as useHead, b as useFetch, i as _export_sfc } from '../server.mjs';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderList } from 'vue/server-renderer';
import { _ as __nuxt_component_0$2 } from './BlogItem-1242a3e6.mjs';
import { _ as __nuxt_component_3 } from './LeegstandNoButton-70f79216.mjs';
import { _ as __nuxt_component_4 } from './BgBigGreen-554b8e3d.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './client-only-29ef7f45.mjs';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'vee-validate';
import './useRequestHelper-553b0504.mjs';
import './arrow-small-right-9e640e2c.mjs';

const _sfc_main$2 = {
  __name: "Community",
  __ssrInlineRender: true,
  props: {
    dontShowTitle: Boolean,
    showTitleHeader: Boolean
  },
  async setup(__props) {
    let __temp, __restore;
    const { requestOptions } = useRequestOptions();
    [__temp, __restore] = withAsyncContext(() => useFetch(`/community-blogs`, {
      method: "get",
      ...requestOptions
    }, "$SUENHaXh7J")), __temp = await __temp, __restore();
    const { data: top } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/top-community-blog`, {
      method: "get",
      ...requestOptions
    }, "$uAUGb2uTrz")), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b;
      const _component_TitleHeader = __nuxt_component_0$1;
      const _component_EachBlogBig = __nuxt_component_1$1;
      const _component_EachBlogSmall = __nuxt_component_2$1;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "mx-5 lg:container-custom py-10" }, _attrs))}>`);
      if (__props.dontShowTitle) {
        _push(`<div>`);
        if (!__props.showTitleHeader) {
          _push(`<div><div class="pl-3 pb-5 md:pb-10 sm:w-[70%]"><h1 class="text-[20px] sm:text-[26px] md:text-[32px] font-bold"> Lees onze laatste blog\u2019s </h1></div></div>`);
        } else if (__props.showTitleHeader) {
          _push(ssrRenderComponent(_component_TitleHeader, {
            title: `Updates & blogs`,
            secondTitle: `Lees de Werkstek community`,
            description: `Op de hoogte blijven van de nieuwste kantoortrends? Op zoek naar tips en tricks voor ondernemers? Lees dan ook onze inspirerende blogs!`
          }, null, _parent));
        } else {
          _push(`<!---->`);
        }
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<div class="flex w-full gap-2"><div class="flex flex-col min-[320px]:flex-row w-full lg:w-[60%] justify-center"><!--[-->`);
      ssrRenderList((_a = unref(top)) == null ? void 0 : _a.data.slice(0, 2), (article) => {
        _push(ssrRenderComponent(_component_EachBlogBig, {
          key: article.id,
          imageSrc: article.image,
          title: article.title,
          description: article.meta,
          link: `/werkstek-community/${article.slug}`
        }, null, _parent));
      });
      _push(`<!--]--></div><div class="flex-col justify-between lg:flex hidden lg:w-[40%]"><!--[-->`);
      ssrRenderList((_b = unref(top)) == null ? void 0 : _b.data.slice(2, 5), (article) => {
        _push(ssrRenderComponent(_component_EachBlogSmall, {
          key: article.id,
          imageSrc: article.image,
          title: article.title,
          description: article.meta,
          link: `/werkstek-community/${article.slug}`
        }, null, _parent));
      });
      _push(`<!--]--></div></div></section>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Community.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "Community2",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { requestOptions } = useRequestOptions();
    const { data, refresh } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/community-blogs`, {
      method: "get",
      ...requestOptions
    }, "$BONY9kY7he")), __temp = await __temp, __restore(), __temp);
    return (_ctx, _push, _parent, _attrs) => {
      const _component_BlogItem = __nuxt_component_0$2;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "container-custom" }, _attrs))} data-v-ca445f1b><div class="grid min-[320px]:grid-cols-2 lg:grid-cols-3 gap-3 mt-10" data-v-ca445f1b><!--[-->`);
      ssrRenderList(unref(data).data, (item) => {
        _push(ssrRenderComponent(_component_BlogItem, {
          link: `/werkstek-community/${item.slug}`,
          image: item.image,
          title: item.title,
          description: item.meta,
          key: item.id
        }, null, _parent));
      });
      _push(`<!--]--></div></section>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Community2.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-ca445f1b"]]);
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Werkstek Community"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderWCity = __nuxt_component_0;
      const _component_Community = __nuxt_component_1;
      const _component_Community2 = __nuxt_component_2;
      const _component_LeegstandNoButton = __nuxt_component_3;
      const _component_BgBigGreen = __nuxt_component_4;
      _push(`<!--[--><div class="mt-28"></div>`);
      _push(ssrRenderComponent(_component_HeaderWCity, {
        title1: "Onze community",
        title2: "De Werkstek community",
        description: "Ontmoet je graag ondernemers uit verschillende branches die in hetzelfde kantoorgebouw werken? Dan zit je bij Werkstek goed. Wij hebben een gezellige community van enthousiaste ondernemers die elkaar gemakkelijk weten te vinden."
      }, null, _parent));
      _push(ssrRenderComponent(_component_Community, {
        showButton: false,
        dontShowTitle: false,
        class: "my-10"
      }, null, _parent));
      _push(ssrRenderComponent(_component_Community2, null, null, _parent));
      _push(ssrRenderComponent(_component_LeegstandNoButton, {
        uniqueIdProp: 10,
        image: "/images/union-community.png",
        imgAlt: "image-page4-2",
        title: "Leegstand vullen",
        description: "Wil je je kennis en ervaring delen met onze ambitieuze ondernemers? Vind je het leuk om plannen en idee\xEBn uit te wisselen met anderen? Wil je jouw visie op werken en ondernemen onder de aandacht brengen?",
        description2: "Werkstek zorgt hiervoor door bijvoorbeeld regelmatig leuke evenementen in een ontspannen sfeer te organiseren waarin iedereen kan netwerken. Onze gezellige community cre\xEBert daarmee mogelijkheden voor creatieve en succesvolle samenwerkingen. Daarmee helpen we elkaar verder met het behalen van onze doelen.",
        titledescription2: "Bij Werkstek ontmoet je elkaar dagelijks op de werkvloer of in de gemeenschappelijke ruimtes."
      }, null, _parent));
      _push(ssrRenderComponent(_component_BgBigGreen, {
        title1: "Aanmelden",
        title2: "Je bedrijf in de spotlights?",
        title3: "Wil je een werkplek of kantoorunit huren? Dan kun je je natuurlijk meteen inschrijven. Je kunt ook gebruik maken van ons stappenplan, zodat er een juiste match is tussen jou en je toekomstige werkplek in het kantoorgebouw van jouw keuze.",
        showButtonSection: true,
        showEmailSection: false,
        linkTitle: "Verstuur je video",
        showPhoneEmail: false,
        backgroundColor: "secondary"
      }, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/werkstek-community/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-5a4cab53.mjs.map
