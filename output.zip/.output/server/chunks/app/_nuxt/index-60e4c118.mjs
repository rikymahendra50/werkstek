import { _ as __nuxt_component_0 } from './ButtonAddIndex-0be538de.mjs';
import { i as _export_sfc, u as useRouter, a as useRoute, j as useAsyncData, d as useHead, _ as __nuxt_component_0$1 } from '../server.mjs';
import __nuxt_component_2 from './Icon-7d2a1472.mjs';
import { _ as __nuxt_component_3 } from './Pagination-d765680b.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { ref, withAsyncContext, watch, unref, withCtx, createVNode, isRef, useSSRContext } from 'vue';
import { ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import { u as useTimeoutFn } from './index-73677d9a.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './config-54e8ad1b.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    useSnackbar();
    const router = useRouter();
    useRoute();
    const page = ref(1);
    const search = ref("");
    const {
      data: job,
      error,
      refresh
    } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "job",
      () => $fetch(`/admins/jobs`, {
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    const { start, stop } = useTimeoutFn(() => {
      replaceWindow();
    }, 1e3);
    watch(
      () => page.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          start();
        }
      }
    );
    watch(
      () => search.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          page.value = 1;
          start();
        }
      }
    );
    function replaceWindow() {
      router.replace(`/admin/vacatures?page=${page.value}&search=${search.value}`);
      refresh();
    }
    useHead({
      title: "Admin Vacatures"
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      const _component_CompAdminButtonAddIndex = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_icon = __nuxt_component_2;
      const _component_Pagination = __nuxt_component_3;
      _push(`<!--[--><main class="flex-grow overflow-y-auto" data-v-cddceffa><div class="mx-auto px-2 sm:px-4 lg:px-6 max-w-sm md:max-w-3xl lg:max-w-[720px] xl:max-w-5xl py-8 space-y-8" data-v-cddceffa><div class="flex justify-between items-center" data-v-cddceffa><div data-v-cddceffa><div class="text-lg md:text-2xl font-bold" data-v-cddceffa>Vacatures</div></div>`);
      _push(ssrRenderComponent(_component_CompAdminButtonAddIndex, {
        name: "Vacatures",
        link: "onze-vacatures"
      }, null, _parent));
      _push(`</div><div data-v-cddceffa><div class="overflow-x-auto !py-2 border rounded-t-lg" data-v-cddceffa><table class="table table-xs md:table-md w-full rounded-t-xl" data-v-cddceffa><thead class="h-12" data-v-cddceffa><tr data-v-cddceffa><th class="font-medium" data-v-cddceffa>Name</th><th class="font-medium" data-v-cddceffa>Image</th><th class="font-medium" data-v-cddceffa></th></tr></thead><tbody data-v-cddceffa><!--[-->`);
      ssrRenderList((_a = unref(job)) == null ? void 0 : _a.data, (item, index2) => {
        _push(`<tr class="odd:bg-gray-100 even:hover:bg-gray-100 transition-colors duration-300" data-v-cddceffa><td class="max-w-[80px]" data-v-cddceffa><div class="max-w-[80px] max-h-[80px] overflow-hidden" data-v-cddceffa><img${ssrRenderAttr("src", item.image)}${ssrRenderAttr("alt", `item` + index2)} class="object-cover rounded-md" data-v-cddceffa></div></td><td class="text-gray-500 text-[12px] font-normal !py-2 md:text-sm" data-v-cddceffa>${ssrInterpolate(item.title)}</td><td data-v-cddceffa><div class="flex items-center justify-center gap-4" data-v-cddceffa>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/onze-vacatures/${item.slug}`,
          class: "btn btn-sm normal-case btn-ghost btn-square",
          target: "_blank"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_icon, {
                name: "i-heroicons-eye",
                class: "cursor-pointer"
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_icon, {
                  name: "i-heroicons-eye",
                  class: "cursor-pointer"
                })
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/admin/onze-vacatures/edit/${item.slug}`,
          class: "btn btn-sm normal-case btn-ghost btn-square"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_icon, {
                name: "i-heroicons-pencil-square",
                class: "cursor-pointer"
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_icon, {
                  name: "i-heroicons-pencil-square",
                  class: "cursor-pointer"
                })
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="cursor-pointer btn btn-sm normal-case btn-ghost btn-square" data-v-cddceffa>`);
        _push(ssrRenderComponent(_component_icon, { name: "i-heroicons-trash" }, null, _parent));
        _push(`</div><dialog${ssrRenderAttr("id", "my_modal_" + index2)} class="modal" data-v-cddceffa><div class="modal-box" data-v-cddceffa><h3 class="font-bold text-lg text-red-500" data-v-cddceffa> Warning ! </h3><p class="py-4 text-sm" data-v-cddceffa> Are you sure want to delete this item called ${ssrInterpolate(item.title)}? </p><div class="modal-action" data-v-cddceffa><form method="dialog" data-v-cddceffa><button class="btn btn-outline btn-error mr-3 text-[12px]" data-v-cddceffa> Delete </button><button class="btn" data-v-cddceffa>Close</button></form></div></div></dialog></div></td></tr>`);
      });
      _push(`<!--]--></tbody></table></div></div></div></main>`);
      _push(ssrRenderComponent(_component_Pagination, {
        modelValue: unref(page),
        "onUpdate:modelValue": ($event) => isRef(page) ? page.value = $event : null,
        total: (_c = (_b = unref(job)) == null ? void 0 : _b.meta) == null ? void 0 : _c.total,
        "per-page": (_e = (_d = unref(job)) == null ? void 0 : _d.meta) == null ? void 0 : _e.per_page,
        class: "flex justify-center"
      }, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/onze-vacatures/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-cddceffa"]]);

export { index as default };
//# sourceMappingURL=index-60e4c118.mjs.map
