import { _ as __nuxt_component_0 } from './ButtonAddIndex-0be538de.mjs';
import { h as _export_sfc, u as useRequestOptions, d as useHead, _ as __nuxt_component_0$1 } from '../server.mjs';
import __nuxt_component_2 from './Icon-e394d28f.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { withAsyncContext, mergeProps, unref, withCtx, createVNode, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-101122a4.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './config-aab100d3.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import './asyncData-04c89180.mjs';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const { data: Category, error } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/category-list`, {
      method: "get",
      ...requestOptions
    }, "$X24ISyUjzF")), __temp = await __temp, __restore(), __temp);
    useHead({
      title: "Category"
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a;
      const _component_CompAdminButtonAddIndex = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_icon = __nuxt_component_2;
      _push(`<main${ssrRenderAttrs(mergeProps({ class: "flex-grow overflow-y-auto max-h-[500px]" }, _attrs))} data-v-1d73d932><div class="mx-auto px-2 sm:px-6 lg:px-8 max-w-sm md:max-w-3xl lg:max-w-[720px] xl:max-w-7xl py-8 space-y-8" data-v-1d73d932><div class="flex justify-between items-center" data-v-1d73d932><div data-v-1d73d932><div class="text-xl md:text-2xl font-bold" data-v-1d73d932>Category</div></div>`);
      _push(ssrRenderComponent(_component_CompAdminButtonAddIndex, {
        name: "Category",
        link: "category"
      }, null, _parent));
      _push(`</div><div data-v-1d73d932><div class="overflow-x-auto !py-2 border rounded-t-lg" data-v-1d73d932><table class="table table-xs md:table-md w-full rounded-t-xl" data-v-1d73d932><thead class="h-12" data-v-1d73d932><tr data-v-1d73d932><th class="font-medium" data-v-1d73d932>Name</th><th class="font-medium" data-v-1d73d932>Short Description</th><th class="font-medium" data-v-1d73d932>Full Description</th><th class="font-medium" data-v-1d73d932></th></tr></thead><tbody data-v-1d73d932><!--[-->`);
      ssrRenderList((_a = unref(Category)) == null ? void 0 : _a.data, (item, index2) => {
        _push(`<tr class="odd:bg-gray-100 even:hover:bg-gray-100 transition-colors duration-300" data-v-1d73d932><td class="text-gray-500 text-sm font-normal !py-2" data-v-1d73d932>${ssrInterpolate(item.name)}</td><td class="text-gray-500 text-sm font-normal !py-2" data-v-1d73d932>${ssrInterpolate(item.short_description)}</td><td class="text-gray-500 text-sm font-normal !py-2" data-v-1d73d932>${ssrInterpolate(item.full_description)}</td><td class="flex justify-center gap-4 my-1" data-v-1d73d932>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/admin/category/edit/${item.slug}`,
          class: "cursor-pointer btn btn-sm normal-case btn-ghost btn-square"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_icon, { name: "i-heroicons-pencil-square" }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_icon, { name: "i-heroicons-pencil-square" })
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="cursor-pointer btn btn-sm normal-case btn-ghost btn-square" data-v-1d73d932>`);
        _push(ssrRenderComponent(_component_icon, { name: "i-heroicons-trash" }, null, _parent));
        _push(`</div><dialog${ssrRenderAttr("id", "my_modal_" + index2)} class="modal" data-v-1d73d932><div class="modal-box" data-v-1d73d932><h3 class="font-bold text-xl text-red-500" data-v-1d73d932>Warning !</h3><p class="py-4 text-lg" data-v-1d73d932> Are you sure want to delete this item called ${ssrInterpolate(item.name)}? </p><div class="modal-action" data-v-1d73d932><form method="dialog" data-v-1d73d932><button class="btn btn-outline btn-error mr-3" data-v-1d73d932> Delete </button><button class="btn" data-v-1d73d932>Close</button></form></div></div></dialog></td></tr>`);
      });
      _push(`<!--]--></tbody></table></div></div></div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/category/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-1d73d932"]]);

export { index as default };
//# sourceMappingURL=index-62abee32.mjs.map
