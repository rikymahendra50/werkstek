import { a as _imports_0, _ as __nuxt_component_0$1 } from './building-map-interactive-f174b598.mjs';
import { a as __nuxt_component_1, _ as __nuxt_component_4 } from './BgBigGreen-554b8e3d.mjs';
import __nuxt_component_2$1 from './Icon-7d2a1472.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { computed, ref, unref, useSSRContext, withAsyncContext, mergeProps, watch, withCtx, createVNode, toDisplayString } from 'vue';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { b as useFetch, d as useHead, i as _export_sfc, _ as __nuxt_component_0$1$1 } from '../server.mjs';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderClass, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import { u as useAxios } from './useAxios-029d07ba.mjs';
import { _ as __nuxt_component_1$1 } from './SliderLocatiesSort-9a6b5d39.mjs';
import { _ as __nuxt_component_6$1 } from './SliderTestimony-e6194ec8.mjs';
import { _ as _imports_0$1 } from './arrow-right-150377ce.mjs';
import { a as _imports_0$2 } from './TitleHeader-ee000471.mjs';
import { _ as __nuxt_component_7 } from './Blog-376275f4.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vee-validate';
import 'vue3-snackbar';
import './arrow-small-right-9e640e2c.mjs';
import './config-54e8ad1b.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'axios';
import './client-only-29ef7f45.mjs';
import 'swiper/vue';
import 'swiper/modules';
import './EachBlogSmall-c7af16bb.mjs';

const _sfc_main$4 = {
  __name: "StatistiekLocatiesVideo",
  __ssrInlineRender: true,
  props: {
    video: {
      type: String
    },
    image: {
      type: String
    },
    title1: {
      type: String,
      required: true
    },
    title2: {
      type: String,
      required: true
    },
    title3: {
      type: String,
      required: true
    },
    buttonTitle1: {
      type: String,
      required: false
    },
    buttonLink1: {
      type: String,
      required: false
    },
    buttonTitle2: {
      type: String,
      required: false
    },
    buttonLink2: {
      type: String,
      required: false
    },
    titleBg1: {
      type: String,
      required: true
    },
    titleBg2: {
      type: String,
      required: true
    },
    titleBg3: {
      type: String,
      required: true
    },
    count1: {
      type: Number,
      required: true
    },
    count2: {
      type: Number,
      required: true
    },
    count3: {
      type: Number,
      required: true
    },
    classcustom: {
      type: String,
      required: false
    },
    showButton: {
      type: Boolean,
      required: false,
      default: false
    }
  },
  emits: ["isPerformSearch", "isSearchCity"],
  async setup(__props, { emit }) {
    let __temp, __restore;
    useRequestHelper();
    const searchCity = ref();
    const { requestOptions } = useRequestOptions();
    [__temp, __restore] = withAsyncContext(() => useFetch(`/products`, {
      method: "get",
      ...requestOptions
    }, "$mywLvtK9e1")), __temp = await __temp, __restore();
    ref();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_ButtonPrimary = __nuxt_component_0$1;
      const _component_ButtonSM = __nuxt_component_1;
      const _component_Icon = __nuxt_component_2$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "mt-16 sm:mt-20 mb-16 sm:mb-20 relative" }, _attrs))} data-v-7419fb83><div class="formobile md:hidden" data-v-7419fb83><section class="${ssrRenderClass([__props.classcustom, "flex items-center"])}" data-v-7419fb83><div class="grid md:grid-rows-1 md:grid-cols-12 container-custom -z-10" data-v-7419fb83><div class="flex items-start mt-6 lg:mt-[35px] xl:mt-[45px] col-span-5" data-v-7419fb83><div class="grid gap-2" data-v-7419fb83><span class="text-[19px] font-semibold" data-v-7419fb83>${ssrInterpolate(__props.title1)}</span><span class="text-[30px] md:text-[35px] lg:text-[40px] font-bold" data-v-7419fb83>${ssrInterpolate(__props.title2)}</span><span class="text-[12px] md:text-sm mt-3 md:w-[87%] lg:w-[90%] lg:text-lg" data-v-7419fb83>${ssrInterpolate(__props.title3)}</span>`);
      if (__props.showButton) {
        _push(`<div class="flex mt-5 lg:mt-10 justify-end md:justify-around lg:justify-start gap-5 max-h-[46px] sm:max-h-[64px]" data-v-7419fb83>`);
        _push(ssrRenderComponent(_component_ButtonPrimary, {
          buttonTitle: __props.buttonTitle1,
          buttonLink: __props.buttonLink1
        }, null, _parent));
        _push(ssrRenderComponent(_component_ButtonSM, {
          buttonTitle: __props.buttonTitle2,
          buttonLink: __props.buttonLink2
        }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="grid relative mt-5 justify-items-end col-span-7" data-v-7419fb83><div class="w-[95%] min-[500px]:w-[70%] sm:w-[80%] lg:w-[100%] relative" data-v-7419fb83><div class="shape relative" data-v-7419fb83><div class="z-[999] absolute right-0 w-full" data-v-7419fb83><div class="test w-[50px] lg:w-[100px] lg:h-[100px] h-[50px]" data-v-7419fb83></div><div class="triangle" data-v-7419fb83></div><div class="triangle2 absolute top-0 ml-[50px] lg:ml-[100px]" data-v-7419fb83></div></div><video class="w-full h-full object-cover min-h-[300px] md:min-h-[400px] lg:min-h-[644px] rounded-3xl" autoplay loop muted data-v-7419fb83><source${ssrRenderAttr("src", __props.video)} type="video/mp4" data-v-7419fb83></video></div></div></div></div></section><div class="container-custom mt-[-100px] w-[100%]" data-v-7419fb83><div class="bg-white w-full rounded-[20px] py-4 sm:grid sm:grid-cols-12 shadow-md" data-v-7419fb83><div class="sm:col-span-4 flex justify-center items-center mb-2 sm:mb-0" data-v-7419fb83><img${ssrRenderAttr("src", _imports_0)} alt="building-icon" class="w-16 h-16" data-v-7419fb83><p class="text-secondary text-xl sm:text-2xl lg:text-3xl font-medium z-10 ml-[-20px]" data-v-7419fb83> Waar bent u <br data-v-7419fb83> naar op zoek? </p></div><div class="grid min-[370px]:grid-cols-12 sm:grid-cols-1 md:grid-cols-12 col-span-6 lg:col-span-6 items-center sm:px-0 lg:px-5 sm:gap-2 px-2" data-v-7419fb83><div class="w-full col-span-12 flex justify-center items-center" data-v-7419fb83><div class="w-full min-[500px]:w-[80%] flex flex-col gap-2 md:gap-3" data-v-7419fb83><p class="md:text-lg font-semibold text-sm" data-v-7419fb83>Locaties</p><input type="text" name="" id="" placeholder="Locaties" class="w-full italic text-[12px] sm:text-[14px] flex items-center justify-between bg-[rgb(247,247,247)] rounded-full px-2 pl-4 min-h-[40px] sm:min-h-[40px] mb-2 sm:mb-5 md:mb-0 text-[#676767] border-black border" data-v-7419fb83></div></div></div><div class="flex justify-end sm:justify-center sm:items-center md:justify-start lg:justify-center md:mb-5 min-[320px]:px-5 sm:px-0 col-span-2 mt-3" data-v-7419fb83><a href="#map" class="btn bg-primary text-white md:mt-5 hover:bg-primary w-[55px] h-[55px] sm:w-[65px] sm:h-[60px] lg:w-[76px] lg:h-[76px] rounded-[15px] sm:rounded-[20px] z-10" data-v-7419fb83>`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "iconamoon:search-thin",
        class: "text-white w-10 h-10"
      }, null, _parent));
      _push(`</a></div></div></div></div><div class="forpc hidden md:block" data-v-7419fb83><div class="container-custom md:absolute w-[100%] lg:w-[95%] sm:-bottom-4 xl:bottom-0 min-[1440px]:bottom-20" data-v-7419fb83><div class="bg-white w-full rounded-[20px] py-4 sm:grid sm:grid-cols-12 shadow-md" data-v-7419fb83><div class="sm:col-span-4 flex justify-center items-center mb-2 sm:mb-0" data-v-7419fb83><img${ssrRenderAttr("src", _imports_0)} alt="building-icon" class="w-16 h-16" data-v-7419fb83><p class="text-secondary text-xl sm:text-2xl lg:text-3xl font-medium z-10 ml-[-20px]" data-v-7419fb83> Waar bent u <br data-v-7419fb83> naar op zoek? </p></div><div class="grid min-[370px]:grid-cols-12 sm:grid-cols-1 md:grid-cols-12 col-span-6 lg:col-span-6 sm:px-0 lg:px-5 sm:gap-2 justify-center items-center" data-v-7419fb83><div class="w-full col-span-12 flex justify-center items-center" data-v-7419fb83><div class="w-[90%] flex flex-col gap-3" data-v-7419fb83><p class="text-lg font-semibold" data-v-7419fb83>Locaties</p><input type="text" name="" id="" placeholder="Locaties"${ssrRenderAttr("value", unref(searchCity))} class="w-full italic text-[12px] sm:text-[14px] flex items-center justify-between bg-[rgb(247,247,247)] rounded-full px-2 pl-4 min-h-[40px] sm:min-h-[50px] mb-2 sm:mb-5 md:mb-0 text-[#676767] border-black border" data-v-7419fb83></div></div></div><div class="flex justify-end sm:justify-center sm:items-center md:justify-start lg:justify-center md:mb-5 min-[320px]:px-5 sm:px-0 col-span-2" data-v-7419fb83><a href="#map" class="btn bg-primary text-white md:mt-5 hover:bg-primary w-[55px] h-[55px] sm:w-[65px] sm:h-[60px] lg:w-[76px] lg:h-[76px] rounded-[15px] sm:rounded-[20px] z-10" data-v-7419fb83>`);
      _push(ssrRenderComponent(_component_Icon, {
        name: "iconamoon:search-thin",
        class: "text-white w-10 h-10"
      }, null, _parent));
      _push(`</a></div></div></div><section class="${ssrRenderClass([__props.classcustom, "flex items-center"])}" data-v-7419fb83><div class="grid md:grid-rows-1 md:grid-cols-12 container-custom -z-10 min-[1500px]:gap-10 mt-2" data-v-7419fb83><div class="flex items-start mt-3 lg:mt-[35px] xl:mt-[38px] col-span-5" data-v-7419fb83><div class="grid gap-2" data-v-7419fb83><span class="text-[19px] font-semibold" data-v-7419fb83>${ssrInterpolate(__props.title1)}</span><span class="text-[30px] md:text-[35px] lg:text-[40px] font-bold" data-v-7419fb83>${ssrInterpolate(__props.title2)}</span><span class="text-[12px] md:text-sm mt-3 md:w-[87%] lg:w-[90%] lg:text-lg" data-v-7419fb83>${ssrInterpolate(__props.title3)}</span>`);
      if (__props.showButton) {
        _push(`<div class="flex mt-5 lg:mt-10 justify-end md:justify-around lg:justify-start gap-5 max-h-[46px] sm:max-h-[64px]" data-v-7419fb83>`);
        _push(ssrRenderComponent(_component_ButtonPrimary, {
          buttonTitle: __props.buttonTitle1,
          buttonLink: __props.buttonLink1
        }, null, _parent));
        _push(ssrRenderComponent(_component_ButtonSM, {
          buttonTitle: __props.buttonTitle2,
          buttonLink: __props.buttonLink2
        }, null, _parent));
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div><div class="grid relative mt-5 justify-items-end col-span-7" data-v-7419fb83><div class="w-[95%] min-[500px]:w-[70%] sm:w-[80%] lg:w-[100%] relative" data-v-7419fb83><div class="shape relative" data-v-7419fb83><div class="z-[999] absolute right-0 w-full" data-v-7419fb83><div class="test w-[50px] lg:w-[100px] lg:h-[100px] h-[50px] mt-[-1px]" data-v-7419fb83></div><div class="triangle" data-v-7419fb83></div><div class="triangle2 absolute top-[-1px] ml-[50px] lg:ml-[100px]" data-v-7419fb83></div></div><video class="w-full h-full object-cover min-h-[300px] md:min-h-[400px] lg:min-h-[482px] min-[1440px]:min-h-[582px] rounded-3xl" autoplay loop muted data-v-7419fb83><source${ssrRenderAttr("src", __props.video)} type="video/mp4" data-v-7419fb83></video></div></div></div></div></section></div></div>`);
    };
  }
};
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/StatistiekLocatiesVideo.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["__scopeId", "data-v-7419fb83"]]);
const _sfc_main$3 = {
  __name: "MapInteractive2",
  __ssrInlineRender: true,
  props: {
    ShowContainerCustom: {
      type: Boolean,
      default: true,
      required: false
    },
    searchCityT: {
      type: [String, Number],
      required: false
    },
    SubmitPerform: {
      type: Boolean,
      default: false
    },
    showSearch: {
      type: Boolean,
      default: true
    }
  },
  async setup(__props) {
    var _a;
    let __temp, __restore;
    const props = __props;
    const { axiosRequest } = useAxios();
    ref({ lat: 52.21314997541194, lng: 5.3982948103810795 });
    const { requestOptions } = useRequestOptions();
    const { data, error } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/products`, {
      method: "get",
      ...requestOptions
    }, "$t2GfvNfgAy")), __temp = await __temp, __restore(), __temp);
    const titleMap = ref("Waar bent u op zoek naar?");
    let map = ref(null);
    const markers = ref([]);
    const currentInfoWindow = ref(null);
    (_a = data == null ? void 0 : data.value) == null ? void 0 : _a.data;
    ref(props.searchCityT);
    const filteredData = ref();
    watch(
      () => props.SubmitPerform,
      (newValue, oldValue) => {
        performSearch();
      }
    );
    async function performSearch() {
      try {
        let params = {};
        params["filter[location]"] = props.searchCityT;
        const response = await axiosRequest.get("/products", { params });
        filteredData.value = response.data;
        findMap(filteredData.value);
        recenterMap(filteredData.value);
      } catch (error2) {
        console.error("Failed to retrieve data from API:", error2);
      }
    }
    const recenterMap = (filteredData2) => {
      if (filteredData2 && filteredData2.data && filteredData2.data.length > 0) {
        const bounds = new google.maps.LatLngBounds();
        filteredData2.data.forEach((item) => {
          bounds.extend(
            new google.maps.LatLng(
              parseFloat(item.latitude),
              parseFloat(item.longitude)
            )
          );
        });
        map.fitBounds(bounds);
      }
    };
    function findMap(dataFilter) {
      if (!dataFilter || !dataFilter.data || dataFilter.data.length === 0) {
        alert("Location Not Found. Please adjust your filter");
        return;
      }
      clearInfoWindows();
      const locations = dataFilter == null ? void 0 : dataFilter.data.map((item) => {
        return {
          latitude: parseFloat(item.latitude),
          longitude: parseFloat(item.longitude)
        };
      });
      locations.forEach((location) => {
        moveToLocation(location.latitude, location.longitude);
      });
    }
    const clearInfoWindows = () => {
      if (currentInfoWindow.value) {
        currentInfoWindow.value.close();
      }
    };
    const moveToLocation = (lat, lng) => {
      if (map) {
        map.setCenter({ lat, lng });
        const filteredMarkers = markers.value.filter(
          (marker) => marker.details.filtered
        );
        const bounds = new google.maps.LatLngBounds();
        filteredMarkers.forEach((marker) => {
          bounds.extend(marker.getPosition());
        });
        map.fitBounds(bounds);
        const matchingMarker = markers.value.find(
          (marker) => marker.getPosition().equals(new google.maps.LatLng(lat, lng))
        );
        if (matchingMarker) {
          matchingMarker.details.filtered = true;
          matchingMarker.setAnimation(google.maps.Animation.BOUNCE);
          setTimeout(() => {
            matchingMarker.setAnimation(null);
          }, 7e4);
        }
      }
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({
        class: {
          "container-custom": __props.ShowContainerCustom,
          "relative z-20": true,
          "w-full": !__props.ShowContainerCustom
        }
      }, _attrs))}><div id="map" class="${ssrRenderClass(`relative w-full h-[320px] sm:h-[420px] lg:min-h-[519px] min-[1440px]:h-[619px] z-[-999] rounded-2xl`)}"></div><div class="sm:mx-10 hidden"><div class="bg-tertiary box-shadow mt-[-100px] z-10 rounded-[20px] lg:rounded-[30px]"><div class="min-h-[278px] md:grid md:grid-cols-3 items-center h-full px-6 sm:px-10 font-semibold gap-1 md:gap-3 py-5 sm:py-9"><p class="text-[25px] font-bold lg:leading-10 lg:text-3xl text-secondary mb-4 md:mb-0">${ssrInterpolate(unref(titleMap))}</p><div class="text-tertiary grid justify-end md:col-span-3 mt-4"><button class="bg-primary hover:bg-secondary transition-all rounded-full min-h-[48px] flex items-center gap-4 pl-3 pr-1"><p class="font-semibold text-sm pl-2">Uitgebreid zoeken</p><div class="bg-tertiary flex items-center justify-center rounded-full min-w-[40px] min-h-[40px]"><svg width="9" height="15" viewBox="0 0 9 15" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M1.8125 13.8749L7.99968 7.68767L1.8125 1.50049" stroke="#F0912D" stroke-width="1.875" stroke-linecap="round" stroke-linejoin="round"></path></svg></div></button></div></div></div></div></section>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/MapInteractive2.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$3;
const _sfc_main$2 = {
  data() {
    return {
      Data: [
        {
          title: "Lees alles over Werkstek",
          imageSrc: "/images/Lees alles over Werkstek.png",
          imageAlt: "image1"
        },
        {
          title: "Bekijk onze Vacatures",
          imageSrc: "/images/Bekijk onze Vacatures.png",
          imageAlt: "image2"
        },
        {
          title: "Bekijk alle locaties van Werkstek",
          imageSrc: "/images/Bekijk alle locaties van Werkstek.png ",
          imageAlt: "image3"
        },
        {
          title: "Bekijk alle over de Werkstek communitie",
          imageSrc: "/images/Bekijk alle over de Werkstek communitie.png",
          imageAlt: "image4"
        }
      ]
    };
  },
  methods: {
    isRouteActive(route) {
      return this.$route.path === route;
    }
  }
};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_NuxtLink = __nuxt_component_0$1$1;
  _push(`<section${ssrRenderAttrs(_attrs)} data-v-02535927><div class="flex flex-col container-custom gap-4" data-v-02535927><div class="flex z-10 h-[150px] min-[400px]:h-[200px] sm:h-[400px] md:h-[350px] lg:h-[398px] text-white gap-2" data-v-02535927>`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/over-werkstek",
    class: ["flex flex-wrap max-w-[488px] w-[40%] h-full rounded-xl", { active: $options.isRouteActive("/over-werkstek") }],
    style: {
      backgroundImage: `url('${$data.Data[0].imageSrc}')`,
      backgroundPosition: "center center",
      backgroundRepeat: "no-repeat",
      backgroundSize: "cover"
    }
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div class="flex justify-center items-end w-full relative" data-v-02535927${_scopeId}><div class="h-[45%] sm:h-[30%] md:h-[40%] w-[95%] max-w-[430px] bg-secondary mb-2 rounded-xl flex items-end pl-2 pb-3 sm:pl-4 sm:pb-4 relative" data-v-02535927${_scopeId}><div class="bg-quaternary rounded-full max-w-[22px] sm:max-w-[44px] absolute top-1 right-1 sm:top-3 sm:right-3" data-v-02535927${_scopeId}><img${ssrRenderAttr("src", _imports_0$1)} alt="arrow" class="rotate-[-40deg]" data-v-02535927${_scopeId}></div><h1 class="text-[10px] sm:text-[12px] md:text-xl sm:w-[80%] pl-1" data-v-02535927${_scopeId}>${ssrInterpolate($data.Data[0].title)}</h1></div></div>`);
      } else {
        return [
          createVNode("div", { class: "flex justify-center items-end w-full relative" }, [
            createVNode("div", { class: "h-[45%] sm:h-[30%] md:h-[40%] w-[95%] max-w-[430px] bg-secondary mb-2 rounded-xl flex items-end pl-2 pb-3 sm:pl-4 sm:pb-4 relative" }, [
              createVNode("div", { class: "bg-quaternary rounded-full max-w-[22px] sm:max-w-[44px] absolute top-1 right-1 sm:top-3 sm:right-3" }, [
                createVNode("img", {
                  src: _imports_0$1,
                  alt: "arrow",
                  class: "rotate-[-40deg]"
                })
              ]),
              createVNode("h1", { class: "text-[10px] sm:text-[12px] md:text-xl sm:w-[80%] pl-1" }, toDisplayString($data.Data[0].title), 1)
            ])
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/onze-vacatures",
    class: ["flex flex-wrap w-[60%] h-full rounded-xl transition hover:shadow-xl", { active: $options.isRouteActive("/onze-vacatures") }],
    style: {
      backgroundImage: `url('${$data.Data[1].imageSrc}')`,
      backgroundPosition: "center center",
      backgroundRepeat: "no-repeat",
      backgroundSize: "cover"
    }
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div class="flex justify-end items-end w-full relative" data-v-02535927${_scopeId}><div class="max-w-[430px] h-[45%] sm:h-[30%] md:h-[40%] w-[60%] mr-4 bg-tertiary mb-2 rounded-xl flex items-end pl-2 pb-3 sm:pl-4 sm:pb-4 relative" data-v-02535927${_scopeId}><div class="bg-quaternary rounded-full max-w-[22px] sm:max-w-[44px] absolute top-1 right-1 sm:top-3 sm:right-3" data-v-02535927${_scopeId}><img${ssrRenderAttr("src", _imports_0$1)} alt="arrow" class="rotate-[-40deg]" data-v-02535927${_scopeId}></div><h1 class="text-[10px] sm:text-[12px] md:text-xl sm:w-[60%] pl-1 text-secondary" data-v-02535927${_scopeId}>${ssrInterpolate($data.Data[1].title)}</h1></div></div>`);
      } else {
        return [
          createVNode("div", { class: "flex justify-end items-end w-full relative" }, [
            createVNode("div", { class: "max-w-[430px] h-[45%] sm:h-[30%] md:h-[40%] w-[60%] mr-4 bg-tertiary mb-2 rounded-xl flex items-end pl-2 pb-3 sm:pl-4 sm:pb-4 relative" }, [
              createVNode("div", { class: "bg-quaternary rounded-full max-w-[22px] sm:max-w-[44px] absolute top-1 right-1 sm:top-3 sm:right-3" }, [
                createVNode("img", {
                  src: _imports_0$1,
                  alt: "arrow",
                  class: "rotate-[-40deg]"
                })
              ]),
              createVNode("h1", { class: "text-[10px] sm:text-[12px] md:text-xl sm:w-[60%] pl-1 text-secondary" }, toDisplayString($data.Data[1].title), 1)
            ])
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div><div class="flex z-10 h-[200px] sm:h-[400px] md:h-[350px] lg:h-[398px] text-white gap-2" data-v-02535927>`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/onze-locaties",
    class: ["flex flex-wrap w-[60%] h-full rounded-xl transition hover:shadow-xl", { active: $options.isRouteActive("/onze-locaties") }],
    style: {
      backgroundImage: `url('${$data.Data[2].imageSrc}')`,
      backgroundPosition: "center center",
      backgroundRepeat: "no-repeat",
      backgroundSize: "cover"
    }
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div class="flex justify-start items-end w-full relative" data-v-02535927${_scopeId}><div class="max-w-[430px] h-[45%] sm:h-[30%] md:h-[40%] w-[60%] ml-2 lg:ml-4 bg-tertiary mb-2 lg:mb-4 rounded-2xl flex items-end sm:pl-4 sm:pb-4 relative" data-v-02535927${_scopeId}><div class="bg-quaternary rounded-full max-w-[22px] sm:max-w-[44px] absolute top-1 right-1 sm:top-3 sm:right-3" data-v-02535927${_scopeId}><img${ssrRenderAttr("src", _imports_0$1)} alt="arrow" class="rotate-[-40deg]" data-v-02535927${_scopeId}></div><h1 class="text-[10px] sm:text-[12px] md:text-xl sm:w-[60%] pl-2 pb-2 text-secondary" data-v-02535927${_scopeId}>${ssrInterpolate($data.Data[2].title)}</h1></div></div>`);
      } else {
        return [
          createVNode("div", { class: "flex justify-start items-end w-full relative" }, [
            createVNode("div", { class: "max-w-[430px] h-[45%] sm:h-[30%] md:h-[40%] w-[60%] ml-2 lg:ml-4 bg-tertiary mb-2 lg:mb-4 rounded-2xl flex items-end sm:pl-4 sm:pb-4 relative" }, [
              createVNode("div", { class: "bg-quaternary rounded-full max-w-[22px] sm:max-w-[44px] absolute top-1 right-1 sm:top-3 sm:right-3" }, [
                createVNode("img", {
                  src: _imports_0$1,
                  alt: "arrow",
                  class: "rotate-[-40deg]"
                })
              ]),
              createVNode("h1", { class: "text-[10px] sm:text-[12px] md:text-xl sm:w-[60%] pl-2 pb-2 text-secondary" }, toDisplayString($data.Data[2].title), 1)
            ])
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "/werkstek-community",
    class: ["flex flex-wrap max-w-[488px] w-[40%] h-full rounded-xl transition hover:shadow-xl", { active: $options.isRouteActive("/werkstek-community") }],
    style: {
      backgroundImage: `url('${$data.Data[3].imageSrc}')`,
      backgroundPosition: "center center",
      backgroundRepeat: "no-repeat",
      backgroundSize: "cover"
    }
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div class="flex justify-start items-end w-full relative" data-v-02535927${_scopeId}><div class="h-[45%] sm:h-[30%] md:h-[40%] w-[80%] max-w-[430px] bg-secondary mb-2 ml-2 rounded-2xl flex items-end pl-2 pb-3 sm:pl-4 sm:pb-4 relative" data-v-02535927${_scopeId}><div class="bg-quaternary rounded-full max-w-[22px] sm:max-w-[44px] absolute top-1 right-1 sm:top-3 sm:right-3" data-v-02535927${_scopeId}><img${ssrRenderAttr("src", _imports_0$1)} alt="arrow" class="rotate-[-40deg]" data-v-02535927${_scopeId}></div><h1 class="text-[10px] sm:text-[12px] md:text-xl lg:pl-2 lg:pb-2 text-tertiary" data-v-02535927${_scopeId}>${ssrInterpolate($data.Data[3].title)}</h1></div></div>`);
      } else {
        return [
          createVNode("div", { class: "flex justify-start items-end w-full relative" }, [
            createVNode("div", { class: "h-[45%] sm:h-[30%] md:h-[40%] w-[80%] max-w-[430px] bg-secondary mb-2 ml-2 rounded-2xl flex items-end pl-2 pb-3 sm:pl-4 sm:pb-4 relative" }, [
              createVNode("div", { class: "bg-quaternary rounded-full max-w-[22px] sm:max-w-[44px] absolute top-1 right-1 sm:top-3 sm:right-3" }, [
                createVNode("img", {
                  src: _imports_0$1,
                  alt: "arrow",
                  class: "rotate-[-40deg]"
                })
              ]),
              createVNode("h1", { class: "text-[10px] sm:text-[12px] md:text-xl lg:pl-2 lg:pb-2 text-tertiary" }, toDisplayString($data.Data[3].title), 1)
            ])
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></section>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/FourImages.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_5 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender$1], ["__scopeId", "data-v-02535927"]]);
const _sfc_main$1 = {
  props: {
    title: {
      type: String,
      required: true
    },
    secondTitle: {
      type: String,
      required: true
    },
    description: {
      type: String,
      required: false
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "w-full flex items-center justify-center" }, _attrs))}><div class="flex flex-col justify-center items-center text-center py-10 gap-1"><img${ssrRenderAttr("src", _imports_0$2)} alt="background-title" class="absolute w-[50%] lg:w-[30%]"><span class="text-primary text-[16px]">${ssrInterpolate($props.title)}</span><span class="font-semibold text-[25px] sm:text-[44px] md:text-[2.6rem]">${$props.secondTitle}</span><span class="px-2 text-[10px] min-[420px]:text-[13px] md:text-sm md:w-[100%] text-center">${$props.description}</span></div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/TitleHeader3.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_6 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
function useHomeData() {
  const StatistiekLocatiesData = ref({
    image: "/images/img-home-1.png",
    title1: "De Werkstek locaties",
    title2: "De leukste kantoorruimtes",
    title3: "De perfecte werkplek voor elke organisatie. Kies voor betaalbare huur in een professionele omgeving op een gunstige locatie, en maak deel uit van een ondernemende en inspirerende community.",
    titleBg1: { title: "Locaties", count: 280 },
    titleBg2: { title: "Statistiek 2", count: 15 },
    titleBg3: { title: "Statistiek 3", count: 49 }
  });
  const BgBigGreenData = ref({
    title1: "Blijf op de hoogte",
    title2: "Schrijf je in voor de nieuwsbrief",
    title3: "Op de hoogte blijven van beschikbare werkplekken? Schrijf je dan nu vrijblijvend in!",
    showButtonSection: true,
    titleButton: "Contact opnemen",
    linkButton: "/contact"
  });
  return {
    StatistiekLocatiesData,
    BgBigGreenData
  };
}
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const { requestOptions } = useRequestOptions();
    const { StatistiekLocatiesData, BgBigGreenData } = useHomeData();
    useFetch(`/products`, {
      method: "get",
      ...requestOptions
    }, "$PslAyef5YX");
    const { data: sliderDataTest } = useFetch(`/featured-products`, {
      method: "get",
      ...requestOptions
    }, "$6PO73qLRkI");
    const sortedData = computed(() => {
      var _a, _b;
      return (_b = (_a = sliderDataTest == null ? void 0 : sliderDataTest.value) == null ? void 0 : _a.data) == null ? void 0 : _b.slice().sort((a, b) => a.position - b.position);
    });
    console.log(sortedData.value);
    useHead({
      title: "Home",
      meta: [
        {
          name: "description",
          content: "Als verhuurder leegstand van kantoorpanden voorkomen? Geen zorgen over de risico\u2019s van leegstand van kantoorgebouwen?"
        }
      ]
    });
    const isPerformSearch = ref();
    const isSearchCity = ref();
    const isPerformSearchComp = computed(() => isPerformSearch.value);
    const isSearchCityComp = computed(() => isSearchCity.value);
    function performSearch(data) {
      isPerformSearch.value = data;
    }
    function searchCity(data) {
      isSearchCity.value = data;
      console.log("Ini di functi searchCity", isSearchCity.value);
    }
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
      const _component_StatistiekLocatiesVideo = __nuxt_component_0;
      const _component_ButtonSM = __nuxt_component_1;
      const _component_MapInteractive2 = __nuxt_component_2;
      const _component_SliderLocatiesSort = __nuxt_component_1$1;
      const _component_SliderTestimony = __nuxt_component_6$1;
      const _component_FourImages = __nuxt_component_5;
      const _component_TitleHeader3 = __nuxt_component_6;
      const _component_Blog = __nuxt_component_7;
      const _component_BgBigGreen = __nuxt_component_4;
      _push(`<!--[-->`);
      _push(ssrRenderComponent(_component_StatistiekLocatiesVideo, {
        video: "/images/home-video.mov",
        image: (_a = unref(StatistiekLocatiesData)) == null ? void 0 : _a.image,
        title1: (_b = unref(StatistiekLocatiesData)) == null ? void 0 : _b.title1,
        title2: (_c = unref(StatistiekLocatiesData)) == null ? void 0 : _c.title2,
        title3: (_d = unref(StatistiekLocatiesData)) == null ? void 0 : _d.title3,
        titleBg1: (_e = unref(StatistiekLocatiesData)) == null ? void 0 : _e.titleBg1.title,
        titleBg2: (_f = unref(StatistiekLocatiesData)) == null ? void 0 : _f.titleBg2.title,
        titleBg3: (_g = unref(StatistiekLocatiesData)) == null ? void 0 : _g.titleBg3.title,
        count1: (_h = unref(StatistiekLocatiesData)) == null ? void 0 : _h.titleBg1.count,
        count2: (_i = unref(StatistiekLocatiesData)) == null ? void 0 : _i.titleBg2.count,
        count3: (_j = unref(StatistiekLocatiesData)) == null ? void 0 : _j.titleBg3.count,
        onIsPerformSearch: performSearch,
        onIsSearchCity: searchCity
      }, null, _parent));
      _push(`<div class="grid w-full container-custom"><div class="grid sm:grid-cols-2 justify-between items-center mb-5 gap-5"><div class="flex flex-col gap-2"><p class="text-[12px] min-[500px]:text-[16px] md:text-lg lg:text-[18px] font-bold"> Locaties </p><p class="text-[20px] min-[500px]:text-[25px] md:text-[30px] lg:text-[40px] text-[#231E1F] font-semibold"> Bekijk onze locaties. </p><p class="text-[10px] min-[500px]:text-base md:text-lg lg:text-[16px] text-[#777] font-normal"> Een gezellige werkplek huren in een leuke omgeving? Op deze locaties hebben wij kantoorruimtes </p></div><div class="flex justify-end">`);
      _push(ssrRenderComponent(_component_ButtonSM, {
        buttonTitle: "Bekijk alle locaties",
        buttonLink: "/onze-locaties",
        class: "z-10 hover:bg-secondary hover:bg-opacity-70 hover:text-tertiary"
      }, null, _parent));
      _push(`</div></div></div>`);
      _push(ssrRenderComponent(_component_MapInteractive2, {
        showSearch: false,
        searchCityT: unref(isSearchCityComp),
        SubmitPerform: unref(isPerformSearchComp)
      }, null, _parent));
      _push(`<div id="map"></div>`);
      _push(ssrRenderComponent(_component_SliderLocatiesSort, { data: unref(sortedData) }, null, _parent));
      _push(ssrRenderComponent(_component_SliderTestimony, { class: "my-10" }, null, _parent));
      _push(ssrRenderComponent(_component_FourImages, null, null, _parent));
      _push(`<div class="my-10">`);
      _push(ssrRenderComponent(_component_TitleHeader3, {
        title: "Updates & blogs",
        secondTitle: "Lees de Werkstek blog",
        description: "Op de hoogte blijven van de nieuwste kantoortrends? <br /> Op zoek naar tips en tricks voor ondernemers? Lees dan ook onze inspirerende blogs!"
      }, null, _parent));
      _push(ssrRenderComponent(_component_Blog, null, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_BgBigGreen, {
        title1: unref(BgBigGreenData).title1,
        title2: unref(BgBigGreenData).title2,
        title3: unref(BgBigGreenData).title3,
        showButtonSection: unref(BgBigGreenData).showButtonSection,
        buttonTitle: unref(BgBigGreenData).titleButton,
        buttonLink: unref(BgBigGreenData).linkButton,
        showEmailSection: true,
        "show-button-section": false,
        backgroundColor: "secondary"
      }, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-6b6c55e8.mjs.map
