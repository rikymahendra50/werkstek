import { unref, useSSRContext, ref, withAsyncContext, computed, watch, mergeProps, isRef, withCtx, createVNode, toDisplayString, openBlock, createBlock, createTextVNode } from 'vue';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderAttr, ssrInterpolate, ssrRenderList, ssrIncludeBooleanAttr, ssrLooseEqual, ssrRenderClass, ssrRenderStyle } from 'vue/server-renderer';
import { d as useHead, h as _export_sfc, u as useRequestOptions, a as useRouter, b as useRoute, _ as __nuxt_component_0$1$1 } from '../server.mjs';
import { _ as __nuxt_component_0$1 } from './TitleHeader-8492944b.mjs';
import __nuxt_component_2$1 from './Icon-e394d28f.mjs';
import { _ as _imports_0$2 } from './arrow-right-150377ce.mjs';
import { _ as __nuxt_component_3$1 } from './Pagination-d765680b.mjs';
import { u as useAsyncData } from './asyncData-04c89180.mjs';
import { _ as _imports_0$1, a as _imports_1 } from './marker-dropdown-d764c93e.mjs';
import { u as useTimeoutFn } from './index-73677d9a.mjs';
import { _ as __nuxt_component_4 } from './BgBigGreen-1402b0e9.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import 'devalue';
import '@unhead/ssr';
import './config-aab100d3.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'vee-validate';
import './useRequestHelper-553b0504.mjs';
import './fetch-101122a4.mjs';
import './arrow-small-right-9e640e2c.mjs';

const _sfc_main$4 = {
  props: {
    useTitle2: {
      type: Boolean,
      default: true
    },
    title22: {
      type: String
    },
    image: {
      type: String,
      required: true
    },
    title1: {
      type: String,
      required: true
    },
    title2: {
      type: String,
      required: true
    },
    title3: {
      type: String,
      required: true
    },
    buttonTitle1: {
      type: String,
      required: false
    },
    buttonLink1: {
      type: String,
      required: false
    },
    buttonTitle2: {
      type: String,
      required: false
    },
    buttonLink2: {
      type: String,
      required: false
    },
    titleBg1: {
      type: String,
      required: true
    },
    titleBg2: {
      type: String,
      required: true
    },
    titleBg3: {
      type: String,
      required: true
    },
    count1: {
      type: Number,
      required: true
    },
    count2: {
      type: Number,
      required: true
    },
    count3: {
      type: Number,
      required: true
    },
    classcustom: {
      type: String,
      required: false
    },
    showButton: {
      type: Boolean,
      required: false,
      default: false
    }
  }
};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "container-custom my-5" }, _attrs))}><div class="relative hidden md:block"><div class="relative"><h1 class="text-[12px] min-[400px]:text-[16px] min-[500px]:text-[20px] sm:text-[22px] md:text-[28px] lg:text-[34px] xl:text-[40px] font-bold absolute pl-2 sm:pl-4 sm:pt-1 lg:pl-4 lg:pt-3 top-[-10px]">${$props.title1}</h1><svg viewBox="0 0 1280 504" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path d="M606.856 0C586.231 0 569.511 15.0683 569.511 33.6561V36.5676C569.511 58.659 551.603 76.5676 529.511 76.5676H37.2623C16.6372 76.5676 0 91.6359 0 110.224V470.344C0 488.932 16.7199 504 37.345 504H1242.66C1263.28 504 1280 488.932 1280 470.344V33.6561C1280 15.0684 1263.28 0 1242.66 0H606.856Z" fill="url(#pattern0_57_14544)"></path><path d="M606.856 0C586.231 0 569.511 15.0683 569.511 33.6561V36.5676C569.511 58.659 551.603 76.5676 529.511 76.5676H37.2623C16.6372 76.5676 0 91.6359 0 110.224V470.344C0 488.932 16.7199 504 37.345 504H1242.66C1263.28 504 1280 488.932 1280 470.344V33.6561C1280 15.0684 1263.28 0 1242.66 0H606.856Z" fill="black" fill-opacity="0.4"></path><defs><pattern id="pattern0_57_14544" patternContentUnits="objectBoundingBox" width="1" height="1"><use xlink:href="#image0_57_14544" transform="matrix(0.000244141 0 0 0.00062004 0 -0.346974)"></use></pattern><image id="image0_57_14544" width="4096" height="2732"${ssrRenderAttr("xlink:href", $props.image)}></image></defs></svg><div class="absolute bottom-[30%] min-[500px]:bottom-[20%] sm:bottom-[20%] lg:bottom-[22%] text-white ml-4 sm:ml-10">`);
  if (!$props.useTitle2) {
    _push(`<p class="text-sm min-[420px]:text-base min-[520px]:text-lg sm:text-xl md:text-2xl lg:text-3xl xl:text-4xl font-semibold pb-1 md:pb-4 drop-shadow-2xl xl:leading-snug tracking-widest">${$props.title2}</p>`);
  } else if ($props.useTitle2) {
    _push(`<p class="text-sm min-[420px]:text-base min-[520px]:text-lg sm:text-xl md:text-2xl lg:text-3xl xl:text-4xl font-semibold pb-1 md:pb-4 drop-shadow-2xl xl:leading-snug tracking-widest">${$props.title22}</p>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<p class="text-[8px] min-[420px]:text-[10px] min-[520px]:text-[13px] sm:text-sm md:text-base lg:text-[14px] leading-2 w-[80%] md:w-[60%] drop-shadow-2xl">${$props.title3}</p></div></div></div><div class="relative md:hidden"><h1 class="text-[12px] min-[400px]:text-[16px] min-[500px]:text-[20px] sm:text-[22px] md:text-[28px] lg:text-[34px] xl:text-[40px] font-bold absolute pl-2 sm:pl-4 sm:pt-1 lg:pl-4 lg:pt-3 top-0">${ssrInterpolate($props.title1)}</h1><div class="relative"><svg viewBox="0 0 1280 655" fill="none" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><path d="M606.856 0C586.231 0 569.511 19.5828 569.511 43.7396V59.5075C569.511 81.5989 551.603 99.5075 529.511 99.5075H37.2623C16.6372 99.5075 0 119.09 0 143.247V611.26C0 635.417 16.7199 655 37.345 655H1242.66C1263.28 655 1280 635.417 1280 611.26V43.7396C1280 19.5829 1263.28 0 1242.66 0H606.856Z" fill="url(#pattern0)"></path><path d="M606.856 0C586.231 0 569.511 19.5828 569.511 43.7396V59.5075C569.511 81.5989 551.603 99.5075 529.511 99.5075H37.2623C16.6372 99.5075 0 119.09 0 143.247V611.26C0 635.417 16.7199 655 37.345 655H1242.66C1263.28 655 1280 635.417 1280 611.26V43.7396C1280 19.5829 1263.28 0 1242.66 0H606.856Z" fill="black" fill-opacity="0.4"></path><defs><pattern id="pattern0" patternContentUnits="objectBoundingBox" width="1" height="1"><use xlink:href="#image0_57_14544" transform="matrix(0.000244141 0 0 0.000477099 0 -0.151718)"></use></pattern><image id="image0_57_14544" width="4096" height="2732"${ssrRenderAttr("xlink:href", $props.image)}></image></defs></svg><div class="absolute bottom-[30%] min-[500px]:bottom-[20%] sm:bottom-[20%] lg:bottom-[35%] xl:bottom-36 text-white ml-4 sm:ml-10">`);
  if (!$props.useTitle2) {
    _push(`<p class="text-sm min-[420px]:text-base min-[520px]:text-lg sm:text-xl md:text-2xl lg:text-3xl xl:text-4xl font-semibold pb-1 md:pb-4 text-shadow xl:leading-snug tracking-widest"> De Werkstek locaties </p>`);
  } else if ($props.useTitle2) {
    _push(`<p class="text-sm min-[420px]:text-base min-[520px]:text-lg sm:text-xl md:text-2xl lg:text-3xl xl:text-4xl font-semibold pb-1 md:pb-4 text-shadow xl:leading-snug tracking-widest">${$props.title22}</p>`);
  } else {
    _push(`<!---->`);
  }
  _push(`<p class="text-[8px] min-[420px]:text-[10px] min-[520px]:text-[13px] sm:text-sm md:text-base lg:text-[16px] leading-2 w-[80%] md:w-[60%] text-shadow">${$props.title3}</p></div><div class="bg-primary grid grid-rows-1 grid-cols-3 z-10 absolute w-[80%] sm:w-[70%] content-center justify-items-center py-2 lg:py-5 rounded-lg lg:rounded-[40px] px-2 lg:px-10 bottom-[-20%] min-[620px]:bottom-[-10%] sm:bottom-[-10%] right-3 lg:right-10"><div class="text-white"><p class="text-[20px] min-[620px]:text-[24px] lg:text-[36px] xl:text-[48px] font-semibold">${ssrInterpolate($props.count1)} <span class="text-[#00985B]">+</span></p><p class="text-[10px] min-[620px]:text-[14px] md:text-[16px] font-normal">${ssrInterpolate($props.titleBg1)}</p></div><div class="text-white"><p class="text-[20px] min-[620px]:text-[24px] lg:text-[36px] xl:text-[48px] font-semibold">${ssrInterpolate($props.count2)} <span class="text-[#00985B]">+</span></p><p class="text-[10px] min-[620px]:text-[14px] md:text-[16px] font-normal">${ssrInterpolate($props.titleBg2)}</p></div><div class="text-white"><p class="text-[20px] sm:text-[24px] lg:text-[36px] xl:text-[48px] font-semibold">${ssrInterpolate($props.count3)} <span class="text-[#00985B]">+</span></p><p class="text-[10px] sm:text-[14px] md:text-[16px] font-normal">${ssrInterpolate($props.titleBg3)}</p></div></div></div></div></section>`);
}
const _sfc_setup$4 = _sfc_main$4.setup;
_sfc_main$4.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/StatistiekLocaties2.vue");
  return _sfc_setup$4 ? _sfc_setup$4(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ _export_sfc(_sfc_main$4, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main$3 = {
  __name: "Map",
  __ssrInlineRender: true,
  props: {
    AllData: {}
  },
  setup(__props) {
    const props = __props;
    let map = ref(null);
    const markers = ref([]);
    const currentInfoWindow = ref(null);
    const AllData = ref(props.AllData);
    watch(
      () => props.AllData,
      (newValue) => {
        clearMarkers();
        AllData.value = newValue;
        setupMap();
      }
    );
    const setupMap = () => {
      var _a;
      clearMarkers();
      map = new google.maps.Map(document.getElementById("map"), {
        center: { lat: 52.21314997541194, lng: 5.3982948103810795 },
        zoom: 7.9,
        fullscreenControl: false,
        zoomControl: false,
        keyboardShortcuts: false,
        mapTypeControl: false,
        streetViewControl: false,
        mapId: null
      });
      const bounds = new google.maps.LatLngBounds();
      (_a = AllData == null ? void 0 : AllData.value) == null ? void 0 : _a.forEach((location) => {
        var _a2, _b, _c;
        const lat = parseFloat(location.latitude);
        const lng = parseFloat(location.longitude);
        const icon = {
          url: (_a2 = location == null ? void 0 : location.level_type) == null ? void 0 : _a2.image,
          scaledSize: new google.maps.Size(30, 30)
        };
        const marker = new google.maps.Marker({
          position: { lat, lng },
          map,
          title: location.name,
          icon,
          details: location
        });
        bounds.extend(new google.maps.LatLng(location.lat, location.longitude));
        const contentString = `
      <div class="max-w-[120px] w-full h-full flex flex-col text-end">
        <div class="relative">
          <img src="${(_b = location == null ? void 0 : location.location) == null ? void 0 : _b.image}" alt="${(_c = location == null ? void 0 : location.location) == null ? void 0 : _c.name}" class="w-full min-h-[80px] rounded-md">
          <div class="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-b from-transparent to-white"></div>
        </div>
        <div class="px-2 pb-4">
          <h2 class="text-primary mt-2">${location == null ? void 0 : location.name}</h2>
          <p class="text-black text-[10px]">${location == null ? void 0 : location.area_size}</p>
          <p class="text-black text-[10px]">Price: $${location.price}</p>
        </div>
      </div>
    `;
        const infowindow = new google.maps.InfoWindow({
          content: contentString,
          closeBoxMargin: "10px 10px 0 0"
        });
        marker.addListener("click", () => {
          map.setCenter(marker.getPosition());
          map.setZoom(10);
          if (currentInfoWindow.value) {
            currentInfoWindow.value.close();
          }
          currentInfoWindow.value = infowindow;
        });
        markers.value.push(marker);
      });
    };
    const clearMarkers = () => {
      markers.value.forEach((marker) => {
        marker.setMap(null);
      });
      markers.value = [];
    };
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<section${ssrRenderAttrs(mergeProps({ class: {
        "relative z-20": true
      } }, _attrs))}><div id="map" class="${ssrRenderClass(`relative aspect-video lg:h-[219px] z-[-999] mt-5 w-full`)}"></div></section>`);
    };
  }
};
const _sfc_setup$3 = _sfc_main$3.setup;
_sfc_main$3.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Map.vue");
  return _sfc_setup$3 ? _sfc_setup$3(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$3;
const _imports_0 = "" + __publicAssetsURL("images/icon-rating-white.svg");
const _sfc_main$2 = {
  props: {
    link: {
      type: String
    },
    areaSize: {
      type: [String, Number],
      default: "Opervlakte"
    },
    address: {
      type: [String, Number],
      default: "address"
    },
    latitude: {},
    longitude: {},
    image: {
      type: String,
      default: "/images/image-not-found.png"
    },
    rating: {
      default: "Rating"
    },
    type: {
      default: "Level type"
    },
    name: {},
    email: {
      type: String,
      default: "Mail Adres"
    },
    phone: {
      default: 31302393838
    },
    price: {},
    detailLinkTitle: {
      type: String,
      default: "Neem een kijkje"
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_NuxtLink = __nuxt_component_0$1$1;
  _push(`<div${ssrRenderAttrs(_attrs)}>`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: $props.link,
    class: "grid grid-cols-8 grid-rows-1 mb-2 lg:mb-5 ounded-lg group hover:shadow-lg transition min-h-[150px] sm:min-h-[170px] md:min-h-[200px]",
    style: { "box-shadow": "2px 4px 15px rgba(0, 0, 0, 0.05)" }
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div class="grid col-span-4 md:col-span-4 md:min-h-[210px] h-full bg-no-repeat bg-cover rounded-lg relative text-white" style="${ssrRenderStyle({
          background: `linear-gradient(90deg, rgba(251,249,249,0) 39%, rgba(255,255,255,1) 100%), url('${$props.image}')`,
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
          backgroundSize: "cover"
        })}"${_scopeId}><div class="flex flex-col"${_scopeId}><div class="bg-primary absolute flex items-center sm:py-1 px-1 sm:px-2 gap-1 md:gap-2 rounded-full ml-2 mt-2 text-[12px] sm:text-sm"${_scopeId}><div class="flex items-center gap-1 px-1"${_scopeId}><img${ssrRenderAttr("src", _imports_0)} alt="page2" class="w-[14px]"${_scopeId}><span class="pt-[2px] text-[12px]"${_scopeId}>${ssrInterpolate($props.rating)}</span></div></div><span class="bg-primary absolute top-[20%] sm:top-[30%] md:top-[20%] left-0 flex sm:py-1 px-1 sm:px-2 rounded-full ml-2 mt-2 text-[12px] font-semibold"${_scopeId}><span${_scopeId}>${ssrInterpolate($props.type)}</span></span></div></div><div class="grid col-span-4 md:col-span-4 ml-3 sm:ml-4 md:ml-5 items-center md:pr-4 py-1"${_scopeId}><span class="text-[11px] sm:text-sm lg:text-base font-semibold"${_scopeId}>${ssrInterpolate($props.name)}</span>`);
        if ($props.address == null) {
          _push2(`<span class="text-[10px] sm:text-sm text-ellipsis"${_scopeId}>Address</span>`);
        } else {
          _push2(`<span class="text-[10px] sm:text-[12px] text-ellipsis line-clamp-1 lg:line-clamp-2 opacity-90"${_scopeId}>${ssrInterpolate($props.address)}</span>`);
        }
        _push2(`<div class="flex justify-between"${_scopeId}><span class="text-[10px] sm:text-sm font-bold"${_scopeId}><span${_scopeId}>${ssrInterpolate($props.areaSize)} m<sup${_scopeId}>2</sup></span></span><span class="text-[10px] sm:text-sm"${_scopeId}>+${ssrInterpolate($props.phone)}</span></div><div class="flex justify-between"${_scopeId}><span class="text-[10px] sm:text-sm"${_scopeId}>${ssrInterpolate($props.price)} \u20AC</span><span class="text-[10px] sm:text-sm"${_scopeId}>${ssrInterpolate($props.email)}</span></div><div class="flex justify-end w-full"${_scopeId}><div class="flex mt-2 sm:mt-0"${_scopeId}><div class="flex relative bottom-0 mt-2 sm:mt-4 border border-primary group-hover:border-secondary w-fit items-center rounded-full"${_scopeId}><span class="py-2 pl-3 pr-2 sm:py-3 sm:pl-4 sm:pr-3 text-primary group-hover:text-secondary text-[10px] sm:text-sm font-medium"${_scopeId}>${ssrInterpolate($props.detailLinkTitle)}</span><div class="bg-primary group-hover:bg-secondary w-[25px] h-[25px] sm:w-[37px] sm:h-[37px] rounded-full mr-1"${_scopeId}><img${ssrRenderAttr("src", _imports_0$2)} alt="arrow"${_scopeId}></div></div></div></div></div>`);
      } else {
        return [
          createVNode("div", {
            class: "grid col-span-4 md:col-span-4 md:min-h-[210px] h-full bg-no-repeat bg-cover rounded-lg relative text-white",
            style: {
              background: `linear-gradient(90deg, rgba(251,249,249,0) 39%, rgba(255,255,255,1) 100%), url('${$props.image}')`,
              backgroundPosition: "center",
              backgroundRepeat: "no-repeat",
              backgroundSize: "cover"
            }
          }, [
            createVNode("div", { class: "flex flex-col" }, [
              createVNode("div", { class: "bg-primary absolute flex items-center sm:py-1 px-1 sm:px-2 gap-1 md:gap-2 rounded-full ml-2 mt-2 text-[12px] sm:text-sm" }, [
                createVNode("div", { class: "flex items-center gap-1 px-1" }, [
                  createVNode("img", {
                    src: _imports_0,
                    alt: "page2",
                    class: "w-[14px]"
                  }),
                  createVNode("span", { class: "pt-[2px] text-[12px]" }, toDisplayString($props.rating), 1)
                ])
              ]),
              createVNode("span", { class: "bg-primary absolute top-[20%] sm:top-[30%] md:top-[20%] left-0 flex sm:py-1 px-1 sm:px-2 rounded-full ml-2 mt-2 text-[12px] font-semibold" }, [
                createVNode("span", null, toDisplayString($props.type), 1)
              ])
            ])
          ], 4),
          createVNode("div", { class: "grid col-span-4 md:col-span-4 ml-3 sm:ml-4 md:ml-5 items-center md:pr-4 py-1" }, [
            createVNode("span", { class: "text-[11px] sm:text-sm lg:text-base font-semibold" }, toDisplayString($props.name), 1),
            $props.address == null ? (openBlock(), createBlock("span", {
              key: 0,
              class: "text-[10px] sm:text-sm text-ellipsis"
            }, "Address")) : (openBlock(), createBlock("span", {
              key: 1,
              class: "text-[10px] sm:text-[12px] text-ellipsis line-clamp-1 lg:line-clamp-2 opacity-90"
            }, toDisplayString($props.address), 1)),
            createVNode("div", { class: "flex justify-between" }, [
              createVNode("span", { class: "text-[10px] sm:text-sm font-bold" }, [
                createVNode("span", null, [
                  createTextVNode(toDisplayString($props.areaSize) + " m", 1),
                  createVNode("sup", null, "2")
                ])
              ]),
              createVNode("span", { class: "text-[10px] sm:text-sm" }, "+" + toDisplayString($props.phone), 1)
            ]),
            createVNode("div", { class: "flex justify-between" }, [
              createVNode("span", { class: "text-[10px] sm:text-sm" }, toDisplayString($props.price) + " \u20AC", 1),
              createVNode("span", { class: "text-[10px] sm:text-sm" }, toDisplayString($props.email), 1)
            ]),
            createVNode("div", { class: "flex justify-end w-full" }, [
              createVNode("div", { class: "flex mt-2 sm:mt-0" }, [
                createVNode("div", { class: "flex relative bottom-0 mt-2 sm:mt-4 border border-primary group-hover:border-secondary w-fit items-center rounded-full" }, [
                  createVNode("span", { class: "py-2 pl-3 pr-2 sm:py-3 sm:pl-4 sm:pr-3 text-primary group-hover:text-secondary text-[10px] sm:text-sm font-medium" }, toDisplayString($props.detailLinkTitle), 1),
                  createVNode("div", { class: "bg-primary group-hover:bg-secondary w-[25px] h-[25px] sm:w-[37px] sm:h-[37px] rounded-full mr-1" }, [
                    createVNode("img", {
                      src: _imports_0$2,
                      alt: "arrow"
                    })
                  ])
                ])
              ])
            ])
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/eachLocaties.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_3 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main$1 = {
  __name: "OnzeLocaties",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { requestOptions } = useRequestOptions();
    const router = useRouter();
    useRoute();
    const page = ref(1);
    const selectedCity = ref("");
    const selectedSoortLocatie = ref("");
    const selectedMinPrice = ref("");
    const selectedMaxPrice = ref("");
    const selectedMeterMin = ref("");
    const selectedMeterMax = ref("");
    const selectedFunctie = ref([]);
    const dataForFilter = ref([]);
    const locations = ref([]);
    const soortLocatiesRadio = ref([]);
    const functieCheckbox = ref([]);
    const variableToggleLocatie = ref();
    const selectedCityForShow = ref("Locatie");
    const {
      data: dataProduct,
      error,
      refresh
    } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "dataProduct",
      () => $fetch(
        `/products?filter[location]=${selectedCity.value}&filter[type_id]=${selectedSoortLocatie.value}&filter[min_price]=${selectedMinPrice.value}&filter[max_price]=${selectedMaxPrice.value}&filter[min_area]=${selectedMeterMin.value}&filter[max_area]=${selectedMeterMax.value}&${selectedFacilities.value}`,
        {
          method: "get",
          headers: {
            Accept: "application/json"
          },
          ...requestOptions
        }
      )
    )), __temp = await __temp, __restore(), __temp);
    const selectedFacilities = computed(() => {
      if (selectedFunctie.value.length > 0) {
        return `filter[facilities]=${selectedFunctie.value.map((item) => item.toString()).join("|")}`;
      } else {
        return "";
      }
    });
    const { start, stop } = useTimeoutFn(() => {
      replaceWindow();
    }, 3e3);
    watch(
      () => page.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          start();
        }
      }
    );
    watch(
      () => selectedMinPrice.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          page.value = 1;
          start();
        }
      }
    );
    watch(
      () => selectedMaxPrice.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          page.value = 1;
          start();
        }
      }
    );
    watch(
      () => selectedCity.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          page.value = 1;
          start();
        }
      }
    );
    watch(
      () => selectedSoortLocatie.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          page.value = 1;
          start();
        }
      }
    );
    watch(
      () => selectedMeterMin.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          page.value = 1;
          start();
        }
      }
    );
    watch(
      () => selectedMeterMax.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          page.value = 1;
          start();
        }
      }
    );
    watch(
      () => selectedFunctie.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          page.value = 1;
          start();
        }
      }
    );
    const showFilter = ref();
    const city = computed(() => {
      return locations.value.map((item) => item);
    });
    computed(() => {
      const numericPrices = dataForFilter.value.map(
        (item) => parseFloat(item.price)
      );
      if (numericPrices.length === 0) {
        return 0;
      }
      const highestPrice2 = Math.max(...numericPrices);
      return highestPrice2;
    });
    function isSelectedFuncti(id) {
      return selectedFunctie.value.includes(id);
    }
    function replaceWindow() {
      let filters = [];
      if (selectedCity.value) {
        filters.push(`location=${selectedCity.value}`);
      }
      if (selectedSoortLocatie.value) {
        filters.push(`type_id=${selectedSoortLocatie.value}`);
      }
      if (selectedMaxPrice.value) {
        filters.push(`min_price=${selectedMinPrice.value}`);
        filters.push(`max_price=${selectedMaxPrice.value}`);
      }
      if (selectedMeterMin && selectedMeterMax) {
        filters.push(`filter[min_area]=${selectedMeterMin.value}`);
        filters.push(`filter[max_area]=${selectedMeterMax.value}`);
      }
      if (selectedFunctie == null ? void 0 : selectedFunctie.value) {
        const facilitiesQuery = selectedFunctie.value.join("|");
        filters.push(`facilities=${facilitiesQuery}`);
      }
      const queryString = filters.join("&");
      const url = `/onze-locaties?page=${page.value}${queryString ? `&${queryString}` : ""}`;
      router.replace(url);
      refresh();
    }
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f, _g, _h;
      const _component_TitleHeader = __nuxt_component_0$1;
      const _component_Icon = __nuxt_component_2$1;
      const _component_Map = __nuxt_component_2;
      const _component_eachLocaties = __nuxt_component_3;
      const _component_Pagination = __nuxt_component_3$1;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "py-10 sm:py-10" }, _attrs))} data-v-3ef98672>`);
      _push(ssrRenderComponent(_component_TitleHeader, {
        title: "Onze locaties",
        secondTitle: "Bekijk al onze locaties",
        description: "Op deze locaties hebben we kantoorruimtes"
      }, null, _parent));
      _push(`<div class="md:grid md:grid-cols-12 container-custom mx-2 sm:mx-0" data-v-3ef98672><div class="md:col-span-4 sm:w-[90%]" data-v-3ef98672><div class="sm:mt-5" data-v-3ef98672><button class="btn w-full bg-primary hover:bg-secondary text-white font-bold py-2 px-4 rounded normal-case text-md" data-v-3ef98672> Al Onze Locaties </button><button class="flex items-center gap-3 hover:text-primary" data-v-3ef98672><img${ssrRenderAttr("src", _imports_0$1)} class="w-5 h-5 my-4" alt="filter" data-v-3ef98672><p class="text-base opacity-50" data-v-3ef98672>Meer filter opties</p></button></div>`);
      if (unref(showFilter)) {
        _push(`<div class="" data-v-3ef98672><div class="relative" data-v-3ef98672><label for="city" class="text-base mt-3 opacity-50" data-v-3ef98672>Kies een locatie</label><div class="w-full border py-3 rounded-lg px-2 flex justify-between items-center cursor-pointer mt-2 select-none" data-v-3ef98672><div class="flex items-center gap-2" data-v-3ef98672><img${ssrRenderAttr("src", _imports_1)} alt="markers" data-v-3ef98672><p class="text-[#ADA7A7] text-base" data-v-3ef98672>${ssrInterpolate(unref(selectedCityForShow))}</p></div>`);
        _push(ssrRenderComponent(_component_Icon, {
          name: "ep:arrow-up-bold",
          class: "text-[#ADA7A7] rotate-180"
        }, null, _parent));
        _push(`</div>`);
        if (unref(variableToggleLocatie)) {
          _push(`<div class="w-full absolute bg-white mt-2 z-10 select-none" data-v-3ef98672><ul class="flex flex-col rounded-lg border text-[#ADA7A7] max-h-[150px] overflow-y-auto" data-v-3ef98672><!--[-->`);
          ssrRenderList(unref(city), (item, index) => {
            _push(`<li class="hover:bg-primary bg-white hover:text-white cursor-pointer pl-3 py-2 rounded-lg" data-v-3ef98672>${ssrInterpolate(item.name)}</li>`);
          });
          _push(`<!--]--></ul></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div><div class="flex flex-col" data-v-3ef98672><span class="text-base mt-3 opacity-50 pb-3" data-v-3ef98672>Soort locatie</span><fieldset id="soortLocatie" class="grid lg:grid-cols-2 gap-2" data-v-3ef98672><!--[-->`);
        ssrRenderList(unref(soortLocatiesRadio), (item) => {
          _push(`<div class="flex items-center cursor-pointer gap-2" data-v-3ef98672><input${ssrRenderAttr("id", item.id)}${ssrRenderAttr("name", "Soort" + item.id)}${ssrRenderAttr("value", item.id)}${ssrIncludeBooleanAttr(ssrLooseEqual(unref(selectedSoortLocatie), item.id)) ? " checked" : ""} type="radio" data-v-3ef98672><label${ssrRenderAttr("for", item.id)} class="cursor-pointer text-sm" data-v-3ef98672>${ssrInterpolate(item.name)}</label></div>`);
        });
        _push(`<!--]--></fieldset><label for="MinPrice" class="text-sm mt-3 opacity-50" data-v-3ef98672>Price</label><label for="MaxPrice" class="text-sm mt-3 opacity-50 hidden" data-v-3ef98672>Price</label><div class="grid grid-cols-2 my-2" data-v-3ef98672><div class="relative" data-v-3ef98672><input type="number" id="MinPrice" placeholder="Min" min="0" class="input input-bordered w-[95%] p-[10px] input-md"${ssrRenderAttr("value", unref(selectedMinPrice))} data-v-3ef98672><br data-v-3ef98672><span class="absolute top-3 right-8" data-v-3ef98672>\u20AC</span></div><div class="relative" data-v-3ef98672><input type="number" id="MaxPrice" min="0" placeholder="Max" class="input input-bordered w-[95%] p-[10px] input-md"${ssrRenderAttr("value", unref(selectedMaxPrice))} data-v-3ef98672><br data-v-3ef98672><span class="absolute top-3 right-8" data-v-3ef98672>\u20AC</span></div></div><div class="" data-v-3ef98672><label for="deopervlakteMin" class="text-sm mt-3 opacity-50" data-v-3ef98672>De opervlakte m\xB2</label><label for="deopervlakteMax" class="text-sm mt-3 opacity-50 hidden" data-v-3ef98672>De opervlakte m\xB2</label><div class="grid grid-cols-2 my-2" data-v-3ef98672><div class="relative" data-v-3ef98672><input type="number" id="deopervlakteMin" placeholder="Min" min="0" class="input input-bordered w-[95%] p-[10px]input-md"${ssrRenderAttr("value", unref(selectedMeterMin))} data-v-3ef98672><br data-v-3ef98672><span class="absolute top-3 right-8" data-v-3ef98672>m<sup data-v-3ef98672>2</sup></span></div><div class="relative" data-v-3ef98672><input type="number" id="deopervlakteMax" min="0" placeholder="Max" class="input input-bordered w-[95%] p-[10px] input-md"${ssrRenderAttr("value", unref(selectedMeterMax))} data-v-3ef98672><br data-v-3ef98672><span class="absolute top-3 right-8" data-v-3ef98672>m<sup data-v-3ef98672>2</sup></span></div></div><p class="text-base mt-3 opacity-50 pb-3" data-v-3ef98672>Facility</p><fieldset id="facility" class="grid lg:grid-cols-1 gap-4" data-v-3ef98672><!--[-->`);
        ssrRenderList(unref(functieCheckbox), (item) => {
          _push(`<div class="flex items-center gap-2 cursor-pointer" data-v-3ef98672><input${ssrRenderAttr("id", `facility-${item.id}`)}${ssrRenderAttr("value", item.name)} type="checkbox" name="facility"${ssrIncludeBooleanAttr(isSelectedFuncti(item.id)) ? " checked" : ""} data-v-3ef98672><label${ssrRenderAttr("for", `facility-${item.id}`)} class="cursor-pointer text-sm" data-v-3ef98672>${ssrInterpolate(item.name)}</label></div>`);
        });
        _push(`<!--]--></fieldset>`);
        _push(ssrRenderComponent(_component_Map, {
          AllData: (_a = unref(dataProduct)) == null ? void 0 : _a.data
        }, null, _parent));
        _push(`</div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="md:col-span-8 py-5 overflow-auto" data-v-3ef98672><div class="max-h-[400px] md:max-h-[870px] flex flex-col scrollbar-onze" data-v-3ef98672>`);
      if ((_b = unref(dataProduct)) == null ? void 0 : _b.data) {
        _push(`<!--[-->`);
        ssrRenderList((_c = unref(dataProduct)) == null ? void 0 : _c.data, (item, index) => {
          var _a2, _b2, _c2;
          _push(ssrRenderComponent(_component_eachLocaties, {
            key: item == null ? void 0 : item.id,
            name: item == null ? void 0 : item.name,
            address: item == null ? void 0 : item.address,
            category: (_a2 = item == null ? void 0 : item.type) == null ? void 0 : _a2.name,
            areaSize: item == null ? void 0 : item.area_size,
            type: (_b2 = item == null ? void 0 : item.level_type) == null ? void 0 : _b2.name,
            latitude: item == null ? void 0 : item.latitude,
            longitude: item == null ? void 0 : item.longitude,
            link: `/onze-locaties/${item.slug}`,
            price: item == null ? void 0 : item.price,
            email: item == null ? void 0 : item.email,
            phone: item == null ? void 0 : item.phone_number,
            image: (_c2 = item == null ? void 0 : item.images[0]) == null ? void 0 : _c2.image,
            rating: item == null ? void 0 : item.rating
          }, null, _parent));
        });
        _push(`<!--]-->`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      if ((_d = unref(dataProduct)) == null ? void 0 : _d.meta) {
        _push(ssrRenderComponent(_component_Pagination, {
          includeFirstLast: false,
          modelValue: unref(page),
          "onUpdate:modelValue": ($event) => isRef(page) ? page.value = $event : null,
          first: "Eerst",
          last: "Laatst",
          prev: "Vorig",
          next: "Volgende",
          total: (_f = (_e = unref(dataProduct)) == null ? void 0 : _e.meta) == null ? void 0 : _f.total,
          "per-page": (_h = (_g = unref(dataProduct)) == null ? void 0 : _g.meta) == null ? void 0 : _h.per_page,
          class: "flex justify-center mt-5"
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></section>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/OnzeLocaties.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-3ef98672"]]);
function useOnzeLocatiesData() {
  const StatistiekLocaties2Data = ref({
    image: "/images/onze-locaties.png",
    title1: "Bekijk onze locaties",
    title2: "De Werkstek </br> locaties",
    title22: "De Werkstek </br> locaties",
    title3: "De perfecte werkplek voor elke organisatie. Kies voor  betaalbare huur in een professionele omgeving </br> op een  gunstige locatie, en maak deel uit van een </br> ondernemende en inspirerende community.",
    titleBg1: { title: "Locaties", count: 280 },
    titleBg2: { title: "Statistiek 2", count: 15 },
    titleBg3: { title: "Statistiek 3", count: 49 }
  });
  const dropdownData = ref(["Utrecht", "Locatie", "Denpasar", "Amsterdam"]);
  const checkboxData = ref({
    soortLocaties: [
      {
        id: 1,
        name: "Alles"
      },
      {
        id: 2,
        name: "Anders"
      },
      {
        id: 3,
        name: "Kantoorruimte"
      }
    ],
    functie: [
      {
        id: 9,
        name: "Wifi"
      },
      {
        id: 10,
        name: "Parkeerplaats"
      },
      {
        id: 11,
        name: "Receptie"
      },
      {
        id: 12,
        name: "Koffiebar"
      },
      {
        id: 13,
        name: "Keuken"
      },
      {
        id: 14,
        name: "Vlakbij het treinstation"
      },
      {
        id: 15,
        name: "Loungeplekken"
      },
      {
        id: 16,
        name: "Vergaderruimtes met videoschermen"
      }
    ]
  });
  const LocatiesData = ref([
    {
      id: 1,
      name: "Utrecht",
      soortLocaties: ["Alles", "Anders"],
      deopervlakte: 19,
      price: 320,
      functie: ["Wifi", "Parkeerplaats"],
      image: "/images/img-each-locatie-1.png",
      type: "Premium",
      adres: "Adres",
      opervlakte: "Opervlakte",
      phoneNumber: "+31302393838",
      mailAdres: "Mail adres",
      detailLinkTitle: "Neem een kijkje",
      detailLink: "/onze-locaties/rikymahendra",
      rating: 9.4
    },
    {
      id: 2,
      name: "Locatie",
      soortLocaties: ["Anders", "Alles"],
      price: 100,
      deopervlakte: 20,
      functie: ["Wifi", "Parkeerplaats", "Loungeplekken"],
      image: "/images/img-each-locatie-2.jpg",
      type: "Premium",
      adres: "Adres",
      opervlakte: "Opervlakte",
      phoneNumber: "+31302393838",
      mailAdres: "Mail adres",
      detailLinkTitle: "Neem een kijkje",
      detailLink: "/onze-locaties/rikymahendra",
      rating: 9.4
    },
    {
      id: 3,
      name: "Locatie",
      soortLocaties: ["Anders"],
      price: 120,
      deopervlakte: 23,
      functie: [
        "Wifi",
        "Parkeerplaats",
        "Loungeplekken",
        "Loungeplekken",
        "Koffiebar"
      ],
      image: "/images/img-each-locatie-1.png",
      type: "Premium",
      adres: "Adres",
      opervlakte: "Opervlakte",
      phoneNumber: "+31302393838",
      mailAdres: "Mail adres",
      detailLinkTitle: "Neem een kijkje",
      detailLink: "/onze-locaties/rikymahendra",
      rating: 9.4
    },
    {
      id: 4,
      name: "Amsterdam",
      soortLocaties: ["Alles"],
      price: 100,
      deopervlakte: 25,
      functie: ["Loungeplekken", "Loungeplekken", "Koffiebar"],
      image: "/images/img-each-locatie-3.jpg",
      type: "Premium",
      adres: "Adres",
      opervlakte: "Opervlakte",
      phoneNumber: "+31302393838",
      mailAdres: "Mail adres",
      detailLinkTitle: "Neem een kijkje",
      detailLink: "/onze-locaties/rikymahendra",
      rating: 9.4
    }
  ]);
  const BgBigGreenData = ref({
    title1: "Aanvragen",
    title2: "Niks kunnen vinden?",
    title3: "Neem dan contact met ons op. Samen zoeken we jouw perfecte werkplek.",
    showButtonSection: true,
    showEmailSection: false
  });
  return {
    StatistiekLocaties2Data,
    BgBigGreenData,
    LocatiesData,
    checkboxData,
    dropdownData
  };
}
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    const { StatistiekLocaties2Data, BgBigGreenData } = useOnzeLocatiesData();
    useHead({
      title: "Onze Locaties"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_StatistiekLocaties2 = __nuxt_component_0;
      const _component_OnzeLocaties = __nuxt_component_1;
      const _component_BgBigGreen = __nuxt_component_4;
      _push(`<!--[--><div class="mt-28">`);
      _push(ssrRenderComponent(_component_StatistiekLocaties2, {
        useTitle2: false,
        image: unref(StatistiekLocaties2Data).image,
        title1: unref(StatistiekLocaties2Data).title1,
        title2: unref(StatistiekLocaties2Data).title2,
        title22: unref(StatistiekLocaties2Data).title22,
        title3: unref(StatistiekLocaties2Data).title3,
        titleBg1: unref(StatistiekLocaties2Data).titleBg1.title,
        titleBg2: unref(StatistiekLocaties2Data).titleBg2.title,
        titleBg3: unref(StatistiekLocaties2Data).titleBg3.title,
        count1: unref(StatistiekLocaties2Data).titleBg1.count,
        count2: unref(StatistiekLocaties2Data).titleBg2.count,
        count3: unref(StatistiekLocaties2Data).titleBg3.count
      }, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_OnzeLocaties, { id: "section-2" }, null, _parent));
      _push(ssrRenderComponent(_component_BgBigGreen, {
        title1: unref(BgBigGreenData).title1,
        title2: unref(BgBigGreenData).title2,
        title3: unref(BgBigGreenData).title3,
        phoneNumber: unref(BgBigGreenData).phoneNumber,
        mail: unref(BgBigGreenData).mail,
        showEmailSection: unref(BgBigGreenData).showEmailSection,
        showButtonSection: unref(BgBigGreenData).showButtonSection,
        backgroundColor: "primary"
      }, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/onze-locaties/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-6bea2632.mjs.map
