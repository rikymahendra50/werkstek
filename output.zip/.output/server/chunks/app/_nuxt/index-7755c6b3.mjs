import { _ as __nuxt_component_0 } from './ButtonAddIndex-0be538de.mjs';
import { h as _export_sfc, u as useRequestOptions, a as useRouter, b as useRoute, d as useHead, _ as __nuxt_component_0$1 } from '../server.mjs';
import __nuxt_component_2 from './Icon-e394d28f.mjs';
import { _ as __nuxt_component_3 } from './Pagination-d765680b.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { ref, withAsyncContext, watch, unref, withCtx, createVNode, isRef, useSSRContext } from 'vue';
import { u as useAsyncData } from './asyncData-04c89180.mjs';
import { ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import { u as useTimeoutFn } from './index-73677d9a.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './config-aab100d3.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    useSnackbar();
    const router = useRouter();
    useRoute();
    const page = ref(1);
    const {
      data: locations,
      error,
      refresh
    } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "locations",
      () => $fetch(`/admins/locations?page=${page.value}`, {
        method: "get",
        headers: {
          Accept: "application/json"
        },
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    const { start, stop } = useTimeoutFn(() => {
      replaceWindow();
    }, 1e3);
    watch(
      () => page.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          start();
        }
      }
    );
    function replaceWindow() {
      router.replace(`/admin/location?page=${page.value}`);
      refresh();
    }
    useHead({
      title: "Location"
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c;
      const _component_CompAdminButtonAddIndex = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_icon = __nuxt_component_2;
      const _component_Pagination = __nuxt_component_3;
      _push(`<!--[--><main class="flex-grow overflow-y-auto" data-v-5a269988><div class="mx-auto px-2 sm:px-6 lg:px-8 max-w-sm md:max-w-3xl lg:max-w-[720px] xl:max-w-7xl py-8 space-y-8" data-v-5a269988><div class="flex justify-between items-center" data-v-5a269988><div data-v-5a269988><div class="text-xl md:text-2xl font-bold" data-v-5a269988>Location</div></div>`);
      _push(ssrRenderComponent(_component_CompAdminButtonAddIndex, {
        name: "Location",
        link: "location"
      }, null, _parent));
      _push(`</div><div data-v-5a269988><div class="overflow-x-auto !py-2 border rounded-t-lg" data-v-5a269988><table class="table table-xs md:table-md w-full rounded-t-xl" data-v-5a269988><thead class="h-12" data-v-5a269988><tr data-v-5a269988><th class="font-medium" data-v-5a269988>Name</th><th class="font-medium" data-v-5a269988></th></tr></thead><tbody data-v-5a269988><!--[-->`);
      ssrRenderList((_a = unref(locations)) == null ? void 0 : _a.data, (item, index2) => {
        _push(`<tr class="odd:bg-gray-100 even:hover:bg-gray-100 transition-colors duration-300" data-v-5a269988><td class="text-gray-500 font-normal !py-2 text-[12px] md:text-sm" data-v-5a269988>${ssrInterpolate(item.name)}</td><td class="flex items-center gap-2" data-v-5a269988>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/admin/location/edit/${item.slug}`,
          class: "cursor-pointer btn btn-sm normal-case btn-ghost btn-square"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_icon, { name: "i-heroicons-pencil-square" }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_icon, { name: "i-heroicons-pencil-square" })
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="cursor-pointer btn btn-sm normal-case btn-ghost btn-square" data-v-5a269988>`);
        _push(ssrRenderComponent(_component_icon, { name: "i-heroicons-trash" }, null, _parent));
        _push(`</div><dialog${ssrRenderAttr("id", "my_modal_" + index2)} class="modal" data-v-5a269988><div class="modal-box" data-v-5a269988><h3 class="font-bold text-lg text-red-500" data-v-5a269988>Warning !</h3><p class="py-4 text-sm" data-v-5a269988> Are you sure want to delete this item called ${ssrInterpolate(item.name)}? </p><div class="modal-action" data-v-5a269988><form method="dialog" data-v-5a269988><button class="btn btn-outline btn-error mr-3 text-[12px]" data-v-5a269988> Delete </button><button class="btn" data-v-5a269988>Close</button></form></div></div></dialog></td></tr>`);
      });
      _push(`<!--]--></tbody></table></div></div></div></main>`);
      _push(ssrRenderComponent(_component_Pagination, {
        modelValue: unref(page),
        "onUpdate:modelValue": ($event) => isRef(page) ? page.value = $event : null,
        total: (_b = unref(locations)) == null ? void 0 : _b.total,
        "per-page": (_c = unref(locations)) == null ? void 0 : _c.per_page,
        class: "flex justify-center"
      }, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/location/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-5a269988"]]);

export { index as default };
//# sourceMappingURL=index-7755c6b3.mjs.map
