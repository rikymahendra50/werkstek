import { useSSRContext, defineComponent, ref, withAsyncContext, mergeProps, unref } from 'vue';
import { h as _export_sfc, d as useHead, u as useRequestOptions, i as useAuth } from '../server.mjs';
import { u as useFetch } from './fetch-101122a4.mjs';
import { ssrRenderAttrs, ssrInterpolate } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './asyncData-04c89180.mjs';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    ref(true);
    useHead({
      title: "Admin Home"
    });
    const { requestOptions } = useRequestOptions();
    [__temp, __restore] = withAsyncContext(() => useFetch(`/admins/profile`, {
      headers: {
        accept: "application/json"
      },
      method: "get",
      ...requestOptions
    }, "$W3ipyljEsJ")), __temp = await __temp, __restore();
    const { $user, $logout } = useAuth();
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d;
      _push(`<table${ssrRenderAttrs(mergeProps({ class: "tableAdmin" }, _attrs))} data-v-169158d3><caption data-v-169158d3> Your Profile </caption><thead data-v-169158d3><tr class="text-sm" data-v-169158d3><th scope="col" data-v-169158d3>Name</th><th scope="col" data-v-169158d3>Position</th><th scope="col" data-v-169158d3>Email</th><th scope="col" data-v-169158d3>Active</th></tr></thead><tbody data-v-169158d3><tr class="text-sm" data-v-169158d3><td scope="row" data-label="Name" data-v-169158d3>${ssrInterpolate((_a = unref($user)) == null ? void 0 : _a.first_name)}</td><td data-label="Position" data-v-169158d3>${ssrInterpolate((_b = unref($user)) == null ? void 0 : _b.last_name)}</td><td data-label="Email" data-v-169158d3>${ssrInterpolate((_c = unref($user)) == null ? void 0 : _c.email)}</td><td data-label="Active" data-v-169158d3>${ssrInterpolate(((_d = unref($user)) == null ? void 0 : _d.is_active) === 1 ? "Active" : "Nonaktif")}</td></tr></tbody></table>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-169158d3"]]);

export { index as default };
//# sourceMappingURL=index-8a279180.mjs.map
