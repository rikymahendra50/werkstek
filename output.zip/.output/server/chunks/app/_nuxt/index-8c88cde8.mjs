import { _ as __nuxt_component_0 } from './ButtonAddIndex-0be538de.mjs';
import { i as _export_sfc, u as useRouter, a as useRoute, j as useAsyncData, d as useHead, _ as __nuxt_component_0$1 } from '../server.mjs';
import __nuxt_component_2 from './Icon-7d2a1472.mjs';
import { _ as __nuxt_component_3 } from './Pagination-d765680b.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { ref, withAsyncContext, watch, unref, withCtx, createVNode, isRef, useSSRContext } from 'vue';
import { ssrRenderComponent, ssrRenderList, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import { u as useTimeoutFn } from './index-73677d9a.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './config-54e8ad1b.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    useSnackbar();
    const router = useRouter();
    useRoute();
    const page = ref(1);
    const search = ref("");
    const {
      data: author,
      error,
      refresh
    } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "author",
      () => $fetch(`/admins/authors`, {
        method: "get",
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    const { start, stop } = useTimeoutFn(() => {
      replaceWindow();
    }, 1e3);
    watch(
      () => page.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          start();
        }
      }
    );
    watch(
      () => search.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          page.value = 1;
          start();
        }
      }
    );
    function replaceWindow() {
      router.replace(`/admin/author?page=${page.value}&search=${search.value}`);
      refresh();
    }
    useHead({
      title: "Author"
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      const _component_CompAdminButtonAddIndex = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_icon = __nuxt_component_2;
      const _component_Pagination = __nuxt_component_3;
      _push(`<!--[--><main class="flex-grow overflow-y-auto" data-v-ebb6776a><div class="mx-auto px-2 sm:px-6 lg:px-8 max-w-sm md:max-w-3xl lg:max-w-[720px] xl:max-w-7xl py-8 space-y-8" data-v-ebb6776a><div class="flex justify-between items-center" data-v-ebb6776a><div data-v-ebb6776a><div class="text-xl md:text-2xl font-bold" data-v-ebb6776a>Author</div></div>`);
      _push(ssrRenderComponent(_component_CompAdminButtonAddIndex, {
        name: "Author",
        link: "author"
      }, null, _parent));
      _push(`</div><div class="space-y-4" data-v-ebb6776a><div class="overflow-x-auto !py-2 border rounded-t-lg" data-v-ebb6776a><table class="table table-xs md:table-md w-full rounded-t-xl" data-v-ebb6776a><thead class="h-12" data-v-ebb6776a><tr data-v-ebb6776a><th class="font-medium" data-v-ebb6776a>Image</th><th class="font-medium" data-v-ebb6776a>Name</th><th class="font-medium" data-v-ebb6776a></th></tr></thead><tbody data-v-ebb6776a><!--[-->`);
      ssrRenderList((_a = unref(author)) == null ? void 0 : _a.data, (item, index2) => {
        _push(`<tr class="odd:bg-gray-100 even:hover:bg-gray-100 transition-colors duration-300" data-v-ebb6776a><td class="flex items-center" data-v-ebb6776a><div class="aspect-square" data-v-ebb6776a><img${ssrRenderAttr("src", item.image)}${ssrRenderAttr("alt", `item` + index2)} class="object-cover rounded-md w-20 h-20" data-v-ebb6776a></div></td><td class="text-gray-500 text-[12px] font-normal !py-2" data-v-ebb6776a>${ssrInterpolate(item.name)}</td><td data-v-ebb6776a><div class="flex justify-center items-center gap-4 my-1" data-v-ebb6776a>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/admin/author/edit/${item.id}`,
          class: "btn mr-2 btn-sm normal-case btn-ghost btn-square"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_icon, {
                name: "i-heroicons-pencil-square",
                class: "cursor-pointer"
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_icon, {
                  name: "i-heroicons-pencil-square",
                  class: "cursor-pointer"
                })
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="cursor-pointer btn btn-sm normal-case btn-ghost btn-square" data-v-ebb6776a>`);
        _push(ssrRenderComponent(_component_icon, { name: "i-heroicons-trash" }, null, _parent));
        _push(`</div><dialog${ssrRenderAttr("id", "my_modal_" + index2)} class="modal" data-v-ebb6776a><div class="modal-box" data-v-ebb6776a><h3 class="font-bold text-lg text-red-500" data-v-ebb6776a> Warning ! </h3><p class="py-4 text-sm" data-v-ebb6776a> Are you sure want to delete this author called ${ssrInterpolate(item.name)}? </p><div class="modal-action" data-v-ebb6776a><form method="dialog" data-v-ebb6776a><button class="btn btn-outline btn-error mr-3" data-v-ebb6776a> Delete </button><button class="btn" data-v-ebb6776a>Close</button></form></div></div></dialog></div></td></tr>`);
      });
      _push(`<!--]--></tbody></table></div></div></div></main>`);
      _push(ssrRenderComponent(_component_Pagination, {
        modelValue: unref(page),
        "onUpdate:modelValue": ($event) => isRef(page) ? page.value = $event : null,
        total: (_c = (_b = unref(author)) == null ? void 0 : _b.meta) == null ? void 0 : _c.total,
        "per-page": (_e = (_d = unref(author)) == null ? void 0 : _d.meta) == null ? void 0 : _e.per_page,
        class: "flex justify-center"
      }, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/author/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-ebb6776a"]]);

export { index as default };
//# sourceMappingURL=index-8c88cde8.mjs.map
