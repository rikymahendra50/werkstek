import { h as _export_sfc, u as useRequestOptions, a as useRouter, b as useRoute, d as useHead, _ as __nuxt_component_0$1 } from '../server.mjs';
import __nuxt_component_2 from './Icon-e394d28f.mjs';
import { _ as __nuxt_component_3 } from './Pagination-d765680b.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { ref, withAsyncContext, watch, unref, withCtx, createTextVNode, toDisplayString, createVNode, isRef, useSSRContext } from 'vue';
import { u as useAsyncData } from './asyncData-04c89180.mjs';
import { ssrRenderList, ssrInterpolate, ssrRenderComponent, ssrRenderAttr } from 'vue/server-renderer';
import { u as useTimeoutFn } from './index-73677d9a.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './config-aab100d3.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const router = useRouter();
    useRoute();
    const page = ref(1);
    const search = ref("");
    const {
      data: contact,
      error,
      refresh
    } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "contact",
      () => $fetch(`/admins/contacts?page=${page.value}&filter[search]=${search.value}`, {
        method: "get",
        headers: {
          Accept: "application/json"
        },
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    const { start, stop } = useTimeoutFn(() => {
      replaceWindow();
    }, 1e3);
    watch(
      () => page.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          start();
        }
      }
    );
    watch(
      () => search.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          page.value = 1;
          start();
        }
      }
    );
    function replaceWindow() {
      router.replace(`/admin/contact?page=${page.value}&search=${search.value}`);
      refresh();
    }
    useHead({
      title: "Contact"
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_icon = __nuxt_component_2;
      const _component_Pagination = __nuxt_component_3;
      _push(`<!--[--><main class="flex-grow overflow-y-auto" data-v-9861d9b5><div class="mx-auto px-2 sm:px-6 lg:px-8 max-w-sm md:max-w-3xl lg:max-w-[720px] xl:max-w-7xl py-8 space-y-8" data-v-9861d9b5><div class="flex justify-between items-center" data-v-9861d9b5><div data-v-9861d9b5><div class="text-xl md:text-2xl font-bold" data-v-9861d9b5>Contact</div></div></div><div class="space-y-4" data-v-9861d9b5><div class="overflow-x-auto !py-2 border rounded-t-lg" data-v-9861d9b5><table class="table table-xs md:table-md w-full rounded-t-xl" data-v-9861d9b5><thead class="h-12" data-v-9861d9b5><tr data-v-9861d9b5><th class="font-medium" data-v-9861d9b5>First Name</th><th class="font-medium" data-v-9861d9b5>Last Name</th><th class="font-medum" data-v-9861d9b5>Email</th><th class="font-medium" data-v-9861d9b5>Subject</th><th class="font-medium" data-v-9861d9b5>Message</th><th data-v-9861d9b5></th></tr></thead><tbody data-v-9861d9b5><!--[-->`);
      ssrRenderList((_a = unref(contact)) == null ? void 0 : _a.data, (item, index2) => {
        _push(`<tr class="odd:bg-gray-100 even:hover:bg-gray-100 transition-colors duration-300" data-v-9861d9b5><td class="text-gray-500 text-[12px] font-normal !py-2" data-v-9861d9b5>${ssrInterpolate(item.first_name)}</td><td class="font-medium text-[12px]" data-v-9861d9b5>${ssrInterpolate(item.last_name)}</td><td class="font-medum text-[12px]" data-v-9861d9b5>${ssrInterpolate(item.email)}</td><td class="font-medium text-[12px]" data-v-9861d9b5>${ssrInterpolate(item.subject)}</td><td class="font-medium max-w-[200px] overflow-hidden text-ellipsis whitespace-nowrap text-[12px]" data-v-9861d9b5>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/admin/contact/${item.id}`
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(`${ssrInterpolate(item.message)}`);
            } else {
              return [
                createTextVNode(toDisplayString(item.message), 1)
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</td><td class="flex justify-center items-center gap-4 my-1" data-v-9861d9b5><span class="text-gray-500 text-[12px] font-normal !py-1.5" data-v-9861d9b5>`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/admin/contact/${item.id}`,
          class: "cursor-pointer btn btn-sm normal-case btn-ghost btn-square"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_icon, {
                name: "i-heroicons-eye",
                class: "cursor-pointer"
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_icon, {
                  name: "i-heroicons-eye",
                  class: "cursor-pointer"
                })
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</span><div class="cursor-pointer btn btn-sm normal-case btn-ghost btn-square" data-v-9861d9b5>`);
        _push(ssrRenderComponent(_component_icon, { name: "i-heroicons-trash" }, null, _parent));
        _push(`</div><dialog${ssrRenderAttr("id", "my_modal_" + index2)} class="modal" data-v-9861d9b5><div class="modal-box" data-v-9861d9b5><h3 class="font-bold text-xl text-red-500" data-v-9861d9b5>Warning !</h3><p class="py-4 text-sm" data-v-9861d9b5> Are you sure want to delete this item? </p><div class="modal-action" data-v-9861d9b5><form method="dialog" data-v-9861d9b5><button class="btn btn-outline btn-error mr-3 text-[12px]" data-v-9861d9b5> Delete </button><button class="btn" data-v-9861d9b5>Close</button></form></div></div></dialog></td></tr>`);
      });
      _push(`<!--]--></tbody></table></div></div></div></main>`);
      _push(ssrRenderComponent(_component_Pagination, {
        modelValue: unref(page),
        "onUpdate:modelValue": ($event) => isRef(page) ? page.value = $event : null,
        total: (_c = (_b = unref(contact)) == null ? void 0 : _b.meta) == null ? void 0 : _c.total,
        "per-page": (_e = (_d = unref(contact)) == null ? void 0 : _d.meta) == null ? void 0 : _e.per_page,
        class: "flex justify-center"
      }, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/contact/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const index = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-9861d9b5"]]);

export { index as default };
//# sourceMappingURL=index-ab6fe357.mjs.map
