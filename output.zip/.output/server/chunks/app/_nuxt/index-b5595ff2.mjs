import { _ as __nuxt_component_0 } from './ButtonAddIndex-0be538de.mjs';
import { u as useRequestOptions, a as useRouter, b as useRoute, d as useHead, _ as __nuxt_component_0$1 } from '../server.mjs';
import __nuxt_component_2 from './Icon-e394d28f.mjs';
import { _ as __nuxt_component_3 } from './Pagination-d765680b.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { ref, withAsyncContext, watch, unref, withCtx, createVNode, isRef, useSSRContext } from 'vue';
import { u as useAsyncData } from './asyncData-04c89180.mjs';
import { ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderClass } from 'vue/server-renderer';
import { u as useTimeoutFn } from './index-73677d9a.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './config-aab100d3.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const router = useRouter();
    useRoute();
    const page = ref(1);
    const search = ref("");
    const {
      data: admins,
      error,
      refresh
    } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "admins",
      () => $fetch(`/admins?page=${page.value}`, {
        method: "get",
        headers: {
          Accept: "application/json"
        },
        ...requestOptions
      })
    )), __temp = await __temp, __restore(), __temp);
    const { start, stop } = useTimeoutFn(() => {
      replaceWindow();
    }, 1e3);
    watch(
      () => page.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          start();
        }
      }
    );
    watch(
      () => search.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          page.value = 1;
          start();
        }
      }
    );
    function replaceWindow() {
      router.replace(`/admin/admin-list?page=${page.value}`);
      refresh();
    }
    useHead({
      title: "Admin List"
    });
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e;
      const _component_CompAdminButtonAddIndex = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_icon = __nuxt_component_2;
      const _component_Pagination = __nuxt_component_3;
      _push(`<!--[--><main class="flex-grow overflow-y-auto"><div class="mx-auto px-2 sm:px-6 lg:px-8 max-w-sm md:max-w-3xl lg:max-w-[720px] xl:max-w-5xl py-8 space-y-8"><div class="flex justify-between items-center"><div><div class="text-lg md:text-2xl font-bold">Admin List</div></div>`);
      _push(ssrRenderComponent(_component_CompAdminButtonAddIndex, {
        name: "Admin",
        link: "admin-list"
      }, null, _parent));
      _push(`</div><div><div class="overflow-x-auto !py-2 rounded-t-lg"><table class="table table-xs md:table-md w-full rounded-t-xl"><thead class="h-12"><tr><th class="font-medium">First Name</th><th class="font-medium">Last Name</th><th class="font-medium">Email</th><th class="font-medium">Is Active</th><th class="font-medium"></th></tr></thead><tbody><!--[-->`);
      ssrRenderList((_a = unref(admins)) == null ? void 0 : _a.data, (item, index) => {
        _push(`<tr class="odd:bg-gray-100 even:hover:bg-gray-100 transition-colors duration-300"><td class="text-gray-500 text-[12px] font-normal !py-2">${ssrInterpolate(item.first_name)}</td><td class="text-gray-500 text-[12px] font-normal !py-2">${ssrInterpolate(item.last_name)}</td><td class="text-[12px]">${ssrInterpolate(item.email)}</td><td class="${ssrRenderClass([{
          "text-green-500": item.is_active === 1,
          "text-red-500": item.is_active !== 1
        }, "text-[12px]"])}">${ssrInterpolate(item.is_active === 1 ? "Active" : "Nonaktif")}</td><td class="flex justify-center items-center gap-4 h-full">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/admin/admin-list/${item.uuid}`,
          class: "btn btn-sm normal-case btn-ghost btn-square"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_icon, {
                name: "i-heroicons-pencil-square",
                class: "cursor-pointer"
              }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_icon, {
                  name: "i-heroicons-pencil-square",
                  class: "cursor-pointer"
                })
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`</td></tr>`);
      });
      _push(`<!--]--></tbody></table></div></div></div></main>`);
      _push(ssrRenderComponent(_component_Pagination, {
        modelValue: unref(page),
        "onUpdate:modelValue": ($event) => isRef(page) ? page.value = $event : null,
        total: (_c = (_b = unref(admins)) == null ? void 0 : _b.meta) == null ? void 0 : _c.total,
        "per-page": (_e = (_d = unref(admins)) == null ? void 0 : _d.meta) == null ? void 0 : _e.per_page,
        class: "flex justify-center"
      }, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/admin-list/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-b5595ff2.mjs.map
