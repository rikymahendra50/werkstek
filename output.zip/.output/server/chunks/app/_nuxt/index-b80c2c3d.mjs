import { _ as __nuxt_component_0 } from './BackButton-454ea1e4.mjs';
import { _ as __nuxt_component_0$1 } from './ButtonAddIndex-0be538de.mjs';
import { Form } from 'vee-validate';
import __nuxt_component_2 from './Icon-7d2a1472.mjs';
import { _ as __nuxt_component_3 } from './ButtonAddForm-aa118db7.mjs';
import { d as useHead, u as useRouter, a as useRoute, b as useFetch } from '../server.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { computed, ref, mergeProps, withCtx, unref, createVNode, openBlock, createBlock, Fragment, renderList, toDisplayString, withDirectives, vModelText, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import './config-54e8ad1b.mjs';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Add Featured Property"
    });
    const { loading, transformErrors } = useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const snackbar = useSnackbar();
    const router = useRouter();
    const route = useRoute();
    computed(() => route.params.slug);
    const { data: sliderDataFeatured } = useFetch(`/admins/featured-products`, {
      method: "get",
      ...requestOptions
    }, "$12iHoT2KuS");
    const sortedSliderData = computed(() => {
      var _a, _b;
      return (_b = (_a = sliderDataFeatured.value) == null ? void 0 : _a.data) == null ? void 0 : _b.slice().sort((a, b) => a.position - b.position);
    });
    const showModal = (index) => {
      const modalId = `my_modal_${index}`;
      const modal = document.getElementById(modalId);
      if (modal) {
        modal.showModal();
      }
    };
    const closeModal = (index) => {
      const modalId = `my_modal_${index}`;
      const modal = document.getElementById(modalId);
      if (modal) {
        modal.close();
      }
    };
    const featured_products = ref([]);
    function addPosition(id, name, position, index) {
      console.log(`ID: ${id}, Name: ${name}, New Position: ${position}`);
      featured_products.value.push({ position, product_id: id });
      closeModal(index);
    }
    const hasChanges = computed(() => {
      if (featured_products.value.length === 0) {
        return false;
      }
      return true;
    });
    async function onSubmit(ctx) {
      var _a2;
      var _a, _b, _c;
      loading.value = true;
      const { data, error } = await useFetch("/admins/featured-products", {
        method: "POST",
        body: { featured_products: featured_products.value },
        ...requestOptions
      }, "$xsWtzBM5m0");
      if (error.value) {
        ctx.setErrors(transformErrors((_a = error.value) == null ? void 0 : _a.data));
        snackbar.add({
          type: "error",
          text: (_a2 = (_c = (_b = error.value) == null ? void 0 : _b.data) == null ? void 0 : _c.message) != null ? _a2 : "Something went wrong"
        });
      } else {
        snackbar.add({
          type: "success",
          text: "Success Change Sort"
        });
        router.push("/admin/onze-locaties");
      }
      loading.value = false;
    }
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CompAdminBackButton = __nuxt_component_0;
      const _component_CompAdminButtonAddIndex = __nuxt_component_0$1;
      const _component_VeeForm = Form;
      const _component_icon = __nuxt_component_2;
      const _component_CompAdminButtonAddForm = __nuxt_component_3;
      _push(`<main${ssrRenderAttrs(mergeProps({ class: "flex-grow overflow-y-auto" }, _attrs))}><div class="mx-auto px-2 sm:px-4 lg:px-6 max-w-sm md:max-w-3xl lg:max-w-[720px] xl:max-w-5xl py-8 space-y-8"><div class="flex justify-between items-center"><div><div class="text-lg md:text-2xl font-bold">`);
      _push(ssrRenderComponent(_component_CompAdminBackButton, {
        link: "onze-locaties",
        linkTitle: "Sort list Property Slider"
      }, null, _parent));
      _push(`</div></div>`);
      _push(ssrRenderComponent(_component_CompAdminButtonAddIndex, {
        name: "Sort Property",
        link: "onze-locaties/featured-property/add-sortlist"
      }, null, _parent));
      _push(`</div>`);
      _push(ssrRenderComponent(_component_VeeForm, { onSubmit }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="overflow-x-auto !py-2 border rounded-t-lg"${_scopeId}><table class="table table-xs md:table-md w-full rounded-t-xl"${_scopeId}><thead class="h-12"${_scopeId}><tr${_scopeId}><th class="font-medium"${_scopeId}>Name</th><th class="font-medium"${_scopeId}>Position</th></tr></thead><tbody${_scopeId}><!--[-->`);
            ssrRenderList(unref(sortedSliderData), (item, index) => {
              var _a, _b, _c;
              _push2(`<tr class="odd:bg-gray-100 even:hover:bg-gray-100 transition-colors duration-300"${_scopeId}><td class="text-gray-500 text-[12px] font-normal !py-2 md:text-sm"${_scopeId}>${ssrInterpolate((_a = item == null ? void 0 : item.product) == null ? void 0 : _a.name)}</td><td class="text-gray-500 text-[12px] font-normal !py-2 md:text-sm"${_scopeId}>${ssrInterpolate(item == null ? void 0 : item.position)}</td><td class="flex items-center gap-3"${_scopeId}><div class="cursor-pointer btn btn-sm normal-case btn-ghost btn-square"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_icon, {
                name: "i-heroicons-pencil-square",
                class: "cursor-pointer"
              }, null, _parent2, _scopeId));
              _push2(`</div><dialog${ssrRenderAttr("id", "my_modal_" + index)} class="modal"${_scopeId}><div class="modal-box"${_scopeId}><h3 class="font-bold text-lg"${_scopeId}> Edit Position Sort of ${ssrInterpolate((_b = item == null ? void 0 : item.product) == null ? void 0 : _b.name)}? </h3><input${ssrRenderAttr("id", (_c = item == null ? void 0 : item.product) == null ? void 0 : _c.name)} type="number" placeholder="Type here" class="input input-bordered input-sm w-full max-w-xs my-3"${ssrRenderAttr("value", item.position)}${_scopeId}><div class="modal-action"${_scopeId}><div class="btn btn-outline btn-warning mr-3 text-[12px]"${_scopeId}> Edit </div><div class="btn"${_scopeId}>Close</div></div></div></dialog></td></tr>`);
            });
            _push2(`<!--]--></tbody></table></div><div class="flex justify-end w-full mt-5"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_CompAdminButtonAddForm, {
              buttonName: "Save Sorting",
              isLoading: unref(loading),
              disabled: !unref(hasChanges)
            }, null, _parent2, _scopeId));
            _push2(`</div>`);
          } else {
            return [
              createVNode("div", { class: "overflow-x-auto !py-2 border rounded-t-lg" }, [
                createVNode("table", { class: "table table-xs md:table-md w-full rounded-t-xl" }, [
                  createVNode("thead", { class: "h-12" }, [
                    createVNode("tr", null, [
                      createVNode("th", { class: "font-medium" }, "Name"),
                      createVNode("th", { class: "font-medium" }, "Position")
                    ])
                  ]),
                  createVNode("tbody", null, [
                    (openBlock(true), createBlock(Fragment, null, renderList(unref(sortedSliderData), (item, index) => {
                      var _a, _b, _c;
                      return openBlock(), createBlock("tr", {
                        class: "odd:bg-gray-100 even:hover:bg-gray-100 transition-colors duration-300",
                        key: item.id
                      }, [
                        createVNode("td", { class: "text-gray-500 text-[12px] font-normal !py-2 md:text-sm" }, toDisplayString((_a = item == null ? void 0 : item.product) == null ? void 0 : _a.name), 1),
                        createVNode("td", { class: "text-gray-500 text-[12px] font-normal !py-2 md:text-sm" }, toDisplayString(item == null ? void 0 : item.position), 1),
                        createVNode("td", { class: "flex items-center gap-3" }, [
                          createVNode("div", {
                            class: "cursor-pointer btn btn-sm normal-case btn-ghost btn-square",
                            onClick: ($event) => showModal(index)
                          }, [
                            createVNode(_component_icon, {
                              name: "i-heroicons-pencil-square",
                              class: "cursor-pointer"
                            })
                          ], 8, ["onClick"]),
                          createVNode("dialog", {
                            id: "my_modal_" + index,
                            class: "modal"
                          }, [
                            createVNode("div", { class: "modal-box" }, [
                              createVNode("h3", { class: "font-bold text-lg" }, " Edit Position Sort of " + toDisplayString((_b = item == null ? void 0 : item.product) == null ? void 0 : _b.name) + "? ", 1),
                              withDirectives(createVNode("input", {
                                id: (_c = item == null ? void 0 : item.product) == null ? void 0 : _c.name,
                                type: "number",
                                placeholder: "Type here",
                                class: "input input-bordered input-sm w-full max-w-xs my-3",
                                "onUpdate:modelValue": ($event) => item.position = $event
                              }, null, 8, ["id", "onUpdate:modelValue"]), [
                                [vModelText, item.position]
                              ]),
                              createVNode("div", { class: "modal-action" }, [
                                createVNode("div", {
                                  onClick: ($event) => {
                                    var _a2, _b2;
                                    return addPosition(
                                      (_a2 = item == null ? void 0 : item.product) == null ? void 0 : _a2.id,
                                      (_b2 = item == null ? void 0 : item.product) == null ? void 0 : _b2.name,
                                      item == null ? void 0 : item.position,
                                      index
                                    );
                                  },
                                  class: "btn btn-outline btn-warning mr-3 text-[12px]"
                                }, " Edit ", 8, ["onClick"]),
                                createVNode("div", {
                                  onClick: ($event) => closeModal(index),
                                  class: "btn"
                                }, "Close", 8, ["onClick"])
                              ])
                            ])
                          ], 8, ["id"])
                        ])
                      ]);
                    }), 128))
                  ])
                ])
              ]),
              createVNode("div", { class: "flex justify-end w-full mt-5" }, [
                createVNode(_component_CompAdminButtonAddForm, {
                  buttonName: "Save Sorting",
                  isLoading: unref(loading),
                  disabled: !unref(hasChanges)
                }, null, 8, ["isLoading", "disabled"])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/onze-locaties/featured-property/add/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-b80c2c3d.mjs.map
