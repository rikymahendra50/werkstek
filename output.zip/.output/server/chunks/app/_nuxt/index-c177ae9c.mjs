import { _ as __nuxt_component_0 } from './ButtonAddIndex-0be538de.mjs';
import { u as useRequestOptions, d as useHead, _ as __nuxt_component_0$1 } from '../server.mjs';
import __nuxt_component_2 from './Icon-e394d28f.mjs';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { useSnackbar } from 'vue3-snackbar';
import { withAsyncContext, mergeProps, unref, withCtx, createVNode, useSSRContext } from 'vue';
import { u as useFetch } from './fetch-101122a4.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrRenderList, ssrInterpolate, ssrRenderAttr } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import './config-aab100d3.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import './asyncData-04c89180.mjs';

const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    useRequestHelper();
    const { requestOptions } = useRequestOptions();
    useSnackbar();
    const {
      data: type,
      error,
      refresh
    } = ([__temp, __restore] = withAsyncContext(() => useFetch(`/admins/type-list`, {
      method: "get",
      ...requestOptions
    }, "$9VYAD3Igtd")), __temp = await __temp, __restore(), __temp);
    useHead({
      title: "Type"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_CompAdminButtonAddIndex = __nuxt_component_0;
      const _component_NuxtLink = __nuxt_component_0$1;
      const _component_icon = __nuxt_component_2;
      _push(`<main${ssrRenderAttrs(mergeProps({ class: "flex-grow overflow-y-auto" }, _attrs))}><div class="mx-auto px-2 sm:px-6 lg:px-8 max-w-sm md:max-w-3xl lg:max-w-[720px] xl:max-w-7xl py-8 space-y-8"><div class="flex justify-between items-center"><div><div class="text-xl md:text-3xl font-bold">Type</div></div><div>`);
      _push(ssrRenderComponent(_component_CompAdminButtonAddIndex, {
        name: "Type",
        link: "type"
      }, null, _parent));
      _push(`</div></div><div><div class="overflow-x-auto !py-2 border rounded-t-lg"><table class="table table-xs md:table-md w-full rounded-t-xl"><thead class="h-12"><tr><th class="font-medium">Name</th><th class="font-medium"></th></tr></thead><tbody><!--[-->`);
      ssrRenderList(unref(type), (item, index) => {
        _push(`<tr class="odd:bg-gray-100 even:hover:bg-gray-100 transition-colors duration-300"><td class="text-gray-500 font-normal !py-2 text-[12px] md:text-sm">${ssrInterpolate(item.name)}</td><td class="flex justify-center gap-4 my-1">`);
        _push(ssrRenderComponent(_component_NuxtLink, {
          to: `/admin/type/edit/${item.id}`,
          class: "cursor-pointer btn btn-sm normal-case btn-ghost btn-square"
        }, {
          default: withCtx((_, _push2, _parent2, _scopeId) => {
            if (_push2) {
              _push2(ssrRenderComponent(_component_icon, { name: "i-heroicons-pencil-square" }, null, _parent2, _scopeId));
            } else {
              return [
                createVNode(_component_icon, { name: "i-heroicons-pencil-square" })
              ];
            }
          }),
          _: 2
        }, _parent));
        _push(`<div class="cursor-pointer btn btn-sm normal-case btn-ghost btn-square">`);
        _push(ssrRenderComponent(_component_icon, { name: "i-heroicons-trash" }, null, _parent));
        _push(`</div><dialog${ssrRenderAttr("id", "my_modal_" + index)} class="modal"><div class="modal-box"><h3 class="font-bold text-lg text-red-500">Warning !</h3><p class="py-4 text-sm"> Are you sure want to delete this item called ${ssrInterpolate(item.name)}? </p><div class="modal-action"><form method="dialog"><button class="btn btn-outline btn-error mr-3 text-[12px]"> Delete </button><button class="btn">Close</button></form></div></div></dialog></td></tr>`);
      });
      _push(`<!--]--></tbody></table></div></div></div></main>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/type/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-c177ae9c.mjs.map
