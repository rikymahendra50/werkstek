import { _ as __nuxt_component_0 } from './HeaderWCity-239feb2c.mjs';
import { _ as __nuxt_component_0$1 } from './TitleHeader-ee000471.mjs';
import __nuxt_component_2$1 from './Icon-7d2a1472.mjs';
import { d as useHead, u as useRouter, a as useRoute, j as useAsyncData, i as _export_sfc, _ as __nuxt_component_0$1$1 } from '../server.mjs';
import { u as useDateFormatter } from './useConvertTime-0bc9d513.mjs';
import { useSSRContext, ref, computed, withAsyncContext, watch, mergeProps, unref, isRef, withCtx, createVNode, toDisplayString, openBlock, createBlock } from 'vue';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderAttr, ssrInterpolate, ssrRenderList, ssrIncludeBooleanAttr, ssrRenderStyle } from 'vue/server-renderer';
import { _ as _imports_0$1 } from './arrow-right-150377ce.mjs';
import { _ as __nuxt_component_3 } from './Pagination-d765680b.mjs';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { _ as _imports_0, a as _imports_1 } from './marker-dropdown-d764c93e.mjs';
import { u as useTimeoutFn } from './index-73677d9a.mjs';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import './config-54e8ad1b.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main$2 = {
  __name: "eachVacatures",
  __ssrInlineRender: true,
  props: {
    link: {
      type: String
    },
    category: {
      type: [String, Number],
      default: "Opervlakte"
    },
    address: {
      type: [String, Number],
      default: "address"
    },
    latitude: {},
    longitude: {},
    image: {
      type: String,
      default: "/images/image-not-found.png"
    },
    rating: {
      default: "Rating"
    },
    type: {
      default: "Level type"
    },
    name: {},
    time: {
      type: String,
      default: "Time Update"
    },
    phone: {
      default: 31302393838
    },
    hours: {},
    detailLinkTitle: {
      type: String,
      default: "Neem een kijkje"
    }
  },
  setup(__props) {
    const { formatDate } = useDateFormatter();
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1$1;
      _push(`<div${ssrRenderAttrs(_attrs)}>`);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: __props.link,
        class: "grid grid-cols-8 grid-rows-1 mb-2 lg:mb-5 ounded-lg group hover:shadow-lg transition min-h-[150px] sm:min-h-[170px] md:min-h-[200px]",
        style: { "box-shadow": "2px 4px 15px rgba(0, 0, 0, 0.05)" }
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="grid col-span-4 md:col-span-4 md:min-h-[210px] h-full bg-no-repeat bg-cover rounded-lg relative text-white" style="${ssrRenderStyle({
              backgroundImage: `url('${__props.image}')`,
              background: `linear-gradient(90deg, rgba(251,249,249,0) 39%, rgba(255,255,255,1) 100%), url('${__props.image}')`,
              backgroundPosition: "center center",
              backgroundRepeat: "no-repeat",
              backgroundSize: "cover"
            })}"${_scopeId}></div><div class="grid col-span-4 md:col-span-4 ml-3 sm:ml-4 md:ml-5 items-center md:pr-4 py-1"${_scopeId}><span class="text-[11px] sm:text-sm lg:text-base font-semibold"${_scopeId}>${ssrInterpolate(__props.name)}</span>`);
            if (__props.address == null) {
              _push2(`<span class="text-[10px] sm:text-sm text-ellipsis"${_scopeId}>${ssrInterpolate(__props.category)}</span>`);
            } else {
              _push2(`<span class="text-[10px] sm:text-[12px] text-ellipsis line-clamp-1 lg:line-clamp-2 opacity-90"${_scopeId}>${ssrInterpolate(__props.category)}</span>`);
            }
            _push2(`<div class="flex justify-between"${_scopeId}><span class="text-[10px] sm:text-sm"${_scopeId}>${ssrInterpolate(__props.hours)} vuur</span><span class="text-[10px] sm:text-sm"${_scopeId}>${ssrInterpolate(unref(formatDate)(__props.time))}</span></div><div class="flex justify-end w-full"${_scopeId}><div class="flex mt-2 sm:mt-0"${_scopeId}><div class="flex relative bottom-0 mt-2 sm:mt-4 border border-primary group-hover:border-secondary w-fit items-center rounded-full"${_scopeId}><span class="py-2 pl-3 pr-2 sm:py-3 sm:pl-4 sm:pr-3 text-primary group-hover:text-secondary text-[10px] sm:text-sm font-medium"${_scopeId}>${ssrInterpolate(__props.detailLinkTitle)}</span><div class="bg-primary group-hover:bg-secondary w-[25px] h-[25px] sm:w-[37px] sm:h-[37px] rounded-full mr-1"${_scopeId}><img${ssrRenderAttr("src", _imports_0$1)} alt="arrow"${_scopeId}></div></div></div></div></div>`);
          } else {
            return [
              createVNode("div", {
                class: "grid col-span-4 md:col-span-4 md:min-h-[210px] h-full bg-no-repeat bg-cover rounded-lg relative text-white",
                style: {
                  backgroundImage: `url('${__props.image}')`,
                  background: `linear-gradient(90deg, rgba(251,249,249,0) 39%, rgba(255,255,255,1) 100%), url('${__props.image}')`,
                  backgroundPosition: "center center",
                  backgroundRepeat: "no-repeat",
                  backgroundSize: "cover"
                }
              }, null, 4),
              createVNode("div", { class: "grid col-span-4 md:col-span-4 ml-3 sm:ml-4 md:ml-5 items-center md:pr-4 py-1" }, [
                createVNode("span", { class: "text-[11px] sm:text-sm lg:text-base font-semibold" }, toDisplayString(__props.name), 1),
                __props.address == null ? (openBlock(), createBlock("span", {
                  key: 0,
                  class: "text-[10px] sm:text-sm text-ellipsis"
                }, toDisplayString(__props.category), 1)) : (openBlock(), createBlock("span", {
                  key: 1,
                  class: "text-[10px] sm:text-[12px] text-ellipsis line-clamp-1 lg:line-clamp-2 opacity-90"
                }, toDisplayString(__props.category), 1)),
                createVNode("div", { class: "flex justify-between" }, [
                  createVNode("span", { class: "text-[10px] sm:text-sm" }, toDisplayString(__props.hours) + " vuur", 1),
                  createVNode("span", { class: "text-[10px] sm:text-sm" }, toDisplayString(unref(formatDate)(__props.time)), 1)
                ]),
                createVNode("div", { class: "flex justify-end w-full" }, [
                  createVNode("div", { class: "flex mt-2 sm:mt-0" }, [
                    createVNode("div", { class: "flex relative bottom-0 mt-2 sm:mt-4 border border-primary group-hover:border-secondary w-fit items-center rounded-full" }, [
                      createVNode("span", { class: "py-2 pl-3 pr-2 sm:py-3 sm:pl-4 sm:pr-3 text-primary group-hover:text-secondary text-[10px] sm:text-sm font-medium" }, toDisplayString(__props.detailLinkTitle), 1),
                      createVNode("div", { class: "bg-primary group-hover:bg-secondary w-[25px] h-[25px] sm:w-[37px] sm:h-[37px] rounded-full mr-1" }, [
                        createVNode("img", {
                          src: _imports_0$1,
                          alt: "arrow"
                        })
                      ])
                    ])
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div>`);
    };
  }
};
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/eachVacatures.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_2 = _sfc_main$2;
const _sfc_main$1 = {
  __name: "OnzeVacaturies",
  __ssrInlineRender: true,
  async setup(__props) {
    let __temp, __restore;
    const { requestOptions } = useRequestOptions();
    const router = useRouter();
    useRoute();
    const page = ref(1);
    const selectedCity = ref("");
    const selectedMinHours = ref("");
    const selectedMaxHours = ref("");
    const selectedFunctie = ref([]);
    const locations = ref([]);
    const soortLocatiesRadio = ref([]);
    const variableToggleLocatie = ref();
    const selectedCityForShow = ref("Locatie");
    const selectedFacilities = computed(() => {
      if (selectedFunctie.value.length > 0) {
        return `filter[types]=${selectedFunctie.value.join("|")}`;
      } else {
        return "";
      }
    });
    const {
      data: dataProduct2,
      error,
      refresh
    } = ([__temp, __restore] = withAsyncContext(() => useAsyncData(
      "dataProduct2",
      () => $fetch(
        `/jobs?filter[location_id]=${selectedCity.value}&filter[min_hours]=${selectedMinHours.value}&filter[max_hours]=${selectedMaxHours.value}&${selectedFacilities.value}`,
        {
          method: "get",
          ...requestOptions
        }
      )
    )), __temp = await __temp, __restore(), __temp);
    const { start, stop } = useTimeoutFn(() => {
      replaceWindow();
    }, 100);
    watch(
      () => page.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          start();
        }
      }
    );
    watch(
      () => selectedMinHours.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          page.value = 1;
          start();
        }
      }
    );
    watch(
      () => selectedMaxHours.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          page.value = 1;
          start();
        }
      }
    );
    watch(
      () => selectedCity.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          page.value = 1;
          start();
        }
      }
    );
    watch(
      () => selectedFunctie.value,
      (newValue, oldValue) => {
        if (newValue !== oldValue) {
          page.value = 1;
          start();
        }
      }
    );
    const showFilter = ref();
    const city = computed(() => {
      return locations.value.map((item) => item);
    });
    function isSelectedFuncti(id) {
      return selectedFunctie.value.includes(id);
    }
    function replaceWindow() {
      let filters = [];
      if (selectedCity.value) {
        filters.push(`location=${selectedCity.value}`);
      }
      if (selectedMaxHours.value) {
        filters.push(`max_hours=${selectedMaxHours.value}`);
      }
      if (selectedMinHours.value) {
        filters.push(`min_hours=${selectedMinHours.value}`);
      }
      if (selectedFunctie == null ? void 0 : selectedFunctie.value) {
        const facilitiesQuery = selectedFunctie.value.join("|");
        filters.push(`facilities=${facilitiesQuery}`);
      }
      const queryString = filters.join("&");
      const url = `/onze-vacatures?page=${page.value}${queryString ? `&${queryString}` : ""}`;
      router.replace(url);
      refresh();
    }
    return (_ctx, _push, _parent, _attrs) => {
      var _a, _b, _c, _d, _e, _f, _g;
      const _component_TitleHeader = __nuxt_component_0$1;
      const _component_Icon = __nuxt_component_2$1;
      const _component_eachVacatures = __nuxt_component_2;
      const _component_Pagination = __nuxt_component_3;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "pb-20 overflow-hidden" }, _attrs))} data-v-4afab038>`);
      _push(ssrRenderComponent(_component_TitleHeader, {
        title: "Onze locaties",
        secondTitle: "Bekijk al onze vacatures",
        description: "Op deze locaties hebben we kantoorruimtes"
      }, null, _parent));
      _push(`<div class="md:grid md:grid-cols-12 container-custom" data-v-4afab038><div class="md:col-span-4 sm:w-[90%]" data-v-4afab038><div class="mt-5" data-v-4afab038><button class="btn w-full bg-primary hover:bg-secondary text-white font-bold py-2 px-4 rounded normal-case text-md" data-v-4afab038> Al Vacatures </button><button class="flex items-center gap-3 hover:text-primary" data-v-4afab038><img${ssrRenderAttr("src", _imports_0)} class="w-5 h-5 my-4" alt="filter" data-v-4afab038><p class="text-base opacity-50" data-v-4afab038>Meer filter opties</p></button></div>`);
      if (unref(showFilter)) {
        _push(`<div data-v-4afab038><div class="relative" data-v-4afab038><div class="text-base mt-3 opacity-50" data-v-4afab038>Kies een locatie</div><div class="w-full border py-3 rounded-lg px-2 flex justify-between items-center cursor-pointer mt-2 select-none" data-v-4afab038><div class="flex items-center gap-2" data-v-4afab038><img${ssrRenderAttr("src", _imports_1)} alt="markers" data-v-4afab038><p class="text-[#ADA7A7] text-base" data-v-4afab038>${ssrInterpolate(unref(selectedCityForShow))}</p></div>`);
        _push(ssrRenderComponent(_component_Icon, {
          name: "ep:arrow-up-bold",
          class: "text-[#ADA7A7] rotate-180"
        }, null, _parent));
        _push(`</div>`);
        if (unref(variableToggleLocatie)) {
          _push(`<div class="w-full absolute bg-white mt-2 z-10 select-none" data-v-4afab038><ul class="flex flex-col rounded-lg border text-[#ADA7A7] max-h-[150px] overflow-y-auto" data-v-4afab038><!--[-->`);
          ssrRenderList(unref(city), (item, index) => {
            _push(`<li class="hover:bg-primary bg-white hover:text-white cursor-pointer pl-3 py-2 rounded-lg" data-v-4afab038>${ssrInterpolate(item.name)}</li>`);
          });
          _push(`<!--]--></ul></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div><div class="flex flex-col" data-v-4afab038><p class="text-sm mt-3 opacity-50" data-v-4afab038>Vuur</p><div class="grid grid-cols-2 my-2" data-v-4afab038><div class="relative" data-v-4afab038><input type="number" id="MinPrice" placeholder="Min" min="0" class="input input-bordered w-[95%] p-[10px]input-md"${ssrRenderAttr("value", unref(selectedMinHours))} data-v-4afab038><br data-v-4afab038><span class="absolute top-3 right-8" data-v-4afab038>vuur</span></div><div class="relative" data-v-4afab038><input type="number" id="MaxPrice" min="0" placeholder="Max" class="input input-bordered w-[95%] p-[10px] input-md"${ssrRenderAttr("value", unref(selectedMaxHours))} data-v-4afab038><br data-v-4afab038><span class="absolute top-3 right-8" data-v-4afab038>vuur</span></div></div><div class="" data-v-4afab038><p class="text-base mt-3 opacity-50 pb-3" data-v-4afab038>Opleidings niveau</p><fieldset id="facility" class="grid grid-cols-1 gap-2" data-v-4afab038><!--[-->`);
        ssrRenderList(unref(soortLocatiesRadio), (item) => {
          _push(`<div class="flex items-center gap-2 cursor-pointer" data-v-4afab038><input${ssrRenderAttr("id", `facility-${item.id}`)}${ssrRenderAttr("value", item.name)} type="checkbox" name="facility"${ssrIncludeBooleanAttr(isSelectedFuncti(item.id)) ? " checked" : ""} data-v-4afab038><label${ssrRenderAttr("for", `facility-${item.id}`)} class="cursor-pointer" data-v-4afab038>${ssrInterpolate(item.name)}</label></div>`);
        });
        _push(`<!--]--></fieldset></div></div></div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div><div class="md:col-span-8 py-5 overflow-auto" data-v-4afab038><div class="max-h-[400px] md:max-h-[870px] flex flex-col scrollbar-onze" data-v-4afab038>`);
      if ((_a = unref(dataProduct2)) == null ? void 0 : _a.data) {
        _push(`<!--[-->`);
        ssrRenderList((_b = unref(dataProduct2)) == null ? void 0 : _b.data, (item, index) => {
          _push(ssrRenderComponent(_component_eachVacatures, {
            key: item == null ? void 0 : item.id,
            image: item == null ? void 0 : item.image,
            link: `/onze-vacatures/${item == null ? void 0 : item.slug}`,
            name: item == null ? void 0 : item.title,
            hours: item == null ? void 0 : item.hours,
            category: item == null ? void 0 : item.category,
            time: item == null ? void 0 : item.updated_at
          }, null, _parent));
        });
        _push(`<!--]-->`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
      if ((_c = unref(dataProduct2)) == null ? void 0 : _c.meta) {
        _push(ssrRenderComponent(_component_Pagination, {
          includeFirstLast: false,
          modelValue: unref(page),
          "onUpdate:modelValue": ($event) => isRef(page) ? page.value = $event : null,
          first: "Eerst",
          last: "Laatst",
          prev: "Vorig",
          next: "Volgende",
          total: (_e = (_d = unref(dataProduct2)) == null ? void 0 : _d.meta) == null ? void 0 : _e.total,
          "per-page": (_g = (_f = unref(dataProduct2)) == null ? void 0 : _f.meta) == null ? void 0 : _g.per_page,
          class: "flex justify-center mt-10"
        }, null, _parent));
      } else {
        _push(`<!---->`);
      }
      _push(`</div></div></section>`);
    };
  }
};
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/OnzeVacaturies.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-4afab038"]]);
const _sfc_main = {
  __name: "index",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Onze Vacatures"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_HeaderWCity = __nuxt_component_0;
      const _component_OnzeVacaturies = __nuxt_component_1;
      _push(`<!--[--><div class="mt-20"></div>`);
      _push(ssrRenderComponent(_component_HeaderWCity, {
        title1: "Bekijk onze locaties",
        title2: "De Werkstek Vacatures",
        description: "Werkstek is een bedrijf die leegstaande panden omtovert tot bruisende broedplaatsen. Een groot deel van ons bedrijf draait om het werven van start-ups en creatievelingen voor onze broedplaatsen. Het werven van deze partijen gebeurt voor een groot deel online. Het is dan ook belangrijk dat onze online presence er goed en aantrekkelijk uitziet."
      }, null, _parent));
      _push(ssrRenderComponent(_component_OnzeVacaturies, null, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/onze-vacatures/index.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=index-c91ea281.mjs.map
