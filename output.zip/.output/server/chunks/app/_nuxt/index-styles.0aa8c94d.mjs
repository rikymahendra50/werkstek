const Blog2_vue_vue_type_style_index_0_scoped_b66094e9_lang = ".scrollbar-hidden[data-v-b66094e9]{-ms-overflow-style:none;overflow-y:auto;scrollbar-width:none}.scrollbar-hidden[data-v-b66094e9]::-webkit-scrollbar{display:none}";

const indexStyles_0aa8c94d = [Blog2_vue_vue_type_style_index_0_scoped_b66094e9_lang];

export { indexStyles_0aa8c94d as default };
//# sourceMappingURL=index-styles.0aa8c94d.mjs.map
