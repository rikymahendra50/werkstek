const OnzeVacaturies_vue_vue_type_style_index_0_scoped_4afab038_lang = ".scrollbar-onze[data-v-4afab038]{-ms-overflow-style:none;overflow-y:auto;scrollbar-width:none}.scrollbar-onze[data-v-4afab038]::-webkit-scrollbar{display:none}";

const indexStyles_1c867c20 = [OnzeVacaturies_vue_vue_type_style_index_0_scoped_4afab038_lang];

export { indexStyles_1c867c20 as default };
//# sourceMappingURL=index-styles.1c867c20.mjs.map
