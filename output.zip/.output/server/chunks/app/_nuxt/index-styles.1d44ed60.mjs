const index_vue_vue_type_style_index_0_scoped_f61f4c6f_lang = ".overflow-auto[data-v-f61f4c6f]{max-height:400px;overflow-y:auto}.overflow-auto[data-v-f61f4c6f]::-webkit-scrollbar{display:none}";

const indexStyles_1d44ed60 = [index_vue_vue_type_style_index_0_scoped_f61f4c6f_lang, index_vue_vue_type_style_index_0_scoped_f61f4c6f_lang];

export { indexStyles_1d44ed60 as default };
//# sourceMappingURL=index-styles.1d44ed60.mjs.map
