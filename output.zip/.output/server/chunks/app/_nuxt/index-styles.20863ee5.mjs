const OnzeLocaties_vue_vue_type_style_index_0_scoped_83070ae1_lang = ".scrollbar-onze[data-v-83070ae1]{-ms-overflow-style:none;overflow-y:auto;scrollbar-width:none}.scrollbar-onze[data-v-83070ae1]::-webkit-scrollbar{display:none}";

const indexStyles_20863ee5 = [OnzeLocaties_vue_vue_type_style_index_0_scoped_83070ae1_lang];

export { indexStyles_20863ee5 as default };
//# sourceMappingURL=index-styles.20863ee5.mjs.map
