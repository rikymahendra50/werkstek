const index_vue_vue_type_style_index_0_scoped_1d73d932_lang = ".overflow-auto[data-v-1d73d932]{overflow-y:auto}.overflow-auto[data-v-1d73d932]::-webkit-scrollbar{display:none}";

const indexStyles_49ee37e5 = [index_vue_vue_type_style_index_0_scoped_1d73d932_lang, index_vue_vue_type_style_index_0_scoped_1d73d932_lang];

export { indexStyles_49ee37e5 as default };
//# sourceMappingURL=index-styles.49ee37e5.mjs.map
