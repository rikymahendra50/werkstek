const index_vue_vue_type_style_index_0_scoped_6d7995bc_lang = ".overflow-auto[data-v-6d7995bc]{overflow-y:auto}.overflow-auto[data-v-6d7995bc]::-webkit-scrollbar{display:none}";

const indexStyles_550c2b25 = [index_vue_vue_type_style_index_0_scoped_6d7995bc_lang, index_vue_vue_type_style_index_0_scoped_6d7995bc_lang];

export { indexStyles_550c2b25 as default };
//# sourceMappingURL=index-styles.550c2b25.mjs.map
