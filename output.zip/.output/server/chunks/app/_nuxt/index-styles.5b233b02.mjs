const OnzeLocaties_vue_vue_type_style_index_0_scoped_3ef98672_lang = ".scrollbar-onze[data-v-3ef98672]{-ms-overflow-style:none;overflow-y:auto;scrollbar-width:none}.scrollbar-onze[data-v-3ef98672]::-webkit-scrollbar{display:none}";

const indexStyles_5b233b02 = [OnzeLocaties_vue_vue_type_style_index_0_scoped_3ef98672_lang];

export { indexStyles_5b233b02 as default };
//# sourceMappingURL=index-styles.5b233b02.mjs.map
