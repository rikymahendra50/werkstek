const index_vue_vue_type_style_index_0_scoped_883f4740_lang = ".scrollBarAdmin[data-v-883f4740]::-webkit-scrollbar{display:none}.overflow-auto[data-v-883f4740]{max-height:400px;overflow-y:auto}.overflow-auto[data-v-883f4740]::-webkit-scrollbar{display:none}";

const indexStyles_68a67473 = [index_vue_vue_type_style_index_0_scoped_883f4740_lang, index_vue_vue_type_style_index_0_scoped_883f4740_lang];

export { indexStyles_68a67473 as default };
//# sourceMappingURL=index-styles.68a67473.mjs.map
