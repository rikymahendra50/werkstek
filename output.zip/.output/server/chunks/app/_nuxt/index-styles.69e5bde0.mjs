const OnzeVacaturies_vue_vue_type_style_index_0_scoped_dec13135_lang = ".scrollbar-onze[data-v-dec13135]{-ms-overflow-style:none;overflow-y:auto;scrollbar-width:none}.scrollbar-onze[data-v-dec13135]::-webkit-scrollbar{display:none}";

const indexStyles_69e5bde0 = [OnzeVacaturies_vue_vue_type_style_index_0_scoped_dec13135_lang];

export { indexStyles_69e5bde0 as default };
//# sourceMappingURL=index-styles.69e5bde0.mjs.map
