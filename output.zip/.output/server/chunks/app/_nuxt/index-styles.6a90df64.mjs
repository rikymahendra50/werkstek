const index_vue_vue_type_style_index_0_scoped_a7e3a3fa_lang = ".overflow-auto[data-v-a7e3a3fa]{max-height:400px;overflow-y:auto}.overflow-auto[data-v-a7e3a3fa]::-webkit-scrollbar{display:none}";

const indexStyles_6a90df64 = [index_vue_vue_type_style_index_0_scoped_a7e3a3fa_lang, index_vue_vue_type_style_index_0_scoped_a7e3a3fa_lang];

export { indexStyles_6a90df64 as default };
//# sourceMappingURL=index-styles.6a90df64.mjs.map
