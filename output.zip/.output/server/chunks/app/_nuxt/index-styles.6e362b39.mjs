const OnzeLocaties_vue_vue_type_style_index_0_scoped_8250e67b_lang = ".scrollbar-onze[data-v-8250e67b]{-ms-overflow-style:none;overflow-y:auto;scrollbar-width:none}.scrollbar-onze[data-v-8250e67b]::-webkit-scrollbar{display:none}";

const indexStyles_6e362b39 = [OnzeLocaties_vue_vue_type_style_index_0_scoped_8250e67b_lang];

export { indexStyles_6e362b39 as default };
//# sourceMappingURL=index-styles.6e362b39.mjs.map
