const index_vue_vue_type_style_index_0_scoped_cddceffa_lang = ".scrollBarAdmin[data-v-cddceffa]::-webkit-scrollbar{display:none}.overflow-auto[data-v-cddceffa]{max-height:400px;overflow-y:auto}.overflow-auto[data-v-cddceffa]::-webkit-scrollbar{display:none}";

const indexStyles_6ed99cd4 = [index_vue_vue_type_style_index_0_scoped_cddceffa_lang, index_vue_vue_type_style_index_0_scoped_cddceffa_lang];

export { indexStyles_6ed99cd4 as default };
//# sourceMappingURL=index-styles.6ed99cd4.mjs.map
