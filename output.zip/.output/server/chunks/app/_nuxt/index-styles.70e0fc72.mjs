const index_vue_vue_type_style_index_0_scoped_d90b1e13_lang = ".scrollBarAdmin[data-v-d90b1e13]::-webkit-scrollbar{display:none}.overflow-auto[data-v-d90b1e13]{max-height:400px;overflow-y:auto}.overflow-auto[data-v-d90b1e13]::-webkit-scrollbar{display:none}";

const indexStyles_70e0fc72 = [index_vue_vue_type_style_index_0_scoped_d90b1e13_lang, index_vue_vue_type_style_index_0_scoped_d90b1e13_lang];

export { indexStyles_70e0fc72 as default };
//# sourceMappingURL=index-styles.70e0fc72.mjs.map
