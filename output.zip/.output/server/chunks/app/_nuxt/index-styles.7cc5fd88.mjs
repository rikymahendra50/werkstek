const index_vue_vue_type_style_index_0_scoped_9aad3a76_lang = ".scrollBarAdmin[data-v-9aad3a76]::-webkit-scrollbar{display:none}.overflow-auto[data-v-9aad3a76]{max-height:400px;overflow-y:auto}.overflow-auto[data-v-9aad3a76]::-webkit-scrollbar{display:none}";

const indexStyles_7cc5fd88 = [index_vue_vue_type_style_index_0_scoped_9aad3a76_lang, index_vue_vue_type_style_index_0_scoped_9aad3a76_lang];

export { indexStyles_7cc5fd88 as default };
//# sourceMappingURL=index-styles.7cc5fd88.mjs.map
