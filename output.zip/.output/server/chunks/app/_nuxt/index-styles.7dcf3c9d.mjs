const index_vue_vue_type_style_index_0_scoped_a0e7edfb_lang = ".overflow-auto[data-v-a0e7edfb]{max-height:400px;overflow-y:auto}.overflow-auto[data-v-a0e7edfb]::-webkit-scrollbar{display:none}";

const indexStyles_7dcf3c9d = [index_vue_vue_type_style_index_0_scoped_a0e7edfb_lang, index_vue_vue_type_style_index_0_scoped_a0e7edfb_lang];

export { indexStyles_7dcf3c9d as default };
//# sourceMappingURL=index-styles.7dcf3c9d.mjs.map
