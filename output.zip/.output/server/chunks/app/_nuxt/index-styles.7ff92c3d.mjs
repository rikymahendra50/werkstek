const index_vue_vue_type_style_index_0_scoped_05a2e04c_lang = ".overflow-auto[data-v-05a2e04c]{max-height:400px;overflow-y:auto}.overflow-auto[data-v-05a2e04c]::-webkit-scrollbar{display:none}";

const indexStyles_7ff92c3d = [index_vue_vue_type_style_index_0_scoped_05a2e04c_lang, index_vue_vue_type_style_index_0_scoped_05a2e04c_lang];

export { indexStyles_7ff92c3d as default };
//# sourceMappingURL=index-styles.7ff92c3d.mjs.map
