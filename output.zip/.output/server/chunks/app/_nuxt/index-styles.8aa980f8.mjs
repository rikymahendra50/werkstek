const index_vue_vue_type_style_index_0_lang = ".scrollBarAdmin::-webkit-scrollbar{display:none}";

const indexStyles_8aa980f8 = [index_vue_vue_type_style_index_0_lang, index_vue_vue_type_style_index_0_lang];

export { indexStyles_8aa980f8 as default };
//# sourceMappingURL=index-styles.8aa980f8.mjs.map
