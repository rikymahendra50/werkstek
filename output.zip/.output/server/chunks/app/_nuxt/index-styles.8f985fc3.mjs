const index_vue_vue_type_style_index_0_scoped_ebb6776a_lang = ".overflow-auto[data-v-ebb6776a]{max-height:400px;overflow-y:auto}.overflow-auto[data-v-ebb6776a]::-webkit-scrollbar{display:none}";

const indexStyles_8f985fc3 = [index_vue_vue_type_style_index_0_scoped_ebb6776a_lang, index_vue_vue_type_style_index_0_scoped_ebb6776a_lang];

export { indexStyles_8f985fc3 as default };
//# sourceMappingURL=index-styles.8f985fc3.mjs.map
