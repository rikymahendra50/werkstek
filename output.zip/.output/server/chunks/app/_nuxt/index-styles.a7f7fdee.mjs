const index_vue_vue_type_style_index_0_scoped_53f0cf12_lang = ".overflow-auto[data-v-53f0cf12]{overflow-y:auto}.overflow-auto[data-v-53f0cf12]::-webkit-scrollbar{display:none}";

const indexStyles_a7f7fdee = [index_vue_vue_type_style_index_0_scoped_53f0cf12_lang, index_vue_vue_type_style_index_0_scoped_53f0cf12_lang];

export { indexStyles_a7f7fdee as default };
//# sourceMappingURL=index-styles.a7f7fdee.mjs.map
