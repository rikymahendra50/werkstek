const Community2_vue_vue_type_style_index_0_scoped_ca445f1b_lang = ".scrollbar-hidden[data-v-ca445f1b]{-ms-overflow-style:none;overflow-y:auto;scrollbar-width:none}.scrollbar-hidden[data-v-ca445f1b]::-webkit-scrollbar{display:none}";

const indexStyles_b179fdf8 = [Community2_vue_vue_type_style_index_0_scoped_ca445f1b_lang];

export { indexStyles_b179fdf8 as default };
//# sourceMappingURL=index-styles.b179fdf8.mjs.map
