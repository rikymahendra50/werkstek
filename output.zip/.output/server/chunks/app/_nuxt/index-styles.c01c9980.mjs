const index_vue_vue_type_style_index_0_scoped_5a269988_lang = ".overflow-auto[data-v-5a269988]{overflow-y:auto}.overflow-auto[data-v-5a269988]::-webkit-scrollbar{display:none}";

const indexStyles_c01c9980 = [index_vue_vue_type_style_index_0_scoped_5a269988_lang, index_vue_vue_type_style_index_0_scoped_5a269988_lang];

export { indexStyles_c01c9980 as default };
//# sourceMappingURL=index-styles.c01c9980.mjs.map
