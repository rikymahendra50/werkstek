const index_vue_vue_type_style_index_0_scoped_fa6bca42_lang = ".overflow-auto[data-v-fa6bca42]{overflow-y:auto}.overflow-auto[data-v-fa6bca42]::-webkit-scrollbar{display:none}";

const indexStyles_c8f3ee9e = [index_vue_vue_type_style_index_0_scoped_fa6bca42_lang, index_vue_vue_type_style_index_0_scoped_fa6bca42_lang];

export { indexStyles_c8f3ee9e as default };
//# sourceMappingURL=index-styles.c8f3ee9e.mjs.map
