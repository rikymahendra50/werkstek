const index_vue_vue_type_style_index_0_scoped_e70d382b_lang = ".overflow-auto[data-v-e70d382b]{overflow-y:auto}.overflow-auto[data-v-e70d382b]::-webkit-scrollbar{display:none}";

const indexStyles_d2c8dd1e = [index_vue_vue_type_style_index_0_scoped_e70d382b_lang, index_vue_vue_type_style_index_0_scoped_e70d382b_lang];

export { indexStyles_d2c8dd1e as default };
//# sourceMappingURL=index-styles.d2c8dd1e.mjs.map
