const index_vue_vue_type_style_index_0_scoped_9a1f4a7f_lang = ".overflow-auto[data-v-9a1f4a7f]{overflow-y:auto}.overflow-auto[data-v-9a1f4a7f]::-webkit-scrollbar{display:none}";

const indexStyles_d2d5a27f = [index_vue_vue_type_style_index_0_scoped_9a1f4a7f_lang, index_vue_vue_type_style_index_0_scoped_9a1f4a7f_lang];

export { indexStyles_d2d5a27f as default };
//# sourceMappingURL=index-styles.d2d5a27f.mjs.map
