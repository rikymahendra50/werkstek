const index_vue_vue_type_style_index_0_scoped_94580168_lang = ".overflow-auto[data-v-94580168]{max-height:400px;overflow-y:auto}.overflow-auto[data-v-94580168]::-webkit-scrollbar{display:none}";

const indexStyles_e15df5d2 = [index_vue_vue_type_style_index_0_scoped_94580168_lang, index_vue_vue_type_style_index_0_scoped_94580168_lang];

export { indexStyles_e15df5d2 as default };
//# sourceMappingURL=index-styles.e15df5d2.mjs.map
