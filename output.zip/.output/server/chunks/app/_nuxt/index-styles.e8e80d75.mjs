const index_vue_vue_type_style_index_0_scoped_7cffe5cc_lang = ".overflow-auto[data-v-7cffe5cc]{overflow-y:auto}.overflow-auto[data-v-7cffe5cc]::-webkit-scrollbar{display:none}";

const indexStyles_e8e80d75 = [index_vue_vue_type_style_index_0_scoped_7cffe5cc_lang, index_vue_vue_type_style_index_0_scoped_7cffe5cc_lang];

export { indexStyles_e8e80d75 as default };
//# sourceMappingURL=index-styles.e8e80d75.mjs.map
