const index_vue_vue_type_style_index_0_scoped_9861d9b5_lang = ".overflow-auto[data-v-9861d9b5]{overflow-y:auto}.overflow-auto[data-v-9861d9b5]::-webkit-scrollbar{display:none}";

const indexStyles_fac9ca39 = [index_vue_vue_type_style_index_0_scoped_9861d9b5_lang, index_vue_vue_type_style_index_0_scoped_9861d9b5_lang];

export { indexStyles_fac9ca39 as default };
//# sourceMappingURL=index-styles.fac9ca39.mjs.map
