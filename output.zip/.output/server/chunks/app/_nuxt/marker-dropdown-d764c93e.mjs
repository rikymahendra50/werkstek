import { p as publicAssetsURL } from '../../handlers/renderer.mjs';

const _imports_0 = "" + publicAssetsURL("images/filter-icon.svg");
const _imports_1 = "" + publicAssetsURL("images/marker-dropdown.svg");

export { _imports_0 as _, _imports_1 as a };
//# sourceMappingURL=marker-dropdown-d764c93e.mjs.map
