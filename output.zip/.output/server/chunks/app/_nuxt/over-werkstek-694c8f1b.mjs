import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0 } from './VerhuurdersHeader-a2d481b0.mjs';
import { d as useHead, h as _export_sfc, _ as __nuxt_component_0$1 } from '../server.mjs';
import { unref, useSSRContext, ref, withCtx, createVNode, openBlock, createBlock } from 'vue';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderAttr } from 'vue/server-renderer';
import { _ as __nuxt_component_3 } from './LeegstandNoButton-7b7e2600.mjs';
import { _ as __nuxt_component_4 } from './BgBigGreen-1402b0e9.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'vee-validate';
import './useRequestHelper-553b0504.mjs';
import './fetch-101122a4.mjs';
import './asyncData-04c89180.mjs';
import './arrow-small-right-9e640e2c.mjs';

const _imports_0 = "" + publicAssetsURL("images/logo-werstek-big.svg");
const _sfc_main$1 = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  const _component_NuxtLink = __nuxt_component_0$1;
  _push(`<section${ssrRenderAttrs(_attrs)}><div class="grid min-[440px]:grid-cols-12 gap-5"><div class="bg-tertiary flex col-span-6 sm:col-span-5 rounded-r-full items-center w-[70%] min-[450px]:w-full justify-center p-5"><img${ssrRenderAttr("src", _imports_0)} alt="logo-werstek-big" class="my-3 max-w-[140px] sm:max-w-[200px] md:max-w-[250px]"></div><div class="col-span-6 flex-flex-col flex justify-center flex-col gap-4 lg:gap-10 mx-4 min-[420px]:w-[mx-2] md:mx-10 text-[12px] sm:text-[14px] lg:text-base"><p class="text-justify"> Werkstek is een bedrijf dat kantoorruimtes verhuurt in verschillende indelingen en groottes, vari\xEBrend van 20m3 voor werkplekken. Wij bieden flexibele oplossingen die aansluiten bij de behoeften van ondernemers, waardoor je als verhuurder geen zorgen hoeft te maken over de risico&#39;s van leegstand. </p>`);
  _push(ssrRenderComponent(_component_NuxtLink, {
    to: "https://maps.app.goo.gl/B2n6ZjGxupqbL2nt7",
    class: "group"
  }, {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div class="flex items-center gap-3"${_scopeId}><span class="h-[30px] w-[30px] lg:h-[40px] lg:w-[40px]"${_scopeId}><svg width="100%" height="100%" viewBox="0 0 46 46" fill="none" xmlns="http://www.w3.org/2000/svg"${_scopeId}><path d="M36.6328 0.539062H9.36719C7.02646 0.541131 4.78219 1.4719 3.12705 3.12705C1.4719 4.78219 0.541131 7.02646 0.539062 9.36719V36.6328C0.541131 38.9735 1.4719 41.2178 3.12705 42.873C4.78219 44.5281 7.02646 45.4589 9.36719 45.4609H36.6328C38.9735 45.4589 41.2178 44.5281 42.873 42.873C44.5281 41.2178 45.4589 38.9735 45.4609 36.6328V9.36719C45.4589 7.02646 44.5281 4.78219 42.873 3.12705C41.2178 1.4719 38.9735 0.541131 36.6328 0.539062ZM23.4375 37.0625C23.3825 37.1242 23.3151 37.1736 23.2397 37.2074C23.1643 37.2412 23.0826 37.2587 23 37.2587C22.9174 37.2587 22.8357 37.2412 22.7603 37.2074C22.6849 37.1736 22.6175 37.1242 22.5625 37.0625C22.1562 36.6094 12.5312 25.8125 12.5312 19.875C12.5312 13.7578 17.2188 8.77344 23 8.77344C28.7812 8.77344 33.4688 13.7266 33.4688 19.875C33.4688 25.8125 23.8438 36.6094 23.4375 37.0625Z" fill="#859C81"${_scopeId}></path><path d="M23 23.3281C25.4551 23.3281 27.4453 21.3379 27.4453 18.8828C27.4453 16.4277 25.4551 14.4375 23 14.4375C20.5449 14.4375 18.5547 16.4277 18.5547 18.8828C18.5547 21.3379 20.5449 23.3281 23 23.3281Z" fill="#859C81" class="bg-secondary"${_scopeId}></path></svg></span><span class="text-black font-bold text-[12px] lg:text-sm"${_scopeId}>Breitnerstraat 19, Arnhem, 6813HN, Nederland</span></div>`);
      } else {
        return [
          createVNode("div", { class: "flex items-center gap-3" }, [
            createVNode("span", { class: "h-[30px] w-[30px] lg:h-[40px] lg:w-[40px]" }, [
              (openBlock(), createBlock("svg", {
                width: "100%",
                height: "100%",
                viewBox: "0 0 46 46",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg"
              }, [
                createVNode("path", {
                  d: "M36.6328 0.539062H9.36719C7.02646 0.541131 4.78219 1.4719 3.12705 3.12705C1.4719 4.78219 0.541131 7.02646 0.539062 9.36719V36.6328C0.541131 38.9735 1.4719 41.2178 3.12705 42.873C4.78219 44.5281 7.02646 45.4589 9.36719 45.4609H36.6328C38.9735 45.4589 41.2178 44.5281 42.873 42.873C44.5281 41.2178 45.4589 38.9735 45.4609 36.6328V9.36719C45.4589 7.02646 44.5281 4.78219 42.873 3.12705C41.2178 1.4719 38.9735 0.541131 36.6328 0.539062ZM23.4375 37.0625C23.3825 37.1242 23.3151 37.1736 23.2397 37.2074C23.1643 37.2412 23.0826 37.2587 23 37.2587C22.9174 37.2587 22.8357 37.2412 22.7603 37.2074C22.6849 37.1736 22.6175 37.1242 22.5625 37.0625C22.1562 36.6094 12.5312 25.8125 12.5312 19.875C12.5312 13.7578 17.2188 8.77344 23 8.77344C28.7812 8.77344 33.4688 13.7266 33.4688 19.875C33.4688 25.8125 23.8438 36.6094 23.4375 37.0625Z",
                  fill: "#859C81"
                }),
                createVNode("path", {
                  d: "M23 23.3281C25.4551 23.3281 27.4453 21.3379 27.4453 18.8828C27.4453 16.4277 25.4551 14.4375 23 14.4375C20.5449 14.4375 18.5547 16.4277 18.5547 18.8828C18.5547 21.3379 20.5449 23.3281 23 23.3281Z",
                  fill: "#859C81",
                  class: "bg-secondary"
                })
              ]))
            ]),
            createVNode("span", { class: "text-black font-bold text-[12px] lg:text-sm" }, "Breitnerstraat 19, Arnhem, 6813HN, Nederland")
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
  _push(`</div></div></section>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/LogoandLocation.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
function useOverWerkstek() {
  const VerhuurdersHeaderData = ref({
    image: "/images/image-page5-1.png",
    title1: "Verhuurders",
    title2: "Alles over Werkstek",
    description1: "Als verhuurder leegstand van kantoorpanden voorkomen? Geen zorgen over de risico\u2019s van leegstand van kantoorgebouwen?",
    description2: "Werkstek heeft de kennis en ervaring om leegstaande kantoorpanden in te richten en te verhuren aan ondernemers uit verschillende branches.",
    buttonTitle1: "Over Werkstek",
    buttonLink1: "/faq"
  });
  return {
    VerhuurdersHeaderData
  };
}
const _sfc_main = {
  __name: "over-werkstek",
  __ssrInlineRender: true,
  setup(__props) {
    const { VerhuurdersHeaderData } = useOverWerkstek();
    useHead({
      title: "Over Werkstek"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VerhuurdersHeader = __nuxt_component_0;
      const _component_LogoandLocation = __nuxt_component_1;
      const _component_LeegstandNoButton = __nuxt_component_3;
      const _component_BgBigGreen = __nuxt_component_4;
      _push(`<!--[--><div class="mt-16"></div>`);
      _push(ssrRenderComponent(_component_VerhuurdersHeader, {
        image: unref(VerhuurdersHeaderData).image,
        title1: unref(VerhuurdersHeaderData).title1,
        title2: unref(VerhuurdersHeaderData).title2,
        description1: unref(VerhuurdersHeaderData).description1,
        description2: unref(VerhuurdersHeaderData).description2,
        buttonTitle1: unref(VerhuurdersHeaderData).buttonTitle1,
        buttonLink1: unref(VerhuurdersHeaderData).buttonLink1
      }, null, _parent));
      _push(ssrRenderComponent(_component_LogoandLocation, { class: "py-10" }, null, _parent));
      _push(ssrRenderComponent(_component_LeegstandNoButton, {
        uniqueIdProp: 7,
        image: "/images/over-page2-1.png",
        title: "Betaalbare werkplekken",
        description: "Als zzp\u2019er of kleine ondernemer huur je bij Werkstek een werkplek of kantoorunit die voor jou betaalbaar is. Wij zorgen voor een makkelijk bereikbare kantoorlocatie en een goede inrichting van jouw werkplek. Als huurder van een werkplek bij Werkstek maak je gebruik van alle gezamenlijke faciliteiten."
      }, null, _parent));
      _push(ssrRenderComponent(_component_LeegstandNoButton, {
        uniqueIdProp: 8,
        background: "bg-[#EEF3ED]",
        image: "/images/image-page5-3.png",
        title: "Samen ondernemen",
        description: "Werkstek biedt onderdak aan huurders uit verschillende branches. Wij vinden het belangrijk dat onze ondernemers elkaar makkelijk weten te vinden. Door gemeenschappelijke ruimtes te cre\xEBren en regelmatig evenementen te organiseren brengen we onze huurders bij elkaar. Zo ontstaat een community van ondernemers die elkaar stimuleren en inspireren.",
        leftToRight: false
      }, null, _parent));
      _push(ssrRenderComponent(_component_LeegstandNoButton, {
        uniqueIdProp: 9,
        image: "/images/image-page5-4.png",
        title: "Voor verhuurders",
        description: "Wil je je kantoorpand op een makkelijke manier verhuren? Werkstek ontzorgt: zowel de inrichting als de verhuur van kantoorruimtes nemen we uit handen. Wij zorgen voor een effici\xEBnte verdeling van de ruimtes en verhuren vervolgens werkplekken en kantoorunits aan zzp\u2019ers en kleine ondernemingen. Zo voorkomen we leegstand van kantoorgebouwen en brengen we vraag en aanbod bij elkaar."
      }, null, _parent));
      _push(ssrRenderComponent(_component_BgBigGreen, {
        title1: "Aanmelden",
        title2: "Het proces.",
        title3: "Wil je een werkplek of kantoorunit huren? Dan kun je je natuurlijk meteen inschrijven. Je kunt ook gebruik maken van ons stappenplan, zodat er een juiste match is tussen jou en je toekomstige werkplek in het kantoorgebouw van jouw keuze.",
        showEmailSection: false,
        showButtonSection: true,
        linkButtonSmaller: "/faq",
        ShowSmallerButton: true,
        showPhoneEmail: false,
        backgroundColor: "secondary"
      }, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/over-werkstek.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=over-werkstek-694c8f1b.mjs.map
