import { d as useHead, _ as __nuxt_component_0$1 } from '../server.mjs';
import { mergeProps, withCtx, createTextVNode, useSSRContext } from 'vue';
import { ssrRenderAttrs, ssrRenderComponent } from 'vue/server-renderer';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';

const _sfc_main = {
  __name: "privacy-verklaring",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Privacy verklaring"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<section${ssrRenderAttrs(mergeProps({ class: "container-custom mt-32 mb-20" }, _attrs))}><div class="grid gap-4"><h1 class="text-[40px] font-bold text-[#404040]">Privacyverklaring</h1><p class="text-lg"> Deze pagina is op 24 mei 2018 voor het laast aangepast. </p><p class="text-lg"> De website www.werkstek.nl is de online uiting van het Werkstek B.V., KVK: 64476723 </p></div><br><p class="text-lg leading-loose"> Als een bezoeker van deze website een formulier invult of ons een email stuurt waarin persoonlijke informatie staat. Slaan we dit op. In deze privacyverklaring leggen we uit wat we opslaan, waarom we dat doen, waarvoor we deze informatie gebruiken en hoe lang we uw gegevens opslaan. <br><br> Voor vragen of opmerkingen kunt u altijd mailen naar `);
      _push(ssrRenderComponent(_component_NuxtLink, {
        to: "mailto:info@werkstek.nl",
        class: "hover:text-primary"
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`info@werkstek.nl`);
          } else {
            return [
              createTextVNode("info@werkstek.nl")
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</p><br><p class="text-lg leading-loose"> Wij zetten ons altijd in om uw persoonlijke gegevens met grote zorg te verwerken en veilig op te slaan. Dit doen we in lijn met de Europese wetgeving omtrent privacy de AVG, ook wel de GDPR genoemd. </p><br><h1 class="text-[30px] font-bold text-[#404040]"> Hoe we de gegevens verzamelen en opslaan </h1><br><p class="text-lg leading-loose"> Op de website van Werkstek staan diverse formulieren waarmee u uw persoonlijke gegevens zoals uw bedrijfsnaam, uw naam, email adres en/of telefoonnummer kunt doorgeven aan ons. </p><br><p class="text-lg leading-loose"> Wij gebruiken de service van Airtable (www.airtable.com) om de ingevulde formulieren op te slaan. Hun privacyverklaring is hier te lezen: <a href="https://airtable.com/privacy."></a></p><br><p class="text-lg leading-loose"> Via cookies (kleine stukjes code) verzamelen we data over het gebruik van de bezoekers op de website. Deze informatie wordt door google analytics verzameld. Hun privacyverklaring is hier te vinden: <a href="https://policies.google.com/privacy" class="hover:text-primary">https://policies.google.com/privacy</a></p><br><h1 class="text-[30px] font-bold text-[#404040]"> Waarom we deze gegevens bewaren </h1><br><p class="text-lg leading-loose"> We gebruiken deze gegevens om telefonisch of via email contact met u op te kunnen nemen over zaken die met Werkstek te maken hebben. We delen deze gegevens nooit met derden zonder eerst uw toestemming te vragen. </p><br><h1 class="text-[30px] font-bold">Hoe lang we deze gegevens bewaren:</h1><br><p class="text-lg leading-loose"> Als u op deze website een formulier invult, of ons een e-mail of brief stuurt, dan worden de gegevens die je ons toestuurt bewaard zolang het relevant is voor de samenwerking. Als u niet meer in onze database wil staan kunt u ons dit telefonisch of via de email laten weten. We zullen uw gegevens direct verwijderen. </p><br><h1 class="text-[30px] font-bold text-[#404040]">Statistieken</h1><br><p class="text-lg leading-loose"> Voor de meting van het gebruik van deze website verzamelt werkstek.nl in de meeste gevallen anonieme gegevens over het gebruik van de website. Door analyse van de verzamelde gegevens kan de website worden verbeterd en kan werkstek.nl beter inzien hoe mensen de website gebruiken. De verzamelde gegevens worden niet voor een ander doel gebruikt. </p><br><h1 class="text-[30px] font-bold text-[#404040]"> Inzage en wijziging van jouw gegevens. </h1><br><p class="text-lg leading-loose"> Het gaat om de volgende gegevens: je IP-adres, het adres van je internetprovider, de browser die je gebruikt het tijdstip en de duur van je bezoek en welke pagina\u2019s je hebt bezocht. </p></section>`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/privacy-verklaring.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=privacy-verklaring-a88ef33c.mjs.map
