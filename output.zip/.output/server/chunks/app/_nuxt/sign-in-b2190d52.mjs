import { _ as __nuxt_component_0 } from './Werkstek-58cf971d.mjs';
import { Form } from 'vee-validate';
import { _ as _sfc_main$1 } from './TextField-7edd2a1a.mjs';
import { d as useHead, b as useFetch, R as Role, P as Provider, _ as __nuxt_component_0$1, h as useNuxtApp } from '../server.mjs';
import { defineComponent, ref, mergeProps, unref, withCtx, createTextVNode, createVNode, useSSRContext } from 'vue';
import { u as useRequestHelper } from './useRequestHelper-553b0504.mjs';
import { u as useRequestOptions } from './useRequestOptions-0d03dffc.mjs';
import { u as useSchema } from './useSchema-3365865c.mjs';
import { ssrRenderAttrs, ssrRenderComponent, ssrIncludeBooleanAttr } from 'vue/server-renderer';
import '../../handlers/renderer.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'zod';
import '@vee-validate/zod';

const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "sign-in",
  __ssrInlineRender: true,
  setup(__props) {
    const { $setCredential } = useNuxtApp();
    const { loading, message, alertType, setErrorMessage, transformErrors } = useRequestHelper();
    const { requestOptions } = useRequestOptions();
    const { loginSchema } = useSchema();
    const form = ref({
      email: "",
      password: ""
    });
    async function onSubmit(values, ctx) {
      var _a, _b, _c, _d, _e;
      loading.value = true;
      const { data, error } = await useFetch("/admins/login", {
        method: "post",
        body: { ...form.value },
        ...requestOptions
      }, "$PZYdOEX1dg");
      if (error.value) {
        setErrorMessage((_b = (_a = error.value) == null ? void 0 : _a.data) == null ? void 0 : _b.message);
        ctx.setErrors(transformErrors((_c = error.value) == null ? void 0 : _c.data));
      } else if ((_d = data.value) == null ? void 0 : _d.token) {
        $setCredential({
          token: (_e = data == null ? void 0 : data.value) == null ? void 0 : _e.token,
          role: Role.ADMIN,
          provider: Provider.LOCAL
        });
        window.location.replace("/admin");
      }
      loading.value = false;
    }
    useHead({
      title: "Login"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_Werkstek = __nuxt_component_0;
      const _component_VeeForm = Form;
      const _component_FormTextField = _sfc_main$1;
      const _component_NuxtLink = __nuxt_component_0$1;
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "grid place-items-center items-center h-screen" }, _attrs))}><div class="w-[500px] p-10 justify-center shadow-lg">`);
      _push(ssrRenderComponent(_component_Werkstek, { class: "mb-10" }, null, _parent));
      _push(ssrRenderComponent(_component_VeeForm, {
        "validation-schema": unref(loginSchema),
        onSubmit
      }, {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex flex-col space-y-4"${_scopeId}><div class="flex flex-col"${_scopeId}><label for="email" class="pb-1 text-lg"${_scopeId}>Email</label>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "email",
              name: "email",
              modelValue: unref(form).email,
              "onUpdate:modelValue": ($event) => unref(form).email = $event,
              placeholder: "Email",
              class: "input input-bordered"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="flex flex-col"${_scopeId}><label for="password" class="pb-1 text-lg"${_scopeId}>Password</label>`);
            _push2(ssrRenderComponent(_component_FormTextField, {
              id: "password",
              name: "password",
              modelValue: unref(form).password,
              "onUpdate:modelValue": ($event) => unref(form).password = $event,
              placeholder: "*******",
              type: "password",
              class: "input input-bordered"
            }, null, _parent2, _scopeId));
            _push2(`</div><div class="mt-5"${_scopeId}><button${ssrIncludeBooleanAttr(unref(loading)) ? " disabled" : ""} type="submit" class="btn bg-[#F0912D] text-white w-full hover:bg-secondary"${_scopeId}> Sign In </button></div><div class="mt-5"${_scopeId}>`);
            _push2(ssrRenderComponent(_component_NuxtLink, {
              to: "/admin/forgot-password",
              disabled: unref(loading),
              type: "submit",
              class: "p-2 text-center text-primary hover:text-secondary w-full rounded-lg hover:border-secondary"
            }, {
              default: withCtx((_2, _push3, _parent3, _scopeId2) => {
                if (_push3) {
                  _push3(` Forgot Password? `);
                } else {
                  return [
                    createTextVNode(" Forgot Password? ")
                  ];
                }
              }),
              _: 1
            }, _parent2, _scopeId));
            _push2(`</div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex flex-col space-y-4" }, [
                createVNode("div", { class: "flex flex-col" }, [
                  createVNode("label", {
                    for: "email",
                    class: "pb-1 text-lg"
                  }, "Email"),
                  createVNode(_component_FormTextField, {
                    id: "email",
                    name: "email",
                    modelValue: unref(form).email,
                    "onUpdate:modelValue": ($event) => unref(form).email = $event,
                    placeholder: "Email",
                    class: "input input-bordered"
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode("div", { class: "flex flex-col" }, [
                  createVNode("label", {
                    for: "password",
                    class: "pb-1 text-lg"
                  }, "Password"),
                  createVNode(_component_FormTextField, {
                    id: "password",
                    name: "password",
                    modelValue: unref(form).password,
                    "onUpdate:modelValue": ($event) => unref(form).password = $event,
                    placeholder: "*******",
                    type: "password",
                    class: "input input-bordered"
                  }, null, 8, ["modelValue", "onUpdate:modelValue"])
                ]),
                createVNode("div", { class: "mt-5" }, [
                  createVNode("button", {
                    disabled: unref(loading),
                    type: "submit",
                    class: "btn bg-[#F0912D] text-white w-full hover:bg-secondary"
                  }, " Sign In ", 8, ["disabled"])
                ]),
                createVNode("div", { class: "mt-5" }, [
                  createVNode(_component_NuxtLink, {
                    to: "/admin/forgot-password",
                    disabled: unref(loading),
                    type: "submit",
                    class: "p-2 text-center text-primary hover:text-secondary w-full rounded-lg hover:border-secondary"
                  }, {
                    default: withCtx(() => [
                      createTextVNode(" Forgot Password? ")
                    ]),
                    _: 1
                  }, 8, ["disabled"])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
      _push(`</div></div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/admin/sign-in.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=sign-in-b2190d52.mjs.map
