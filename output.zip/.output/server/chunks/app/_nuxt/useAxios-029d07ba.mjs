import { e as useCookie, f as useRuntimeConfig } from '../server.mjs';
import axios from 'axios';

function useAxios() {
  var _a;
  const config = /* @__PURE__ */ useRuntimeConfig();
  const credential = useCookie("auth-token", {
    expires: new Date(Date.now() + 12096e5),
    // 2 weeks from now
    sameSite: "lax",
    path: "/",
    watch: true
  });
  const axiosContext = axios.create({
    baseURL: config.public.API_ENDPOINT,
    headers: {
      Authorization: "Bearer " + ((_a = credential.value) == null ? void 0 : _a.token)
    }
  });
  const clearCredential = async () => {
  };
  axiosContext.interceptors.response.use(
    (response) => response,
    (error) => {
      if (error.response && error.response.status === 401) {
        clearCredential();
      }
      return Promise.reject(error);
    }
  );
  return {
    axiosRequest: axiosContext
  };
}

export { useAxios as u };
//# sourceMappingURL=useAxios-029d07ba.mjs.map
