import { useSSRContext, ref, defineComponent, mergeProps } from 'vue';
import { ssrRenderAttrs, ssrRenderAttr, ssrInterpolate, ssrRenderSlot } from 'vue/server-renderer';

const _sfc_main = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "Group",
  __ssrInlineRender: true,
  props: {
    /**
     * input label
     * @type {string}
     * @example
     */
    label: {
      type: String,
      required: true
    },
    name: {
      type: String,
      required: true
    }
  },
  setup(__props) {
    const props = __props;
    return (_ctx, _push, _parent, _attrs) => {
      _push(`<div${ssrRenderAttrs(mergeProps({ class: "grid grid-cols-1 gap-1 text-left" }, _attrs))}><label${ssrRenderAttr("for", props.name)} class="tracking-wide font-medium">${ssrInterpolate(props.label)}</label>`);
      if (_ctx.$slots.descriptionTop) {
        _push(`<div class="form-description">`);
        ssrRenderSlot(_ctx.$slots, "descriptionTop", {}, null, _push, _parent);
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      ssrRenderSlot(_ctx.$slots, "default", {}, null, _push, _parent);
      if (_ctx.$slots.descriptionBottom) {
        _push(`<div class="form-description">`);
        ssrRenderSlot(_ctx.$slots, "descriptionBottom", {}, null, _push, _parent);
        _push(`</div>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</div>`);
    };
  }
});
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Form/Group.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
function useForgotPassword() {
  const stateForm = ref({
    email: "",
    otp: "",
    password: "",
    password_confirmation: ""
  });
  const showPinEmailExpired = ref(false);
  const secondTime = ref(60);
  function countdown() {
    const interval = setInterval(() => {
      if (secondTime.value === 0) {
        clearInterval(interval);
        showPinEmailExpired.value = true;
      } else {
        secondTime.value--;
      }
    }, 1e3);
  }
  return {
    stateForm,
    countdown,
    showPinEmailExpired,
    secondTime
  };
}

export { _sfc_main as _, useForgotPassword as u };
//# sourceMappingURL=useForgotPassword-e6ea2eaa.mjs.map
