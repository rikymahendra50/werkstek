import { ref } from 'vue';

const useRequestHelper = () => {
  const message = ref("");
  const alertType = ref("success");
  const loading = ref(false);
  function transformErrors(errorObject) {
    const transformedObject = ref({});
    for (let key in errorObject.errors) {
      transformedObject.value[key] = errorObject.errors[key][0];
    }
    return transformedObject.value;
  }
  function setSuccessMessage(successMessage) {
    message.value = successMessage;
    alertType.value = "success";
  }
  function setErrorMessage(errorMessage) {
    message.value = errorMessage;
    alertType.value = "error";
  }
  return {
    message,
    alertType,
    loading,
    transformErrors,
    setSuccessMessage,
    setErrorMessage
  };
};

export { useRequestHelper as u };
//# sourceMappingURL=useRequestHelper-553b0504.mjs.map
