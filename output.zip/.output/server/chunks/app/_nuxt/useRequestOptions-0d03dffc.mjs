import { e as useCookie, f as useRuntimeConfig } from '../server.mjs';

function useRequestOptions() {
  const config = /* @__PURE__ */ useRuntimeConfig();
  const credential = useCookie("auth-token", {
    expires: new Date(Date.now() + 12096e5),
    // 2 weeks from now
    sameSite: "lax",
    path: "/",
    watch: true
  });
  async function clearCredential() {
  }
  function onRequest(context) {
    var _a, _b;
    context.options.headers = context.options.headers || {};
    context.options.headers.authorization = ((_a = credential.value) == null ? void 0 : _a.token) ? "Bearer " + ((_b = credential.value) == null ? void 0 : _b.token) : "";
  }
  function onResponseError(context) {
    if (context.response.status === 401) {
      return clearCredential();
    }
  }
  const requestOptions = {
    baseURL: config.public.API_ENDPOINT,
    onRequest: (contex) => onRequest(contex),
    onResponseError: (context) => onResponseError(context)
  };
  return {
    requestOptions
  };
}

export { useRequestOptions as u };
//# sourceMappingURL=useRequestOptions-0d03dffc.mjs.map
