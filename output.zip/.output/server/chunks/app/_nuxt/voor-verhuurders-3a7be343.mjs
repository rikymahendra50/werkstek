import { p as publicAssetsURL } from '../../handlers/renderer.mjs';
import { _ as __nuxt_component_0 } from './VerhuurdersHeader-531d6c1f.mjs';
import { useSSRContext, mergeProps } from 'vue';
import { ssrRenderComponent, ssrRenderAttrs, ssrRenderAttr, ssrInterpolate } from 'vue/server-renderer';
import { d as useHead, i as _export_sfc } from '../server.mjs';
import { _ as __nuxt_component_0$1 } from './building-map-interactive-f174b598.mjs';
import { _ as __nuxt_component_4$1, a as __nuxt_component_1$1 } from './BgBigGreen-554b8e3d.mjs';
import { _ as __nuxt_component_3 } from './LeegstandNoButton-70f79216.mjs';
import { _ as __nuxt_component_4 } from './MapInteractive-ae8c81de.mjs';
import { _ as __nuxt_component_6 } from './SliderTestimony-e6194ec8.mjs';
import 'vue-bundle-renderer/runtime';
import '../../nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
import 'devalue';
import '@unhead/ssr';
import 'unhead';
import '@unhead/shared';
import 'vue-router';
import 'vue3-snackbar';
import '@floating-ui/utils';
import 'is-https';
import 'vue-tel-input';
import 'vee-validate';
import './useRequestHelper-553b0504.mjs';
import './useRequestOptions-0d03dffc.mjs';
import './arrow-small-right-9e640e2c.mjs';
import './Icon-7d2a1472.mjs';
import './config-54e8ad1b.mjs';
import '@iconify/vue/dist/offline';
import '@iconify/vue';
import './useAxios-029d07ba.mjs';
import 'axios';
import './arrow-right-150377ce.mjs';
import './TitleHeader-ee000471.mjs';
import 'swiper/vue';
import 'swiper/modules';

const _imports_0 = "" + publicAssetsURL("images/people-logo.png");
const _sfc_main$2 = {};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs) {
  _push(`<section${ssrRenderAttrs(mergeProps({ class: "container-custom" }, _attrs))}><div class="grid sm:grid-cols-12 sm:gap-4"><div class="col-span-6 grid grid-cols-12 min-h-[170px] sm:min-h-[200px] gap-1"><div class="bg-quaternary rounded-full max-w-[16px] box-shadow flex flex-col justify-center"></div><div class="col-span-11 rounded-2xl bg-primary text-tertiary flex flex-col justify-center gap-3 p-3 pl-2 xl:px-10 br"><h1 class="text-lg md:text-2xl xl:text-3xl font-regular xl:w-[70%] px-2 sm:px-0"> Werkstek wordt vertrouwt door </h1></div></div><div class="col-span-6 mt-10 sm:mt-5 md:mt-0"><div class="flex justify-center items-center flex-col"><img${ssrRenderAttr("src", _imports_0)} alt="people-logo" class="w-[100%] max-w-[300px] sm:w-[70%] h-24"><p class="text-[12px] sm:text-sm text-start sm:text-center font-regular"> Vanuit people@places hebben we zeer goede ervaringen met Werkstek. Er wordt altijd snel geschakeld en het contact met Ernst verloopt prettig. Hij kijkt altijd naar een oplossing voor alle partijen. We werken met Werkstek op verschillende locaties naar alle tevredenheid. Ernst is correct, commercieel gedreven en betrokken en altijd op zoek naar het beste resultaat. </p></div></div></div></section>`);
}
const _sfc_setup$2 = _sfc_main$2.setup;
_sfc_main$2.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/VertrouwdDoor.vue");
  return _sfc_setup$2 ? _sfc_setup$2(props, ctx) : void 0;
};
const __nuxt_component_1 = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main$1 = {
  props: {
    image: {
      type: String,
      required: true
    },
    title: {
      type: String,
      required: true
    },
    description: {
      type: String,
      required: true
    },
    buttonTitle1: {
      type: String,
      required: false
    },
    buttonLink1: {
      type: String,
      required: false
    },
    buttonTitle2: {
      type: String,
      required: false
    },
    buttonLink2: {
      type: String,
      required: false
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_ButtonPrimary = __nuxt_component_0$1;
  const _component_ButtonSM = __nuxt_component_1$1;
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "grid md:grid-cols-2 items-center container-custom my-10 lg:gap-6 min-[1231px]:gap-0" }, _attrs))}><div class="flex sm:order-1 w-full"><div class="w-[70%] md:w-full"><img${ssrRenderAttr("src", $props.image)} alt="image" class="object-contain"></div></div><div class="flex flex-col sm:mx-5 xl:mx-16 order-1 sm:order-2 w-full"><h1 class="text-xl lg:text-[36px] text-[#404040] my-2 md:my-7 mt-4 font-bold">${ssrInterpolate($props.title)}</h1><p class="text-[12px] md:text-[14px] lg:text-[16px] leading-6 lg:leading-9 text-justify pr-3 sm:pr-6 md:pr-[30px] lg:pr-[40px] xl:pr-[106px]">${ssrInterpolate($props.description)}</p><div class="grid min-[350px]:grid-cols-12 min-[903px]:grid-cols-12 items-center gap-4 lg:gap-0 my-5">`);
  _push(ssrRenderComponent(_component_ButtonPrimary, {
    buttonTitle: $props.buttonTitle1,
    buttonLink: $props.buttonLink1,
    class: "w-fit col-span-4 lg:col-span-4"
  }, null, _parent));
  _push(ssrRenderComponent(_component_ButtonSM, {
    buttonTitle: $props.buttonTitle2,
    buttonLink: $props.buttonLink2,
    class: "col-span-7 lg:col-span-7"
  }, null, _parent));
  _push(`</div></div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/LeegstandWbutton.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const __nuxt_component_2 = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender]]);
const _sfc_main = {
  __name: "voor-verhuurders",
  __ssrInlineRender: true,
  setup(__props) {
    useHead({
      title: "Voor-Verhuurders"
    });
    return (_ctx, _push, _parent, _attrs) => {
      const _component_VerhuurdersHeader = __nuxt_component_0;
      const _component_VertrouwdDoor = __nuxt_component_1;
      const _component_LeegstandWbutton = __nuxt_component_2;
      const _component_LeegstandNoButton = __nuxt_component_3;
      const _component_MapInteractive = __nuxt_component_4;
      const _component_BgBigGreen = __nuxt_component_4$1;
      const _component_SliderTestimony = __nuxt_component_6;
      _push(`<!--[--><div class="mt-16"></div>`);
      _push(ssrRenderComponent(_component_VerhuurdersHeader, {
        image: "/images/image-page4-1.png",
        imageAlt: "image-page4-1",
        title1: "Verhuurders",
        title2: "Voor de verhuurders",
        description1: "Als verhuurder leegstand van kantoorpanden voorkomen? Geen zorgen over de risico\u2019s van leegstand van kantoorgebouwen?",
        description2: "Werkstek heeft de kennis en ervaring om leegstaande kantoorpanden in te richten en te verhuren aan ondernemers uit verschillende branches.",
        buttonTitle1: "Over Werkstek",
        buttonTitle2: "Voor verhuurders",
        buttonLink1: "/over-werkstek",
        buttonLink2: "/over-werkstek",
        useButton2: false
      }, null, _parent));
      _push(ssrRenderComponent(_component_VertrouwdDoor, null, null, _parent));
      _push(ssrRenderComponent(_component_LeegstandWbutton, {
        image: "/images/over-page2-1.png",
        title: "Leegstand vullen",
        description: "Werkstek heeft als doel oplossingen te vinden voor leegstaand vastgoed. Dat doen we door servicekosten of onkosten te betalen om placemakers of kwartiermakers voor een lage huur te laten werken waardoor de locatie aantrekkelijker wordt. Door een goede verdeling van de ruimtes en een effici\xEBnte inrichting maakt Werkstek deze kantoorruimtes geschikt voor zzp\u2019ers en kleine ondernemingen.",
        buttonTitle1: "Schrijf je in",
        buttonTitle2: "Bekijk onze locaties",
        buttonLink1: "https://api.whatsapp.com/send?phone=0850290598",
        buttonLink2: "/onze-locaties"
      }, null, _parent));
      _push(ssrRenderComponent(_component_LeegstandNoButton, {
        background: "bg-tertiary",
        image: "/images/ruimtes.png",
        uniqueIdProp: 4,
        imageAlt: "image-page4-3",
        title: "Ruimtes inrichten",
        description: "Werkstek richt kantoorruimtes in zodat deze aantrekkelijk zijn voor zzp\u2019ers en ondernemingen. Daarbij houden wij rekening met de wensen en behoeften van onze huurders. Zo kijken we bijvoorbeeld of er een ruimte aanwezig is of gecre\xEBerd kan worden voor het organiseren van evenementen.",
        leftToRight: false
      }, null, _parent));
      _push(ssrRenderComponent(_component_MapInteractive, {
        ShowContainerCustom: false,
        class: "container-custom my-10"
      }, null, _parent));
      _push(ssrRenderComponent(_component_LeegstandNoButton, {
        uniqueIdProp: 5,
        image: "/images/ruimtes_proten.png",
        imageAlt: "image-page4-4",
        title: "Ruimtes promoten",
        description: "Via onze website, social media en google marketing promoten wij de kantoorpanden die we willen verhuren. Bovendien zetten we regelmatig online marketingcampagnes in om potenti\xEBle huurders van werkplekken en kantoorunits aan te trekken. Tegen een lage prijs ontwikkelen we een website, logo en branding voor je kantoorpand.",
        leftToRight: true
      }, null, _parent));
      _push(ssrRenderComponent(_component_LeegstandNoButton, {
        uniqueIdProp: 6,
        image: "/images/facilitien.png",
        imageAlt: "image-page4-5",
        title: "Faciliteiten",
        description: "Om het plaatje compleet te maken leveren wij pand gebonden faciliteiten zoals receptiediensten (hostess/ kwartiermaker/ Placemaker) en ondersteunde horeca en cateringdiensten (marketing gedreven horecaondernemer/ Wundermart).",
        leftToRight: false
      }, null, _parent));
      _push(ssrRenderComponent(_component_BgBigGreen, {
        title1: "Aanvragen",
        title2: "Ge\xEFnteresseerd?",
        title3: "Neem dan contact met ons op. Samen zoeken we jouw perfecte werkplek.",
        showButtonSection: true,
        linkButtonSmaller: "/Faq",
        backgroundColor: "secondary"
      }, null, _parent));
      _push(ssrRenderComponent(_component_SliderTestimony, null, null, _parent));
      _push(`<!--]-->`);
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("pages/voor-verhuurders.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};

export { _sfc_main as default };
//# sourceMappingURL=voor-verhuurders-3a7be343.mjs.map
