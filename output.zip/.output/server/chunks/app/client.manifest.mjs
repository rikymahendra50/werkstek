const client_manifest = {
  "BgBigGreen.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "BgBigGreen.f4cc734e.css",
    "src": "BgBigGreen.css"
  },
  "MapInteractive.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "MapInteractive.ffc01d21.css",
    "src": "MapInteractive.css"
  },
  "SliderLocatiesSort.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "SliderLocatiesSort.a9d13604.css",
    "src": "SliderLocatiesSort.css"
  },
  "SliderTestimony.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "SliderTestimony.29a5e60b.css",
    "src": "SliderTestimony.css"
  },
  "TextEditor.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "TextEditor.65389021.css",
    "src": "TextEditor.css"
  },
  "_BackButton.4f9b5027.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "BackButton.4f9b5027.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_BgBigGreen.08d1effd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "BgBigGreen.f4cc734e.css"
    ],
    "file": "BgBigGreen.08d1effd.js",
    "imports": [
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_arrow-small-right.f134a89f.js"
    ]
  },
  "BgBigGreen.f4cc734e.css": {
    "file": "BgBigGreen.f4cc734e.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Blog.af69d081.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Blog.af69d081.js",
    "imports": [
      "_TitleHeader.8c7c1887.js",
      "_EachBlogSmall.d1f7316e.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_BlogImageCrop.a753f6a6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "BlogImageCrop.a753f6a6.js",
    "imports": [
      "_swiper-vue.c4ed3832.js",
      "_index.eb66e43d.js",
      "_client-only.8db14b52.js"
    ]
  },
  "_BlogItem.19ed3f29.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "BlogItem.19ed3f29.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_client-only.8db14b52.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_ButtonAddForm.c9876862.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ButtonAddForm.c9876862.js",
    "imports": [
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_ButtonAddIndex.88abfb55.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ButtonAddIndex.88abfb55.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_EachBlog.7fbcc1cd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "EachBlog.7fbcc1cd.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_EachBlogSmall.d1f7316e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "EachBlogSmall.d1f7316e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_client-only.8db14b52.js",
      "_arrow-right.7f05de45.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_HeaderWCity.25be3157.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "HeaderWCity.25be3157.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_LeegstandNoButton.dbd1875e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "LeegstandNoButton.dbd1875e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_MapInteractive.42ccc241.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "MapInteractive.ffc01d21.css"
    ],
    "file": "MapInteractive.42ccc241.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useAxios.5cb5d970.js",
      "_swiper-vue.c4ed3832.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_arrow-right.7f05de45.js",
      "_building-map-interactive.689ebe72.js"
    ]
  },
  "MapInteractive.ffc01d21.css": {
    "file": "MapInteractive.ffc01d21.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_MapsTest.b9946333.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MapsTest.b9946333.js",
    "imports": [
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_NuxtSnackbar.d2150c91.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "NuxtSnackbar.d2150c91.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_Pagination.2437a7a8.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Pagination.2437a7a8.js",
    "imports": [
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_SliderLocatiesSort.9b415077.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "SliderLocatiesSort.a9d13604.css"
    ],
    "file": "SliderLocatiesSort.9b415077.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_client-only.8db14b52.js"
    ]
  },
  "SliderLocatiesSort.a9d13604.css": {
    "file": "SliderLocatiesSort.a9d13604.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_SliderTestimony.053f6788.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "SliderTestimony.29a5e60b.css"
    ],
    "file": "SliderTestimony.053f6788.js",
    "imports": [
      "_TitleHeader.8c7c1887.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "SliderTestimony.29a5e60b.css": {
    "file": "SliderTestimony.29a5e60b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TextEditor.970f7376.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "TextEditor.65389021.css"
    ],
    "file": "TextEditor.970f7376.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "TextEditor.65389021.css": {
    "file": "TextEditor.65389021.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TextField.vue.6821dfd0.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TextField.vue.6821dfd0.js",
    "imports": [
      "_vee-validate.esm.c9394f45.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_TitleHeader.8c7c1887.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TitleHeader.8c7c1887.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_VerhuurdersHeader.d36f2a69.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "VerhuurdersHeader.d36f2a69.js",
    "imports": [
      "_BgBigGreen.08d1effd.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_Werkstek.8f9db025.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Werkstek.8f9db025.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_arrow-right.7f05de45.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "arrow-right.7f05de45.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_arrow-small-right.f134a89f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "arrow-small-right.f134a89f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_building-map-interactive.689ebe72.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "building-map-interactive.689ebe72.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_client-only.8db14b52.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "client-only.8db14b52.js",
    "imports": [
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_config.c05ba55f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "config.c05ba55f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_index.cda55f3a.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.cda55f3a.js",
    "imports": [
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_index.eb66e43d.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.eb66e43d.js",
    "imports": [
      "_index.cda55f3a.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_marker-dropdown.0313b897.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "marker-dropdown.0313b897.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_swiper-vue.c4ed3832.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "swiper-vue.3061406d.css"
    ],
    "file": "swiper-vue.c4ed3832.js"
  },
  "swiper-vue.3061406d.css": {
    "file": "swiper-vue.3061406d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_useAxios.5cb5d970.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useAxios.5cb5d970.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useConvertTime.957d2e34.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useConvertTime.957d2e34.js"
  },
  "_useForgotPassword.b72e7c6e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useForgotPassword.b72e7c6e.js",
    "imports": [
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_useRequestHelper.0a27376f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useRequestHelper.0a27376f.js",
    "imports": [
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_useRequestOptions.8400c119.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useRequestOptions.8400c119.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useSchema.a1c7f408.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useSchema.a1c7f408.js"
  },
  "_vee-validate.esm.c9394f45.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vee-validate.esm.c9394f45.js",
    "imports": [
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "assets/fonts/Noto/NotoSans-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "NotoSans-Bold.cf382cad.ttf",
    "src": "assets/fonts/Noto/NotoSans-Bold.ttf"
  },
  "assets/fonts/Noto/NotoSans-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "NotoSans-Medium.9d0511ca.ttf",
    "src": "assets/fonts/Noto/NotoSans-Medium.ttf"
  },
  "assets/fonts/Noto/NotoSans-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "NotoSans-Regular.3be6b371.ttf",
    "src": "assets/fonts/Noto/NotoSans-Regular.ttf"
  },
  "assets/fonts/Poppins/Poppins-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "Poppins-Bold.7219547e.ttf",
    "src": "assets/fonts/Poppins/Poppins-Bold.ttf"
  },
  "assets/fonts/Poppins/Poppins-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "Poppins-Medium.8d909883.ttf",
    "src": "assets/fonts/Poppins/Poppins-Medium.ttf"
  },
  "assets/fonts/Poppins/Poppins-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "Poppins-Regular.707fdc5c.ttf",
    "src": "assets/fonts/Poppins/Poppins-Regular.ttf"
  },
  "i18n.config.ts?hash=bffaebcb&config=1": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "i18n.config.b03cc2fe.js",
    "isDynamicEntry": true,
    "src": "i18n.config.ts?hash=bffaebcb&config=1"
  },
  "layouts/admin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.1f7883e6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useRequestHelper.0a27376f.js",
      "_swiper-vue.c4ed3832.js",
      "_NuxtSnackbar.d2150c91.js",
      "_index.eb66e43d.js",
      "_config.c05ba55f.js",
      "_index.cda55f3a.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/admin.vue"
  },
  "layouts/default.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "default.4c48797d.css",
    "src": "layouts/default.css"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "default.1d558349.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_Werkstek.8f9db025.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_index.eb66e43d.js",
      "_arrow-small-right.f134a89f.js",
      "_NuxtSnackbar.d2150c91.js",
      "_useRequestOptions.8400c119.js",
      "_config.c05ba55f.js",
      "_index.cda55f3a.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "default.4c48797d.css": {
    "file": "default.4c48797d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "middleware/admin.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.e2a9c127.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/admin.ts"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Icon.6f5d80f8.css",
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.css"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "Icon.e21f34d4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_config.c05ba55f.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.vue"
  },
  "Icon.6f5d80f8.css": {
    "file": "Icon.6f5d80f8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "IconCSS.fe0874d9.css",
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.css"
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "IconCSS.be940773.js",
    "imports": [
      "_swiper-vue.c4ed3832.js",
      "_config.c05ba55f.js",
      "node_modules/nuxt/dist/app/entry.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.vue"
  },
  "IconCSS.fe0874d9.css": {
    "file": "IconCSS.fe0874d9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "entry.2cc35f7b.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.2cc35f7b.css"
    ],
    "dynamicImports": [
      "middleware/admin.ts",
      "layouts/admin.vue",
      "layouts/default.vue",
      "i18n.config.ts?hash=bffaebcb&config=1"
    ],
    "file": "entry.34fd0028.js",
    "imports": [
      "_swiper-vue.c4ed3832.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.2cc35f7b.css": {
    "file": "entry.2cc35f7b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/Faq.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Faq.b1e4972e.js",
    "imports": [
      "_HeaderWCity.25be3157.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/Faq.vue"
  },
  "pages/admin/admin-list/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.b06dece9.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_TextField.vue.6821dfd0.js",
      "_vee-validate.esm.c9394f45.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/[slug].vue"
  },
  "pages/admin/admin-list/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.f1467e87.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_TextField.vue.6821dfd0.js",
      "_useForgotPassword.b72e7c6e.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/add.vue"
  },
  "pages/admin/admin-list/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.83be4652.js",
    "imports": [
      "_ButtonAddIndex.88abfb55.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_index.cda55f3a.js",
      "_swiper-vue.c4ed3832.js",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/index.vue"
  },
  "pages/admin/author/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.8bed271e.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_vee-validate.esm.c9394f45.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/author/add.vue"
  },
  "pages/admin/author/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.f485eeb7.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_vee-validate.esm.c9394f45.js",
      "_BlogImageCrop.a753f6a6.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js",
      "_client-only.8db14b52.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/author/edit/[slug].vue"
  },
  "pages/admin/author/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.76bae901.css",
    "src": "pages/admin/author/index.css"
  },
  "pages/admin/author/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.e734883e.js",
    "imports": [
      "_ButtonAddIndex.88abfb55.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/author/index.vue"
  },
  "index.76bae901.css": {
    "file": "index.76bae901.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/blog-category/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.bf2fe442.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog-category/add.vue"
  },
  "pages/admin/blog-category/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.ae12ef5c.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog-category/edit/[slug].vue"
  },
  "pages/admin/blog-category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.54901065.js",
    "imports": [
      "_ButtonAddIndex.88abfb55.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog-category/index.vue"
  },
  "pages/admin/blog/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.93dea157.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_vee-validate.esm.c9394f45.js",
      "_BlogImageCrop.a753f6a6.js",
      "_TextField.vue.6821dfd0.js",
      "_TextEditor.970f7376.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js",
      "_client-only.8db14b52.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog/add.vue"
  },
  "pages/admin/blog/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.caf0d04a.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_BlogImageCrop.a753f6a6.js",
      "_TextField.vue.6821dfd0.js",
      "_vee-validate.esm.c9394f45.js",
      "_TextEditor.970f7376.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js",
      "_client-only.8db14b52.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog/edit/[slug].vue"
  },
  "pages/admin/blog/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.0641ddf1.css",
    "src": "pages/admin/blog/index.css"
  },
  "pages/admin/blog/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.87c8b9b9.js",
    "imports": [
      "_ButtonAddIndex.88abfb55.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog/index.vue"
  },
  "index.0641ddf1.css": {
    "file": "index.0641ddf1.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/category/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.57bb67b2.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_vee-validate.esm.c9394f45.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/category/add.vue"
  },
  "pages/admin/category/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.04bdf7dd.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useSchema.a1c7f408.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/category/edit/[slug].vue"
  },
  "pages/admin/category/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.0aa3d082.css",
    "src": "pages/admin/category/index.css"
  },
  "pages/admin/category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.479a1f36.js",
    "imports": [
      "_ButtonAddIndex.88abfb55.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_swiper-vue.c4ed3832.js",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/category/index.vue"
  },
  "index.0aa3d082.css": {
    "file": "index.0aa3d082.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/community/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.af3a516a.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_vee-validate.esm.c9394f45.js",
      "_BlogImageCrop.a753f6a6.js",
      "_TextField.vue.6821dfd0.js",
      "_TextEditor.970f7376.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js",
      "_client-only.8db14b52.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/community/add.vue"
  },
  "pages/admin/community/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.c0ff9892.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_BlogImageCrop.a753f6a6.js",
      "_TextField.vue.6821dfd0.js",
      "_vee-validate.esm.c9394f45.js",
      "_TextEditor.970f7376.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js",
      "_client-only.8db14b52.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/community/edit/[slug].vue"
  },
  "pages/admin/community/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.d6b0647b.css",
    "src": "pages/admin/community/index.css"
  },
  "pages/admin/community/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.bd15b337.js",
    "imports": [
      "_ButtonAddIndex.88abfb55.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/community/index.vue"
  },
  "index.d6b0647b.css": {
    "file": "index.d6b0647b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/contact/[slug].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_slug_.7b803f9d.css",
    "src": "pages/admin/contact/[slug].css"
  },
  "pages/admin/contact/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_slug_.9dc52ece.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestOptions.8400c119.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/contact/[slug].vue"
  },
  "_slug_.7b803f9d.css": {
    "file": "_slug_.7b803f9d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/contact/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.bd007d78.css",
    "src": "pages/admin/contact/index.css"
  },
  "pages/admin/contact/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.b57bd45e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/contact/index.vue"
  },
  "index.bd007d78.css": {
    "file": "index.bd007d78.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/dashboard.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dashboard.4ce27b69.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/dashboard.vue"
  },
  "pages/admin/edit-admin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "edit-admin.1d9a7c83.js",
    "imports": [
      "_Werkstek.8f9db025.js",
      "_vee-validate.esm.c9394f45.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/edit-admin.vue"
  },
  "pages/admin/facility/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.1bd0678c.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility/add.vue"
  },
  "pages/admin/facility/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.1512398c.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility/edit/[slug].vue"
  },
  "pages/admin/facility/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.1c9e8deb.css",
    "src": "pages/admin/facility/index.css"
  },
  "pages/admin/facility/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.dcaf711c.js",
    "imports": [
      "_ButtonAddIndex.88abfb55.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility/index.vue"
  },
  "index.1c9e8deb.css": {
    "file": "index.1c9e8deb.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/forgot-password.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "forgot-password.8e2dcae8.js",
    "imports": [
      "_TextField.vue.6821dfd0.js",
      "_useForgotPassword.b72e7c6e.js",
      "_vee-validate.esm.c9394f45.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestOptions.8400c119.js",
      "_useRequestHelper.0a27376f.js",
      "_swiper-vue.c4ed3832.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/forgot-password.vue"
  },
  "pages/admin/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.82b6dac0.css",
    "src": "pages/admin/index.css"
  },
  "pages/admin/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.45d0a6ec.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestOptions.8400c119.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/index.vue"
  },
  "index.82b6dac0.css": {
    "file": "index.82b6dac0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/level-type/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.6e3096f1.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_vee-validate.esm.c9394f45.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/level-type/add.vue"
  },
  "pages/admin/level-type/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.2b938c00.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_vee-validate.esm.c9394f45.js",
      "_BlogImageCrop.a753f6a6.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js",
      "_client-only.8db14b52.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/level-type/edit/[slug].vue"
  },
  "pages/admin/level-type/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.564b1a34.js",
    "imports": [
      "_ButtonAddIndex.88abfb55.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_swiper-vue.c4ed3832.js",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/level-type/index.vue"
  },
  "pages/admin/location/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.11d47319.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_TextField.vue.6821dfd0.js",
      "_vee-validate.esm.c9394f45.js",
      "_BlogImageCrop.a753f6a6.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js",
      "_client-only.8db14b52.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/location/add.vue"
  },
  "pages/admin/location/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.38b7cf21.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_TextField.vue.6821dfd0.js",
      "_BlogImageCrop.a753f6a6.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js",
      "_client-only.8db14b52.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/location/edit/[slug].vue"
  },
  "pages/admin/location/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.386b9b69.css",
    "src": "pages/admin/location/index.css"
  },
  "pages/admin/location/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.b8671dea.js",
    "imports": [
      "_ButtonAddIndex.88abfb55.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/location/index.vue"
  },
  "index.386b9b69.css": {
    "file": "index.386b9b69.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/newsletter/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.7f2a3b5c.css",
    "src": "pages/admin/newsletter/index.css"
  },
  "pages/admin/newsletter/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.27ab6324.js",
    "imports": [
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/newsletter/index.vue"
  },
  "index.7f2a3b5c.css": {
    "file": "index.7f2a3b5c.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/onze-locaties/add-image/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.0b0b6f3e.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/add-image/[slug].vue"
  },
  "pages/admin/onze-locaties/add-video/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.91610850.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useAxios.5cb5d970.js",
      "_useSchema.a1c7f408.js",
      "_useRequestOptions.8400c119.js",
      "_useRequestHelper.0a27376f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/add-video/[slug].vue"
  },
  "pages/admin/onze-locaties/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.081bed32.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_TextField.vue.6821dfd0.js",
      "_vee-validate.esm.c9394f45.js",
      "_TextEditor.970f7376.js",
      "_MapsTest.b9946333.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/add.vue"
  },
  "pages/admin/onze-locaties/edit-locaties/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.e0de15f6.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_TextField.vue.6821dfd0.js",
      "_vee-validate.esm.c9394f45.js",
      "_TextEditor.970f7376.js",
      "_MapsTest.b9946333.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/edit-locaties/[slug].vue"
  },
  "pages/admin/onze-locaties/featured-property/[slug].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_slug_.898c4a20.css",
    "src": "pages/admin/onze-locaties/featured-property/[slug].css"
  },
  "pages/admin/onze-locaties/featured-property/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_slug_.2352e53c.js",
    "imports": [
      "_ButtonAddIndex.88abfb55.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/featured-property/[slug].vue"
  },
  "_slug_.898c4a20.css": {
    "file": "_slug_.898c4a20.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/onze-locaties/featured-property/add-sortlist/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.039133fe.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/featured-property/add-sortlist/add.vue"
  },
  "pages/admin/onze-locaties/featured-property/add/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.b3bf3dfc.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_ButtonAddIndex.88abfb55.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/featured-property/add/index.vue"
  },
  "pages/admin/onze-locaties/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.1a5fb2ed.css",
    "src": "pages/admin/onze-locaties/index.css"
  },
  "pages/admin/onze-locaties/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.3671b96d.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_ButtonAddIndex.88abfb55.js",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/index.vue"
  },
  "index.1a5fb2ed.css": {
    "file": "index.1a5fb2ed.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/onze-vacatures/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.8d5e0401.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_vee-validate.esm.c9394f45.js",
      "_BlogImageCrop.a753f6a6.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_useAxios.5cb5d970.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js",
      "_client-only.8db14b52.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-vacatures/add.vue"
  },
  "pages/admin/onze-vacatures/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.27c58a46.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_vee-validate.esm.c9394f45.js",
      "_BlogImageCrop.a753f6a6.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_useAxios.5cb5d970.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js",
      "_client-only.8db14b52.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-vacatures/edit/[slug].vue"
  },
  "pages/admin/onze-vacatures/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.629bd52d.css",
    "src": "pages/admin/onze-vacatures/index.css"
  },
  "pages/admin/onze-vacatures/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.bef4907a.js",
    "imports": [
      "_ButtonAddIndex.88abfb55.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-vacatures/index.vue"
  },
  "index.629bd52d.css": {
    "file": "index.629bd52d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/privilages/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.11c342cc.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/privilages/add.vue"
  },
  "pages/admin/privilages/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.e5bbb8e8.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/privilages/edit/[slug].vue"
  },
  "pages/admin/privilages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.a9a319af.js",
    "imports": [
      "_ButtonAddIndex.88abfb55.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_swiper-vue.c4ed3832.js",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/privilages/index.vue"
  },
  "pages/admin/registration.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "registration.662ceb99.js",
    "imports": [
      "_Werkstek.8f9db025.js",
      "_TextField.vue.6821dfd0.js",
      "_useForgotPassword.b72e7c6e.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/registration.vue"
  },
  "pages/admin/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-in.e8a6dae0.js",
    "imports": [
      "_Werkstek.8f9db025.js",
      "_TextField.vue.6821dfd0.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/sign-in.vue"
  },
  "pages/admin/type-vacatures/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.694a3a6c.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type-vacatures/add.vue"
  },
  "pages/admin/type-vacatures/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.dee25ceb.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type-vacatures/edit/[slug].vue"
  },
  "pages/admin/type-vacatures/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.2e043579.css",
    "src": "pages/admin/type-vacatures/index.css"
  },
  "pages/admin/type-vacatures/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.38c27746.js",
    "imports": [
      "_ButtonAddIndex.88abfb55.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type-vacatures/index.vue"
  },
  "index.2e043579.css": {
    "file": "index.2e043579.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/type/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.1c11db62.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type/add.vue"
  },
  "pages/admin/type/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.310f2be8.js",
    "imports": [
      "_BackButton.4f9b5027.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type/edit/[slug].vue"
  },
  "pages/admin/type/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.ea8eeb0a.js",
    "imports": [
      "_ButtonAddIndex.88abfb55.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_swiper-vue.c4ed3832.js",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type/index.vue"
  },
  "pages/admin/verified-email/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.79fca000.js",
    "imports": [
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/verified-email/[slug].vue"
  },
  "pages/blog/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.e41a5e7a.js",
    "imports": [
      "_EachBlog.7fbcc1cd.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestOptions.8400c119.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js",
      "_useRequestHelper.0a27376f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/blog/[slug].vue"
  },
  "pages/blog/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.fd1b55a2.css",
    "src": "pages/blog/index.css"
  },
  "pages/blog/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.1c012f09.js",
    "imports": [
      "_HeaderWCity.25be3157.js",
      "_Blog.af69d081.js",
      "_BlogItem.19ed3f29.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_BgBigGreen.08d1effd.js",
      "_TitleHeader.8c7c1887.js",
      "_EachBlogSmall.d1f7316e.js",
      "_client-only.8db14b52.js",
      "_arrow-right.7f05de45.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_arrow-small-right.f134a89f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/blog/index.vue"
  },
  "index.fd1b55a2.css": {
    "file": "index.fd1b55a2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/contact.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contact.21875d64.js",
    "imports": [
      "_building-map-interactive.689ebe72.js",
      "_BgBigGreen.08d1effd.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_vee-validate.esm.c9394f45.js",
      "_useSchema.a1c7f408.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_MapInteractive.42ccc241.js",
      "_arrow-small-right.f134a89f.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js",
      "_useAxios.5cb5d970.js",
      "_arrow-right.7f05de45.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/contact.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.39dd8f95.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.ab6de112.js",
    "imports": [
      "_building-map-interactive.689ebe72.js",
      "_BgBigGreen.08d1effd.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useRequestHelper.0a27376f.js",
      "_swiper-vue.c4ed3832.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useAxios.5cb5d970.js",
      "_SliderLocatiesSort.9b415077.js",
      "_SliderTestimony.053f6788.js",
      "_arrow-right.7f05de45.js",
      "_TitleHeader.8c7c1887.js",
      "_Blog.af69d081.js",
      "_vee-validate.esm.c9394f45.js",
      "_arrow-small-right.f134a89f.js",
      "_config.c05ba55f.js",
      "_client-only.8db14b52.js",
      "_EachBlogSmall.d1f7316e.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.39dd8f95.css": {
    "file": "index.39dd8f95.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/onze-locaties/[slug].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_slug_.ebc7e03b.css",
    "src": "pages/onze-locaties/[slug].css"
  },
  "pages/onze-locaties/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_slug_.cdc6d7d2.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useRequestOptions.8400c119.js",
      "_SliderLocatiesSort.9b415077.js",
      "_SliderTestimony.053f6788.js",
      "_config.c05ba55f.js",
      "_client-only.8db14b52.js",
      "_TitleHeader.8c7c1887.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/onze-locaties/[slug].vue"
  },
  "_slug_.ebc7e03b.css": {
    "file": "_slug_.ebc7e03b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/onze-locaties/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.00d07fbc.css",
    "src": "pages/onze-locaties/index.css"
  },
  "pages/onze-locaties/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.38359802.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_TitleHeader.8c7c1887.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_arrow-right.7f05de45.js",
      "_Pagination.2437a7a8.js",
      "_useRequestOptions.8400c119.js",
      "_marker-dropdown.0313b897.js",
      "_index.cda55f3a.js",
      "_BgBigGreen.08d1effd.js",
      "_config.c05ba55f.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_arrow-small-right.f134a89f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/onze-locaties/index.vue"
  },
  "index.00d07fbc.css": {
    "file": "index.00d07fbc.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/onze-vacatures/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.30c6cfec.js",
    "imports": [
      "_HeaderWCity.25be3157.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useConvertTime.957d2e34.js",
      "_useRequestOptions.8400c119.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/onze-vacatures/[slug].vue"
  },
  "pages/onze-vacatures/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.dc5bba6a.css",
    "src": "pages/onze-vacatures/index.css"
  },
  "pages/onze-vacatures/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.dc514e30.js",
    "imports": [
      "_HeaderWCity.25be3157.js",
      "_TitleHeader.8c7c1887.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useConvertTime.957d2e34.js",
      "_arrow-right.7f05de45.js",
      "_swiper-vue.c4ed3832.js",
      "_Pagination.2437a7a8.js",
      "_useRequestOptions.8400c119.js",
      "_marker-dropdown.0313b897.js",
      "_index.cda55f3a.js",
      "_config.c05ba55f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/onze-vacatures/index.vue"
  },
  "index.dc5bba6a.css": {
    "file": "index.dc5bba6a.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/over-werkstek.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "over-werkstek.98e99f18.js",
    "imports": [
      "_VerhuurdersHeader.d36f2a69.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_LeegstandNoButton.dbd1875e.js",
      "_BgBigGreen.08d1effd.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_arrow-small-right.f134a89f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/over-werkstek.vue"
  },
  "pages/privacy-verklaring.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "privacy-verklaring.2197c58c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/privacy-verklaring.vue"
  },
  "pages/voor-verhuurders.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "voor-verhuurders.42498c4b.js",
    "imports": [
      "_VerhuurdersHeader.d36f2a69.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_building-map-interactive.689ebe72.js",
      "_BgBigGreen.08d1effd.js",
      "_LeegstandNoButton.dbd1875e.js",
      "_MapInteractive.42ccc241.js",
      "_SliderTestimony.053f6788.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.8400c119.js",
      "_arrow-small-right.f134a89f.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js",
      "_useAxios.5cb5d970.js",
      "_arrow-right.7f05de45.js",
      "_TitleHeader.8c7c1887.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/voor-verhuurders.vue"
  },
  "pages/werkstek-community/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.23f3a29f.js",
    "imports": [
      "_EachBlog.7fbcc1cd.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestOptions.8400c119.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.c05ba55f.js",
      "_useRequestHelper.0a27376f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/werkstek-community/[slug].vue"
  },
  "pages/werkstek-community/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.476fca53.css",
    "src": "pages/werkstek-community/index.css"
  },
  "pages/werkstek-community/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.bb4131ee.js",
    "imports": [
      "_HeaderWCity.25be3157.js",
      "_TitleHeader.8c7c1887.js",
      "_EachBlogSmall.d1f7316e.js",
      "_useRequestOptions.8400c119.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_BlogItem.19ed3f29.js",
      "_LeegstandNoButton.dbd1875e.js",
      "_BgBigGreen.08d1effd.js",
      "_client-only.8db14b52.js",
      "_arrow-right.7f05de45.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_arrow-small-right.f134a89f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/werkstek-community/index.vue"
  },
  "index.476fca53.css": {
    "file": "index.476fca53.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "swiper-vue.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "swiper-vue.3061406d.css",
    "src": "swiper-vue.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
