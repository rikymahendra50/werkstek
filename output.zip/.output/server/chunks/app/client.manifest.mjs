const client_manifest = {
  "BgBigGreen.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "BgBigGreen.f4cc734e.css",
    "src": "BgBigGreen.css"
  },
  "MapInteractive.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "MapInteractive.ffc01d21.css",
    "src": "MapInteractive.css"
  },
  "SliderLocatiesSort.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "SliderLocatiesSort.a9d13604.css",
    "src": "SliderLocatiesSort.css"
  },
  "SliderTestimony.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "SliderTestimony.29a5e60b.css",
    "src": "SliderTestimony.css"
  },
  "TextEditor.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "TextEditor.65389021.css",
    "src": "TextEditor.css"
  },
  "_BackButton.c5749f52.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "BackButton.c5749f52.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_BgBigGreen.85ab7f06.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "BgBigGreen.f4cc734e.css"
    ],
    "file": "BgBigGreen.85ab7f06.js",
    "imports": [
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_arrow-small-right.7d30c044.js"
    ]
  },
  "BgBigGreen.f4cc734e.css": {
    "file": "BgBigGreen.f4cc734e.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Blog.13a29325.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Blog.13a29325.js",
    "imports": [
      "_TitleHeader.a3343425.js",
      "_EachBlogSmall.fd18be6e.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_BlogImageCrop.a753f6a6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "BlogImageCrop.a753f6a6.js",
    "imports": [
      "_swiper-vue.c4ed3832.js",
      "_index.eb66e43d.js",
      "_client-only.8db14b52.js"
    ]
  },
  "_BlogItem.22b4b817.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "BlogItem.22b4b817.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_client-only.8db14b52.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_ButtonAddForm.c9876862.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ButtonAddForm.c9876862.js",
    "imports": [
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_ButtonAddIndex.4d82ad7b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ButtonAddIndex.4d82ad7b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_EachBlog.98882aa7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "EachBlog.98882aa7.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_EachBlogSmall.fd18be6e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "EachBlogSmall.fd18be6e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_client-only.8db14b52.js",
      "_arrow-right.a45eafb6.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_HeaderWCity.14955d6a.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "HeaderWCity.14955d6a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_LeegstandNoButton.2b4d3500.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "LeegstandNoButton.2b4d3500.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_MapInteractive.86bc1020.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "MapInteractive.ffc01d21.css"
    ],
    "file": "MapInteractive.86bc1020.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useAxios.4fc5cc89.js",
      "_swiper-vue.c4ed3832.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_arrow-right.a45eafb6.js",
      "_building-map-interactive.d90eb802.js"
    ]
  },
  "MapInteractive.ffc01d21.css": {
    "file": "MapInteractive.ffc01d21.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_MapsTest.b9946333.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MapsTest.b9946333.js",
    "imports": [
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_NuxtSnackbar.49e0adc9.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "NuxtSnackbar.49e0adc9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_Pagination.2437a7a8.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Pagination.2437a7a8.js",
    "imports": [
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_SliderLocatiesSort.cab04195.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "SliderLocatiesSort.a9d13604.css"
    ],
    "file": "SliderLocatiesSort.cab04195.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_client-only.8db14b52.js"
    ]
  },
  "SliderLocatiesSort.a9d13604.css": {
    "file": "SliderLocatiesSort.a9d13604.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_SliderTestimony.e339e365.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "SliderTestimony.29a5e60b.css"
    ],
    "file": "SliderTestimony.e339e365.js",
    "imports": [
      "_TitleHeader.a3343425.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "SliderTestimony.29a5e60b.css": {
    "file": "SliderTestimony.29a5e60b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TextEditor.bc7fa590.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "TextEditor.65389021.css"
    ],
    "file": "TextEditor.bc7fa590.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "TextEditor.65389021.css": {
    "file": "TextEditor.65389021.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TextField.vue.6821dfd0.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TextField.vue.6821dfd0.js",
    "imports": [
      "_vee-validate.esm.c9394f45.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_TitleHeader.a3343425.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TitleHeader.a3343425.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_VerhuurdersHeader.4b09f194.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "VerhuurdersHeader.4b09f194.js",
    "imports": [
      "_BgBigGreen.85ab7f06.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_Werkstek.72dcc6c6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Werkstek.72dcc6c6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_arrow-right.a45eafb6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "arrow-right.a45eafb6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_arrow-small-right.7d30c044.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "arrow-small-right.7d30c044.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_building-map-interactive.d90eb802.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "building-map-interactive.d90eb802.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_client-only.8db14b52.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "client-only.8db14b52.js",
    "imports": [
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_config.29f3c879.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "config.29f3c879.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_index.cda55f3a.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.cda55f3a.js",
    "imports": [
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_index.eb66e43d.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.eb66e43d.js",
    "imports": [
      "_index.cda55f3a.js",
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_marker-dropdown.8e6efcdd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "marker-dropdown.8e6efcdd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_swiper-vue.c4ed3832.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "swiper-vue.3061406d.css"
    ],
    "file": "swiper-vue.c4ed3832.js"
  },
  "swiper-vue.3061406d.css": {
    "file": "swiper-vue.3061406d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_useAxios.4fc5cc89.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useAxios.4fc5cc89.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useConvertTime.957d2e34.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useConvertTime.957d2e34.js"
  },
  "_useForgotPassword.b72e7c6e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useForgotPassword.b72e7c6e.js",
    "imports": [
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_useRequestHelper.0a27376f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useRequestHelper.0a27376f.js",
    "imports": [
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "_useRequestOptions.46438cd1.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useRequestOptions.46438cd1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useSchema.a1c7f408.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useSchema.a1c7f408.js"
  },
  "_vee-validate.esm.c9394f45.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vee-validate.esm.c9394f45.js",
    "imports": [
      "_swiper-vue.c4ed3832.js"
    ]
  },
  "assets/fonts/Noto/NotoSans-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "NotoSans-Bold.cf382cad.ttf",
    "src": "assets/fonts/Noto/NotoSans-Bold.ttf"
  },
  "assets/fonts/Noto/NotoSans-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "NotoSans-Medium.9d0511ca.ttf",
    "src": "assets/fonts/Noto/NotoSans-Medium.ttf"
  },
  "assets/fonts/Noto/NotoSans-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "NotoSans-Regular.3be6b371.ttf",
    "src": "assets/fonts/Noto/NotoSans-Regular.ttf"
  },
  "assets/fonts/Poppins/Poppins-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "Poppins-Bold.7219547e.ttf",
    "src": "assets/fonts/Poppins/Poppins-Bold.ttf"
  },
  "assets/fonts/Poppins/Poppins-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "Poppins-Medium.8d909883.ttf",
    "src": "assets/fonts/Poppins/Poppins-Medium.ttf"
  },
  "assets/fonts/Poppins/Poppins-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "Poppins-Regular.707fdc5c.ttf",
    "src": "assets/fonts/Poppins/Poppins-Regular.ttf"
  },
  "i18n.config.ts?hash=bffaebcb&config=1": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "i18n.config.b03cc2fe.js",
    "isDynamicEntry": true,
    "src": "i18n.config.ts?hash=bffaebcb&config=1"
  },
  "layouts/admin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.fbfc5ada.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useRequestHelper.0a27376f.js",
      "_swiper-vue.c4ed3832.js",
      "_NuxtSnackbar.49e0adc9.js",
      "_index.eb66e43d.js",
      "_config.29f3c879.js",
      "_index.cda55f3a.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/admin.vue"
  },
  "layouts/default.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "default.4c48797d.css",
    "src": "layouts/default.css"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "default.54721906.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_Werkstek.72dcc6c6.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_index.eb66e43d.js",
      "_arrow-small-right.7d30c044.js",
      "_NuxtSnackbar.49e0adc9.js",
      "_useRequestOptions.46438cd1.js",
      "_config.29f3c879.js",
      "_index.cda55f3a.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "default.4c48797d.css": {
    "file": "default.4c48797d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "middleware/admin.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.3235dfd7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/admin.ts"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Icon.6f5d80f8.css",
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.css"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "Icon.ed72e118.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_config.29f3c879.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.vue"
  },
  "Icon.6f5d80f8.css": {
    "file": "Icon.6f5d80f8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "IconCSS.fe0874d9.css",
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.css"
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "IconCSS.8c95fe12.js",
    "imports": [
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.vue"
  },
  "IconCSS.fe0874d9.css": {
    "file": "IconCSS.fe0874d9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "entry.2cc35f7b.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.2cc35f7b.css"
    ],
    "dynamicImports": [
      "middleware/admin.ts",
      "layouts/admin.vue",
      "layouts/default.vue",
      "i18n.config.ts?hash=bffaebcb&config=1"
    ],
    "file": "entry.22855478.js",
    "imports": [
      "_swiper-vue.c4ed3832.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.2cc35f7b.css": {
    "file": "entry.2cc35f7b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/Faq.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Faq.faa71c9e.js",
    "imports": [
      "_HeaderWCity.14955d6a.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/Faq.vue"
  },
  "pages/admin/admin-list/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.d3d1c00a.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_TextField.vue.6821dfd0.js",
      "_vee-validate.esm.c9394f45.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/[slug].vue"
  },
  "pages/admin/admin-list/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.f8c9e985.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_TextField.vue.6821dfd0.js",
      "_useForgotPassword.b72e7c6e.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/add.vue"
  },
  "pages/admin/admin-list/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.eea32fa3.js",
    "imports": [
      "_ButtonAddIndex.4d82ad7b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_index.cda55f3a.js",
      "_swiper-vue.c4ed3832.js",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/index.vue"
  },
  "pages/admin/author/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.bdd80256.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_vee-validate.esm.c9394f45.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/author/add.vue"
  },
  "pages/admin/author/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.dd10f699.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_vee-validate.esm.c9394f45.js",
      "_BlogImageCrop.a753f6a6.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js",
      "_client-only.8db14b52.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/author/edit/[slug].vue"
  },
  "pages/admin/author/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.76bae901.css",
    "src": "pages/admin/author/index.css"
  },
  "pages/admin/author/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.fd976f41.js",
    "imports": [
      "_ButtonAddIndex.4d82ad7b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/author/index.vue"
  },
  "index.76bae901.css": {
    "file": "index.76bae901.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/blog-category/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.56a8ee64.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog-category/add.vue"
  },
  "pages/admin/blog-category/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.15a6bb30.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog-category/edit/[slug].vue"
  },
  "pages/admin/blog-category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.281cf79b.js",
    "imports": [
      "_ButtonAddIndex.4d82ad7b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog-category/index.vue"
  },
  "pages/admin/blog/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.625cd122.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_vee-validate.esm.c9394f45.js",
      "_BlogImageCrop.a753f6a6.js",
      "_TextField.vue.6821dfd0.js",
      "_TextEditor.bc7fa590.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js",
      "_client-only.8db14b52.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog/add.vue"
  },
  "pages/admin/blog/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.8c5f8e42.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_BlogImageCrop.a753f6a6.js",
      "_TextField.vue.6821dfd0.js",
      "_vee-validate.esm.c9394f45.js",
      "_TextEditor.bc7fa590.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js",
      "_client-only.8db14b52.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog/edit/[slug].vue"
  },
  "pages/admin/blog/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.0641ddf1.css",
    "src": "pages/admin/blog/index.css"
  },
  "pages/admin/blog/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.a07f383e.js",
    "imports": [
      "_ButtonAddIndex.4d82ad7b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog/index.vue"
  },
  "index.0641ddf1.css": {
    "file": "index.0641ddf1.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/category/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.77db7793.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_vee-validate.esm.c9394f45.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/category/add.vue"
  },
  "pages/admin/category/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.9c5b8447.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useSchema.a1c7f408.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/category/edit/[slug].vue"
  },
  "pages/admin/category/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.0aa3d082.css",
    "src": "pages/admin/category/index.css"
  },
  "pages/admin/category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.65cee9da.js",
    "imports": [
      "_ButtonAddIndex.4d82ad7b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_swiper-vue.c4ed3832.js",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/category/index.vue"
  },
  "index.0aa3d082.css": {
    "file": "index.0aa3d082.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/community/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.b7c469e2.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_vee-validate.esm.c9394f45.js",
      "_BlogImageCrop.a753f6a6.js",
      "_TextField.vue.6821dfd0.js",
      "_TextEditor.bc7fa590.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js",
      "_client-only.8db14b52.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/community/add.vue"
  },
  "pages/admin/community/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.b1645171.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_BlogImageCrop.a753f6a6.js",
      "_TextField.vue.6821dfd0.js",
      "_vee-validate.esm.c9394f45.js",
      "_TextEditor.bc7fa590.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js",
      "_client-only.8db14b52.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/community/edit/[slug].vue"
  },
  "pages/admin/community/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.d6b0647b.css",
    "src": "pages/admin/community/index.css"
  },
  "pages/admin/community/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.805cc46a.js",
    "imports": [
      "_ButtonAddIndex.4d82ad7b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/community/index.vue"
  },
  "index.d6b0647b.css": {
    "file": "index.d6b0647b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/contact/[slug].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_slug_.7b803f9d.css",
    "src": "pages/admin/contact/[slug].css"
  },
  "pages/admin/contact/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_slug_.45692cc6.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestOptions.46438cd1.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/contact/[slug].vue"
  },
  "_slug_.7b803f9d.css": {
    "file": "_slug_.7b803f9d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/contact/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.bd007d78.css",
    "src": "pages/admin/contact/index.css"
  },
  "pages/admin/contact/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.2c4544e4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/contact/index.vue"
  },
  "index.bd007d78.css": {
    "file": "index.bd007d78.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/dashboard.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dashboard.18751809.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/dashboard.vue"
  },
  "pages/admin/edit-admin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "edit-admin.08600c8e.js",
    "imports": [
      "_Werkstek.72dcc6c6.js",
      "_vee-validate.esm.c9394f45.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/edit-admin.vue"
  },
  "pages/admin/facility/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.82e52e80.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility/add.vue"
  },
  "pages/admin/facility/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.29e4215d.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility/edit/[slug].vue"
  },
  "pages/admin/facility/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.1c9e8deb.css",
    "src": "pages/admin/facility/index.css"
  },
  "pages/admin/facility/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.61e52b26.js",
    "imports": [
      "_ButtonAddIndex.4d82ad7b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility/index.vue"
  },
  "index.1c9e8deb.css": {
    "file": "index.1c9e8deb.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/forgot-password.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "forgot-password.c6337406.js",
    "imports": [
      "_TextField.vue.6821dfd0.js",
      "_useForgotPassword.b72e7c6e.js",
      "_vee-validate.esm.c9394f45.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestOptions.46438cd1.js",
      "_useRequestHelper.0a27376f.js",
      "_swiper-vue.c4ed3832.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/forgot-password.vue"
  },
  "pages/admin/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.82b6dac0.css",
    "src": "pages/admin/index.css"
  },
  "pages/admin/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.93b31405.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestOptions.46438cd1.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/index.vue"
  },
  "index.82b6dac0.css": {
    "file": "index.82b6dac0.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/level-type/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.a165a2db.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_vee-validate.esm.c9394f45.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/level-type/add.vue"
  },
  "pages/admin/level-type/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.d3c3cd76.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_vee-validate.esm.c9394f45.js",
      "_BlogImageCrop.a753f6a6.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js",
      "_client-only.8db14b52.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/level-type/edit/[slug].vue"
  },
  "pages/admin/level-type/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.00aa2b7b.js",
    "imports": [
      "_ButtonAddIndex.4d82ad7b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_swiper-vue.c4ed3832.js",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/level-type/index.vue"
  },
  "pages/admin/location/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.6a563ee8.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_TextField.vue.6821dfd0.js",
      "_vee-validate.esm.c9394f45.js",
      "_BlogImageCrop.a753f6a6.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js",
      "_client-only.8db14b52.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/location/add.vue"
  },
  "pages/admin/location/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.fd50c878.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_TextField.vue.6821dfd0.js",
      "_BlogImageCrop.a753f6a6.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js",
      "_client-only.8db14b52.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/location/edit/[slug].vue"
  },
  "pages/admin/location/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.386b9b69.css",
    "src": "pages/admin/location/index.css"
  },
  "pages/admin/location/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.6853e17d.js",
    "imports": [
      "_ButtonAddIndex.4d82ad7b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/location/index.vue"
  },
  "index.386b9b69.css": {
    "file": "index.386b9b69.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/newsletter/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.7f2a3b5c.css",
    "src": "pages/admin/newsletter/index.css"
  },
  "pages/admin/newsletter/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.c0c42e77.js",
    "imports": [
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/newsletter/index.vue"
  },
  "index.7f2a3b5c.css": {
    "file": "index.7f2a3b5c.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/onze-locaties/add-image/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.557993f5.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/add-image/[slug].vue"
  },
  "pages/admin/onze-locaties/add-video/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.43a3bcd0.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useAxios.4fc5cc89.js",
      "_useSchema.a1c7f408.js",
      "_useRequestOptions.46438cd1.js",
      "_useRequestHelper.0a27376f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/add-video/[slug].vue"
  },
  "pages/admin/onze-locaties/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.c705d305.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_TextField.vue.6821dfd0.js",
      "_vee-validate.esm.c9394f45.js",
      "_TextEditor.bc7fa590.js",
      "_MapsTest.b9946333.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/add.vue"
  },
  "pages/admin/onze-locaties/edit-locaties/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.758442e1.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_TextField.vue.6821dfd0.js",
      "_vee-validate.esm.c9394f45.js",
      "_TextEditor.bc7fa590.js",
      "_MapsTest.b9946333.js",
      "_ButtonAddForm.c9876862.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/edit-locaties/[slug].vue"
  },
  "pages/admin/onze-locaties/featured-property/[slug].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_slug_.898c4a20.css",
    "src": "pages/admin/onze-locaties/featured-property/[slug].css"
  },
  "pages/admin/onze-locaties/featured-property/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_slug_.2d8750cc.js",
    "imports": [
      "_ButtonAddIndex.4d82ad7b.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/featured-property/[slug].vue"
  },
  "_slug_.898c4a20.css": {
    "file": "_slug_.898c4a20.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/onze-locaties/featured-property/add-sortlist/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.a9810045.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/featured-property/add-sortlist/add.vue"
  },
  "pages/admin/onze-locaties/featured-property/add/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.9d008d94.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_ButtonAddIndex.4d82ad7b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/featured-property/add/index.vue"
  },
  "pages/admin/onze-locaties/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.1a5fb2ed.css",
    "src": "pages/admin/onze-locaties/index.css"
  },
  "pages/admin/onze-locaties/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.e672c549.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_ButtonAddIndex.4d82ad7b.js",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/index.vue"
  },
  "index.1a5fb2ed.css": {
    "file": "index.1a5fb2ed.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/onze-vacatures/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.de836e35.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_vee-validate.esm.c9394f45.js",
      "_BlogImageCrop.a753f6a6.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_useAxios.4fc5cc89.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js",
      "_client-only.8db14b52.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-vacatures/add.vue"
  },
  "pages/admin/onze-vacatures/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.baa2629a.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_vee-validate.esm.c9394f45.js",
      "_BlogImageCrop.a753f6a6.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_useAxios.4fc5cc89.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js",
      "_index.eb66e43d.js",
      "_index.cda55f3a.js",
      "_client-only.8db14b52.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-vacatures/edit/[slug].vue"
  },
  "pages/admin/onze-vacatures/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.629bd52d.css",
    "src": "pages/admin/onze-vacatures/index.css"
  },
  "pages/admin/onze-vacatures/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.8a98a8ac.js",
    "imports": [
      "_ButtonAddIndex.4d82ad7b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-vacatures/index.vue"
  },
  "index.629bd52d.css": {
    "file": "index.629bd52d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/privilages/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.4fbf5587.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/privilages/add.vue"
  },
  "pages/admin/privilages/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.0f86dc0b.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/privilages/edit/[slug].vue"
  },
  "pages/admin/privilages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.9b449fc5.js",
    "imports": [
      "_ButtonAddIndex.4d82ad7b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_swiper-vue.c4ed3832.js",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/privilages/index.vue"
  },
  "pages/admin/registration.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "registration.84ae2a1c.js",
    "imports": [
      "_Werkstek.72dcc6c6.js",
      "_TextField.vue.6821dfd0.js",
      "_useForgotPassword.b72e7c6e.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/registration.vue"
  },
  "pages/admin/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-in.bfb029d5.js",
    "imports": [
      "_Werkstek.72dcc6c6.js",
      "_TextField.vue.6821dfd0.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/sign-in.vue"
  },
  "pages/admin/type-vacatures/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.6d42216f.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type-vacatures/add.vue"
  },
  "pages/admin/type-vacatures/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.ffcb9d3d.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type-vacatures/edit/[slug].vue"
  },
  "pages/admin/type-vacatures/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.2e043579.css",
    "src": "pages/admin/type-vacatures/index.css"
  },
  "pages/admin/type-vacatures/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.32929a61.js",
    "imports": [
      "_ButtonAddIndex.4d82ad7b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.2437a7a8.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_swiper-vue.c4ed3832.js",
      "_index.cda55f3a.js",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type-vacatures/index.vue"
  },
  "index.2e043579.css": {
    "file": "index.2e043579.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/type/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.4bcade72.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type/add.vue"
  },
  "pages/admin/type/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.995b03e9.js",
    "imports": [
      "_BackButton.c5749f52.js",
      "_TextField.vue.6821dfd0.js",
      "_ButtonAddForm.c9876862.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type/edit/[slug].vue"
  },
  "pages/admin/type/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.8ba0cde3.js",
    "imports": [
      "_ButtonAddIndex.4d82ad7b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_swiper-vue.c4ed3832.js",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type/index.vue"
  },
  "pages/admin/verified-email/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.cee96cbc.js",
    "imports": [
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/verified-email/[slug].vue"
  },
  "pages/blog/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.27b8ac8c.js",
    "imports": [
      "_EachBlog.98882aa7.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestOptions.46438cd1.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js",
      "_useRequestHelper.0a27376f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/blog/[slug].vue"
  },
  "pages/blog/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.fd1b55a2.css",
    "src": "pages/blog/index.css"
  },
  "pages/blog/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.a1850b7f.js",
    "imports": [
      "_HeaderWCity.14955d6a.js",
      "_Blog.13a29325.js",
      "_BlogItem.22b4b817.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_BgBigGreen.85ab7f06.js",
      "_TitleHeader.a3343425.js",
      "_EachBlogSmall.fd18be6e.js",
      "_client-only.8db14b52.js",
      "_arrow-right.a45eafb6.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_arrow-small-right.7d30c044.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/blog/index.vue"
  },
  "index.fd1b55a2.css": {
    "file": "index.fd1b55a2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/contact.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contact.338d6d66.js",
    "imports": [
      "_building-map-interactive.d90eb802.js",
      "_BgBigGreen.85ab7f06.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_vee-validate.esm.c9394f45.js",
      "_useSchema.a1c7f408.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_MapInteractive.86bc1020.js",
      "_arrow-small-right.7d30c044.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js",
      "_useAxios.4fc5cc89.js",
      "_arrow-right.a45eafb6.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/contact.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.39dd8f95.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.f892a436.js",
    "imports": [
      "_building-map-interactive.d90eb802.js",
      "_BgBigGreen.85ab7f06.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useRequestHelper.0a27376f.js",
      "_swiper-vue.c4ed3832.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useAxios.4fc5cc89.js",
      "_SliderLocatiesSort.cab04195.js",
      "_SliderTestimony.e339e365.js",
      "_arrow-right.a45eafb6.js",
      "_TitleHeader.a3343425.js",
      "_Blog.13a29325.js",
      "_vee-validate.esm.c9394f45.js",
      "_arrow-small-right.7d30c044.js",
      "_config.29f3c879.js",
      "_client-only.8db14b52.js",
      "_EachBlogSmall.fd18be6e.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.39dd8f95.css": {
    "file": "index.39dd8f95.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/onze-locaties/[slug].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_slug_.ebc7e03b.css",
    "src": "pages/onze-locaties/[slug].css"
  },
  "pages/onze-locaties/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_slug_.15b8aba8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useRequestOptions.46438cd1.js",
      "_SliderLocatiesSort.cab04195.js",
      "_SliderTestimony.e339e365.js",
      "_config.29f3c879.js",
      "_client-only.8db14b52.js",
      "_TitleHeader.a3343425.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/onze-locaties/[slug].vue"
  },
  "_slug_.ebc7e03b.css": {
    "file": "_slug_.ebc7e03b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/onze-locaties/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.00d07fbc.css",
    "src": "pages/onze-locaties/index.css"
  },
  "pages/onze-locaties/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.470b3dc7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_TitleHeader.a3343425.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_arrow-right.a45eafb6.js",
      "_Pagination.2437a7a8.js",
      "_useRequestOptions.46438cd1.js",
      "_marker-dropdown.8e6efcdd.js",
      "_index.cda55f3a.js",
      "_BgBigGreen.85ab7f06.js",
      "_config.29f3c879.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_arrow-small-right.7d30c044.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/onze-locaties/index.vue"
  },
  "index.00d07fbc.css": {
    "file": "index.00d07fbc.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/onze-vacatures/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.43594a99.js",
    "imports": [
      "_HeaderWCity.14955d6a.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useConvertTime.957d2e34.js",
      "_useRequestOptions.46438cd1.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/onze-vacatures/[slug].vue"
  },
  "pages/onze-vacatures/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.dc5bba6a.css",
    "src": "pages/onze-vacatures/index.css"
  },
  "pages/onze-vacatures/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.0fdd3fd2.js",
    "imports": [
      "_HeaderWCity.14955d6a.js",
      "_TitleHeader.a3343425.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useConvertTime.957d2e34.js",
      "_arrow-right.a45eafb6.js",
      "_swiper-vue.c4ed3832.js",
      "_Pagination.2437a7a8.js",
      "_useRequestOptions.46438cd1.js",
      "_marker-dropdown.8e6efcdd.js",
      "_index.cda55f3a.js",
      "_config.29f3c879.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/onze-vacatures/index.vue"
  },
  "index.dc5bba6a.css": {
    "file": "index.dc5bba6a.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/over-werkstek.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "over-werkstek.35927dcd.js",
    "imports": [
      "_VerhuurdersHeader.4b09f194.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_LeegstandNoButton.2b4d3500.js",
      "_BgBigGreen.85ab7f06.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_arrow-small-right.7d30c044.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/over-werkstek.vue"
  },
  "pages/privacy-verklaring.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "privacy-verklaring.feb6f89b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/privacy-verklaring.vue"
  },
  "pages/voor-verhuurders.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "voor-verhuurders.6b4529bd.js",
    "imports": [
      "_VerhuurdersHeader.4b09f194.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_building-map-interactive.d90eb802.js",
      "_BgBigGreen.85ab7f06.js",
      "_LeegstandNoButton.2b4d3500.js",
      "_MapInteractive.86bc1020.js",
      "_SliderTestimony.e339e365.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_useRequestOptions.46438cd1.js",
      "_arrow-small-right.7d30c044.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js",
      "_useAxios.4fc5cc89.js",
      "_arrow-right.a45eafb6.js",
      "_TitleHeader.a3343425.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/voor-verhuurders.vue"
  },
  "pages/werkstek-community/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.432e52a0.js",
    "imports": [
      "_EachBlog.98882aa7.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestOptions.46438cd1.js",
      "_swiper-vue.c4ed3832.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.29f3c879.js",
      "_useRequestHelper.0a27376f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/werkstek-community/[slug].vue"
  },
  "pages/werkstek-community/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.476fca53.css",
    "src": "pages/werkstek-community/index.css"
  },
  "pages/werkstek-community/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.333418d7.js",
    "imports": [
      "_HeaderWCity.14955d6a.js",
      "_TitleHeader.a3343425.js",
      "_EachBlogSmall.fd18be6e.js",
      "_useRequestOptions.46438cd1.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.c4ed3832.js",
      "_BlogItem.22b4b817.js",
      "_LeegstandNoButton.2b4d3500.js",
      "_BgBigGreen.85ab7f06.js",
      "_client-only.8db14b52.js",
      "_arrow-right.a45eafb6.js",
      "_vee-validate.esm.c9394f45.js",
      "_useRequestHelper.0a27376f.js",
      "_arrow-small-right.7d30c044.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/werkstek-community/index.vue"
  },
  "index.476fca53.css": {
    "file": "index.476fca53.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "swiper-vue.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "swiper-vue.3061406d.css",
    "src": "swiper-vue.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
