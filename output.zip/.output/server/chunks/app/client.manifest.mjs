const client_manifest = {
  "BgBigGreen.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "BgBigGreen.f4cc734e.css",
    "src": "BgBigGreen.css"
  },
  "MapInteractive.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "MapInteractive.ffc01d21.css",
    "src": "MapInteractive.css"
  },
  "SliderLocatiesSort.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "SliderLocatiesSort.a9d13604.css",
    "src": "SliderLocatiesSort.css"
  },
  "SliderTestimony.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "SliderTestimony.29a5e60b.css",
    "src": "SliderTestimony.css"
  },
  "TextEditor.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "TextEditor.65389021.css",
    "src": "TextEditor.css"
  },
  "_BackButton.058dc03a.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "BackButton.058dc03a.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_BgBigGreen.44e781e8.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "BgBigGreen.f4cc734e.css"
    ],
    "file": "BgBigGreen.44e781e8.js",
    "imports": [
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_arrow-small-right.dc0e01ff.js"
    ]
  },
  "BgBigGreen.f4cc734e.css": {
    "file": "BgBigGreen.f4cc734e.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Blog.a5b1ba97.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Blog.a5b1ba97.js",
    "imports": [
      "_TitleHeader.61d4a951.js",
      "_EachBlogSmall.affe650c.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_BlogImageCrop.5a8b5103.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "BlogImageCrop.5a8b5103.js",
    "imports": [
      "_swiper-vue.481cfa94.js",
      "_index.73ae3a71.js",
      "_client-only.0a906c49.js"
    ]
  },
  "_BlogItem.bdfab12d.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "BlogItem.bdfab12d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_client-only.0a906c49.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_ButtonAddForm.51f2c614.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ButtonAddForm.51f2c614.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_ButtonAddIndex.38c5ed13.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ButtonAddIndex.38c5ed13.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_EachBlog.5746f35e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "EachBlog.5746f35e.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_EachBlogSmall.affe650c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "EachBlogSmall.affe650c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_client-only.0a906c49.js",
      "_arrow-right.5a646e90.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_HeaderWCity.b363ed3d.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "HeaderWCity.b363ed3d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_LeegstandNoButton.7948037f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "LeegstandNoButton.7948037f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_MapInteractive.4946b0e2.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "MapInteractive.ffc01d21.css"
    ],
    "file": "MapInteractive.4946b0e2.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useAxios.f98c2a57.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_arrow-right.5a646e90.js",
      "_building-map-interactive.5a195fd4.js"
    ]
  },
  "MapInteractive.ffc01d21.css": {
    "file": "MapInteractive.ffc01d21.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_MapsTest.739ff50f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MapsTest.739ff50f.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_NuxtSnackbar.82214fcd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "NuxtSnackbar.82214fcd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_Pagination.840304e6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Pagination.840304e6.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_SliderLocatiesSort.b170f9b1.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "SliderLocatiesSort.a9d13604.css"
    ],
    "file": "SliderLocatiesSort.b170f9b1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_client-only.0a906c49.js"
    ]
  },
  "SliderLocatiesSort.a9d13604.css": {
    "file": "SliderLocatiesSort.a9d13604.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_SliderTestimony.55574086.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "SliderTestimony.29a5e60b.css"
    ],
    "file": "SliderTestimony.55574086.js",
    "imports": [
      "_TitleHeader.61d4a951.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "SliderTestimony.29a5e60b.css": {
    "file": "SliderTestimony.29a5e60b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TextEditor.9ae0bcab.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "TextEditor.65389021.css"
    ],
    "file": "TextEditor.9ae0bcab.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "TextEditor.65389021.css": {
    "file": "TextEditor.65389021.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TextField.vue.222c6931.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TextField.vue.222c6931.js",
    "imports": [
      "_vee-validate.esm.0085992c.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_TitleHeader.61d4a951.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TitleHeader.61d4a951.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_VerhuurdersHeader.6bf3eaa9.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "VerhuurdersHeader.6bf3eaa9.js",
    "imports": [
      "_BgBigGreen.44e781e8.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_Werkstek.8f6898da.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Werkstek.8f6898da.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_arrow-right.5a646e90.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "arrow-right.5a646e90.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_arrow-small-right.dc0e01ff.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "arrow-small-right.dc0e01ff.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_asyncData.1c0ed1d3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "asyncData.1c0ed1d3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_building-map-interactive.5a195fd4.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "building-map-interactive.5a195fd4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_client-only.0a906c49.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "client-only.0a906c49.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_config.45f3bc24.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "config.45f3bc24.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_fetch.fb92db8b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "fetch.fb92db8b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_asyncData.1c0ed1d3.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_index.73ae3a71.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.73ae3a71.js",
    "imports": [
      "_index.bc79cc22.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_index.bc79cc22.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.bc79cc22.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_marker-dropdown.137127fb.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "marker-dropdown.137127fb.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_swiper-vue.481cfa94.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "swiper-vue.3061406d.css"
    ],
    "file": "swiper-vue.481cfa94.js"
  },
  "swiper-vue.3061406d.css": {
    "file": "swiper-vue.3061406d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_useAxios.f98c2a57.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useAxios.f98c2a57.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useConvertTime.957d2e34.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useConvertTime.957d2e34.js"
  },
  "_useForgotPassword.da3a5afd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useForgotPassword.da3a5afd.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_useRequestHelper.49566a60.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useRequestHelper.49566a60.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_useSchema.a1c7f408.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useSchema.a1c7f408.js"
  },
  "_vee-validate.esm.0085992c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vee-validate.esm.0085992c.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "assets/fonts/Noto/NotoSans-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "NotoSans-Bold.cf382cad.ttf",
    "src": "assets/fonts/Noto/NotoSans-Bold.ttf"
  },
  "assets/fonts/Noto/NotoSans-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "NotoSans-Medium.9d0511ca.ttf",
    "src": "assets/fonts/Noto/NotoSans-Medium.ttf"
  },
  "assets/fonts/Noto/NotoSans-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "NotoSans-Regular.3be6b371.ttf",
    "src": "assets/fonts/Noto/NotoSans-Regular.ttf"
  },
  "assets/fonts/Poppins/Poppins-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "Poppins-Bold.7219547e.ttf",
    "src": "assets/fonts/Poppins/Poppins-Bold.ttf"
  },
  "assets/fonts/Poppins/Poppins-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "Poppins-Medium.8d909883.ttf",
    "src": "assets/fonts/Poppins/Poppins-Medium.ttf"
  },
  "assets/fonts/Poppins/Poppins-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "Poppins-Regular.707fdc5c.ttf",
    "src": "assets/fonts/Poppins/Poppins-Regular.ttf"
  },
  "i18n.config.ts?hash=bffaebcb&config=1": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "i18n.config.b03cc2fe.js",
    "isDynamicEntry": true,
    "src": "i18n.config.ts?hash=bffaebcb&config=1"
  },
  "layouts/admin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.58e2cc64.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useRequestHelper.49566a60.js",
      "_swiper-vue.481cfa94.js",
      "_NuxtSnackbar.82214fcd.js",
      "_index.73ae3a71.js",
      "_config.45f3bc24.js",
      "_index.bc79cc22.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/admin.vue"
  },
  "layouts/default.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "default.4c48797d.css",
    "src": "layouts/default.css"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "default.1b4f313f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_Werkstek.8f6898da.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_index.73ae3a71.js",
      "_arrow-small-right.dc0e01ff.js",
      "_NuxtSnackbar.82214fcd.js",
      "_fetch.fb92db8b.js",
      "_config.45f3bc24.js",
      "_index.bc79cc22.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "default.4c48797d.css": {
    "file": "default.4c48797d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "middleware/admin.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.95d867b6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/admin.ts"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Icon.6f5d80f8.css",
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.css"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "Icon.861e11ab.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_config.45f3bc24.js",
      "_swiper-vue.481cfa94.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.vue"
  },
  "Icon.6f5d80f8.css": {
    "file": "Icon.6f5d80f8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "IconCSS.fe0874d9.css",
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.css"
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "IconCSS.2f380603.js",
    "imports": [
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_config.45f3bc24.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.vue"
  },
  "IconCSS.fe0874d9.css": {
    "file": "IconCSS.fe0874d9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "entry.2cc35f7b.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.2cc35f7b.css"
    ],
    "dynamicImports": [
      "middleware/admin.ts",
      "layouts/admin.vue",
      "layouts/default.vue",
      "i18n.config.ts?hash=bffaebcb&config=1"
    ],
    "file": "entry.96c405ac.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.2cc35f7b.css": {
    "file": "entry.2cc35f7b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/Faq.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Faq.e9db3fcd.js",
    "imports": [
      "_HeaderWCity.b363ed3d.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/Faq.vue"
  },
  "pages/admin/admin-list/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.d6e34b9a.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_TextField.vue.222c6931.js",
      "_vee-validate.esm.0085992c.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/[slug].vue"
  },
  "pages/admin/admin-list/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.fff9d1c5.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_TextField.vue.222c6931.js",
      "_useForgotPassword.da3a5afd.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/add.vue"
  },
  "pages/admin/admin-list/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.67013048.js",
    "imports": [
      "_ButtonAddIndex.38c5ed13.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1c0ed1d3.js",
      "_index.bc79cc22.js",
      "_swiper-vue.481cfa94.js",
      "_config.45f3bc24.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/index.vue"
  },
  "pages/admin/author/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.1afb7fc9.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_vee-validate.esm.0085992c.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/author/add.vue"
  },
  "pages/admin/author/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.5ce97bb3.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/author/edit/[slug].vue"
  },
  "pages/admin/author/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.78ae27b1.css",
    "src": "pages/admin/author/index.css"
  },
  "pages/admin/author/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.89ca2193.js",
    "imports": [
      "_ButtonAddIndex.38c5ed13.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1c0ed1d3.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.45f3bc24.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/author/index.vue"
  },
  "index.78ae27b1.css": {
    "file": "index.78ae27b1.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/blog-category/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.1bbecb90.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog-category/add.vue"
  },
  "pages/admin/blog-category/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.31925bf3.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog-category/edit/[slug].vue"
  },
  "pages/admin/blog-category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.4bc24538.js",
    "imports": [
      "_ButtonAddIndex.38c5ed13.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1c0ed1d3.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.45f3bc24.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog-category/index.vue"
  },
  "pages/admin/blog/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.6b9dbaf1.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_TextEditor.9ae0bcab.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog/add.vue"
  },
  "pages/admin/blog/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.5e072fce.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_vee-validate.esm.0085992c.js",
      "_TextEditor.9ae0bcab.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog/edit/[slug].vue"
  },
  "pages/admin/blog/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.3a43e528.css",
    "src": "pages/admin/blog/index.css"
  },
  "pages/admin/blog/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.6d98f5b6.js",
    "imports": [
      "_ButtonAddIndex.38c5ed13.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1c0ed1d3.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.45f3bc24.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog/index.vue"
  },
  "index.3a43e528.css": {
    "file": "index.3a43e528.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/category/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.4bb33584.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_vee-validate.esm.0085992c.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/category/add.vue"
  },
  "pages/admin/category/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.ab309cdc.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useSchema.a1c7f408.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_fetch.fb92db8b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/category/edit/[slug].vue"
  },
  "pages/admin/category/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.0aa3d082.css",
    "src": "pages/admin/category/index.css"
  },
  "pages/admin/category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.9162b2c1.js",
    "imports": [
      "_ButtonAddIndex.38c5ed13.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/category/index.vue"
  },
  "index.0aa3d082.css": {
    "file": "index.0aa3d082.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/community/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.48c5c7b4.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_TextEditor.9ae0bcab.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/community/add.vue"
  },
  "pages/admin/community/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.2660cb37.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_vee-validate.esm.0085992c.js",
      "_TextEditor.9ae0bcab.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/community/edit/[slug].vue"
  },
  "pages/admin/community/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.2bdd19ad.css",
    "src": "pages/admin/community/index.css"
  },
  "pages/admin/community/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.8a5d99be.js",
    "imports": [
      "_ButtonAddIndex.38c5ed13.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1c0ed1d3.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.45f3bc24.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/community/index.vue"
  },
  "index.2bdd19ad.css": {
    "file": "index.2bdd19ad.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/contact/[slug].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_slug_.7b803f9d.css",
    "src": "pages/admin/contact/[slug].css"
  },
  "pages/admin/contact/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_slug_.c24fb652.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/contact/[slug].vue"
  },
  "_slug_.7b803f9d.css": {
    "file": "_slug_.7b803f9d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/contact/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.80c0b2b9.css",
    "src": "pages/admin/contact/index.css"
  },
  "pages/admin/contact/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.eccafaba.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1c0ed1d3.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.45f3bc24.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/contact/index.vue"
  },
  "index.80c0b2b9.css": {
    "file": "index.80c0b2b9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/dashboard.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dashboard.9a287995.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/dashboard.vue"
  },
  "pages/admin/edit-admin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "edit-admin.fa56ca7f.js",
    "imports": [
      "_Werkstek.8f6898da.js",
      "_vee-validate.esm.0085992c.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_useSchema.a1c7f408.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/edit-admin.vue"
  },
  "pages/admin/facility/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.7c618c01.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility/add.vue"
  },
  "pages/admin/facility/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.cf6545b0.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility/edit/[slug].vue"
  },
  "pages/admin/facility/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.aba0e47d.css",
    "src": "pages/admin/facility/index.css"
  },
  "pages/admin/facility/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.568b35a7.js",
    "imports": [
      "_ButtonAddIndex.38c5ed13.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1c0ed1d3.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.45f3bc24.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility/index.vue"
  },
  "index.aba0e47d.css": {
    "file": "index.aba0e47d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/forgot-password.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "forgot-password.862bddd5.js",
    "imports": [
      "_TextField.vue.222c6931.js",
      "_useForgotPassword.da3a5afd.js",
      "_vee-validate.esm.0085992c.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_index.73ae3a71.js",
      "_asyncData.1c0ed1d3.js",
      "_index.bc79cc22.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/forgot-password.vue"
  },
  "pages/admin/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.116e6dc9.css",
    "src": "pages/admin/index.css"
  },
  "pages/admin/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.7c340b99.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/index.vue"
  },
  "index.116e6dc9.css": {
    "file": "index.116e6dc9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/level-type/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.3fbe4779.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_vee-validate.esm.0085992c.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/level-type/add.vue"
  },
  "pages/admin/level-type/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.2a910240.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/level-type/edit/[slug].vue"
  },
  "pages/admin/level-type/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.7c373136.js",
    "imports": [
      "_ButtonAddIndex.38c5ed13.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/level-type/index.vue"
  },
  "pages/admin/location/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.2c1b00e7.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_TextField.vue.222c6931.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/location/add.vue"
  },
  "pages/admin/location/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.664febde.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_TextField.vue.222c6931.js",
      "_BlogImageCrop.5a8b5103.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/location/edit/[slug].vue"
  },
  "pages/admin/location/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.9e212985.css",
    "src": "pages/admin/location/index.css"
  },
  "pages/admin/location/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.35e4770e.js",
    "imports": [
      "_ButtonAddIndex.38c5ed13.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1c0ed1d3.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.45f3bc24.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/location/index.vue"
  },
  "index.9e212985.css": {
    "file": "index.9e212985.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/newsletter/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.ca61fc98.css",
    "src": "pages/admin/newsletter/index.css"
  },
  "pages/admin/newsletter/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.7da98992.js",
    "imports": [
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_asyncData.1c0ed1d3.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/newsletter/index.vue"
  },
  "index.ca61fc98.css": {
    "file": "index.ca61fc98.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/onze-locaties/add-image/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.3e25c66a.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/add-image/[slug].vue"
  },
  "pages/admin/onze-locaties/add-video/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.df51474c.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useAxios.f98c2a57.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/add-video/[slug].vue"
  },
  "pages/admin/onze-locaties/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.2e8f4cee.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_TextField.vue.222c6931.js",
      "_vee-validate.esm.0085992c.js",
      "_TextEditor.9ae0bcab.js",
      "_MapsTest.739ff50f.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/add.vue"
  },
  "pages/admin/onze-locaties/edit-locaties/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.97414edd.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_TextField.vue.222c6931.js",
      "_vee-validate.esm.0085992c.js",
      "_TextEditor.9ae0bcab.js",
      "_MapsTest.739ff50f.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/edit-locaties/[slug].vue"
  },
  "pages/admin/onze-locaties/featured-property/[slug].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_slug_.abd9ceb2.css",
    "src": "pages/admin/onze-locaties/featured-property/[slug].css"
  },
  "pages/admin/onze-locaties/featured-property/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_slug_.6af8666f.js",
    "imports": [
      "_ButtonAddIndex.38c5ed13.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/featured-property/[slug].vue"
  },
  "_slug_.abd9ceb2.css": {
    "file": "_slug_.abd9ceb2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/onze-locaties/featured-property/add-sortlist/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.2cd0d2e3.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.fb92db8b.js",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/featured-property/add-sortlist/add.vue"
  },
  "pages/admin/onze-locaties/featured-property/add/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.93812870.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_ButtonAddIndex.38c5ed13.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.fb92db8b.js",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/featured-property/add/index.vue"
  },
  "pages/admin/onze-locaties/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.1a5fb2ed.css",
    "src": "pages/admin/onze-locaties/index.css"
  },
  "pages/admin/onze-locaties/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.c46b03d6.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_ButtonAddIndex.38c5ed13.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1c0ed1d3.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.45f3bc24.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/index.vue"
  },
  "index.1a5fb2ed.css": {
    "file": "index.1a5fb2ed.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/onze-vacatures/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.e7e53629.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_useAxios.f98c2a57.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-vacatures/add.vue"
  },
  "pages/admin/onze-vacatures/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.411c77d7.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_useAxios.f98c2a57.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_asyncData.1c0ed1d3.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-vacatures/edit/[slug].vue"
  },
  "pages/admin/onze-vacatures/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.473830ec.css",
    "src": "pages/admin/onze-vacatures/index.css"
  },
  "pages/admin/onze-vacatures/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.b0fe3eff.js",
    "imports": [
      "_ButtonAddIndex.38c5ed13.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1c0ed1d3.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.45f3bc24.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-vacatures/index.vue"
  },
  "index.473830ec.css": {
    "file": "index.473830ec.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/privilages/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.23bc6897.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/privilages/add.vue"
  },
  "pages/admin/privilages/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.d1922ef8.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/privilages/edit/[slug].vue"
  },
  "pages/admin/privilages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.b63abace.js",
    "imports": [
      "_ButtonAddIndex.38c5ed13.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/privilages/index.vue"
  },
  "pages/admin/registration.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "registration.26bb5e09.js",
    "imports": [
      "_Werkstek.8f6898da.js",
      "_TextField.vue.222c6931.js",
      "_useForgotPassword.da3a5afd.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/registration.vue"
  },
  "pages/admin/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-in.d9b7a30e.js",
    "imports": [
      "_Werkstek.8f6898da.js",
      "_TextField.vue.222c6931.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/sign-in.vue"
  },
  "pages/admin/type-vacatures/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.7f0b1fb9.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type-vacatures/add.vue"
  },
  "pages/admin/type-vacatures/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.c8da42f3.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type-vacatures/edit/[slug].vue"
  },
  "pages/admin/type-vacatures/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.5fab9ce3.css",
    "src": "pages/admin/type-vacatures/index.css"
  },
  "pages/admin/type-vacatures/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.7f176e8b.js",
    "imports": [
      "_ButtonAddIndex.38c5ed13.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1c0ed1d3.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.45f3bc24.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type-vacatures/index.vue"
  },
  "index.5fab9ce3.css": {
    "file": "index.5fab9ce3.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/type/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.182a8a8e.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type/add.vue"
  },
  "pages/admin/type/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.88446351.js",
    "imports": [
      "_BackButton.058dc03a.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type/edit/[slug].vue"
  },
  "pages/admin/type/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.6199310c.js",
    "imports": [
      "_ButtonAddIndex.38c5ed13.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type/index.vue"
  },
  "pages/admin/verified-email/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.97cdde6b.js",
    "imports": [
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/verified-email/[slug].vue"
  },
  "pages/blog/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.c0032981.js",
    "imports": [
      "_EachBlog.5746f35e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/blog/[slug].vue"
  },
  "pages/blog/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.fd1b55a2.css",
    "src": "pages/blog/index.css"
  },
  "pages/blog/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.72b58746.js",
    "imports": [
      "_HeaderWCity.b363ed3d.js",
      "_Blog.a5b1ba97.js",
      "_BlogItem.bdfab12d.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_asyncData.1c0ed1d3.js",
      "_swiper-vue.481cfa94.js",
      "_BgBigGreen.44e781e8.js",
      "_TitleHeader.61d4a951.js",
      "_EachBlogSmall.affe650c.js",
      "_client-only.0a906c49.js",
      "_arrow-right.5a646e90.js",
      "_fetch.fb92db8b.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "_arrow-small-right.dc0e01ff.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/blog/index.vue"
  },
  "index.fd1b55a2.css": {
    "file": "index.fd1b55a2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/contact.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contact.e037b501.js",
    "imports": [
      "_building-map-interactive.5a195fd4.js",
      "_BgBigGreen.44e781e8.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_vee-validate.esm.0085992c.js",
      "_useSchema.a1c7f408.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.fb92db8b.js",
      "_MapInteractive.4946b0e2.js",
      "_arrow-small-right.dc0e01ff.js",
      "_asyncData.1c0ed1d3.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_useAxios.f98c2a57.js",
      "_arrow-right.5a646e90.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/contact.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.39dd8f95.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.9a73d502.js",
    "imports": [
      "_building-map-interactive.5a195fd4.js",
      "_BgBigGreen.44e781e8.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useRequestHelper.49566a60.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_useAxios.f98c2a57.js",
      "_SliderLocatiesSort.b170f9b1.js",
      "_SliderTestimony.55574086.js",
      "_arrow-right.5a646e90.js",
      "_TitleHeader.61d4a951.js",
      "_Blog.a5b1ba97.js",
      "_vee-validate.esm.0085992c.js",
      "_arrow-small-right.dc0e01ff.js",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js",
      "_client-only.0a906c49.js",
      "_EachBlogSmall.affe650c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.39dd8f95.css": {
    "file": "index.39dd8f95.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/onze-locaties/[slug].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_slug_.ebc7e03b.css",
    "src": "pages/onze-locaties/[slug].css"
  },
  "pages/onze-locaties/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_slug_.d01aa670.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_fetch.fb92db8b.js",
      "_SliderLocatiesSort.b170f9b1.js",
      "_SliderTestimony.55574086.js",
      "_config.45f3bc24.js",
      "_asyncData.1c0ed1d3.js",
      "_client-only.0a906c49.js",
      "_TitleHeader.61d4a951.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/onze-locaties/[slug].vue"
  },
  "_slug_.ebc7e03b.css": {
    "file": "_slug_.ebc7e03b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/onze-locaties/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.a22b6581.css",
    "src": "pages/onze-locaties/index.css"
  },
  "pages/onze-locaties/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.47f747ad.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_TitleHeader.61d4a951.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_arrow-right.5a646e90.js",
      "_Pagination.840304e6.js",
      "_asyncData.1c0ed1d3.js",
      "_marker-dropdown.137127fb.js",
      "_index.bc79cc22.js",
      "_BgBigGreen.44e781e8.js",
      "_config.45f3bc24.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.fb92db8b.js",
      "_arrow-small-right.dc0e01ff.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/onze-locaties/index.vue"
  },
  "index.a22b6581.css": {
    "file": "index.a22b6581.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/onze-vacatures/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.1773a3d3.js",
    "imports": [
      "_HeaderWCity.b363ed3d.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_useConvertTime.957d2e34.js",
      "_swiper-vue.481cfa94.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/onze-vacatures/[slug].vue"
  },
  "pages/onze-vacatures/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.881b2779.css",
    "src": "pages/onze-vacatures/index.css"
  },
  "pages/onze-vacatures/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.8b397894.js",
    "imports": [
      "_HeaderWCity.b363ed3d.js",
      "_TitleHeader.61d4a951.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useConvertTime.957d2e34.js",
      "_arrow-right.5a646e90.js",
      "_swiper-vue.481cfa94.js",
      "_Pagination.840304e6.js",
      "_asyncData.1c0ed1d3.js",
      "_marker-dropdown.137127fb.js",
      "_index.bc79cc22.js",
      "_config.45f3bc24.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/onze-vacatures/index.vue"
  },
  "index.881b2779.css": {
    "file": "index.881b2779.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/over-werkstek.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "over-werkstek.72ea309d.js",
    "imports": [
      "_VerhuurdersHeader.6bf3eaa9.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_LeegstandNoButton.7948037f.js",
      "_BgBigGreen.44e781e8.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.fb92db8b.js",
      "_asyncData.1c0ed1d3.js",
      "_arrow-small-right.dc0e01ff.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/over-werkstek.vue"
  },
  "pages/privacy-verklaring.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "privacy-verklaring.001ffa6c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/privacy-verklaring.vue"
  },
  "pages/voor-verhuurders.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "voor-verhuurders.ed0f6848.js",
    "imports": [
      "_VerhuurdersHeader.6bf3eaa9.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_building-map-interactive.5a195fd4.js",
      "_BgBigGreen.44e781e8.js",
      "_LeegstandNoButton.7948037f.js",
      "_MapInteractive.4946b0e2.js",
      "_SliderTestimony.55574086.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.fb92db8b.js",
      "_asyncData.1c0ed1d3.js",
      "_arrow-small-right.dc0e01ff.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_useAxios.f98c2a57.js",
      "_arrow-right.5a646e90.js",
      "_TitleHeader.61d4a951.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/voor-verhuurders.vue"
  },
  "pages/werkstek-community/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.f86edf86.js",
    "imports": [
      "_EachBlog.5746f35e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.45f3bc24.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1c0ed1d3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/werkstek-community/[slug].vue"
  },
  "pages/werkstek-community/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.476fca53.css",
    "src": "pages/werkstek-community/index.css"
  },
  "pages/werkstek-community/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.1217fb37.js",
    "imports": [
      "_HeaderWCity.b363ed3d.js",
      "_TitleHeader.61d4a951.js",
      "_EachBlogSmall.affe650c.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.fb92db8b.js",
      "_swiper-vue.481cfa94.js",
      "_BlogItem.bdfab12d.js",
      "_LeegstandNoButton.7948037f.js",
      "_BgBigGreen.44e781e8.js",
      "_client-only.0a906c49.js",
      "_arrow-right.5a646e90.js",
      "_asyncData.1c0ed1d3.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "_arrow-small-right.dc0e01ff.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/werkstek-community/index.vue"
  },
  "index.476fca53.css": {
    "file": "index.476fca53.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "swiper-vue.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "swiper-vue.3061406d.css",
    "src": "swiper-vue.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
