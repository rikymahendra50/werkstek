const client_manifest = {
  "BgBigGreen.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "BgBigGreen.f4cc734e.css",
    "src": "BgBigGreen.css"
  },
  "MapInteractive.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "MapInteractive.ffc01d21.css",
    "src": "MapInteractive.css"
  },
  "SliderLocatiesSort.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "SliderLocatiesSort.a9d13604.css",
    "src": "SliderLocatiesSort.css"
  },
  "SliderTestimony.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "SliderTestimony.29a5e60b.css",
    "src": "SliderTestimony.css"
  },
  "TextEditor.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "TextEditor.65389021.css",
    "src": "TextEditor.css"
  },
  "_BackButton.64691c86.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "BackButton.64691c86.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_BgBigGreen.8b4dfa13.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "BgBigGreen.f4cc734e.css"
    ],
    "file": "BgBigGreen.8b4dfa13.js",
    "imports": [
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_arrow-small-right.6a9de69a.js"
    ]
  },
  "BgBigGreen.f4cc734e.css": {
    "file": "BgBigGreen.f4cc734e.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Blog.30ad783f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Blog.30ad783f.js",
    "imports": [
      "_TitleHeader.2f74a40b.js",
      "_EachBlogSmall.c29ec035.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_BlogImageCrop.5a8b5103.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "BlogImageCrop.5a8b5103.js",
    "imports": [
      "_swiper-vue.481cfa94.js",
      "_index.73ae3a71.js",
      "_client-only.0a906c49.js"
    ]
  },
  "_BlogItem.d9d30eb7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "BlogItem.d9d30eb7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_client-only.0a906c49.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_ButtonAddForm.51f2c614.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ButtonAddForm.51f2c614.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_ButtonAddIndex.f8432e49.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ButtonAddIndex.f8432e49.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_EachBlog.53083ec7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "EachBlog.53083ec7.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_EachBlogSmall.c29ec035.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "EachBlogSmall.c29ec035.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_client-only.0a906c49.js",
      "_arrow-right.39a8cb77.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_HeaderWCity.66c3fd63.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "HeaderWCity.66c3fd63.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_LeegstandNoButton.09c20eb0.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "LeegstandNoButton.09c20eb0.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_MapInteractive.efc12962.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "MapInteractive.ffc01d21.css"
    ],
    "file": "MapInteractive.efc12962.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useAxios.e39d2645.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_arrow-right.39a8cb77.js",
      "_building-map-interactive.ed841323.js"
    ]
  },
  "MapInteractive.ffc01d21.css": {
    "file": "MapInteractive.ffc01d21.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_MapsTest.739ff50f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MapsTest.739ff50f.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_NuxtSnackbar.cd17a9b1.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "NuxtSnackbar.cd17a9b1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_Pagination.840304e6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Pagination.840304e6.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_SliderLocatiesSort.6c309e2c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "SliderLocatiesSort.a9d13604.css"
    ],
    "file": "SliderLocatiesSort.6c309e2c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_client-only.0a906c49.js"
    ]
  },
  "SliderLocatiesSort.a9d13604.css": {
    "file": "SliderLocatiesSort.a9d13604.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_SliderTestimony.67e664fa.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "SliderTestimony.29a5e60b.css"
    ],
    "file": "SliderTestimony.67e664fa.js",
    "imports": [
      "_TitleHeader.2f74a40b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "SliderTestimony.29a5e60b.css": {
    "file": "SliderTestimony.29a5e60b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TextEditor.54e8e77e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "TextEditor.65389021.css"
    ],
    "file": "TextEditor.54e8e77e.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "TextEditor.65389021.css": {
    "file": "TextEditor.65389021.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TextField.vue.222c6931.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TextField.vue.222c6931.js",
    "imports": [
      "_vee-validate.esm.0085992c.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_TitleHeader.2f74a40b.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TitleHeader.2f74a40b.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_VerhuurdersHeader.db4b4d3c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "VerhuurdersHeader.db4b4d3c.js",
    "imports": [
      "_BgBigGreen.8b4dfa13.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_Werkstek.c3f6fa10.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Werkstek.c3f6fa10.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_arrow-right.39a8cb77.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "arrow-right.39a8cb77.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_arrow-small-right.6a9de69a.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "arrow-small-right.6a9de69a.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_asyncData.8c4da2c1.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "asyncData.8c4da2c1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_building-map-interactive.ed841323.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "building-map-interactive.ed841323.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_client-only.0a906c49.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "client-only.0a906c49.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_config.4ab687a3.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "config.4ab687a3.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_fetch.bb9c004f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "fetch.bb9c004f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_asyncData.8c4da2c1.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_index.73ae3a71.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.73ae3a71.js",
    "imports": [
      "_index.bc79cc22.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_index.bc79cc22.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.bc79cc22.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_marker-dropdown.ca3443fd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "marker-dropdown.ca3443fd.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_swiper-vue.481cfa94.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "swiper-vue.3061406d.css"
    ],
    "file": "swiper-vue.481cfa94.js"
  },
  "swiper-vue.3061406d.css": {
    "file": "swiper-vue.3061406d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_useAxios.e39d2645.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useAxios.e39d2645.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useConvertTime.957d2e34.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useConvertTime.957d2e34.js"
  },
  "_useForgotPassword.da3a5afd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useForgotPassword.da3a5afd.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_useRequestHelper.49566a60.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useRequestHelper.49566a60.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_useSchema.a1c7f408.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useSchema.a1c7f408.js"
  },
  "_vee-validate.esm.0085992c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vee-validate.esm.0085992c.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "assets/fonts/Noto/NotoSans-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "NotoSans-Bold.cf382cad.ttf",
    "src": "assets/fonts/Noto/NotoSans-Bold.ttf"
  },
  "assets/fonts/Noto/NotoSans-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "NotoSans-Medium.9d0511ca.ttf",
    "src": "assets/fonts/Noto/NotoSans-Medium.ttf"
  },
  "assets/fonts/Noto/NotoSans-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "NotoSans-Regular.3be6b371.ttf",
    "src": "assets/fonts/Noto/NotoSans-Regular.ttf"
  },
  "assets/fonts/Poppins/Poppins-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "Poppins-Bold.7219547e.ttf",
    "src": "assets/fonts/Poppins/Poppins-Bold.ttf"
  },
  "assets/fonts/Poppins/Poppins-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "Poppins-Medium.8d909883.ttf",
    "src": "assets/fonts/Poppins/Poppins-Medium.ttf"
  },
  "assets/fonts/Poppins/Poppins-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "Poppins-Regular.707fdc5c.ttf",
    "src": "assets/fonts/Poppins/Poppins-Regular.ttf"
  },
  "i18n.config.ts?hash=bffaebcb&config=1": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "i18n.config.b03cc2fe.js",
    "isDynamicEntry": true,
    "src": "i18n.config.ts?hash=bffaebcb&config=1"
  },
  "layouts/admin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.582272d9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useRequestHelper.49566a60.js",
      "_swiper-vue.481cfa94.js",
      "_NuxtSnackbar.cd17a9b1.js",
      "_index.73ae3a71.js",
      "_config.4ab687a3.js",
      "_index.bc79cc22.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/admin.vue"
  },
  "layouts/default.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "default.4c48797d.css",
    "src": "layouts/default.css"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "default.a6c1404d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_Werkstek.c3f6fa10.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_index.73ae3a71.js",
      "_arrow-small-right.6a9de69a.js",
      "_NuxtSnackbar.cd17a9b1.js",
      "_fetch.bb9c004f.js",
      "_config.4ab687a3.js",
      "_index.bc79cc22.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "default.4c48797d.css": {
    "file": "default.4c48797d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "middleware/admin.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.238ac99e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/admin.ts"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Icon.6f5d80f8.css",
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.css"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "Icon.828a0e14.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_config.4ab687a3.js",
      "_swiper-vue.481cfa94.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.vue"
  },
  "Icon.6f5d80f8.css": {
    "file": "Icon.6f5d80f8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "IconCSS.fe0874d9.css",
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.css"
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "IconCSS.06191121.js",
    "imports": [
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_config.4ab687a3.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.vue"
  },
  "IconCSS.fe0874d9.css": {
    "file": "IconCSS.fe0874d9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "entry.2cc35f7b.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.2cc35f7b.css"
    ],
    "dynamicImports": [
      "middleware/admin.ts",
      "layouts/admin.vue",
      "layouts/default.vue",
      "i18n.config.ts?hash=bffaebcb&config=1"
    ],
    "file": "entry.6b1d3618.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.2cc35f7b.css": {
    "file": "entry.2cc35f7b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/Faq.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Faq.0d208c12.js",
    "imports": [
      "_HeaderWCity.66c3fd63.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/Faq.vue"
  },
  "pages/admin/admin-list/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.45ea6a41.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_TextField.vue.222c6931.js",
      "_vee-validate.esm.0085992c.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/[slug].vue"
  },
  "pages/admin/admin-list/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.1c4d607f.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_TextField.vue.222c6931.js",
      "_useForgotPassword.da3a5afd.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/add.vue"
  },
  "pages/admin/admin-list/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.da1efdf4.js",
    "imports": [
      "_ButtonAddIndex.f8432e49.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.8c4da2c1.js",
      "_index.bc79cc22.js",
      "_swiper-vue.481cfa94.js",
      "_config.4ab687a3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/index.vue"
  },
  "pages/admin/author/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.9d3bc9e9.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_vee-validate.esm.0085992c.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/author/add.vue"
  },
  "pages/admin/author/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.318b333b.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/author/edit/[slug].vue"
  },
  "pages/admin/author/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.78ae27b1.css",
    "src": "pages/admin/author/index.css"
  },
  "pages/admin/author/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.07099f31.js",
    "imports": [
      "_ButtonAddIndex.f8432e49.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.8c4da2c1.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.4ab687a3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/author/index.vue"
  },
  "index.78ae27b1.css": {
    "file": "index.78ae27b1.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/blog-category/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.2063e9ae.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog-category/add.vue"
  },
  "pages/admin/blog-category/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.d60bb6a6.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog-category/edit/[slug].vue"
  },
  "pages/admin/blog-category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.d61dd9f1.js",
    "imports": [
      "_ButtonAddIndex.f8432e49.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.8c4da2c1.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.4ab687a3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog-category/index.vue"
  },
  "pages/admin/blog/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.d2c6f328.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_TextEditor.54e8e77e.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog/add.vue"
  },
  "pages/admin/blog/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.c950e8ac.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_vee-validate.esm.0085992c.js",
      "_TextEditor.54e8e77e.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog/edit/[slug].vue"
  },
  "pages/admin/blog/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.3a43e528.css",
    "src": "pages/admin/blog/index.css"
  },
  "pages/admin/blog/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.9ded0541.js",
    "imports": [
      "_ButtonAddIndex.f8432e49.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.8c4da2c1.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.4ab687a3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog/index.vue"
  },
  "index.3a43e528.css": {
    "file": "index.3a43e528.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/category/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.10565cb7.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_vee-validate.esm.0085992c.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/category/add.vue"
  },
  "pages/admin/category/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.db9a5615.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useSchema.a1c7f408.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_fetch.bb9c004f.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/category/edit/[slug].vue"
  },
  "pages/admin/category/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.0aa3d082.css",
    "src": "pages/admin/category/index.css"
  },
  "pages/admin/category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.d67e6eb0.js",
    "imports": [
      "_ButtonAddIndex.f8432e49.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/category/index.vue"
  },
  "index.0aa3d082.css": {
    "file": "index.0aa3d082.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/community/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.b3fe72c6.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_TextEditor.54e8e77e.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/community/add.vue"
  },
  "pages/admin/community/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.cc8bfbb9.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_vee-validate.esm.0085992c.js",
      "_TextEditor.54e8e77e.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/community/edit/[slug].vue"
  },
  "pages/admin/community/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.2bdd19ad.css",
    "src": "pages/admin/community/index.css"
  },
  "pages/admin/community/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.6057b701.js",
    "imports": [
      "_ButtonAddIndex.f8432e49.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.8c4da2c1.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.4ab687a3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/community/index.vue"
  },
  "index.2bdd19ad.css": {
    "file": "index.2bdd19ad.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/contact/[slug].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_slug_.7b803f9d.css",
    "src": "pages/admin/contact/[slug].css"
  },
  "pages/admin/contact/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_slug_.95751cc7.js",
    "imports": [
      "_BackButton.64691c86.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/contact/[slug].vue"
  },
  "_slug_.7b803f9d.css": {
    "file": "_slug_.7b803f9d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/contact/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.80c0b2b9.css",
    "src": "pages/admin/contact/index.css"
  },
  "pages/admin/contact/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.250d9708.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.8c4da2c1.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.4ab687a3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/contact/index.vue"
  },
  "index.80c0b2b9.css": {
    "file": "index.80c0b2b9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/dashboard.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dashboard.0580c503.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/dashboard.vue"
  },
  "pages/admin/edit-admin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "edit-admin.75319f90.js",
    "imports": [
      "_Werkstek.c3f6fa10.js",
      "_vee-validate.esm.0085992c.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_useSchema.a1c7f408.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/edit-admin.vue"
  },
  "pages/admin/facility/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.aeba6c91.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility/add.vue"
  },
  "pages/admin/facility/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.4347db93.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility/edit/[slug].vue"
  },
  "pages/admin/facility/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.aba0e47d.css",
    "src": "pages/admin/facility/index.css"
  },
  "pages/admin/facility/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.a28601b5.js",
    "imports": [
      "_ButtonAddIndex.f8432e49.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.8c4da2c1.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.4ab687a3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility/index.vue"
  },
  "index.aba0e47d.css": {
    "file": "index.aba0e47d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/forgot-password.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "forgot-password.81ea0537.js",
    "imports": [
      "_TextField.vue.222c6931.js",
      "_useForgotPassword.da3a5afd.js",
      "_vee-validate.esm.0085992c.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_index.73ae3a71.js",
      "_asyncData.8c4da2c1.js",
      "_index.bc79cc22.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/forgot-password.vue"
  },
  "pages/admin/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.116e6dc9.css",
    "src": "pages/admin/index.css"
  },
  "pages/admin/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.a20c1d76.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/index.vue"
  },
  "index.116e6dc9.css": {
    "file": "index.116e6dc9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/level-type/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.479605ef.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_vee-validate.esm.0085992c.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/level-type/add.vue"
  },
  "pages/admin/level-type/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.d9afc115.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/level-type/edit/[slug].vue"
  },
  "pages/admin/level-type/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.21f62b68.js",
    "imports": [
      "_ButtonAddIndex.f8432e49.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/level-type/index.vue"
  },
  "pages/admin/location/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.96286695.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_TextField.vue.222c6931.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/location/add.vue"
  },
  "pages/admin/location/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.5611869e.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_TextField.vue.222c6931.js",
      "_BlogImageCrop.5a8b5103.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/location/edit/[slug].vue"
  },
  "pages/admin/location/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.9e212985.css",
    "src": "pages/admin/location/index.css"
  },
  "pages/admin/location/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.e12250dc.js",
    "imports": [
      "_ButtonAddIndex.f8432e49.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.8c4da2c1.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.4ab687a3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/location/index.vue"
  },
  "index.9e212985.css": {
    "file": "index.9e212985.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/newsletter/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.ca61fc98.css",
    "src": "pages/admin/newsletter/index.css"
  },
  "pages/admin/newsletter/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.1cfd57b6.js",
    "imports": [
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_asyncData.8c4da2c1.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/newsletter/index.vue"
  },
  "index.ca61fc98.css": {
    "file": "index.ca61fc98.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/onze-locaties/add-image/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.64d0046c.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/add-image/[slug].vue"
  },
  "pages/admin/onze-locaties/add-video/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.b44ede8b.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useAxios.e39d2645.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/add-video/[slug].vue"
  },
  "pages/admin/onze-locaties/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.02e613ca.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_TextField.vue.222c6931.js",
      "_vee-validate.esm.0085992c.js",
      "_TextEditor.54e8e77e.js",
      "_MapsTest.739ff50f.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/add.vue"
  },
  "pages/admin/onze-locaties/edit-locaties/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.857e867c.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_TextField.vue.222c6931.js",
      "_vee-validate.esm.0085992c.js",
      "_TextEditor.54e8e77e.js",
      "_MapsTest.739ff50f.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/edit-locaties/[slug].vue"
  },
  "pages/admin/onze-locaties/featured-property/[slug].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_slug_.abd9ceb2.css",
    "src": "pages/admin/onze-locaties/featured-property/[slug].css"
  },
  "pages/admin/onze-locaties/featured-property/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_slug_.15fff94f.js",
    "imports": [
      "_ButtonAddIndex.f8432e49.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/featured-property/[slug].vue"
  },
  "_slug_.abd9ceb2.css": {
    "file": "_slug_.abd9ceb2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/onze-locaties/featured-property/add-sortlist/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.221085d9.js",
    "imports": [
      "_BackButton.64691c86.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.bb9c004f.js",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/featured-property/add-sortlist/add.vue"
  },
  "pages/admin/onze-locaties/featured-property/add/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.007e7b65.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_ButtonAddIndex.f8432e49.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.bb9c004f.js",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/featured-property/add/index.vue"
  },
  "pages/admin/onze-locaties/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.1a5fb2ed.css",
    "src": "pages/admin/onze-locaties/index.css"
  },
  "pages/admin/onze-locaties/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.e7452d8e.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_ButtonAddIndex.f8432e49.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.8c4da2c1.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.4ab687a3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/index.vue"
  },
  "index.1a5fb2ed.css": {
    "file": "index.1a5fb2ed.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/onze-vacatures/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.54aceb1b.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_useAxios.e39d2645.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-vacatures/add.vue"
  },
  "pages/admin/onze-vacatures/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.3d121ab2.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_useAxios.e39d2645.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_asyncData.8c4da2c1.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-vacatures/edit/[slug].vue"
  },
  "pages/admin/onze-vacatures/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.473830ec.css",
    "src": "pages/admin/onze-vacatures/index.css"
  },
  "pages/admin/onze-vacatures/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.cce67406.js",
    "imports": [
      "_ButtonAddIndex.f8432e49.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.8c4da2c1.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.4ab687a3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-vacatures/index.vue"
  },
  "index.473830ec.css": {
    "file": "index.473830ec.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/privilages/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.9f30b2ac.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/privilages/add.vue"
  },
  "pages/admin/privilages/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.e0d7a7bf.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/privilages/edit/[slug].vue"
  },
  "pages/admin/privilages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.586dc876.js",
    "imports": [
      "_ButtonAddIndex.f8432e49.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/privilages/index.vue"
  },
  "pages/admin/registration.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "registration.ddcaffcd.js",
    "imports": [
      "_Werkstek.c3f6fa10.js",
      "_TextField.vue.222c6931.js",
      "_useForgotPassword.da3a5afd.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/registration.vue"
  },
  "pages/admin/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-in.1d014e86.js",
    "imports": [
      "_Werkstek.c3f6fa10.js",
      "_TextField.vue.222c6931.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/sign-in.vue"
  },
  "pages/admin/type-vacatures/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.312737d7.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type-vacatures/add.vue"
  },
  "pages/admin/type-vacatures/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.4256036b.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type-vacatures/edit/[slug].vue"
  },
  "pages/admin/type-vacatures/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.5fab9ce3.css",
    "src": "pages/admin/type-vacatures/index.css"
  },
  "pages/admin/type-vacatures/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.e6b05436.js",
    "imports": [
      "_ButtonAddIndex.f8432e49.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.8c4da2c1.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.4ab687a3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type-vacatures/index.vue"
  },
  "index.5fab9ce3.css": {
    "file": "index.5fab9ce3.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/type/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.0872c593.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type/add.vue"
  },
  "pages/admin/type/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.d4b54e74.js",
    "imports": [
      "_BackButton.64691c86.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type/edit/[slug].vue"
  },
  "pages/admin/type/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.8cf58726.js",
    "imports": [
      "_ButtonAddIndex.f8432e49.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type/index.vue"
  },
  "pages/admin/verified-email/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.0ca824da.js",
    "imports": [
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/verified-email/[slug].vue"
  },
  "pages/blog/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.8dcfa4bf.js",
    "imports": [
      "_EachBlog.53083ec7.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/blog/[slug].vue"
  },
  "pages/blog/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.fd1b55a2.css",
    "src": "pages/blog/index.css"
  },
  "pages/blog/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.a8d980a0.js",
    "imports": [
      "_HeaderWCity.66c3fd63.js",
      "_Blog.30ad783f.js",
      "_BlogItem.d9d30eb7.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_asyncData.8c4da2c1.js",
      "_swiper-vue.481cfa94.js",
      "_BgBigGreen.8b4dfa13.js",
      "_TitleHeader.2f74a40b.js",
      "_EachBlogSmall.c29ec035.js",
      "_client-only.0a906c49.js",
      "_arrow-right.39a8cb77.js",
      "_fetch.bb9c004f.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "_arrow-small-right.6a9de69a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/blog/index.vue"
  },
  "index.fd1b55a2.css": {
    "file": "index.fd1b55a2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/contact.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contact.fb18d337.js",
    "imports": [
      "_building-map-interactive.ed841323.js",
      "_BgBigGreen.8b4dfa13.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_vee-validate.esm.0085992c.js",
      "_useSchema.a1c7f408.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.bb9c004f.js",
      "_MapInteractive.efc12962.js",
      "_arrow-small-right.6a9de69a.js",
      "_asyncData.8c4da2c1.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_useAxios.e39d2645.js",
      "_arrow-right.39a8cb77.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/contact.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.39dd8f95.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.3a8bb9b1.js",
    "imports": [
      "_building-map-interactive.ed841323.js",
      "_BgBigGreen.8b4dfa13.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useRequestHelper.49566a60.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_useAxios.e39d2645.js",
      "_SliderLocatiesSort.6c309e2c.js",
      "_SliderTestimony.67e664fa.js",
      "_arrow-right.39a8cb77.js",
      "_TitleHeader.2f74a40b.js",
      "_Blog.30ad783f.js",
      "_vee-validate.esm.0085992c.js",
      "_arrow-small-right.6a9de69a.js",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js",
      "_client-only.0a906c49.js",
      "_EachBlogSmall.c29ec035.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.39dd8f95.css": {
    "file": "index.39dd8f95.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/onze-locaties/[slug].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_slug_.ebc7e03b.css",
    "src": "pages/onze-locaties/[slug].css"
  },
  "pages/onze-locaties/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_slug_.00f6040d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_fetch.bb9c004f.js",
      "_SliderLocatiesSort.6c309e2c.js",
      "_SliderTestimony.67e664fa.js",
      "_config.4ab687a3.js",
      "_asyncData.8c4da2c1.js",
      "_client-only.0a906c49.js",
      "_TitleHeader.2f74a40b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/onze-locaties/[slug].vue"
  },
  "_slug_.ebc7e03b.css": {
    "file": "_slug_.ebc7e03b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/onze-locaties/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.a22b6581.css",
    "src": "pages/onze-locaties/index.css"
  },
  "pages/onze-locaties/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.e61de73d.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_TitleHeader.2f74a40b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_arrow-right.39a8cb77.js",
      "_Pagination.840304e6.js",
      "_asyncData.8c4da2c1.js",
      "_marker-dropdown.ca3443fd.js",
      "_index.bc79cc22.js",
      "_BgBigGreen.8b4dfa13.js",
      "_config.4ab687a3.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.bb9c004f.js",
      "_arrow-small-right.6a9de69a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/onze-locaties/index.vue"
  },
  "index.a22b6581.css": {
    "file": "index.a22b6581.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/onze-vacatures/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.fcaecf3d.js",
    "imports": [
      "_HeaderWCity.66c3fd63.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_useConvertTime.957d2e34.js",
      "_swiper-vue.481cfa94.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/onze-vacatures/[slug].vue"
  },
  "pages/onze-vacatures/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.881b2779.css",
    "src": "pages/onze-vacatures/index.css"
  },
  "pages/onze-vacatures/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.721ee3ee.js",
    "imports": [
      "_HeaderWCity.66c3fd63.js",
      "_TitleHeader.2f74a40b.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useConvertTime.957d2e34.js",
      "_arrow-right.39a8cb77.js",
      "_swiper-vue.481cfa94.js",
      "_Pagination.840304e6.js",
      "_asyncData.8c4da2c1.js",
      "_marker-dropdown.ca3443fd.js",
      "_index.bc79cc22.js",
      "_config.4ab687a3.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/onze-vacatures/index.vue"
  },
  "index.881b2779.css": {
    "file": "index.881b2779.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/over-werkstek.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "over-werkstek.99064f0a.js",
    "imports": [
      "_VerhuurdersHeader.db4b4d3c.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_LeegstandNoButton.09c20eb0.js",
      "_BgBigGreen.8b4dfa13.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.bb9c004f.js",
      "_asyncData.8c4da2c1.js",
      "_arrow-small-right.6a9de69a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/over-werkstek.vue"
  },
  "pages/privacy-verklaring.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "privacy-verklaring.0586ef51.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/privacy-verklaring.vue"
  },
  "pages/voor-verhuurders.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "voor-verhuurders.de6b4aea.js",
    "imports": [
      "_VerhuurdersHeader.db4b4d3c.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_building-map-interactive.ed841323.js",
      "_BgBigGreen.8b4dfa13.js",
      "_LeegstandNoButton.09c20eb0.js",
      "_MapInteractive.efc12962.js",
      "_SliderTestimony.67e664fa.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.bb9c004f.js",
      "_asyncData.8c4da2c1.js",
      "_arrow-small-right.6a9de69a.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_useAxios.e39d2645.js",
      "_arrow-right.39a8cb77.js",
      "_TitleHeader.2f74a40b.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/voor-verhuurders.vue"
  },
  "pages/werkstek-community/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.02267158.js",
    "imports": [
      "_EachBlog.53083ec7.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.4ab687a3.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.8c4da2c1.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/werkstek-community/[slug].vue"
  },
  "pages/werkstek-community/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.476fca53.css",
    "src": "pages/werkstek-community/index.css"
  },
  "pages/werkstek-community/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.9d319b3a.js",
    "imports": [
      "_HeaderWCity.66c3fd63.js",
      "_TitleHeader.2f74a40b.js",
      "_EachBlogSmall.c29ec035.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.bb9c004f.js",
      "_swiper-vue.481cfa94.js",
      "_BlogItem.d9d30eb7.js",
      "_LeegstandNoButton.09c20eb0.js",
      "_BgBigGreen.8b4dfa13.js",
      "_client-only.0a906c49.js",
      "_arrow-right.39a8cb77.js",
      "_asyncData.8c4da2c1.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "_arrow-small-right.6a9de69a.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/werkstek-community/index.vue"
  },
  "index.476fca53.css": {
    "file": "index.476fca53.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "swiper-vue.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "swiper-vue.3061406d.css",
    "src": "swiper-vue.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
