const client_manifest = {
  "BgBigGreen.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "BgBigGreen.f4cc734e.css",
    "src": "BgBigGreen.css"
  },
  "MapInteractive.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "MapInteractive.ffc01d21.css",
    "src": "MapInteractive.css"
  },
  "SliderLocatiesSort.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "SliderLocatiesSort.a9d13604.css",
    "src": "SliderLocatiesSort.css"
  },
  "SliderTestimony.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "SliderTestimony.29a5e60b.css",
    "src": "SliderTestimony.css"
  },
  "TextEditor.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "TextEditor.65389021.css",
    "src": "TextEditor.css"
  },
  "_BackButton.ec42111e.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "BackButton.ec42111e.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_BgBigGreen.4a27a271.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "BgBigGreen.f4cc734e.css"
    ],
    "file": "BgBigGreen.4a27a271.js",
    "imports": [
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_arrow-small-right.ec44ead5.js"
    ]
  },
  "BgBigGreen.f4cc734e.css": {
    "file": "BgBigGreen.f4cc734e.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_Blog.7953d1c8.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Blog.7953d1c8.js",
    "imports": [
      "_TitleHeader.d31ecfbf.js",
      "_EachBlogSmall.3c694df7.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_BlogImageCrop.5a8b5103.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "BlogImageCrop.5a8b5103.js",
    "imports": [
      "_swiper-vue.481cfa94.js",
      "_index.73ae3a71.js",
      "_client-only.0a906c49.js"
    ]
  },
  "_BlogItem.db4595cf.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "BlogItem.db4595cf.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_client-only.0a906c49.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_ButtonAddForm.51f2c614.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ButtonAddForm.51f2c614.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_ButtonAddIndex.787b9cc9.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "ButtonAddIndex.787b9cc9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_EachBlog.1fa18a0a.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "EachBlog.1fa18a0a.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_EachBlogSmall.3c694df7.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "EachBlogSmall.3c694df7.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_client-only.0a906c49.js",
      "_arrow-right.5e39afe9.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_HeaderWCity.e10e4680.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "HeaderWCity.e10e4680.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_LeegstandNoButton.9f51e253.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "LeegstandNoButton.9f51e253.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_MapInteractive.223e9ac2.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "MapInteractive.ffc01d21.css"
    ],
    "file": "MapInteractive.223e9ac2.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useAxios.d38d551c.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_arrow-right.5e39afe9.js",
      "_building-map-interactive.23864f79.js"
    ]
  },
  "MapInteractive.ffc01d21.css": {
    "file": "MapInteractive.ffc01d21.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_MapsTest.739ff50f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "MapsTest.739ff50f.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_NuxtSnackbar.c4ad2b0c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "NuxtSnackbar.c4ad2b0c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_Pagination.840304e6.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Pagination.840304e6.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_SliderLocatiesSort.b1659e9f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "SliderLocatiesSort.a9d13604.css"
    ],
    "file": "SliderLocatiesSort.b1659e9f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_client-only.0a906c49.js"
    ]
  },
  "SliderLocatiesSort.a9d13604.css": {
    "file": "SliderLocatiesSort.a9d13604.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_SliderTestimony.462781e0.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "SliderTestimony.29a5e60b.css"
    ],
    "file": "SliderTestimony.462781e0.js",
    "imports": [
      "_TitleHeader.d31ecfbf.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "SliderTestimony.29a5e60b.css": {
    "file": "SliderTestimony.29a5e60b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TextEditor.2730b79a.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "TextEditor.65389021.css"
    ],
    "file": "TextEditor.2730b79a.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "TextEditor.65389021.css": {
    "file": "TextEditor.65389021.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_TextField.vue.222c6931.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TextField.vue.222c6931.js",
    "imports": [
      "_vee-validate.esm.0085992c.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_TitleHeader.d31ecfbf.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "TitleHeader.d31ecfbf.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_VerhuurdersHeader.c0f26a3f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "VerhuurdersHeader.c0f26a3f.js",
    "imports": [
      "_BgBigGreen.4a27a271.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_Werkstek.0e7197ea.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Werkstek.0e7197ea.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_arrow-right.5e39afe9.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "arrow-right.5e39afe9.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_arrow-small-right.ec44ead5.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "arrow-small-right.ec44ead5.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_asyncData.1a1dea0f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "asyncData.1a1dea0f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_building-map-interactive.23864f79.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "building-map-interactive.23864f79.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_client-only.0a906c49.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "client-only.0a906c49.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_config.12e1ba5c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "config.12e1ba5c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_fetch.1b62684f.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "fetch.1b62684f.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_asyncData.1a1dea0f.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_index.73ae3a71.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.73ae3a71.js",
    "imports": [
      "_index.bc79cc22.js",
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_index.bc79cc22.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.bc79cc22.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_marker-dropdown.24067f69.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "marker-dropdown.24067f69.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_swiper-vue.481cfa94.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "swiper-vue.3061406d.css"
    ],
    "file": "swiper-vue.481cfa94.js"
  },
  "swiper-vue.3061406d.css": {
    "file": "swiper-vue.3061406d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "_useAxios.d38d551c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useAxios.d38d551c.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js"
    ]
  },
  "_useConvertTime.957d2e34.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useConvertTime.957d2e34.js"
  },
  "_useForgotPassword.da3a5afd.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useForgotPassword.da3a5afd.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_useRequestHelper.49566a60.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useRequestHelper.49566a60.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "_useSchema.a1c7f408.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "useSchema.a1c7f408.js"
  },
  "_vee-validate.esm.0085992c.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "vee-validate.esm.0085992c.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ]
  },
  "assets/fonts/Noto/NotoSans-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "NotoSans-Bold.cf382cad.ttf",
    "src": "assets/fonts/Noto/NotoSans-Bold.ttf"
  },
  "assets/fonts/Noto/NotoSans-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "NotoSans-Medium.9d0511ca.ttf",
    "src": "assets/fonts/Noto/NotoSans-Medium.ttf"
  },
  "assets/fonts/Noto/NotoSans-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "NotoSans-Regular.3be6b371.ttf",
    "src": "assets/fonts/Noto/NotoSans-Regular.ttf"
  },
  "assets/fonts/Poppins/Poppins-Bold.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "Poppins-Bold.7219547e.ttf",
    "src": "assets/fonts/Poppins/Poppins-Bold.ttf"
  },
  "assets/fonts/Poppins/Poppins-Medium.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "Poppins-Medium.8d909883.ttf",
    "src": "assets/fonts/Poppins/Poppins-Medium.ttf"
  },
  "assets/fonts/Poppins/Poppins-Regular.ttf": {
    "resourceType": "font",
    "mimeType": "font/ttf",
    "file": "Poppins-Regular.707fdc5c.ttf",
    "src": "assets/fonts/Poppins/Poppins-Regular.ttf"
  },
  "i18n.config.ts?hash=bffaebcb&config=1": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "i18n.config.b03cc2fe.js",
    "isDynamicEntry": true,
    "src": "i18n.config.ts?hash=bffaebcb&config=1"
  },
  "layouts/admin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.4e2f09e1.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useRequestHelper.49566a60.js",
      "_swiper-vue.481cfa94.js",
      "_NuxtSnackbar.c4ad2b0c.js",
      "_index.73ae3a71.js",
      "_config.12e1ba5c.js",
      "_index.bc79cc22.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/admin.vue"
  },
  "layouts/default.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "default.4c48797d.css",
    "src": "layouts/default.css"
  },
  "layouts/default.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "default.3bc32528.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_Werkstek.0e7197ea.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_index.73ae3a71.js",
      "_arrow-small-right.ec44ead5.js",
      "_NuxtSnackbar.c4ad2b0c.js",
      "_fetch.1b62684f.js",
      "_config.12e1ba5c.js",
      "_index.bc79cc22.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "layouts/default.vue"
  },
  "default.4c48797d.css": {
    "file": "default.4c48797d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "middleware/admin.ts": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "admin.8f67e341.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ],
    "isDynamicEntry": true,
    "src": "middleware/admin.ts"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "Icon.6f5d80f8.css",
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.css"
  },
  "node_modules/nuxt-icon/dist/runtime/Icon.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "Icon.54de3bb6.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_config.12e1ba5c.js",
      "_swiper-vue.481cfa94.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/Icon.vue"
  },
  "Icon.6f5d80f8.css": {
    "file": "Icon.6f5d80f8.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "IconCSS.fe0874d9.css",
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.css"
  },
  "node_modules/nuxt-icon/dist/runtime/IconCSS.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "IconCSS.83e2bf9d.js",
    "imports": [
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_config.12e1ba5c.js"
    ],
    "isDynamicEntry": true,
    "src": "node_modules/nuxt-icon/dist/runtime/IconCSS.vue"
  },
  "IconCSS.fe0874d9.css": {
    "file": "IconCSS.fe0874d9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "node_modules/nuxt/dist/app/entry.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "entry.2cc35f7b.css",
    "src": "node_modules/nuxt/dist/app/entry.css"
  },
  "node_modules/nuxt/dist/app/entry.js": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [
      "entry.2cc35f7b.css"
    ],
    "dynamicImports": [
      "middleware/admin.ts",
      "layouts/admin.vue",
      "layouts/default.vue",
      "i18n.config.ts?hash=bffaebcb&config=1"
    ],
    "file": "entry.9d77ff68.js",
    "imports": [
      "_swiper-vue.481cfa94.js"
    ],
    "isEntry": true,
    "src": "node_modules/nuxt/dist/app/entry.js",
    "_globalCSS": true
  },
  "entry.2cc35f7b.css": {
    "file": "entry.2cc35f7b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/Faq.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "Faq.797b2b93.js",
    "imports": [
      "_HeaderWCity.e10e4680.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/Faq.vue"
  },
  "pages/admin/admin-list/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.bb3a72cd.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_TextField.vue.222c6931.js",
      "_vee-validate.esm.0085992c.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/[slug].vue"
  },
  "pages/admin/admin-list/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.fcafef75.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_TextField.vue.222c6931.js",
      "_useForgotPassword.da3a5afd.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/add.vue"
  },
  "pages/admin/admin-list/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.3adddea5.js",
    "imports": [
      "_ButtonAddIndex.787b9cc9.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1a1dea0f.js",
      "_index.bc79cc22.js",
      "_swiper-vue.481cfa94.js",
      "_config.12e1ba5c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/admin-list/index.vue"
  },
  "pages/admin/author/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.ca65d751.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_vee-validate.esm.0085992c.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/author/add.vue"
  },
  "pages/admin/author/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.891ceff6.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/author/edit/[slug].vue"
  },
  "pages/admin/author/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.78ae27b1.css",
    "src": "pages/admin/author/index.css"
  },
  "pages/admin/author/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.0391da44.js",
    "imports": [
      "_ButtonAddIndex.787b9cc9.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1a1dea0f.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.12e1ba5c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/author/index.vue"
  },
  "index.78ae27b1.css": {
    "file": "index.78ae27b1.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/blog-category/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.83a9785f.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog-category/add.vue"
  },
  "pages/admin/blog-category/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.df659d1f.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog-category/edit/[slug].vue"
  },
  "pages/admin/blog-category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.01479b03.js",
    "imports": [
      "_ButtonAddIndex.787b9cc9.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1a1dea0f.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.12e1ba5c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog-category/index.vue"
  },
  "pages/admin/blog/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.c049d2cf.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_TextEditor.2730b79a.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog/add.vue"
  },
  "pages/admin/blog/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.7ba8a724.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_vee-validate.esm.0085992c.js",
      "_TextEditor.2730b79a.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog/edit/[slug].vue"
  },
  "pages/admin/blog/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.3a43e528.css",
    "src": "pages/admin/blog/index.css"
  },
  "pages/admin/blog/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.aa413bfb.js",
    "imports": [
      "_ButtonAddIndex.787b9cc9.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1a1dea0f.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.12e1ba5c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/blog/index.vue"
  },
  "index.3a43e528.css": {
    "file": "index.3a43e528.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/category/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.cf641259.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_vee-validate.esm.0085992c.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/category/add.vue"
  },
  "pages/admin/category/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.fcbc535e.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useSchema.a1c7f408.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_fetch.1b62684f.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/category/edit/[slug].vue"
  },
  "pages/admin/category/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.0aa3d082.css",
    "src": "pages/admin/category/index.css"
  },
  "pages/admin/category/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.3ca1d68e.js",
    "imports": [
      "_ButtonAddIndex.787b9cc9.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/category/index.vue"
  },
  "index.0aa3d082.css": {
    "file": "index.0aa3d082.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/community/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.4b35a653.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_TextEditor.2730b79a.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/community/add.vue"
  },
  "pages/admin/community/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.836cf97d.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_vee-validate.esm.0085992c.js",
      "_TextEditor.2730b79a.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/community/edit/[slug].vue"
  },
  "pages/admin/community/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.2bdd19ad.css",
    "src": "pages/admin/community/index.css"
  },
  "pages/admin/community/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.898a5074.js",
    "imports": [
      "_ButtonAddIndex.787b9cc9.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1a1dea0f.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.12e1ba5c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/community/index.vue"
  },
  "index.2bdd19ad.css": {
    "file": "index.2bdd19ad.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/contact/[slug].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_slug_.7b803f9d.css",
    "src": "pages/admin/contact/[slug].css"
  },
  "pages/admin/contact/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_slug_.df3aec47.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/contact/[slug].vue"
  },
  "_slug_.7b803f9d.css": {
    "file": "_slug_.7b803f9d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/contact/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.80c0b2b9.css",
    "src": "pages/admin/contact/index.css"
  },
  "pages/admin/contact/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.1c53cc18.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1a1dea0f.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.12e1ba5c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/contact/index.vue"
  },
  "index.80c0b2b9.css": {
    "file": "index.80c0b2b9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/dashboard.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "dashboard.336ac65e.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/dashboard.vue"
  },
  "pages/admin/edit-admin.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "edit-admin.1912533d.js",
    "imports": [
      "_Werkstek.0e7197ea.js",
      "_vee-validate.esm.0085992c.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_useSchema.a1c7f408.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/edit-admin.vue"
  },
  "pages/admin/facility/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.4d765c31.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility/add.vue"
  },
  "pages/admin/facility/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.2dbf763b.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility/edit/[slug].vue"
  },
  "pages/admin/facility/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.aba0e47d.css",
    "src": "pages/admin/facility/index.css"
  },
  "pages/admin/facility/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.1b4eb3eb.js",
    "imports": [
      "_ButtonAddIndex.787b9cc9.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1a1dea0f.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.12e1ba5c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/facility/index.vue"
  },
  "index.aba0e47d.css": {
    "file": "index.aba0e47d.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/forgot-password.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "forgot-password.2a1e6a4e.js",
    "imports": [
      "_TextField.vue.222c6931.js",
      "_useForgotPassword.da3a5afd.js",
      "_vee-validate.esm.0085992c.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_index.73ae3a71.js",
      "_asyncData.1a1dea0f.js",
      "_index.bc79cc22.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/forgot-password.vue"
  },
  "pages/admin/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.116e6dc9.css",
    "src": "pages/admin/index.css"
  },
  "pages/admin/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.2edbcea8.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/index.vue"
  },
  "index.116e6dc9.css": {
    "file": "index.116e6dc9.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/level-type/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.5242122f.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_vee-validate.esm.0085992c.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/level-type/add.vue"
  },
  "pages/admin/level-type/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.9d797416.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/level-type/edit/[slug].vue"
  },
  "pages/admin/level-type/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.4454196d.js",
    "imports": [
      "_ButtonAddIndex.787b9cc9.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/level-type/index.vue"
  },
  "pages/admin/location/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.61eb0074.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_TextField.vue.222c6931.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/location/add.vue"
  },
  "pages/admin/location/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.5de9c21e.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_TextField.vue.222c6931.js",
      "_BlogImageCrop.5a8b5103.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/location/edit/[slug].vue"
  },
  "pages/admin/location/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.9e212985.css",
    "src": "pages/admin/location/index.css"
  },
  "pages/admin/location/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.de9bda62.js",
    "imports": [
      "_ButtonAddIndex.787b9cc9.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1a1dea0f.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.12e1ba5c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/location/index.vue"
  },
  "index.9e212985.css": {
    "file": "index.9e212985.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/newsletter/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.ca61fc98.css",
    "src": "pages/admin/newsletter/index.css"
  },
  "pages/admin/newsletter/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.01277564.js",
    "imports": [
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_asyncData.1a1dea0f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/newsletter/index.vue"
  },
  "index.ca61fc98.css": {
    "file": "index.ca61fc98.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/onze-locaties/add-image/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.4bdbecd5.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/add-image/[slug].vue"
  },
  "pages/admin/onze-locaties/add-video/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.d903a5e5.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useAxios.d38d551c.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/add-video/[slug].vue"
  },
  "pages/admin/onze-locaties/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.4d1e7fa5.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_TextField.vue.222c6931.js",
      "_vee-validate.esm.0085992c.js",
      "_TextEditor.2730b79a.js",
      "_MapsTest.739ff50f.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/add.vue"
  },
  "pages/admin/onze-locaties/edit-locaties/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.287d61ad.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_TextField.vue.222c6931.js",
      "_vee-validate.esm.0085992c.js",
      "_TextEditor.2730b79a.js",
      "_MapsTest.739ff50f.js",
      "_ButtonAddForm.51f2c614.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/edit-locaties/[slug].vue"
  },
  "pages/admin/onze-locaties/featured-property/[slug].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_slug_.abd9ceb2.css",
    "src": "pages/admin/onze-locaties/featured-property/[slug].css"
  },
  "pages/admin/onze-locaties/featured-property/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_slug_.22cfe958.js",
    "imports": [
      "_ButtonAddIndex.787b9cc9.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/featured-property/[slug].vue"
  },
  "_slug_.abd9ceb2.css": {
    "file": "_slug_.abd9ceb2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/onze-locaties/featured-property/add-sortlist/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.cc98e6bc.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.1b62684f.js",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/featured-property/add-sortlist/add.vue"
  },
  "pages/admin/onze-locaties/featured-property/add/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.e50b9999.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_ButtonAddIndex.787b9cc9.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.1b62684f.js",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/featured-property/add/index.vue"
  },
  "pages/admin/onze-locaties/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.1a5fb2ed.css",
    "src": "pages/admin/onze-locaties/index.css"
  },
  "pages/admin/onze-locaties/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.b5aee1c4.js",
    "imports": [
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_ButtonAddIndex.787b9cc9.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1a1dea0f.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.12e1ba5c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-locaties/index.vue"
  },
  "index.1a5fb2ed.css": {
    "file": "index.1a5fb2ed.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/onze-vacatures/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.4c917e35.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_useAxios.d38d551c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-vacatures/add.vue"
  },
  "pages/admin/onze-vacatures/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.1b2c1ae1.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_vee-validate.esm.0085992c.js",
      "_BlogImageCrop.5a8b5103.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_useAxios.d38d551c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_asyncData.1a1dea0f.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_index.73ae3a71.js",
      "_index.bc79cc22.js",
      "_client-only.0a906c49.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-vacatures/edit/[slug].vue"
  },
  "pages/admin/onze-vacatures/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.473830ec.css",
    "src": "pages/admin/onze-vacatures/index.css"
  },
  "pages/admin/onze-vacatures/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.62ad2568.js",
    "imports": [
      "_ButtonAddIndex.787b9cc9.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1a1dea0f.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.12e1ba5c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/onze-vacatures/index.vue"
  },
  "index.473830ec.css": {
    "file": "index.473830ec.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/privilages/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.1f19eb74.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/privilages/add.vue"
  },
  "pages/admin/privilages/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.c17ea283.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/privilages/edit/[slug].vue"
  },
  "pages/admin/privilages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.3f8bd339.js",
    "imports": [
      "_ButtonAddIndex.787b9cc9.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/privilages/index.vue"
  },
  "pages/admin/registration.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "registration.56e3c5d1.js",
    "imports": [
      "_Werkstek.0e7197ea.js",
      "_TextField.vue.222c6931.js",
      "_useForgotPassword.da3a5afd.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/registration.vue"
  },
  "pages/admin/sign-in.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "sign-in.09774b46.js",
    "imports": [
      "_Werkstek.0e7197ea.js",
      "_TextField.vue.222c6931.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/sign-in.vue"
  },
  "pages/admin/type-vacatures/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.2abe7bb7.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type-vacatures/add.vue"
  },
  "pages/admin/type-vacatures/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.d124c65e.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type-vacatures/edit/[slug].vue"
  },
  "pages/admin/type-vacatures/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.5fab9ce3.css",
    "src": "pages/admin/type-vacatures/index.css"
  },
  "pages/admin/type-vacatures/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.9a706aaf.js",
    "imports": [
      "_ButtonAddIndex.787b9cc9.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_Pagination.840304e6.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1a1dea0f.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_index.bc79cc22.js",
      "_config.12e1ba5c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type-vacatures/index.vue"
  },
  "index.5fab9ce3.css": {
    "file": "index.5fab9ce3.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/admin/type/add.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "add.bcc925bb.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_useSchema.a1c7f408.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type/add.vue"
  },
  "pages/admin/type/edit/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.f5535948.js",
    "imports": [
      "_BackButton.ec42111e.js",
      "_TextField.vue.222c6931.js",
      "_ButtonAddForm.51f2c614.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_useSchema.a1c7f408.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type/edit/[slug].vue"
  },
  "pages/admin/type/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "index.50e0a9aa.js",
    "imports": [
      "_ButtonAddIndex.787b9cc9.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/type/index.vue"
  },
  "pages/admin/verified-email/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.aa00d9a6.js",
    "imports": [
      "_useRequestHelper.49566a60.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/admin/verified-email/[slug].vue"
  },
  "pages/blog/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.396fb811.js",
    "imports": [
      "_EachBlog.1fa18a0a.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/blog/[slug].vue"
  },
  "pages/blog/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.fd1b55a2.css",
    "src": "pages/blog/index.css"
  },
  "pages/blog/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.d7af1cf9.js",
    "imports": [
      "_HeaderWCity.e10e4680.js",
      "_Blog.7953d1c8.js",
      "_BlogItem.db4595cf.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_asyncData.1a1dea0f.js",
      "_swiper-vue.481cfa94.js",
      "_BgBigGreen.4a27a271.js",
      "_TitleHeader.d31ecfbf.js",
      "_EachBlogSmall.3c694df7.js",
      "_client-only.0a906c49.js",
      "_arrow-right.5e39afe9.js",
      "_fetch.1b62684f.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "_arrow-small-right.ec44ead5.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/blog/index.vue"
  },
  "index.fd1b55a2.css": {
    "file": "index.fd1b55a2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/contact.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "contact.bee9386c.js",
    "imports": [
      "_building-map-interactive.23864f79.js",
      "_BgBigGreen.4a27a271.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_vee-validate.esm.0085992c.js",
      "_useSchema.a1c7f408.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.1b62684f.js",
      "_MapInteractive.223e9ac2.js",
      "_arrow-small-right.ec44ead5.js",
      "_asyncData.1a1dea0f.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_useAxios.d38d551c.js",
      "_arrow-right.5e39afe9.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/contact.vue"
  },
  "pages/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.39dd8f95.css",
    "src": "pages/index.css"
  },
  "pages/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.af9ffd65.js",
    "imports": [
      "_building-map-interactive.23864f79.js",
      "_BgBigGreen.4a27a271.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_useRequestHelper.49566a60.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_useAxios.d38d551c.js",
      "_SliderLocatiesSort.b1659e9f.js",
      "_SliderTestimony.462781e0.js",
      "_arrow-right.5e39afe9.js",
      "_TitleHeader.d31ecfbf.js",
      "_Blog.7953d1c8.js",
      "_vee-validate.esm.0085992c.js",
      "_arrow-small-right.ec44ead5.js",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js",
      "_client-only.0a906c49.js",
      "_EachBlogSmall.3c694df7.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/index.vue"
  },
  "index.39dd8f95.css": {
    "file": "index.39dd8f95.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/onze-locaties/[slug].css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "_slug_.ebc7e03b.css",
    "src": "pages/onze-locaties/[slug].css"
  },
  "pages/onze-locaties/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "_slug_.7c6b01ab.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_fetch.1b62684f.js",
      "_SliderLocatiesSort.b1659e9f.js",
      "_SliderTestimony.462781e0.js",
      "_config.12e1ba5c.js",
      "_asyncData.1a1dea0f.js",
      "_client-only.0a906c49.js",
      "_TitleHeader.d31ecfbf.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/onze-locaties/[slug].vue"
  },
  "_slug_.ebc7e03b.css": {
    "file": "_slug_.ebc7e03b.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/onze-locaties/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.93902da2.css",
    "src": "pages/onze-locaties/index.css"
  },
  "pages/onze-locaties/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.00966195.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_TitleHeader.d31ecfbf.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_arrow-right.5e39afe9.js",
      "_Pagination.840304e6.js",
      "_asyncData.1a1dea0f.js",
      "_marker-dropdown.24067f69.js",
      "_index.bc79cc22.js",
      "_BgBigGreen.4a27a271.js",
      "_config.12e1ba5c.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.1b62684f.js",
      "_arrow-small-right.ec44ead5.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/onze-locaties/index.vue"
  },
  "index.93902da2.css": {
    "file": "index.93902da2.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/onze-vacatures/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.07ed1bb8.js",
    "imports": [
      "_HeaderWCity.e10e4680.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_useConvertTime.957d2e34.js",
      "_swiper-vue.481cfa94.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/onze-vacatures/[slug].vue"
  },
  "pages/onze-vacatures/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.881b2779.css",
    "src": "pages/onze-vacatures/index.css"
  },
  "pages/onze-vacatures/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.7698c4cd.js",
    "imports": [
      "_HeaderWCity.e10e4680.js",
      "_TitleHeader.d31ecfbf.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "node_modules/nuxt/dist/app/entry.js",
      "_useConvertTime.957d2e34.js",
      "_arrow-right.5e39afe9.js",
      "_swiper-vue.481cfa94.js",
      "_Pagination.840304e6.js",
      "_asyncData.1a1dea0f.js",
      "_marker-dropdown.24067f69.js",
      "_index.bc79cc22.js",
      "_config.12e1ba5c.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/onze-vacatures/index.vue"
  },
  "index.881b2779.css": {
    "file": "index.881b2779.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "pages/over-werkstek.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "over-werkstek.df5402b5.js",
    "imports": [
      "_VerhuurdersHeader.c0f26a3f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_LeegstandNoButton.9f51e253.js",
      "_BgBigGreen.4a27a271.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.1b62684f.js",
      "_asyncData.1a1dea0f.js",
      "_arrow-small-right.ec44ead5.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/over-werkstek.vue"
  },
  "pages/privacy-verklaring.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "privacy-verklaring.b6856af4.js",
    "imports": [
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/privacy-verklaring.vue"
  },
  "pages/voor-verhuurders.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "voor-verhuurders.3b3cc649.js",
    "imports": [
      "_VerhuurdersHeader.c0f26a3f.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_swiper-vue.481cfa94.js",
      "_building-map-interactive.23864f79.js",
      "_BgBigGreen.4a27a271.js",
      "_LeegstandNoButton.9f51e253.js",
      "_MapInteractive.223e9ac2.js",
      "_SliderTestimony.462781e0.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "_fetch.1b62684f.js",
      "_asyncData.1a1dea0f.js",
      "_arrow-small-right.ec44ead5.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_useAxios.d38d551c.js",
      "_arrow-right.5e39afe9.js",
      "_TitleHeader.d31ecfbf.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/voor-verhuurders.vue"
  },
  "pages/werkstek-community/[slug].vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "file": "_slug_.11310873.js",
    "imports": [
      "_EachBlog.1fa18a0a.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "node_modules/nuxt-icon/dist/runtime/Icon.vue",
      "_config.12e1ba5c.js",
      "_useRequestHelper.49566a60.js",
      "_asyncData.1a1dea0f.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/werkstek-community/[slug].vue"
  },
  "pages/werkstek-community/index.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "index.476fca53.css",
    "src": "pages/werkstek-community/index.css"
  },
  "pages/werkstek-community/index.vue": {
    "resourceType": "script",
    "module": true,
    "prefetch": true,
    "preload": true,
    "css": [],
    "file": "index.71ddf141.js",
    "imports": [
      "_HeaderWCity.e10e4680.js",
      "_TitleHeader.d31ecfbf.js",
      "_EachBlogSmall.3c694df7.js",
      "node_modules/nuxt/dist/app/entry.js",
      "_fetch.1b62684f.js",
      "_swiper-vue.481cfa94.js",
      "_BlogItem.db4595cf.js",
      "_LeegstandNoButton.9f51e253.js",
      "_BgBigGreen.4a27a271.js",
      "_client-only.0a906c49.js",
      "_arrow-right.5e39afe9.js",
      "_asyncData.1a1dea0f.js",
      "_vee-validate.esm.0085992c.js",
      "_useRequestHelper.49566a60.js",
      "_arrow-small-right.ec44ead5.js"
    ],
    "isDynamicEntry": true,
    "src": "pages/werkstek-community/index.vue"
  },
  "index.476fca53.css": {
    "file": "index.476fca53.css",
    "resourceType": "style",
    "prefetch": true,
    "preload": true
  },
  "swiper-vue.css": {
    "resourceType": "style",
    "prefetch": true,
    "preload": true,
    "file": "swiper-vue.3061406d.css",
    "src": "swiper-vue.css"
  }
};

export { client_manifest as default };
//# sourceMappingURL=client.manifest.mjs.map
