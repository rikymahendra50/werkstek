const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles.b15f7fa1.mjs').then(interopDefault),
  "pages/admin/author/index.vue": () => import('./_nuxt/index-styles.8f985fc3.mjs').then(interopDefault),
  "pages/admin/blog/index.vue": () => import('./_nuxt/index-styles.7dcf3c9d.mjs').then(interopDefault),
  "pages/admin/category/index.vue": () => import('./_nuxt/index-styles.49ee37e5.mjs').then(interopDefault),
  "pages/admin/community/index.vue": () => import('./_nuxt/index-styles.7ff92c3d.mjs').then(interopDefault),
  "pages/admin/contact/[slug].vue": () => import('./_nuxt/_slug_-styles.56c2c459.mjs').then(interopDefault),
  "pages/admin/contact/index.vue": () => import('./_nuxt/index-styles.550c2b25.mjs').then(interopDefault),
  "pages/admin/facility/index.vue": () => import('./_nuxt/index-styles.e8e80d75.mjs').then(interopDefault),
  "pages/admin/location/index.vue": () => import('./_nuxt/index-styles.a7f7fdee.mjs').then(interopDefault),
  "pages/admin/newsletter/index.vue": () => import('./_nuxt/index-styles.d2c8dd1e.mjs').then(interopDefault),
  "pages/admin/onze-locaties/featured-property/[slug].vue": () => import('./_nuxt/_slug_-styles.d325f4ea.mjs').then(interopDefault),
  "pages/admin/onze-locaties/index.vue": () => import('./_nuxt/index-styles.8aa980f8.mjs').then(interopDefault),
  "pages/admin/index.vue": () => import('./_nuxt/index-styles.070aa100.mjs').then(interopDefault),
  "pages/admin/onze-vacatures/index.vue": () => import('./_nuxt/index-styles.6ed99cd4.mjs').then(interopDefault),
  "pages/admin/type-vacatures/index.vue": () => import('./_nuxt/index-styles.68a67473.mjs').then(interopDefault),
  "pages/blog/index.vue": () => import('./_nuxt/index-styles.0aa8c94d.mjs').then(interopDefault),
  "pages/index.vue": () => import('./_nuxt/index-styles.ddcc463b.mjs').then(interopDefault),
  "pages/onze-locaties/[slug].vue": () => import('./_nuxt/_slug_-styles.65d0c1dc.mjs').then(interopDefault),
  "pages/onze-locaties/index.vue": () => import('./_nuxt/index-styles.6e362b39.mjs').then(interopDefault),
  "pages/onze-vacatures/index.vue": () => import('./_nuxt/index-styles.1c867c20.mjs').then(interopDefault),
  "pages/werkstek-community/index.vue": () => import('./_nuxt/index-styles.b179fdf8.mjs').then(interopDefault),
  "node_modules/nuxt-icon/dist/runtime/IconCSS.vue": () => import('./_nuxt/IconCSS-styles.9ba8332f.mjs').then(interopDefault),
  "node_modules/nuxt-icon/dist/runtime/Icon.vue": () => import('./_nuxt/Icon-styles.3c97f940.mjs').then(interopDefault),
  "layouts/default.vue": () => import('./_nuxt/default-styles.377e3a9f.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
