const interopDefault = r => r.default || r || [];
const styles = {
  "node_modules/nuxt/dist/app/entry.js": () => import('./_nuxt/entry-styles.882a7345.mjs').then(interopDefault),
  "pages/admin/author/index.vue": () => import('./_nuxt/index-styles.6a90df64.mjs').then(interopDefault),
  "pages/admin/blog/index.vue": () => import('./_nuxt/index-styles.1d44ed60.mjs').then(interopDefault),
  "pages/admin/category/index.vue": () => import('./_nuxt/index-styles.49ee37e5.mjs').then(interopDefault),
  "pages/admin/community/index.vue": () => import('./_nuxt/index-styles.e15df5d2.mjs').then(interopDefault),
  "pages/admin/contact/[slug].vue": () => import('./_nuxt/_slug_-styles.56c2c459.mjs').then(interopDefault),
  "pages/admin/contact/index.vue": () => import('./_nuxt/index-styles.fac9ca39.mjs').then(interopDefault),
  "pages/admin/facility/index.vue": () => import('./_nuxt/index-styles.c8f3ee9e.mjs').then(interopDefault),
  "pages/admin/location/index.vue": () => import('./_nuxt/index-styles.c01c9980.mjs').then(interopDefault),
  "pages/admin/newsletter/index.vue": () => import('./_nuxt/index-styles.d2d5a27f.mjs').then(interopDefault),
  "pages/admin/onze-locaties/featured-property/[slug].vue": () => import('./_nuxt/_slug_-styles.67215314.mjs').then(interopDefault),
  "pages/admin/index.vue": () => import('./_nuxt/index-styles.3507c58f.mjs').then(interopDefault),
  "pages/admin/onze-locaties/index.vue": () => import('./_nuxt/index-styles.8aa980f8.mjs').then(interopDefault),
  "pages/admin/onze-vacatures/index.vue": () => import('./_nuxt/index-styles.70e0fc72.mjs').then(interopDefault),
  "pages/admin/type-vacatures/index.vue": () => import('./_nuxt/index-styles.7cc5fd88.mjs').then(interopDefault),
  "pages/blog/index.vue": () => import('./_nuxt/index-styles.0aa8c94d.mjs').then(interopDefault),
  "pages/index.vue": () => import('./_nuxt/index-styles.ddcc463b.mjs').then(interopDefault),
  "pages/onze-locaties/index.vue": () => import('./_nuxt/index-styles.5b233b02.mjs').then(interopDefault),
  "pages/onze-locaties/[slug].vue": () => import('./_nuxt/_slug_-styles.65d0c1dc.mjs').then(interopDefault),
  "pages/onze-vacatures/index.vue": () => import('./_nuxt/index-styles.69e5bde0.mjs').then(interopDefault),
  "pages/werkstek-community/index.vue": () => import('./_nuxt/index-styles.b179fdf8.mjs').then(interopDefault),
  "node_modules/nuxt-icon/dist/runtime/IconCSS.vue": () => import('./_nuxt/IconCSS-styles.9ba8332f.mjs').then(interopDefault),
  "node_modules/nuxt-icon/dist/runtime/Icon.vue": () => import('./_nuxt/Icon-styles.3c97f940.mjs').then(interopDefault),
  "layouts/default.vue": () => import('./_nuxt/default-styles.377e3a9f.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
