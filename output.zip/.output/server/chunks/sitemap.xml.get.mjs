import { a as defineEventHandler, u as useRuntimeConfig, s as setHeader } from './nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';

const sitemap_xml_get = defineEventHandler(async (event) => {
  const config = useRuntimeConfig(event);
  config.public.PUBLIC_URL;
  const routes = [
    "/",
    "/faq",
    "/index",
    "/contact",
    "/blog",
    "/onze-locaties",
    "/onze-vacatures",
    "/werkstek-community",
    "/privacy-verklaring",
    "/voor-verhuurders",
    "/over-werkstek"
  ];
  const timestamp = (/* @__PURE__ */ new Date()).toISOString();
  const sitemap = [
    '<?xml version="1.0" encoding="UTF-8"?>',
    '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">',
    ...routes.map(
      (route) => [
        "<url>",
        `  <loc>${"https://werkstek.nl" + route}</loc>`,
        `  <lastmod>${timestamp}</lastmod>`,
        "</url>"
      ].join("")
    ),
    "</urlset>"
  ].join("");
  setHeader(event, "content-type", "application/xml");
  return sitemap;
});

export { sitemap_xml_get as default };
//# sourceMappingURL=sitemap.xml.get.mjs.map
