globalThis._importMeta_={url:import.meta.url,env:process.env};export { L as default } from './chunks/nitro/node-server.mjs';
import 'node:http';
import 'node:https';
import 'node:zlib';
import 'node:stream';
import 'node:buffer';
import 'node:util';
import 'node:url';
import 'node:net';
import 'node:fs';
import 'node:path';
import 'fs';
import 'path';
import 'ipx';
//# sourceMappingURL=index.mjs.map
